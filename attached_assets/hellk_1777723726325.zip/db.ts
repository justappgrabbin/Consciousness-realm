import { eq, and, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  resonanceNodes, InsertResonanceNode, ResonanceNode,
  resonancePatterns, InsertResonancePattern,
  questProgress, InsertQuestProgress, QuestProgress,
  economicMilestones, InsertEconomicMilestone,
  companionMessages, InsertCompanionMessage,
  networkConnections, InsertNetworkConnection,
  networkMetrics, InsertNetworkMetric
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============================================================================
// USER OPERATIONS
// ============================================================================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============================================================================
// RESONANCE NODE OPERATIONS
// ============================================================================

export async function createResonanceNode(node: InsertResonanceNode): Promise<ResonanceNode | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    await db.insert(resonanceNodes).values(node);
    const result = await db.select().from(resonanceNodes)
      .where(eq(resonanceNodes.graphAddress, node.graphAddress))
      .limit(1);
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to create resonance node:", error);
    throw error;
  }
}

export async function getResonanceNodeByUserId(userId: number): Promise<ResonanceNode | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(resonanceNodes)
    .where(eq(resonanceNodes.userId, userId))
    .limit(1);
  return result[0] || null;
}

export async function getResonanceNodeByAddress(graphAddress: string): Promise<ResonanceNode | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(resonanceNodes)
    .where(eq(resonanceNodes.graphAddress, graphAddress))
    .limit(1);
  return result[0] || null;
}

export async function updateResonanceNode(
  graphAddress: string, 
  updates: Partial<InsertResonanceNode>
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.update(resonanceNodes)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(resonanceNodes.graphAddress, graphAddress));
}

export async function getAllActiveNodes(): Promise<ResonanceNode[]> {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(resonanceNodes)
    .where(eq(resonanceNodes.isActive, true));
}

// ============================================================================
// RESONANCE PATTERN OPERATIONS
// ============================================================================

export async function createResonancePattern(pattern: InsertResonancePattern): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(resonancePatterns).values(pattern);
}

export async function getRecentPatterns(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(resonancePatterns)
    .orderBy(desc(resonancePatterns.createdAt))
    .limit(limit);
}

export async function getPatternsByType(patternType: string) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(resonancePatterns)
    .where(eq(resonancePatterns.patternType, patternType as any))
    .orderBy(desc(resonancePatterns.createdAt));
}

// ============================================================================
// QUEST PROGRESS OPERATIONS
// ============================================================================

export async function getOrCreateQuestProgress(userId: number, nodeAddress: string): Promise<QuestProgress | null> {
  const db = await getDb();
  if (!db) return null;

  let result = await db.select().from(questProgress)
    .where(eq(questProgress.userId, userId))
    .limit(1);

  if (result.length === 0) {
    await db.insert(questProgress).values({
      userId,
      nodeAddress,
      currentStage: "intention"
    });
    result = await db.select().from(questProgress)
      .where(eq(questProgress.userId, userId))
      .limit(1);
  }

  return result[0] || null;
}

export async function updateQuestProgress(
  userId: number, 
  updates: Partial<InsertQuestProgress>
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.update(questProgress)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(questProgress.userId, userId));
}

// ============================================================================
// ECONOMIC MILESTONE OPERATIONS
// ============================================================================

export async function createEconomicMilestone(milestone: InsertEconomicMilestone): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(economicMilestones).values(milestone);
}

export async function getUserMilestones(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(economicMilestones)
    .where(eq(economicMilestones.userId, userId))
    .orderBy(desc(economicMilestones.createdAt));
}

export async function getUnnotifiedMilestones() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(economicMilestones)
    .where(eq(economicMilestones.ownerNotified, false));
}

export async function markMilestoneNotified(milestoneId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.update(economicMilestones)
    .set({ ownerNotified: true, notifiedAt: new Date() })
    .where(eq(economicMilestones.id, milestoneId));
}

// ============================================================================
// COMPANION MESSAGE OPERATIONS
// ============================================================================

export async function createCompanionMessage(message: InsertCompanionMessage): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(companionMessages).values(message);
}

export async function getUserMessages(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(companionMessages)
    .where(eq(companionMessages.userId, userId))
    .orderBy(desc(companionMessages.createdAt))
    .limit(limit);
}

// ============================================================================
// NETWORK CONNECTION OPERATIONS
// ============================================================================

export async function createNetworkConnection(connection: InsertNetworkConnection): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.insert(networkConnections).values(connection);
}

export async function getNodeConnections(nodeAddress: string) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(networkConnections)
    .where(
      and(
        eq(networkConnections.isActive, true),
        sql`(${networkConnections.nodeAddressA} = ${nodeAddress} OR ${networkConnections.nodeAddressB} = ${nodeAddress})`
      )
    );
}

export async function getAllConnections() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(networkConnections)
    .where(eq(networkConnections.isActive, true));
}

// ============================================================================
// NETWORK METRICS OPERATIONS
// ============================================================================

export async function createNetworkMetricSnapshot(): Promise<void> {
  const db = await getDb();
  if (!db) return;

  // Calculate current metrics
  const nodes = await getAllActiveNodes();
  const connections = await getAllConnections();
  const milestones = await db.select().from(economicMilestones);

  const totalNodes = nodes.length;
  const activeNodes = nodes.filter(n => n.lastResonance && 
    new Date(n.lastResonance).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000
  ).length;
  
  const avgCoherence = nodes.length > 0 
    ? nodes.reduce((sum, n) => sum + (n.coherenceScore || 50), 0) / nodes.length 
    : 50;

  const networkResonance = nodes.reduce((sum, n) => sum + (n.resonanceStrength || 0), 0);

  await db.insert(networkMetrics).values({
    totalNodes,
    activeNodes,
    totalConnections: connections.length,
    averageCoherence: avgCoherence,
    networkResonance,
    collectiveIntelligenceScore: (avgCoherence * networkResonance) / 100,
    totalMilestones: milestones.length,
    successRate: totalNodes > 0 ? (milestones.length / totalNodes) * 100 : 0
  });
}

export async function getLatestNetworkMetrics() {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(networkMetrics)
    .orderBy(desc(networkMetrics.snapshotAt))
    .limit(1);
  return result[0] || null;
}

export async function getNetworkMetricsHistory(days: number = 30) {
  const db = await getDb();
  if (!db) return [];

  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  return await db.select().from(networkMetrics)
    .where(sql`${networkMetrics.snapshotAt} >= ${cutoff}`)
    .orderBy(desc(networkMetrics.snapshotAt));
}
