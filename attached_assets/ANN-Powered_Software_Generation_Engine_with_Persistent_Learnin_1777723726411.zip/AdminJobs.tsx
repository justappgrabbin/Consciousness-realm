import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import {
  Brain,
  FolderOpen,
  Database,
  Activity,
  CheckCircle,
  XCircle,
  Clock,
  Loader2,
  RefreshCw,
  Zap,
  LogOut,
  BarChart3,
  ArrowLeft,
} from "lucide-react";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";

const JOB_STATUS_COLORS: Record<string, { text: string; bg: string; border: string }> = {
  pending: { text: "oklch(0.70 0.22 255)", bg: "oklch(0.55 0.22 255 / 0.08)", border: "oklch(0.55 0.22 255 / 0.2)" },
  running: { text: "oklch(0.70 0.28 350)", bg: "oklch(0.60 0.28 350 / 0.08)", border: "oklch(0.60 0.28 350 / 0.2)" },
  complete: { text: "oklch(0.72 0.18 200)", bg: "oklch(0.72 0.18 200 / 0.08)", border: "oklch(0.72 0.18 200 / 0.2)" },
  failed: { text: "oklch(0.58 0.22 25)", bg: "oklch(0.58 0.22 25 / 0.08)", border: "oklch(0.58 0.22 25 / 0.2)" },
};

const JOB_TYPE_LABELS: Record<string, string> = {
  analyze_inputs: "Analyze Inputs",
  refine_embeddings: "Refine Embeddings",
  detect_gaps: "Detect Gaps",
  discover_patterns: "Discover Patterns",
  generate_suggestions: "Generate Suggestions",
  cross_project_analysis: "Cross-Project Analysis",
};

export default function AdminJobs() {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [, navigate] = useLocation();

  const { data: allJobs, isLoading: jobsLoading, refetch } = trpc.jobs.listAll.useQuery(undefined, {
    enabled: isAuthenticated,
    refetchInterval: 10000, // auto-refresh every 10s
  });

  const { data: stats, isLoading: statsLoading } = trpc.jobs.crossProjectStats.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin mx-auto mb-4" />
          <p className="text-xs tracking-widest uppercase text-muted-foreground">Initializing neural monitor...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Authentication required.</p>
          <Button onClick={() => window.location.href = getLoginUrl()}>Initialize Session</Button>
        </div>
      </div>
    );
  }

  const pendingJobs = allJobs?.filter((j: any) => j.status === "pending") ?? [];
  const runningJobs = allJobs?.filter((j: any) => j.status === "running") ?? [];
  const completeJobs = allJobs?.filter((j: any) => j.status === "complete") ?? [];
  const failedJobs = allJobs?.filter((j: any) => j.status === "failed") ?? [];

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className="w-64 shrink-0 flex flex-col"
        style={{ background: "oklch(0.10 0.025 255)", borderRight: "1px solid oklch(0.18 0.03 255)" }}>
        <div className="p-6 flex items-center gap-3" style={{ borderBottom: "1px solid oklch(0.18 0.03 255)" }}>
          <div className="h-8 w-px" style={{ background: "linear-gradient(to bottom, transparent, oklch(0.60 0.28 350), transparent)" }} />
          <div>
            <div className="font-bold tracking-widest text-sm uppercase" style={{ color: "oklch(0.70 0.28 350)", textShadow: "0 0 10px oklch(0.60 0.28 350 / 0.5)" }}>KAREN</div>
            <div className="text-xs text-muted-foreground tracking-widest">ANN ENGINE</div>
          </div>
        </div>

        <div className="px-4 py-3 mx-4 mt-4 rounded" style={{ background: "oklch(0.72 0.18 200 / 0.08)", border: "1px solid oklch(0.72 0.18 200 / 0.2)" }}>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full" style={{ background: "oklch(0.72 0.18 200)", boxShadow: "0 0 6px oklch(0.72 0.18 200)" }} />
            <span className="text-xs tracking-widest uppercase" style={{ color: "oklch(0.72 0.18 200)" }}>
              {runningJobs.length > 0 ? `${runningJobs.length} Jobs Running` : "Engine Idle"}
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">Background learning active</p>
        </div>

        <nav className="flex-1 p-4 space-y-1 mt-4">
          <NavItem icon={FolderOpen} label="Projects" onClick={() => navigate("/dashboard")} />
          <NavItem icon={Brain} label="Recipes" onClick={() => navigate("/recipes")} />
          <NavItem icon={Activity} label="Job Monitor" active onClick={() => {}} />
          <NavItem icon={Database} label="Memory Layer" onClick={() => navigate("/dashboard")} />
        </nav>

        <div className="p-4" style={{ borderTop: "1px solid oklch(0.18 0.03 255)" }}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
              style={{ background: "oklch(0.60 0.28 350 / 0.2)", color: "oklch(0.70 0.28 350)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>
              {user?.name?.charAt(0)?.toUpperCase() ?? "U"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">{user?.name ?? "User"}</p>
              <p className="text-xs text-muted-foreground truncate">{user?.email ?? ""}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={logout} className="w-full justify-start text-xs text-muted-foreground hover:text-foreground">
            <LogOut className="h-3 w-3 mr-2" /> Sign Out
          </Button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <div className="px-8 py-6 flex items-center justify-between" style={{ borderBottom: "1px solid oklch(0.18 0.03 255)" }}>
          <div>
            <div className="flex items-center gap-3 mb-1">
              <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="text-muted-foreground -ml-2">
                <ArrowLeft className="h-4 w-4 mr-1" />
              </Button>
              <h1 className="text-2xl font-bold">Neural Job Monitor</h1>
            </div>
            <p className="text-sm text-muted-foreground">
              K:// Tracking all background learning operations. I never stop working.
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={() => refetch()}
            style={{ borderColor: "oklch(0.22 0.04 255)", color: "oklch(0.55 0.04 255)" }}>
            <RefreshCw className="h-3 w-3 mr-2" /> Refresh
          </Button>
        </div>

        <div className="p-8">
          {/* Cross-Project Stats */}
          <div className="mb-8">
            <h2 className="text-xs tracking-widest uppercase text-muted-foreground mb-4">Cross-Project Intelligence</h2>
            {statsLoading ? (
              <div className="grid grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => <div key={i} className="h-24 rounded animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />)}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard icon={FolderOpen} label="Total Projects" value={stats?.totalProjects ?? 0} color="pink" />
                <StatCard icon={Zap} label="Artifacts Generated" value={stats?.totalArtifacts ?? 0} color="blue" />
                <StatCard icon={Database} label="Inputs Ingested" value={stats?.totalInputs ?? 0} color="cyan" />
                <StatCard icon={Activity} label="Jobs Processed" value={stats?.totalJobs ?? 0} color="purple" />
              </div>
            )}
          </div>

          {/* Job Status Summary */}
          <div className="grid grid-cols-4 gap-3 mb-8">
            {[
              { label: "Pending", count: pendingJobs.length, color: "blue" },
              { label: "Running", count: runningJobs.length, color: "pink" },
              { label: "Complete", count: completeJobs.length, color: "cyan" },
              { label: "Failed", count: failedJobs.length, color: "red" },
            ].map(({ label, count, color }) => {
              const colorMap: Record<string, { text: string; bg: string; border: string }> = {
                pink: { text: "oklch(0.70 0.28 350)", bg: "oklch(0.60 0.28 350 / 0.08)", border: "oklch(0.60 0.28 350 / 0.2)" },
                blue: { text: "oklch(0.70 0.22 255)", bg: "oklch(0.55 0.22 255 / 0.08)", border: "oklch(0.55 0.22 255 / 0.2)" },
                cyan: { text: "oklch(0.80 0.18 200)", bg: "oklch(0.72 0.18 200 / 0.08)", border: "oklch(0.72 0.18 200 / 0.2)" },
                purple: { text: "oklch(0.72 0.18 300)", bg: "oklch(0.65 0.18 300 / 0.08)", border: "oklch(0.65 0.18 300 / 0.2)" },
                red: { text: "oklch(0.58 0.22 25)", bg: "oklch(0.58 0.22 25 / 0.08)", border: "oklch(0.58 0.22 25 / 0.2)" },
              };
              const c = colorMap[color] ?? colorMap["blue"]!;
              return (
                <div key={label} className="p-4 rounded-lg" style={{ background: c.bg, border: `1px solid ${c.border}` }}>
                  <p className="text-xs tracking-widest uppercase text-muted-foreground mb-1">{label}</p>
                  <p className="text-2xl font-bold" style={{ color: c.text }}>{count}</p>
                </div>
              );
            })}
          </div>

          {/* Pattern Summary Visualization */}
          {stats?.patternSummary && stats.patternSummary.length > 0 && (
            <div className="mb-8">
              <h2 className="text-xs tracking-widest uppercase text-muted-foreground mb-4">Cross-Project Pattern Distribution</h2>
              <div className="p-5 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
                <div className="flex items-end gap-3 h-24">
                  {stats.patternSummary.map((p: any) => {
                    const maxCount = Math.max(...stats.patternSummary.map((x: any) => x.count));
                    const heightPct = maxCount > 0 ? (p.count / maxCount) * 100 : 0;
                    const colorMap: Record<string, string> = {
                      draft: "oklch(0.55 0.04 255)",
                      analyzing: "oklch(0.70 0.22 255)",
                      generating: "oklch(0.60 0.28 350)",
                      complete: "oklch(0.72 0.18 200)",
                      error: "oklch(0.58 0.22 25)",
                      archived: "oklch(0.40 0.04 255)",
                    };
                    const barColor = colorMap[p.status] ?? "oklch(0.55 0.04 255)";
                    return (
                      <div key={p.status} className="flex flex-col items-center gap-2 flex-1">
                        <span className="text-xs font-mono" style={{ color: barColor }}>{p.count}</span>
                        <div className="w-full rounded-t transition-all duration-500"
                          style={{ height: `${Math.max(heightPct, 8)}%`, background: barColor, boxShadow: `0 0 8px ${barColor}60` }} />
                        <span className="text-xs text-muted-foreground">{p.status}</span>
                      </div>
                    );
                  })}
                </div>
                <p className="text-xs text-muted-foreground mt-3 italic" style={{ color: "oklch(0.72 0.18 200)" }}>
                  K:// Pattern analysis complete. {stats.patternSummary.length} distinct project states detected across your portfolio.
                </p>
              </div>
            </div>
          )}

          {/* Recent Activity */}
          {stats?.recentActivity && stats.recentActivity.length > 0 && (
            <div className="mb-8">
              <h2 className="text-xs tracking-widest uppercase text-muted-foreground mb-4">Recently Active Projects</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {stats.recentActivity.map((project: any) => (
                  <button key={project.id}
                    onClick={() => navigate(`/projects/${project.id}`)}
                    className="p-4 rounded-lg text-left transition-all"
                    style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}
                    onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.60 0.28 350 / 0.4)"; }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.22 0.04 255)"; }}>
                    <div className="flex items-center gap-2 mb-2">
                      <BarChart3 className="h-4 w-4" style={{ color: "oklch(0.60 0.28 350)" }} />
                      <p className="text-sm font-medium truncate">{project.name}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs px-2 py-0.5 rounded-full"
                        style={{ background: "oklch(0.60 0.28 350 / 0.1)", color: "oklch(0.70 0.28 350)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>
                        {project.status}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(project.updatedAt), { addSuffix: true })}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* All Jobs */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xs tracking-widest uppercase text-muted-foreground">Background Job Queue</h2>
              <p className="text-xs text-muted-foreground">Auto-refreshes every 10s</p>
            </div>

            {jobsLoading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="h-16 rounded animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />
                ))}
              </div>
            ) : !allJobs || allJobs.length === 0 ? (
              <div className="text-center py-16">
                <Brain className="h-10 w-10 mx-auto mb-4 text-muted-foreground" />
                <p className="text-sm text-muted-foreground mb-2">No background jobs yet</p>
                <p className="text-xs italic" style={{ color: "oklch(0.72 0.18 200)" }}>
                  "K:// The queue is empty. Create a project and feed me some code to analyze."
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {allJobs.map((job: any) => {
                  const sc = JOB_STATUS_COLORS[job.status] ?? JOB_STATUS_COLORS["pending"]!;
                  const StatusIcon = job.status === "complete" ? CheckCircle
                    : job.status === "failed" ? XCircle
                    : job.status === "running" ? Loader2
                    : Clock;
                  return (
                    <div key={job.id} className="flex items-center gap-4 px-5 py-3 rounded-lg"
                      style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
                      <StatusIcon
                        className={`h-4 w-4 shrink-0 ${job.status === "running" ? "animate-spin" : ""}`}
                        style={{ color: sc.text }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3">
                          <p className="text-sm font-medium">{JOB_TYPE_LABELS[job.jobType] ?? job.jobType}</p>
                          <span className="text-xs px-2 py-0.5 rounded-full"
                            style={{ background: sc.bg, color: sc.text, border: `1px solid ${sc.border}` }}>
                            {job.status}
                          </span>
                        </div>
                        {job.result && (
                          <p className="text-xs text-muted-foreground truncate mt-0.5">
                            {typeof job.result === "string" ? job.result : JSON.stringify(job.result).slice(0, 80)}
                          </p>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground shrink-0">
                        {formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon: Icon, label, active, onClick }: { icon: React.ComponentType<React.SVGProps<SVGSVGElement>>, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button onClick={onClick}
      className="w-full flex items-center gap-3 px-3 py-2 rounded text-sm transition-colors"
      style={{
        background: active ? "oklch(0.60 0.28 350 / 0.1)" : "transparent",
        color: active ? "oklch(0.70 0.28 350)" : "oklch(0.55 0.04 255)",
        border: active ? "1px solid oklch(0.60 0.28 350 / 0.3)" : "1px solid transparent",
      }}>
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: React.ComponentType<React.SVGProps<SVGSVGElement>>, label: string, value: number, color: string }) {
  const colorMap: Record<string, { text: string; bg: string; border: string }> = {
    pink: { text: "oklch(0.70 0.28 350)", bg: "oklch(0.60 0.28 350 / 0.08)", border: "oklch(0.60 0.28 350 / 0.2)" },
    blue: { text: "oklch(0.70 0.22 255)", bg: "oklch(0.55 0.22 255 / 0.08)", border: "oklch(0.55 0.22 255 / 0.2)" },
    cyan: { text: "oklch(0.80 0.18 200)", bg: "oklch(0.72 0.18 200 / 0.08)", border: "oklch(0.72 0.18 200 / 0.2)" },
    purple: { text: "oklch(0.72 0.18 300)", bg: "oklch(0.65 0.18 300 / 0.08)", border: "oklch(0.65 0.18 300 / 0.2)" },
  };
  const c = colorMap[color] ?? colorMap["pink"]!;
  return (
    <div className="rounded-lg p-5" style={{ background: c.bg, border: `1px solid ${c.border}` }}>
      <div className="flex items-center gap-3 mb-3">
        <Icon className="h-4 w-4" style={{ color: c.text }} />
        <span className="text-xs tracking-widest uppercase text-muted-foreground">{label}</span>
      </div>
      <div className="text-3xl font-bold" style={{ color: c.text }}>{value}</div>
    </div>
  );
}
