CREATE TABLE `codeBlocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`language` varchar(50),
	`code` text NOT NULL,
	`description` text,
	`sourceDocId` int,
	`embedding` text,
	`patternType` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `codeBlocks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `concepts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100),
	`sourceDocId` int,
	`embedding` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `concepts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`filename` varchar(255) NOT NULL,
	`filePath` varchar(500),
	`ingestionStatus` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `relationships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceId` int NOT NULL,
	`sourceType` enum('concept','code_block') NOT NULL,
	`targetId` int NOT NULL,
	`targetType` enum('concept','code_block') NOT NULL,
	`relationshipType` varchar(100),
	`confidence` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `relationships_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trainingMetrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`epoch` int NOT NULL,
	`loss` text NOT NULL,
	`accuracy` text NOT NULL,
	`conceptsCount` int,
	`codeBlocksCount` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trainingMetrics_id` PRIMARY KEY(`id`)
);
