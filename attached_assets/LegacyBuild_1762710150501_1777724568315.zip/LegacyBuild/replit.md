# Legacy - Smart App Assembly Line

## Overview

Legacy is an AI-powered application that intelligently processes code files, books, and documentation to generate optimized applications. The system analyzes uploaded files, unifies code patterns, extracts insights from books, and produces a complete application with monetization strategies and next-step recommendations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript using Vite as the build tool

**UI Component System**: 
- Shadcn/UI components built on Radix UI primitives
- Material Design + Linear-inspired minimalism for developer-focused productivity
- Tailwind CSS for styling with custom design tokens
- Inter font family for typography, JetBrains Mono for code displays

**State Management**:
- TanStack Query (React Query) for server state management and caching
- Local component state with React hooks
- Query invalidation patterns for real-time data synchronization

**Routing**: 
- Wouter for client-side routing
- Main routes: Upload, Process, Reports, Generated App, Download

**File Upload**:
- Uppy library with dashboard UI
- AWS S3-compatible upload mechanism via Google Cloud Storage
- Support for multiple file types: code files (.js, .py, .ts, etc.), books (.pdf, .epub), documentation (.md, .txt), and archives (.zip)

### Backend Architecture

**Server Framework**: Express.js with TypeScript

**Development Setup**:
- Vite middleware for HMR in development
- Static file serving in production
- Custom logging middleware for API request tracking

**API Design**:
- RESTful endpoints organized by resource (projects, files, processing results)
- Consistent error handling with HTTP status codes
- JSON request/response format

**Processing Pipeline**:
1. **Upload**: Files uploaded to object storage
2. **Analyze**: AI analyzes each code file for patterns, language, and reusability
3. **Sort**: Files categorized and unused files identified
4. **Unify**: Code patterns unified across files
5. **Generate**: Complete application generated with filled gaps

**AI Integration**:
- OpenAI GPT-5 via Replit AI Integrations service
- Rate limiting with exponential backoff retry logic (p-retry)
- Concurrency control with p-limit
- JSON-structured responses for parsing
- Functions: code analysis, pattern unification, gap detection, monetization suggestions, next steps

### Data Storage

**Database**: PostgreSQL via Neon serverless driver

**ORM**: Drizzle ORM with schema-first approach

**Schema Design**:
- **projects**: Core project metadata, processing status, statistics
- **files**: Uploaded files with content and processing status
- **processing_results**: Step-by-step processing logs with timing
- **unused_files**: Files excluded from final output with reasoning
- **generated_code**: AI-generated application files
- **ai_insights**: Commentary and analysis from AI

**Storage Strategy**:
- File content stored in database for smaller files
- Object storage paths for larger files
- Cascade deletion for data integrity

### External Dependencies

**Cloud Services**:
- **Google Cloud Storage**: Object storage for uploaded files via Replit sidecar service
- **Neon Database**: Serverless PostgreSQL hosting
- **Replit AI Integrations**: OpenAI API access with managed credentials

**Authentication & Authorization**:
- Object ACL system with owner-based permissions
- Public/private visibility controls
- Group-based access rules (framework present, not fully implemented)

**Key Libraries**:
- **Uppy**: File upload UI and management
- **TanStack Query**: Data fetching and caching
- **Drizzle ORM**: Type-safe database operations
- **Zod**: Runtime validation via drizzle-zod
- **JSZip**: Project download packaging

**Processing Features**:
- Configurable processing modes (fast, balanced, comprehensive)
- AI commentary depth levels (1-5 scale)
- Code gap detection and filling
- Book reference extraction
- Monetization strategy generation
- Next-step recommendations

**Design System**:
- Component library from Shadcn/UI (30+ components)
- Consistent spacing scale (Tailwind units)
- Responsive grid system (12-column base)
- Dark mode support via CSS custom properties
- Fixed sidebar navigation (256px width)