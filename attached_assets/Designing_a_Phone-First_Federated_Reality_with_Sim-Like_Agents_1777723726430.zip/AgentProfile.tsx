import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { useState } from "react";
import { AgentAvatar } from "@/components/AgentAvatar";
import { MoodBadge } from "@/components/MoodBadge";
import { AgentNeeds } from "@/components/NeedsBar";

const PERSONALITY_LABELS: Record<string, { label: string; low: string; high: string }> = {
  openness: { label: "Openness", low: "Conventional", high: "Curious" },
  conscientiousness: { label: "Conscientiousness", low: "Spontaneous", high: "Disciplined" },
  extraversion: { label: "Extraversion", low: "Introverted", high: "Extraverted" },
  agreeableness: { label: "Agreeableness", low: "Competitive", high: "Cooperative" },
  neuroticism: { label: "Neuroticism", low: "Stable", high: "Sensitive" },
};

const RELATIONSHIP_EMOJIS: Record<string, string> = {
  friend: "👫", rival: "⚔️", romantic: "💕", colleague: "🤝",
  acquaintance: "👋", family: "👨‍👩‍👧", enemy: "😤",
};

const TASK_STATUS_CONFIG: Record<string, { color: string; label: string; icon: string }> = {
  pending: { color: "text-amber-400", label: "Pending", icon: "⏳" },
  in_progress: { color: "text-blue-400", label: "In Progress", icon: "🔄" },
  completed: { color: "text-green-400", label: "Done", icon: "✅" },
  failed: { color: "text-red-400", label: "Failed", icon: "❌" },
};

const MEMORY_TYPE_ICONS: Record<string, string> = {
  inner_monologue: "💭",
  conversation: "💬",
  task_completed: "✅",
  migration: "🏃",
  world_event: "🌍",
  relationship: "💫",
};

function PersonalityBar({ label, value, low, high }: { label: string; value: number; low: string; high: string }) {
  const pct = Math.round(value * 100);
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="text-foreground font-medium">{pct}%</span>
      </div>
      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(0.2 0.01 260)" }}>
        <div
          className="h-full rounded-full bg-primary transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex justify-between text-[10px] text-muted-foreground/60">
        <span>{low}</span>
        <span>{high}</span>
      </div>
    </div>
  );
}

export default function AgentProfile({ id }: { id: number }) {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<"overview" | "memories" | "relationships" | "tasks">("overview");

  const { data: profile, isLoading } = trpc.agents.profile.useQuery({ id }, {
    refetchInterval: 8000,
  });

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen bg-background">
        <div className="px-4 pt-12">
          <button onClick={() => navigate("/agents")} className="text-muted-foreground mb-4 flex items-center gap-1">
            <span>←</span> <span className="text-sm">Back</span>
          </button>
        </div>
        <div className="px-4 space-y-4">
          <div className="h-32 rounded-2xl shimmer" />
          <div className="h-48 rounded-2xl shimmer" />
        </div>
      </div>
    );
  }

  if (!profile?.agent) {
    return (
      <div className="flex flex-col min-h-screen bg-background items-center justify-center">
        <p className="text-muted-foreground">Agent not found</p>
        <button onClick={() => navigate("/agents")} className="mt-4 text-primary text-sm">← Back</button>
      </div>
    );
  }

  const { agent, needs, mood, memories, relationships, tasks, conversations } = profile;
  const personality = agent.personality as any;
  const traits = personality?.traits ?? [];

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-20 px-4 pt-12 pb-3"
        style={{ background: "oklch(0.08 0.01 260 / 0.95)", backdropFilter: "blur(20px)" }}>
        <button onClick={() => navigate("/agents")} className="text-muted-foreground mb-3 flex items-center gap-1">
          <span>←</span> <span className="text-sm">All Agents</span>
        </button>

        {/* Agent hero */}
        <div className="flex items-start gap-4">
          <AgentAvatar
            seed={agent.avatarSeed}
            name={agent.name}
            size="lg"
            mood={mood?.mood}
          />
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              {agent.name}
            </h1>
            <p className="text-sm text-muted-foreground">{agent.age} years old · {agent.job}</p>
            {mood && (
              <div className="mt-1.5">
                <MoodBadge mood={mood.mood} dominantEmotion={mood.dominantEmotion} size="sm" />
              </div>
            )}
          </div>
        </div>

        {/* Trait pills */}
        {traits.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-3">
            {traits.map((t: string) => (
              <span key={t} className="text-xs px-2.5 py-1 rounded-full bg-primary/10 text-primary/80">
                {t}
              </span>
            ))}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 mt-3 p-1 rounded-xl" style={{ background: "oklch(0.14 0.012 260)" }}>
          {(["overview", "memories", "relationships", "tasks"] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "flex-1 py-1.5 rounded-lg text-xs font-medium transition-all capitalize",
                activeTab === tab
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-3 pb-24 pt-3 space-y-3">
        {/* OVERVIEW TAB */}
        {activeTab === "overview" && (
          <>
            {/* Current status */}
            <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Current Status</h3>
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-xl p-3" style={{ background: "oklch(0.17 0.015 260)" }}>
                  <p className="text-xs text-muted-foreground mb-1">Activity</p>
                  <p className="text-sm font-medium text-foreground capitalize">{agent.currentActivity}</p>
                </div>
                <div className="rounded-xl p-3" style={{ background: "oklch(0.17 0.015 260)" }}>
                  <p className="text-xs text-muted-foreground mb-1">Location</p>
                  <p className="text-sm font-medium text-foreground capitalize">{agent.currentLocation}</p>
                </div>
              </div>
            </div>

            {/* Needs */}
            {needs && (
              <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Needs</h3>
                <AgentNeeds needs={needs} />
              </div>
            )}

            {/* Backstory */}
            {agent.backstory && (
              <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Backstory</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{agent.backstory}</p>
              </div>
            )}

            {/* Goals */}
            {Array.isArray(agent.goals) && agent.goals.length > 0 && (
              <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Life Goals</h3>
                <div className="space-y-2">
                  {(agent.goals as string[]).map((goal, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="text-primary mt-0.5">◆</span>
                      <p className="text-sm text-foreground">{goal}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Personality */}
            <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Personality (Big Five)</h3>
              <div className="space-y-4">
                {Object.entries(PERSONALITY_LABELS).map(([key, cfg]) => (
                  <PersonalityBar
                    key={key}
                    label={cfg.label}
                    value={personality?.[key] ?? 0.5}
                    low={cfg.low}
                    high={cfg.high}
                  />
                ))}
              </div>
            </div>

            {/* Recent conversations */}
            {conversations && conversations.length > 0 && (
              <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Recent Conversations</h3>
                <div className="space-y-3">
                  {conversations.slice(0, 3).map((c: any) => (
                    <div key={c.id} className="flex items-start gap-2">
                      {c.otherAgent && (
                        <AgentAvatar seed={c.otherAgent.avatarSeed} name={c.otherAgent.name} size="xs" className="mt-0.5" />
                      )}
                      <div>
                        <p className="text-xs font-medium text-foreground">{c.otherAgent?.name ?? "Unknown"}</p>
                        <p className="text-xs text-muted-foreground italic">"{c.summary}"</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* MEMORIES TAB */}
        {activeTab === "memories" && (
          <div className="space-y-2">
            {memories && memories.length > 0 ? memories.map((m: any) => (
              <div key={m.id} className="rounded-2xl p-3 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
                <div className="flex items-start gap-2">
                  <span className="text-base shrink-0 mt-0.5">{MEMORY_TYPE_ICONS[m.type] ?? "💫"}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-foreground leading-relaxed">{m.content}</p>
                    <p className="text-[10px] text-muted-foreground mt-1">
                      Day {m.worldDay} · Importance: {Math.round(m.importance * 100)}%
                    </p>
                  </div>
                </div>
              </div>
            )) : (
              <div className="text-center py-12">
                <p className="text-4xl mb-3">🧠</p>
                <p className="text-muted-foreground text-sm">No memories yet</p>
              </div>
            )}
          </div>
        )}

        {/* RELATIONSHIPS TAB */}
        {activeTab === "relationships" && (
          <div className="space-y-2">
            {relationships && relationships.length > 0 ? relationships.map((r: any) => (
              <button
                key={r.id}
                onClick={() => r.otherAgent && navigate(`/agents/${r.otherAgent.id}`)}
                className="w-full rounded-2xl p-4 border border-border/40 text-left transition-all active:scale-[0.98]"
                style={{ background: "oklch(0.12 0.012 260)" }}
              >
                <div className="flex items-center gap-3">
                  {r.otherAgent && (
                    <AgentAvatar seed={r.otherAgent.avatarSeed} name={r.otherAgent.name} size="sm" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold text-foreground">{r.otherAgent?.name ?? "Unknown"}</p>
                      <span className="text-lg">{RELATIONSHIP_EMOJIS[r.type] ?? "👋"}</span>
                    </div>
                    <p className="text-xs text-muted-foreground capitalize">{r.type} · {r.interactionCount} interactions</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: "oklch(0.2 0.01 260)" }}>
                        <div className="h-full rounded-full bg-primary" style={{ width: `${r.strength * 100}%` }} />
                      </div>
                      <span className="text-[10px] text-muted-foreground">{Math.round(r.strength * 100)}%</span>
                    </div>
                  </div>
                </div>
              </button>
            )) : (
              <div className="text-center py-12">
                <p className="text-4xl mb-3">💫</p>
                <p className="text-muted-foreground text-sm">No relationships yet</p>
                <p className="text-xs text-muted-foreground mt-1">Relationships form through social interactions</p>
              </div>
            )}
          </div>
        )}

        {/* TASKS TAB */}
        {activeTab === "tasks" && (
          <div className="space-y-2">
            {tasks && tasks.length > 0 ? tasks.map((t: any) => {
              const statusCfg = TASK_STATUS_CONFIG[t.status] ?? TASK_STATUS_CONFIG.pending!;
              return (
                <div key={t.id} className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <p className="text-sm font-semibold text-foreground">{t.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{t.description}</p>
                    </div>
                    <span className={cn("text-xs shrink-0", statusCfg.color)}>
                      {statusCfg.icon} {statusCfg.label}
                    </span>
                  </div>
                  {t.status === "in_progress" && (
                    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(0.2 0.01 260)" }}>
                      <div
                        className="h-full rounded-full bg-blue-400 transition-all duration-500"
                        style={{ width: `${t.progress * 100}%` }}
                      />
                    </div>
                  )}
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs px-2 py-0.5 rounded-full bg-secondary text-muted-foreground capitalize">{t.type}</span>
                    <span className="text-xs text-muted-foreground">Priority: {Math.round(t.priority * 100)}%</span>
                  </div>
                </div>
              );
            }) : (
              <div className="text-center py-12">
                <p className="text-4xl mb-3">📋</p>
                <p className="text-muted-foreground text-sm">No tasks yet</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
