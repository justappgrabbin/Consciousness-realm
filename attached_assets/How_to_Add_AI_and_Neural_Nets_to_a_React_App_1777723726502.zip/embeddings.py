"""
Embedding model using Sentence Transformers for semantic understanding
"""

import numpy as np
from sentence_transformers import SentenceTransformer
from typing import List, Union
import torch


class EmbeddingModel:
    """Wrapper around Sentence Transformers for generating semantic embeddings"""
    
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Initialize the embedding model
        
        Args:
            model_name: HuggingFace model identifier
                - all-MiniLM-L6-v2: Fast, 384-dim (default)
                - all-mpnet-base-v2: Slower but more accurate, 768-dim
        """
        self.model_name = model_name
        self.model = SentenceTransformer(model_name)
        self.embedding_dim = self.model.get_sentence_embedding_dimension()
        
        print(f"✓ Loaded {model_name} (embedding_dim={self.embedding_dim})")
    
    def embed_text(self, text: Union[str, List[str]]) -> np.ndarray:
        """
        Generate embeddings for text(s)
        
        Args:
            text: Single string or list of strings
            
        Returns:
            numpy array of shape (n, embedding_dim)
        """
        if isinstance(text, str):
            text = [text]
        
        embeddings = self.model.encode(text, convert_to_numpy=True)
        return embeddings
    
    def embed_code(self, code: Union[str, List[str]]) -> np.ndarray:
        """
        Generate embeddings for code snippets
        Code is treated as text but with special preprocessing
        
        Args:
            code: Single code string or list of code strings
            
        Returns:
            numpy array of shape (n, embedding_dim)
        """
        if isinstance(code, str):
            code = [code]
        
        # Preprocess code: normalize whitespace, remove comments
        processed_code = []
        for c in code:
            # Simple preprocessing
            lines = c.split('\n')
            cleaned = []
            for line in lines:
                # Remove leading/trailing whitespace
                line = line.strip()
                # Skip empty lines and comments
                if line and not line.startswith('#'):
                    cleaned.append(line)
            processed_code.append('\n'.join(cleaned))
        
        embeddings = self.model.encode(processed_code, convert_to_numpy=True)
        return embeddings
    
    def similarity(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """
        Compute cosine similarity between two embeddings
        
        Args:
            embedding1: First embedding vector
            embedding2: Second embedding vector
            
        Returns:
            Similarity score between -1 and 1
        """
        # Normalize embeddings
        emb1_norm = embedding1 / (np.linalg.norm(embedding1) + 1e-8)
        emb2_norm = embedding2 / (np.linalg.norm(embedding2) + 1e-8)
        
        # Compute cosine similarity
        similarity = np.dot(emb1_norm, emb2_norm)
        return float(similarity)
    
    def batch_similarity(self, embeddings1: np.ndarray, embeddings2: np.ndarray) -> np.ndarray:
        """
        Compute pairwise cosine similarities between two sets of embeddings
        
        Args:
            embeddings1: Array of shape (n, embedding_dim)
            embeddings2: Array of shape (m, embedding_dim)
            
        Returns:
            Array of shape (n, m) with similarity scores
        """
        # Normalize embeddings
        emb1_norm = embeddings1 / (np.linalg.norm(embeddings1, axis=1, keepdims=True) + 1e-8)
        emb2_norm = embeddings2 / (np.linalg.norm(embeddings2, axis=1, keepdims=True) + 1e-8)
        
        # Compute cosine similarity matrix
        similarities = np.dot(emb1_norm, emb2_norm.T)
        return similarities
    
    def find_most_similar(self, query_embedding: np.ndarray, candidates: np.ndarray, top_k: int = 5) -> List[int]:
        """
        Find the most similar candidates to a query embedding
        
        Args:
            query_embedding: Query embedding vector
            candidates: Array of candidate embeddings
            top_k: Number of top matches to return
            
        Returns:
            List of indices of top-k most similar candidates
        """
        similarities = self.batch_similarity(query_embedding.reshape(1, -1), candidates).flatten()
        top_indices = np.argsort(similarities)[::-1][:top_k]
        return top_indices.tolist()
