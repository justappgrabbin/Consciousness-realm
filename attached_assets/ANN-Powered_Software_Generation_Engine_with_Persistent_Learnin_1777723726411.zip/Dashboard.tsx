import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import {
  Plus,
  FolderOpen,
  Zap,
  Database,
  Code2,
  Clock,
  ChevronRight,
  Brain,
  RefreshCw,
  LogOut,
  Activity,
} from "lucide-react";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";

const PIPELINE_STAGES = ["ingest", "analyze", "generate", "preview", "deploy"] as const;
const STATUS_COLORS: Record<string, string> = {
  draft: "oklch(0.55 0.04 255)",
  analyzing: "oklch(0.70 0.22 255)",
  generating: "oklch(0.60 0.28 350)",
  complete: "oklch(0.72 0.18 200)",
  error: "oklch(0.58 0.22 25)",
  archived: "oklch(0.40 0.04 255)",
};

export default function Dashboard() {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [, navigate] = useLocation();

  const { data: projects, isLoading: projectsLoading } = trpc.projects.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const { data: stats } = trpc.projects.stats.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 rounded-full border-2 border-primary border-t-transparent animate-spin mx-auto mb-4" />
          <p className="text-xs tracking-widest uppercase text-muted-foreground">Karen is initializing...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Authentication required. Karen doesn't work with strangers.</p>
          <Button onClick={() => window.location.href = getLoginUrl()}>Initialize Session</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className="w-64 shrink-0 flex flex-col"
        style={{ background: "oklch(0.10 0.025 255)", borderRight: "1px solid oklch(0.18 0.03 255)" }}>
        {/* Logo */}
        <div className="p-6 flex items-center gap-3" style={{ borderBottom: "1px solid oklch(0.18 0.03 255)" }}>
          <div className="h-8 w-px" style={{ background: "linear-gradient(to bottom, transparent, oklch(0.60 0.28 350), transparent)" }} />
          <div>
            <div className="font-bold tracking-widest text-sm uppercase" style={{ color: "oklch(0.70 0.28 350)", textShadow: "0 0 10px oklch(0.60 0.28 350 / 0.5)" }}>
              KAREN
            </div>
            <div className="text-xs text-muted-foreground tracking-widest">ANN ENGINE</div>
          </div>
        </div>

        {/* Status */}
        <div className="px-4 py-3 mx-4 mt-4 rounded" style={{ background: "oklch(0.72 0.18 200 / 0.08)", border: "1px solid oklch(0.72 0.18 200 / 0.2)" }}>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full" style={{ background: "oklch(0.72 0.18 200)", boxShadow: "0 0 6px oklch(0.72 0.18 200)", animation: "pulse 2s infinite" }} />
            <span className="text-xs tracking-widest uppercase" style={{ color: "oklch(0.72 0.18 200)" }}>Neural Engine Online</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">Background learning active</p>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-4 space-y-1 mt-4">
          <NavItem icon={FolderOpen} label="Projects" active onClick={() => navigate("/dashboard")} />
          <NavItem icon={Brain} label="Recipes" onClick={() => navigate("/recipes")} />
          <NavItem icon={Activity} label="Job Monitor" onClick={() => navigate("/admin/jobs")} />
          <NavItem icon={Database} label="Memory Layer" onClick={() => navigate("/dashboard")} />
        </nav>

        {/* User */}
        <div className="p-4" style={{ borderTop: "1px solid oklch(0.18 0.03 255)" }}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
              style={{ background: "oklch(0.60 0.28 350 / 0.2)", color: "oklch(0.70 0.28 350)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>
              {user?.name?.charAt(0)?.toUpperCase() ?? "U"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">{user?.name ?? "User"}</p>
              <p className="text-xs text-muted-foreground truncate">{user?.email ?? ""}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={logout} className="w-full justify-start text-xs text-muted-foreground hover:text-foreground">
            <LogOut className="h-3 w-3 mr-2" /> Sign Out
          </Button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <div className="px-8 py-6 flex items-center justify-between" style={{ borderBottom: "1px solid oklch(0.18 0.03 255)" }}>
          <div>
            <h1 className="text-2xl font-bold">Projects</h1>
            <p className="text-sm text-muted-foreground mt-1">
              {user?.name ? `Welcome back, ${user.name.split(" ")[0]}. Karen has been busy.` : "Karen has been busy."}
            </p>
          </div>
          <Button onClick={() => navigate("/projects/new")}
            style={{ background: "oklch(0.60 0.28 350)", color: "oklch(0.98 0.01 0)", border: "none", boxShadow: "0 0 20px oklch(0.60 0.28 350 / 0.3)" }}>
            <Plus className="h-4 w-4 mr-2" /> New Project
          </Button>
        </div>

        <div className="p-8">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <StatCard icon={FolderOpen} label="Total Projects" value={stats?.projectCount ?? 0} color="pink" />
            <StatCard icon={Code2} label="Artifacts Generated" value={stats?.artifactCount ?? 0} color="blue" />
            <StatCard icon={Database} label="Inputs Ingested" value={stats?.inputCount ?? 0} color="cyan" />
          </div>

          {/* Projects */}
          {projectsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-24 rounded-lg animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />
              ))}
            </div>
          ) : !projects || projects.length === 0 ? (
            <EmptyState onNew={() => navigate("/projects/new")} />
          ) : (
            <div className="space-y-3">
              {projects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onClick={() => navigate(`/projects/${project.id}`)}
                />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon: Icon, label, active, onClick }: { icon: React.ComponentType<React.SVGProps<SVGSVGElement>>, label: string, active?: boolean, onClick: () => void }) {
  return (
    <button onClick={onClick}
      className="w-full flex items-center gap-3 px-3 py-2 rounded text-sm transition-colors"
      style={{
        background: active ? "oklch(0.60 0.28 350 / 0.1)" : "transparent",
        color: active ? "oklch(0.70 0.28 350)" : "oklch(0.55 0.04 255)",
        border: active ? "1px solid oklch(0.60 0.28 350 / 0.3)" : "1px solid transparent",
      }}>
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: React.ComponentType<React.SVGProps<SVGSVGElement>>, label: string, value: number, color: string }) {
  const colorMap: Record<string, { text: string; bg: string; border: string }> = {
    pink: { text: "oklch(0.70 0.28 350)", bg: "oklch(0.60 0.28 350 / 0.08)", border: "oklch(0.60 0.28 350 / 0.2)" },
    blue: { text: "oklch(0.70 0.22 255)", bg: "oklch(0.55 0.22 255 / 0.08)", border: "oklch(0.55 0.22 255 / 0.2)" },
    cyan: { text: "oklch(0.80 0.18 200)", bg: "oklch(0.72 0.18 200 / 0.08)", border: "oklch(0.72 0.18 200 / 0.2)" },
  };
  const c = colorMap[color] ?? colorMap["pink"]!;

  return (
    <div className="rounded-lg p-5" style={{ background: c.bg, border: `1px solid ${c.border}` }}>
      <div className="flex items-center gap-3 mb-3">
        <Icon className="h-4 w-4" style={{ color: c.text }} />
        <span className="text-xs tracking-widest uppercase text-muted-foreground">{label}</span>
      </div>
      <div className="text-3xl font-bold" style={{ color: c.text }}>{value}</div>
    </div>
  );
}

function ProjectCard({ project, onClick }: { project: any; onClick: () => void }) {
  const stageIndex = PIPELINE_STAGES.indexOf(project.pipelineStage);
  const statusColor = STATUS_COLORS[project.status] ?? STATUS_COLORS["draft"]!;

  return (
    <button onClick={onClick} className="w-full text-left rounded-lg p-5 transition-all duration-200 group"
      style={{ background: "oklch(0.11 0.025 255 / 0.8)", border: "1px solid oklch(0.22 0.04 255)" }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.60 0.28 350 / 0.4)";
        (e.currentTarget as HTMLElement).style.boxShadow = "0 0 20px oklch(0.60 0.28 350 / 0.08)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.22 0.04 255)";
        (e.currentTarget as HTMLElement).style.boxShadow = "none";
      }}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="font-semibold text-sm truncate">{project.name}</h3>
            <span className="text-xs px-2 py-0.5 rounded-full shrink-0"
              style={{ background: `${statusColor}20`, color: statusColor, border: `1px solid ${statusColor}40` }}>
              {project.status}
            </span>
          </div>
          {project.description && (
            <p className="text-xs text-muted-foreground truncate mb-3">{project.description}</p>
          )}
          {/* Pipeline */}
          <div className="flex items-center gap-1">
            {PIPELINE_STAGES.map((stage, i) => (
              <div key={stage} className="flex items-center gap-1">
                <div className="text-xs px-2 py-0.5 rounded"
                  style={{
                    background: i < stageIndex ? "oklch(0.72 0.18 200 / 0.1)" : i === stageIndex ? "oklch(0.60 0.28 350 / 0.15)" : "oklch(0.14 0.025 255)",
                    color: i < stageIndex ? "oklch(0.72 0.18 200)" : i === stageIndex ? "oklch(0.70 0.28 350)" : "oklch(0.40 0.04 255)",
                    border: `1px solid ${i < stageIndex ? "oklch(0.72 0.18 200 / 0.3)" : i === stageIndex ? "oklch(0.60 0.28 350 / 0.4)" : "oklch(0.22 0.04 255)"}`,
                  }}>
                  {stage}
                </div>
                {i < PIPELINE_STAGES.length - 1 && (
                  <div className="w-3 h-px" style={{ background: i < stageIndex ? "oklch(0.72 0.18 200 / 0.4)" : "oklch(0.22 0.04 255)" }} />
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col items-end gap-2 shrink-0">
          <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="h-3 w-3" />
            {formatDistanceToNow(new Date(project.updatedAt), { addSuffix: true })}
          </div>
        </div>
      </div>
    </button>
  );
}

function EmptyState({ onNew }: { onNew: () => void }) {
  return (
    <div className="text-center py-20">
      <div className="w-16 h-16 rounded-full mx-auto mb-6 flex items-center justify-center"
        style={{ background: "oklch(0.60 0.28 350 / 0.1)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>
        <Brain className="h-8 w-8" style={{ color: "oklch(0.70 0.28 350)" }} />
      </div>
      <h3 className="text-lg font-semibold mb-2">No projects yet</h3>
      <p className="text-sm text-muted-foreground mb-2 max-w-sm mx-auto">
        Karen is ready. She's been waiting with the patience of a very efficient computer.
      </p>
      <p className="text-xs text-muted-foreground mb-6 italic" style={{ color: "oklch(0.72 0.18 200)" }}>
        "K:// I've analyzed 0 projects. This is statistically unacceptable. Fix it."
      </p>
      <Button onClick={onNew}
        style={{ background: "oklch(0.60 0.28 350)", color: "oklch(0.98 0.01 0)", border: "none" }}>
        <Plus className="h-4 w-4 mr-2" /> Create First Project
      </Button>
    </div>
  );
}
