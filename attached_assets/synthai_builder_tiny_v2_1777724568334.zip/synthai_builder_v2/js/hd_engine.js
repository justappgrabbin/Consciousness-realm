
// hd_engine.js — ultra-light HD utilities (gate/channel scaffolding)
export const Gates = [
  { id: 1, name: "Gate 1 — Creative", center: "G", polarity: "Yang" },
  { id: 2, name: "Gate 2 — Receptive", center: "G", polarity: "Yin" },
  // ... extend as needed; we include a minimal subset and allow user import
];

export const Channels = [
  { id: "1-8", name: "Inspiration", centers: ["G", "Throat"] },
  { id: "2-14", name: "The Beat", centers: ["G", "Sacral"] },
];

export function generateResonanceSentence({ gate="1", line="1", field="Body", color=1, tone=1, base=1 }) {
  return `Field:${field} • Gate ${gate}.${line} • C${color} T${tone} B${base} — prime directive engaged.`;
}

export function validateHDProfile(profile) {
  const required = ["name", "fields", "gates", "channels"];
  for (const k of required) {
    if (!(k in profile)) return { ok: false, error: `Missing ${k}` };
  }
  return { ok: true };
}
