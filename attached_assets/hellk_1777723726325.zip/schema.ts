import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, float, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Resonance Node - Each user's private node in the network
 * The graphAddress serves as the privacy-preserving identifier
 */
export const resonanceNodes = mysqlTable("resonance_nodes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  graphAddress: varchar("graphAddress", { length: 128 }).notNull().unique(),
  
  // Birth data (encrypted reference, actual data stored locally)
  birthDataHash: varchar("birthDataHash", { length: 64 }),
  
  // Trinity Fields (gates 1-64)
  bodyGate: int("bodyGate"),
  bodyLine: int("bodyLine"),
  mindGate: int("mindGate"),
  mindLine: int("mindLine"),
  heartGate: int("heartGate"),
  heartLine: int("heartLine"),
  
  // Human Design Type derived from gates
  hdType: mysqlEnum("hdType", ["Generator", "Manifesting Generator", "Projector", "Manifestor", "Reflector"]),
  hdAuthority: varchar("hdAuthority", { length: 64 }),
  
  // Network metrics
  coherenceScore: float("coherenceScore").default(50),
  networkInfluence: float("networkInfluence").default(0),
  resonanceStrength: float("resonanceStrength").default(0),
  
  // Status
  isActive: boolean("isActive").default(true),
  lastResonance: timestamp("lastResonance"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ResonanceNode = typeof resonanceNodes.$inferSelect;
export type InsertResonanceNode = typeof resonanceNodes.$inferInsert;

/**
 * Resonance Patterns - Anonymized patterns contributed to collective intelligence
 * No personal data, only pattern signatures
 */
export const resonancePatterns = mysqlTable("resonance_patterns", {
  id: int("id").autoincrement().primaryKey(),
  sourceNodeAddress: varchar("sourceNodeAddress", { length: 128 }).notNull(),
  
  // Pattern type
  patternType: mysqlEnum("patternType", [
    "field_interference",
    "coherence_spike",
    "quest_completion",
    "economic_milestone",
    "network_connection"
  ]).notNull(),
  
  // Anonymized pattern data (no personal info)
  patternSignature: varchar("patternSignature", { length: 256 }).notNull(),
  frequencyVector: json("frequencyVector"), // [body_freq, mind_freq, heart_freq]
  alignmentScore: float("alignmentScore"),
  
  // Network contribution
  contributionWeight: float("contributionWeight").default(1),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ResonancePattern = typeof resonancePatterns.$inferSelect;
export type InsertResonancePattern = typeof resonancePatterns.$inferInsert;

/**
 * Quest Progress - Tracks user journey through Intention/Skill/Commitment stages
 */
export const questProgress = mysqlTable("quest_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  nodeAddress: varchar("nodeAddress", { length: 128 }).notNull(),
  
  // Quest stages
  currentStage: mysqlEnum("currentStage", ["intention", "skill", "commitment", "qualified"]).default("intention"),
  
  // Intention Quest
  intentionDeclared: text("intentionDeclared"),
  intentionAlignmentScore: float("intentionAlignmentScore"),
  intentionCompletedAt: timestamp("intentionCompletedAt"),
  
  // Skill Quest
  skillDemonstrated: text("skillDemonstrated"),
  skillGateAlignment: float("skillGateAlignment"),
  skillCompletedAt: timestamp("skillCompletedAt"),
  
  // Commitment Quest
  commitmentPractice: text("commitmentPractice"),
  commitmentStrategyScore: float("commitmentStrategyScore"),
  commitmentCompletedAt: timestamp("commitmentCompletedAt"),
  
  // Overall progress
  totalResonanceGenerated: float("totalResonanceGenerated").default(0),
  questsCompleted: int("questsCompleted").default(0),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type QuestProgress = typeof questProgress.$inferSelect;
export type InsertQuestProgress = typeof questProgress.$inferInsert;

/**
 * Economic Milestones - Tracks user success and network correlation
 */
export const economicMilestones = mysqlTable("economic_milestones", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  nodeAddress: varchar("nodeAddress", { length: 128 }).notNull(),
  
  // Milestone details
  milestoneType: mysqlEnum("milestoneType", [
    "first_success",
    "consistent_growth",
    "breakthrough",
    "network_contribution",
    "coherence_mastery"
  ]).notNull(),
  
  description: text("description"),
  value: float("value"), // Numeric value if applicable
  
  // Network correlation
  coherenceAtMilestone: float("coherenceAtMilestone"),
  networkHealthAtMilestone: float("networkHealthAtMilestone"),
  nodeInfluenceGained: float("nodeInfluenceGained"),
  
  // Notification status
  ownerNotified: boolean("ownerNotified").default(false),
  notifiedAt: timestamp("notifiedAt"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EconomicMilestone = typeof economicMilestones.$inferSelect;
export type InsertEconomicMilestone = typeof economicMilestones.$inferInsert;

/**
 * AI Companion Messages - Chat history for private AI node
 * Stored per-user, contributes anonymized patterns to network
 */
export const companionMessages = mysqlTable("companion_messages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  nodeAddress: varchar("nodeAddress", { length: 128 }).notNull(),
  
  // Message content
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  
  // Resonance context
  trinityContext: json("trinityContext"), // {body: gate, mind: gate, heart: gate}
  coherenceAtMessage: float("coherenceAtMessage"),
  resonanceWeight: float("resonanceWeight"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CompanionMessage = typeof companionMessages.$inferSelect;
export type InsertCompanionMessage = typeof companionMessages.$inferInsert;

/**
 * Network Connections - Graph edges between resonant nodes
 * Based on field alignment, not personal data
 */
export const networkConnections = mysqlTable("network_connections", {
  id: int("id").autoincrement().primaryKey(),
  
  // Connected nodes (by graph address, not user ID)
  nodeAddressA: varchar("nodeAddressA", { length: 128 }).notNull(),
  nodeAddressB: varchar("nodeAddressB", { length: 128 }).notNull(),
  
  // Connection strength based on resonance
  resonanceStrength: float("resonanceStrength").default(0),
  fieldAlignment: float("fieldAlignment").default(0),
  
  // Connection type
  connectionType: mysqlEnum("connectionType", [
    "gate_harmonic",
    "field_resonance",
    "quest_collaboration",
    "economic_synergy"
  ]),
  
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type NetworkConnection = typeof networkConnections.$inferSelect;
export type InsertNetworkConnection = typeof networkConnections.$inferInsert;

/**
 * Network Health Metrics - Aggregate network statistics
 */
export const networkMetrics = mysqlTable("network_metrics", {
  id: int("id").autoincrement().primaryKey(),
  
  // Snapshot timestamp
  snapshotAt: timestamp("snapshotAt").defaultNow().notNull(),
  
  // Network statistics
  totalNodes: int("totalNodes").default(0),
  activeNodes: int("activeNodes").default(0),
  totalConnections: int("totalConnections").default(0),
  
  // Health metrics
  averageCoherence: float("averageCoherence").default(50),
  networkResonance: float("networkResonance").default(0),
  collectiveIntelligenceScore: float("collectiveIntelligenceScore").default(0),
  
  // Economic health
  totalMilestones: int("totalMilestones").default(0),
  successRate: float("successRate").default(0),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NetworkMetric = typeof networkMetrics.$inferSelect;
export type InsertNetworkMetric = typeof networkMetrics.$inferInsert;
