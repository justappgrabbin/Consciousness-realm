import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { AgentAvatar } from "@/components/AgentAvatar";
import { WorldClock } from "@/components/WorldClock";
import { MoodBadge } from "@/components/MoodBadge";

const EVENT_TYPE_CONFIG: Record<string, { icon: string; color: string; label: string }> = {
  lifecycle: { icon: "🔄", color: "text-blue-400", label: "Life" },
  social: { icon: "💬", color: "text-pink-400", label: "Social" },
  task: { icon: "✅", color: "text-green-400", label: "Task" },
  mood: { icon: "💭", color: "text-purple-400", label: "Mood" },
  migration: { icon: "🏃", color: "text-amber-400", label: "Move" },
  world_event: { icon: "🌍", color: "text-cyan-400", label: "Event" },
  conversation: { icon: "🗣️", color: "text-indigo-400", label: "Chat" },
};

function formatWorldTime(worldHour: number, worldDay: number): string {
  const h = Math.floor(worldHour);
  const m = Math.round((worldHour - h) * 60);
  const ampm = h >= 12 ? "PM" : "AM";
  const displayH = h % 12 === 0 ? 12 : h % 12;
  return `Day ${worldDay} · ${displayH}:${m.toString().padStart(2, "0")} ${ampm}`;
}

interface FeedItem {
  id: number;
  type: string;
  title: string;
  content: string | null;
  emoji: string | null;
  worldDay: number;
  worldHour: number;
  importance: number;
  agent?: { id: number; name: string; avatarSeed: string } | null;
  district?: { id: number; name: string; color: string } | null;
}

function FeedCard({ item, onAgentClick }: { item: FeedItem; onAgentClick: (id: number) => void }) {
  const typeConfig = EVENT_TYPE_CONFIG[item.type] ?? { icon: "✨", color: "text-slate-400", label: "Event" };
  const isHighImportance = item.importance >= 0.7;

  return (
    <div className={cn(
      "rounded-2xl p-4 border transition-all duration-200 fade-in",
      isHighImportance
        ? "border-primary/30 bg-gradient-to-br from-primary/5 to-transparent"
        : "border-border/40",
    )}
      style={{ background: isHighImportance ? undefined : "oklch(0.12 0.012 260)" }}>
      <div className="flex items-start gap-3">
        {/* Emoji or Avatar */}
        {item.agent ? (
          <button onClick={() => onAgentClick(item.agent!.id)} className="shrink-0">
            <AgentAvatar
              seed={item.agent.avatarSeed}
              name={item.agent.name}
              size="sm"
            />
          </button>
        ) : (
          <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 text-lg"
            style={{ background: "oklch(0.18 0.015 260)" }}>
            {item.emoji ?? typeConfig.icon}
          </div>
        )}

        <div className="flex-1 min-w-0">
          {/* Header row */}
          <div className="flex items-center justify-between gap-2 mb-1">
            <div className="flex items-center gap-1.5 min-w-0">
              {item.agent && (
                <button
                  onClick={() => onAgentClick(item.agent!.id)}
                  className="text-sm font-semibold text-foreground hover:text-primary transition-colors truncate"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  {item.agent.name}
                </button>
              )}
              <span className={cn("text-xs shrink-0", typeConfig.color)}>
                {typeConfig.icon} {typeConfig.label}
              </span>
            </div>
            <span className="text-[10px] text-muted-foreground shrink-0">
              {formatWorldTime(item.worldHour, item.worldDay)}
            </span>
          </div>

          {/* Title */}
          <p className="text-sm font-medium text-foreground/90 mb-1">{item.title}</p>

          {/* Content */}
          {item.content && (
            <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3">
              {item.content}
            </p>
          )}

          {/* District tag */}
          {item.district && (
            <div className="mt-2">
              <span className="text-[10px] px-2 py-0.5 rounded-full"
                style={{
                  background: `${item.district.color}20`,
                  color: item.district.color,
                }}>
                📍 {item.district.name}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ConversationCard({ convo, onAgentClick }: {
  convo: {
    id: number;
    summary: string;
    sentiment: number;
    worldDay: number;
    worldHour: number;
    messages: Array<{ role: string; text: string }>;
    agentA: { id: number; name: string; avatarSeed: string } | null;
    agentB: { id: number; name: string; avatarSeed: string } | null;
  };
  onAgentClick: (id: number) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const sentimentColor = convo.sentiment > 0.7 ? "text-green-400" : convo.sentiment > 0.4 ? "text-blue-400" : "text-red-400";
  const messages = Array.isArray(convo.messages) ? convo.messages : [];

  return (
    <div className="rounded-2xl border border-pink-500/20 p-4"
      style={{ background: "oklch(0.12 0.015 340 / 0.5)" }}>
      <div className="flex items-center gap-2 mb-2">
        <div className="flex -space-x-2">
          {convo.agentA && (
            <button onClick={() => onAgentClick(convo.agentA!.id)}>
              <AgentAvatar seed={convo.agentA.avatarSeed} name={convo.agentA.name} size="xs" />
            </button>
          )}
          {convo.agentB && (
            <button onClick={() => onAgentClick(convo.agentB!.id)}>
              <AgentAvatar seed={convo.agentB.avatarSeed} name={convo.agentB.name} size="xs" />
            </button>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-foreground truncate">
            {convo.agentA?.name} & {convo.agentB?.name}
          </p>
          <p className="text-[10px] text-muted-foreground">
            {formatWorldTime(convo.worldHour, convo.worldDay)}
          </p>
        </div>
        <span className={cn("text-xs", sentimentColor)}>
          {convo.sentiment > 0.7 ? "😊" : convo.sentiment > 0.4 ? "😐" : "😟"}
        </span>
      </div>

      <p className="text-xs text-muted-foreground mb-2 italic">"{convo.summary}"</p>

      {messages.length > 0 && (
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-xs text-primary/70 hover:text-primary transition-colors"
        >
          {expanded ? "Hide conversation" : `Show ${messages.length} messages`}
        </button>
      )}

      {expanded && messages.length > 0 && (
        <div className="mt-3 space-y-2 border-t border-border/30 pt-3">
          {messages.map((msg, i) => {
            const agent = msg.role === "a" ? convo.agentA : convo.agentB;
            return (
              <div key={i} className={cn("flex gap-2", msg.role === "b" && "flex-row-reverse")}>
                {agent && (
                  <AgentAvatar seed={agent.avatarSeed} name={agent.name} size="xs" className="shrink-0 mt-0.5" />
                )}
                <div className={cn(
                  "text-xs px-3 py-2 rounded-2xl max-w-[80%]",
                  msg.role === "a"
                    ? "rounded-tl-sm bg-primary/15 text-foreground"
                    : "rounded-tr-sm bg-secondary text-foreground"
                )}>
                  {msg.text}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function Feed() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<"all" | "social" | "events">("all");
  const [autoRefresh, setAutoRefresh] = useState(true);

  const { data: worldState } = trpc.world.state.useQuery(undefined, {
    refetchInterval: autoRefresh ? 5000 : false,
  });

  const { data: feedItems = [], refetch: refetchFeed } = trpc.feed.global.useQuery(
    { limit: 60 },
    { refetchInterval: autoRefresh ? 6000 : false }
  );

  const { data: conversations = [] } = trpc.feed.conversations.useQuery(undefined, {
    refetchInterval: autoRefresh ? 8000 : false,
  });

  const filteredFeed = feedItems.filter(item => {
    if (activeTab === "social") return ["social", "conversation"].includes(item.type);
    if (activeTab === "events") return ["world_event", "migration", "task"].includes(item.type);
    return true;
  });

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-20 px-4 pt-12 pb-3"
        style={{ background: "oklch(0.08 0.01 260 / 0.95)", backdropFilter: "blur(20px)" }}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Agentic Reality
            </h1>
            <div className="flex items-center gap-2 mt-0.5">
              <div className={cn(
                "w-1.5 h-1.5 rounded-full",
                worldState?.paused ? "bg-amber-400" : "bg-green-400"
              )}
                style={!worldState?.paused ? { animation: "pulse 2s infinite" } : {}} />
              <span className="text-xs text-muted-foreground">
                {worldState?.paused ? "Simulation paused" : "Live simulation"}
              </span>
            </div>
          </div>
          {worldState && (
            <WorldClock
              worldHour={worldState.worldHour}
              worldDay={worldState.worldDay}
              tick={worldState.tick}
              paused={worldState.paused}
              compact
            />
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: "oklch(0.14 0.012 260)" }}>
          {(["all", "social", "events"] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "flex-1 py-1.5 rounded-lg text-xs font-medium transition-all capitalize",
                activeTab === tab
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {tab === "all" ? "All Events" : tab === "social" ? "Social" : "World Events"}
            </button>
          ))}
        </div>
      </div>

      {/* Feed content */}
      <div className="flex-1 px-3 pb-24 space-y-3 pt-2">
        {/* Recent conversations (social tab) */}
        {(activeTab === "all" || activeTab === "social") && conversations.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground px-1 mb-2 font-medium">Recent Conversations</p>
            <div className="space-y-2">
              {conversations.slice(0, activeTab === "social" ? 5 : 2).map(convo => (
                <ConversationCard
                  key={convo.id}
                  convo={convo as any}
                  onAgentClick={(id) => navigate(`/agents/${id}`)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Feed items */}
        {filteredFeed.length > 0 ? (
          <div>
            {(activeTab === "all" || activeTab === "social") && conversations.length > 0 && (
              <p className="text-xs text-muted-foreground px-1 mb-2 font-medium">Activity Feed</p>
            )}
            <div className="space-y-2">
              {filteredFeed.map(item => (
                <FeedCard
                  key={item.id}
                  item={item as any}
                  onAgentClick={(id) => navigate(`/agents/${id}`)}
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="text-5xl mb-4">🌱</div>
            <p className="text-foreground font-medium mb-2">The world is waking up</p>
            <p className="text-muted-foreground text-sm max-w-xs">
              Visit the Observer tab to start the simulation and watch agents come to life.
            </p>
            <button
              onClick={() => navigate("/observer")}
              className="mt-4 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium"
            >
              Open Observer
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
