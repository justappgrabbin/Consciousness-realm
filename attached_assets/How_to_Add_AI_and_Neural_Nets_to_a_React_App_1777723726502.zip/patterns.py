"""
Patterns API routes - Isomorphic pattern detection and suggestions
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import numpy as np

router = APIRouter()


class AddNodeInput(BaseModel):
    """Input for adding a node to the network"""
    node_type: str  # "concept" or "code_block"
    name: str
    embedding: List[float]
    source_doc_id: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None


class AddNodeResponse(BaseModel):
    """Response after adding a node"""
    node_id: int
    message: str


class AddEdgeInput(BaseModel):
    """Input for adding an edge"""
    source_id: int
    target_id: int
    relationship_type: str
    confidence: float = 0.5


class AddEdgeResponse(BaseModel):
    """Response after adding an edge"""
    success: bool
    message: str


class FindPatternsInput(BaseModel):
    """Input for finding isomorphic patterns"""
    embedding: List[float]
    node_type: Optional[str] = None
    top_k: int = 5


class PatternMatch(BaseModel):
    """A matched pattern"""
    node_id: int
    name: str
    type: str
    similarity: float


class FindPatternsResponse(BaseModel):
    """Response with matched patterns"""
    matches: List[PatternMatch]
    query_count: int


class RelatedNode(BaseModel):
    """A related node in the knowledge graph"""
    node_id: int
    name: str
    type: str
    depth: int


class GetRelatedResponse(BaseModel):
    """Response with related nodes"""
    related_nodes: List[RelatedNode]
    total_count: int


@router.post("/add-node", response_model=AddNodeResponse)
async def add_node(input_data: AddNodeInput):
    """
    Add a concept or code block to the isomorphic network
    
    Args:
        input_data: Node information
        
    Returns:
        Node ID and confirmation
    """
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    try:
        embedding = np.array(input_data.embedding)
        node_id = isomorphic_network.add_node(
            node_type=input_data.node_type,
            name=input_data.name,
            embedding=embedding,
            source_doc_id=input_data.source_doc_id,
            metadata=input_data.metadata
        )
        
        return AddNodeResponse(
            node_id=node_id,
            message=f"Added {input_data.node_type} node: {input_data.name}"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/add-edge", response_model=AddEdgeResponse)
async def add_edge(input_data: AddEdgeInput):
    """
    Add a relationship between nodes
    
    Args:
        input_data: Edge information
        
    Returns:
        Success confirmation
    """
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    try:
        isomorphic_network.add_edge(
            source_id=input_data.source_id,
            target_id=input_data.target_id,
            relationship_type=input_data.relationship_type,
            confidence=input_data.confidence
        )
        
        return AddEdgeResponse(
            success=True,
            message=f"Added relationship: {input_data.source_id} -> {input_data.target_id}"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/find-patterns", response_model=FindPatternsResponse)
async def find_patterns(input_data: FindPatternsInput):
    """
    Find isomorphic patterns matching a query embedding
    
    Args:
        input_data: Query embedding and filters
        
    Returns:
        List of matching patterns
    """
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    try:
        query_embedding = np.array(input_data.embedding)
        matches = isomorphic_network.find_isomorphic_patterns(
            query_embedding=query_embedding,
            node_type=input_data.node_type,
            top_k=input_data.top_k
        )
        
        pattern_matches = []
        for node_id, similarity in matches:
            node = isomorphic_network.nodes[node_id]
            pattern_matches.append(PatternMatch(
                node_id=node_id,
                name=node.name,
                type=node.type,
                similarity=similarity
            ))
        
        return FindPatternsResponse(
            matches=pattern_matches,
            query_count=len(isomorphic_network.nodes)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/related/{node_id}", response_model=GetRelatedResponse)
async def get_related_nodes(node_id: int, depth: int = 2):
    """
    Get all nodes related to a given node
    
    Args:
        node_id: Starting node ID
        depth: Maximum depth to traverse
        
    Returns:
        List of related nodes
    """
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    if node_id not in isomorphic_network.nodes:
        raise HTTPException(status_code=404, detail="Node not found")
    
    try:
        related = isomorphic_network.get_related_nodes(node_id, depth)
        
        related_nodes = [
            RelatedNode(
                node_id=nid,
                name=info["name"],
                type=info["type"],
                depth=info["depth"]
            )
            for nid, info in related.items()
        ]
        
        return GetRelatedResponse(
            related_nodes=related_nodes,
            total_count=len(related_nodes)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/network-stats")
async def get_network_stats():
    """Get network statistics"""
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    return isomorphic_network.get_statistics()
