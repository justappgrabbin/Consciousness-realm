# Karen ANN Engine — TODO

## Phase 1: Architecture & Schema
- [x] Initialize project scaffold
- [x] Design and apply full database schema (projects, artifacts, inputs, jobs, recipes, monetization, suggestions)
- [x] Create all tRPC routers (projects, inputs, artifacts, generation, jobs, monetization, karen)

## Phase 2: Backend — AI Engine
- [x] Karen personality system prompt layer
- [x] Intent analysis procedure (natural language → structured requirements)
- [x] Multi-input fusion engine (files + code + intent → unified context)
- [x] ANN-driven code generation procedure (LLM-powered, pattern detection, gap filling)
- [x] Architecture plan generator
- [x] Monetization planning module (pricing models, revenue architecture)
- [x] Project recipe system (reusable patterns stored and retrieved)

## Phase 3: Background Job System
- [x] Background learning loop (processes ingested code/docs when idle)
- [x] Embedding refinement job (cross-project relationship discovery)
- [x] Unresolved gap detection job
- [x] Improvement suggestion queue
- [x] Job status tracking in DB

## Phase 4: File Handling & Artifacts
- [x] File upload endpoint (S3 storage)
- [x] Code snippet ingestion
- [x] Artifact storage (generated code, architecture plans)
- [x] Zip packaging of generated project
- [x] S3 artifact download links

## Phase 5: Frontend — Neon-Noir Design System
- [x] Global CSS: midnight navy bg, hot pink headlines, electric blue glow, cyan/magenta accents
- [x] Typography: Space Grotesk + JetBrains Mono
- [x] Neon glow utility classes (glow-pink, glow-cyan, glow-blue, neon-border, neon-card)
- [x] Dark theme with cinematic neon-noir palette enforced globally
- [x] Radial gradient background with fixed attachment
- [x] Custom scrollbar and selection styling

## Phase 6: Frontend — Landing Page
- [x] Hero section with Karen intro and CTA
- [x] Feature showcase (12 features with color-coded neon cards)
- [x] Neon accent lines and cinematic layout
- [x] Login/auth integration
- [x] Karen personality quote section

## Phase 7: Frontend — Dashboard & Pipeline
- [x] Dashboard layout with sidebar navigation
- [x] Projects list with status indicators and pipeline stages
- [x] Project pipeline visualizer (stages: Ingest → Analyze → Generate → Preview → Deploy)
- [x] Project stats (projects, artifacts, inputs)
- [x] Empty state with Karen personality message

## Phase 8: Frontend — Multi-Input Ingestion
- [x] File upload dropzone (text/code files)
- [x] Code paste editor with language selection
- [x] Natural language intent input (NewProject page)
- [x] Input list with embedding status indicators
- [x] Input deletion

## Phase 9: Frontend — Karen Chat Interface
- [x] Full-featured chat with Karen personality
- [x] AI responses with markdown rendering (Streamdown)
- [x] Karen status messages (K:// prefix)
- [x] Context-aware responses tied to active project
- [x] Typing indicator animation

## Phase 10: Frontend — Code Generation & Preview
- [x] 4-step generation pipeline UI with status indicators
- [x] Architecture plan display with component grid
- [x] Karen assessment in architecture plan
- [x] Artifact viewer with file tree
- [x] Download zip artifact button
- [x] Preview link for generated artifacts

## Phase 11: Frontend — Monetization Planner
- [x] Monetization plan generation trigger
- [x] Primary model and estimated MRR display
- [x] Revenue architecture section
- [x] Monetization strategies with complexity/revenue indicators
- [x] Launch strategy section

## Phase 12: Tests & Delivery
- [x] Vitest unit tests for core routers (13 tests passing)
- [x] Karen personality tests
- [x] Final checkpoint and delivery

## Future Enhancements
- [x] Recipes page UI (list and create reusable patterns)
- [x] Improvement suggestions page UI
- [x] Live preview iframe rendering in Artifacts tab
- [x] Monetization plan JSON export
- [x] Syntax-highlighted code preview in Inputs tab
- [x] Unified context panel showing fused inputs
- [x] Karen chat with typing indicator and full message history (request/response pattern)
- [ ] DEFERRED: True token-level streaming for Karen chat (requires SSE/WebSocket server infrastructure upgrade — documented as known future enhancement, not blocking production use)
- [x] Cross-project pattern discovery visualization (cross-project stats in Job Monitor)
- [x] Admin panel for background job monitoring (/admin/jobs with live job queue, status tracking, cross-project stats)
