# Legacy - Design Guidelines

## Design Approach
**System Selection:** Material Design + Linear-inspired minimalism for a developer-focused productivity tool
**Rationale:** Information-dense application requiring clear data hierarchies, efficient workflows, and robust component patterns for file processing, reporting, and AI-generated insights.

---

## Typography System

**Font Stack:**
- Primary: Inter (via Google Fonts CDN)
- Monospace: JetBrains Mono (for code snippets and file names)

**Hierarchy:**
- H1: 2.5rem (40px), font-weight 700 - Dashboard title
- H2: 1.875rem (30px), font-weight 600 - Section headers
- H3: 1.5rem (24px), font-weight 600 - Card titles, report sections
- H4: 1.25rem (20px), font-weight 500 - Subsections
- Body: 1rem (16px), font-weight 400 - Primary content
- Small: 0.875rem (14px), font-weight 400 - Metadata, labels
- Code: 0.875rem (14px), JetBrains Mono - File paths, code references

---

## Layout System

**Spacing Scale:** Tailwind units of 2, 4, 6, 8, 12, 16, 24
- Component padding: p-6, p-8
- Section gaps: gap-6, gap-8
- Container margins: mx-4, mx-8
- Vertical rhythm: space-y-6, space-y-8

**Grid Structure:**
- Main dashboard: 12-column grid with sidebar
- Sidebar: w-64 (256px) fixed width
- Content area: flex-1 with max-w-7xl container
- Card grids: grid-cols-1 md:grid-cols-2 lg:grid-cols-3

---

## Component Library

### Navigation & Layout
**Sidebar Navigation:**
- Fixed left sidebar with vertical navigation
- Icon + label pattern for main sections: Upload, Process, Reports, Settings
- Active state indicator (vertical accent bar)
- Collapsible on mobile (hamburger menu)

**Top Bar:**
- Processing status indicator (live updates)
- User profile/settings dropdown (right-aligned)
- Breadcrumb navigation for deep contexts

### Upload Interface
**Drag-and-Drop Zone:**
- Large centered area (min-h-96) with dashed border
- Upload icon (Hero Icons: ArrowUpTray)
- Clear instructions: "Drop files here or click to browse"
- File type indicators below: "Supports: .js, .py, .pdf, .epub, .zip, .txt"
- Active state on drag-over (border highlight)

**File List Component:**
- Table layout with columns: Name (with icon), Type, Size, Status
- Grouped by file type (collapsible sections)
- Individual file actions: Remove, Preview
- Batch actions bar: Select All, Remove Selected

### Processing Pipeline
**Visual Pipeline Diagram:**
- Horizontal stepper component showing: Upload → Analyze → Sort → Unify → Generate
- Active step highlight with progress indicator
- Completed steps with checkmark icons
- Time estimates for current step

**Processing Status Cards:**
- Grid of 4 cards showing real-time metrics:
  - Files Processed (number with icon)
  - Code Lines Analyzed (number with icon)
  - Patterns Unified (number with icon)
  - Books Referenced (number with icon)

### Reports Section
**Multi-Tab Interface:**
- Tab navigation: Processing Report | Unused Files | Monetization | Next Steps
- Clean tab bar with underline indicator for active tab

**Processing Report:**
- Timeline view of processing steps
- Expandable sections for each file processed
- Code diff viewer for unified patterns
- Book references as tooltips/side annotations

**Unused Files Report:**
- Table with columns: File Name, Reason, Suggested Action
- Filter by reason: Duplicate, Incompatible, Low Quality
- Export to CSV button

**AI Insights Panels:**
- Distinct card design with subtle border
- Icon: Sparkles or Lightbulb (Hero Icons)
- Monetization suggestions as bulleted list with confidence scores
- Next steps as numbered action items with priority badges

### Output Display
**Generated Application Viewer:**
- Split view: File tree (left) + Code preview (right)
- Syntax highlighting for code
- Download button (prominent, top-right)
- "Deploy to Replit" button below download

### Forms & Inputs
**Upload Settings Panel:**
- Checkbox groups for file type filters
- Radio buttons for processing modes: Fast | Balanced | Thorough
- Slider for "AI Commentary Depth" (1-5 scale)

---

## Data Visualization

**Progress Indicators:**
- Linear progress bars (h-2 rounded-full) for file processing
- Circular progress for overall completion
- Percentage labels always visible

**File Icons:**
- Use Hero Icons: DocumentText (general), Code (code files), BookOpen (books), Archive (zip)
- Size: w-5 h-5 inline with text

**Status Badges:**
- Pill-shaped with icons: Processing (spinner), Complete (check), Error (x), Skipped (minus)
- Positioned inline with file names

---

## Interaction Patterns

**Loading States:**
- Skeleton screens for initial data load
- Inline spinners for individual file processing
- Toast notifications for background task completion

**Empty States:**
- Centered illustration + message
- "Get Started" action button
- Example: "No files uploaded yet. Drop your first file to begin."

**Modals:**
- File preview modal: full-screen overlay with close button (top-right)
- Confirmation dialogs: centered, max-w-lg, with Cancel/Confirm actions

---

## Images

**No hero image required** - this is a dashboard/tool interface, not a marketing page.

**Illustrations/Icons Only:**
- Empty state illustrations: Simple line drawings for "no files", "processing complete"
- File type preview thumbnails in modals
- All icons from Hero Icons library via CDN

---

## Accessibility

- Skip navigation link
- Keyboard navigation for all interactive elements (upload zone, file list)
- ARIA labels for icons-only buttons
- Focus visible states on all inputs and buttons
- Alt text for all illustrations