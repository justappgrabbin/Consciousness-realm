import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  analyzeIntent,
  generateArchitecturePlan,
  generateApplicationCode,
  generateMonetizationPlan,
  karenChat,
} from "./karen";
import {
  createArtifact,
  createJob,
  createMessage,
  createMonetizationPlan,
  createProject,
  createProjectInput,
  createRecipe,
  createSuggestion,
  deleteProject,
  deleteProjectInput,
  getArtifactById,
  getDb,
  getJobsByProject,
  getMonetizationPlan,
  getProjectArtifacts,
  getProjectById,
  getProjectInputs,
  getProjectMessages,
  getProjectsByUser,
  getPublicRecipes,
  getRecipesByUser,
  getSuggestionsByProject,
  getUserStats,
  updateProject,
  updateSuggestionStatus,
} from "./db";
import { packageAndUploadArtifact, generatePreviewScaffold } from "./artifacts";
import { storagePut } from "./storage";

// ─── Projects Router ──────────────────────────────────────────────────────────
const projectsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return getProjectsByUser(ctx.user.id);
  }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const project = await getProjectById(input.id, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND", message: "Project not found" });
      return project;
    }),

  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(255),
        description: z.string().optional(),
        intent: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const id = await createProject({
        userId: ctx.user.id,
        name: input.name,
        description: input.description,
        intent: input.intent,
      });
      return { id };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(255).optional(),
        description: z.string().optional(),
        intent: z.string().optional(),
        status: z.enum(["draft", "analyzing", "generating", "complete", "error", "archived"]).optional(),
        pipelineStage: z.enum(["ingest", "analyze", "generate", "preview", "deploy"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await updateProject(id, ctx.user.id, data);
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      await deleteProject(input.id, ctx.user.id);
      return { success: true };
    }),

  stats: protectedProcedure.query(async ({ ctx }) => {
    return getUserStats(ctx.user.id);
  }),
});

// ─── Inputs Router ────────────────────────────────────────────────────────────
const inputsRouter = router({
  list: protectedProcedure
    .input(z.object({ projectId: z.number() }))
    .query(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      return getProjectInputs(input.projectId);
    }),

  addCodeSnippet: protectedProcedure
    .input(
      z.object({
        projectId: z.number(),
        content: z.string().min(1),
        language: z.string().optional(),
        filename: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });

      const id = await createProjectInput({
        projectId: input.projectId,
        userId: ctx.user.id,
        inputType: "code_snippet",
        content: input.content,
        language: input.language,
        filename: input.filename ?? "snippet.txt",
      });

      // Queue analysis job
      await createJob({
        jobType: "analyze_input",
        projectId: input.projectId,
        inputId: id,
        userId: ctx.user.id,
      });

      return { id };
    }),

  addIntent: protectedProcedure
    .input(
      z.object({
        projectId: z.number(),
        content: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });

      const id = await createProjectInput({
        projectId: input.projectId,
        userId: ctx.user.id,
        inputType: "intent",
        content: input.content,
        filename: "intent.txt",
      });

      await updateProject(input.projectId, ctx.user.id, { intent: input.content });
      return { id };
    }),

  uploadFile: protectedProcedure
    .input(
      z.object({
        projectId: z.number(),
        filename: z.string(),
        mimeType: z.string(),
        content: z.string(),
        fileSize: z.number().optional(),
        language: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });

      // Upload to S3
      const suffix = Math.random().toString(36).substring(2, 10);
      const s3Key = `inputs/project-${input.projectId}-user-${ctx.user.id}-${suffix}-${input.filename}`;
      const buffer = Buffer.from(input.content, "utf-8");
      const { url: s3Url } = await storagePut(s3Key, buffer, input.mimeType);

      const id = await createProjectInput({
        projectId: input.projectId,
        userId: ctx.user.id,
        inputType: input.mimeType.startsWith("text/") ? "document" : "file",
        filename: input.filename,
        mimeType: input.mimeType,
        content: input.content.slice(0, 65000),
        s3Key,
        s3Url,
        fileSize: input.fileSize,
        language: input.language,
      });

      await createJob({
        jobType: input.mimeType.includes("text") ? "analyze_input" : "process_document",
        projectId: input.projectId,
        inputId: id,
        userId: ctx.user.id,
      });

      return { id, s3Url };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number(), projectId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      await deleteProjectInput(input.id, input.projectId);
      return { success: true };
    }),
});

// ─── Generation Router ────────────────────────────────────────────────────────
const generationRouter = router({
  analyzeIntent: protectedProcedure
    .input(
      z.object({
        projectId: z.number(),
        intent: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });

      await updateProject(input.projectId, ctx.user.id, { status: "analyzing" });

      const inputs = await getProjectInputs(input.projectId);
      const existingInputs = inputs
        .filter((i) => i.content)
        .map((i) => `[${i.inputType}] ${i.filename ?? ""}: ${i.content?.slice(0, 500)}`);

      const analysis = await analyzeIntent(input.intent, existingInputs);

      await updateProject(input.projectId, ctx.user.id, {
        intent: input.intent,
        techStack: analysis.techStack as any,
        status: "draft",
        pipelineStage: "analyze",
      });

      // Save Karen's comment as a message
      await createMessage({
        projectId: input.projectId,
        userId: ctx.user.id,
        role: "karen",
        content: analysis.karenComment,
        metadata: { type: "intent_analysis" },
      });

      return analysis;
    }),

  generateArchitecture: protectedProcedure
    .input(
      z.object({
        projectId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      if (!project.intent) throw new TRPCError({ code: "BAD_REQUEST", message: "No intent set for this project." });

      await updateProject(input.projectId, ctx.user.id, { status: "analyzing" });

      const inputs = await getProjectInputs(input.projectId);
      const codeContext = inputs
        .filter((i) => i.content && i.inputType === "code_snippet")
        .map((i) => i.content)
        .join("\n---\n")
        .slice(0, 4000);

      const analysis = await analyzeIntent(project.intent, []);
      const architecturePlan = await generateArchitecturePlan(
        project.name,
        project.intent,
        analysis,
        codeContext
      );

      await updateProject(input.projectId, ctx.user.id, {
        architecturePlan: architecturePlan as any,
        status: "draft",
        pipelineStage: "generate",
      });

      // Save architecture as artifact
      await createArtifact({
        projectId: input.projectId,
        userId: ctx.user.id,
        artifactType: "architecture_plan",
        name: `${project.name} — Architecture Plan`,
        content: JSON.stringify(architecturePlan, null, 2),
        metadata: { generatedAt: new Date().toISOString() },
      });

      await createMessage({
        projectId: input.projectId,
        userId: ctx.user.id,
        role: "karen",
        content: architecturePlan.karenAssessment,
        metadata: { type: "architecture_plan" },
      });

      return architecturePlan;
    }),

  generateCode: protectedProcedure
    .input(z.object({ projectId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      if (!project.intent) throw new TRPCError({ code: "BAD_REQUEST", message: "No intent set." });

      await updateProject(input.projectId, ctx.user.id, { status: "generating" });

      const inputs = await getProjectInputs(input.projectId);
      const inputContext = inputs
        .filter((i) => i.content)
        .map((i) => `[${i.inputType}] ${i.filename ?? ""}:\n${i.content?.slice(0, 2000)}`)
        .join("\n---\n");

      const analysis = await analyzeIntent(project.intent, []);
      const architecturePlan = (project.architecturePlan as any) ??
        (await generateArchitecturePlan(project.name, project.intent, analysis));

      const generatedApp = await generateApplicationCode(
        project.name,
        project.intent,
        analysis,
        architecturePlan,
        inputContext
      );

      // Package and upload to S3
      const { s3Key, s3Url, fileTree } = await packageAndUploadArtifact(
        input.projectId,
        ctx.user.id,
        project.name,
        generatedApp
      );

      // Generate preview scaffold
      const previewHtml = generatePreviewScaffold(project.name, generatedApp);
      const previewBuffer = Buffer.from(previewHtml, "utf-8");
      const previewSuffix = Math.random().toString(36).substring(2, 10);
      const previewKey = `previews/project-${input.projectId}-${previewSuffix}.html`;
      const { url: previewUrl } = await storagePut(previewKey, previewBuffer, "text/html");

      // Save artifact
      const artifactId = await createArtifact({
        projectId: input.projectId,
        userId: ctx.user.id,
        artifactType: "generated_app",
        name: `${project.name} — Generated Application`,
        content: generatedApp.karenNotes,
        s3Key,
        s3Url,
        fileTree: fileTree as any,
        metadata: {
          fileCount: generatedApp.files.length,
          detectedPatterns: generatedApp.detectedPatterns,
          gapsFilled: generatedApp.gapsFilled,
          previewUrl,
          previewKey,
          generatedAt: new Date().toISOString(),
        },
      });

      await updateProject(input.projectId, ctx.user.id, {
        status: "complete",
        pipelineStage: "preview",
        lastGeneratedAt: new Date(),
      });

      // Queue recipe extraction
      await createJob({
        jobType: "generate_recipe",
        projectId: input.projectId,
        userId: ctx.user.id,
        payload: {
          projectName: project.name,
          architecturePlan,
          analysis,
        } as any,
      });

      await createMessage({
        projectId: input.projectId,
        userId: ctx.user.id,
        role: "karen",
        content: `${generatedApp.karenNotes}\n\nI've packaged ${generatedApp.files.length} files. Patterns applied: ${generatedApp.detectedPatterns.join(", ")}. Gaps I filled because you didn't think of them: ${generatedApp.gapsFilled.join(", ")}.`,
        metadata: { type: "code_generation", artifactId },
      });

      return {
        artifactId,
        s3Url,
        previewUrl,
        fileCount: generatedApp.files.length,
        detectedPatterns: generatedApp.detectedPatterns,
        gapsFilled: generatedApp.gapsFilled,
        karenNotes: generatedApp.karenNotes,
      };
    }),
});

// ─── Artifacts Router ─────────────────────────────────────────────────────────
const artifactsRouter = router({
  list: protectedProcedure
    .input(z.object({ projectId: z.number() }))
    .query(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      return getProjectArtifacts(input.projectId);
    }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const artifact = await getArtifactById(input.id);
      if (!artifact || artifact.userId !== ctx.user.id)
        throw new TRPCError({ code: "NOT_FOUND" });
      return artifact;
    }),
});

// ─── Messages Router ──────────────────────────────────────────────────────────
const messagesRouter = router({
  list: protectedProcedure
    .input(z.object({ projectId: z.number(), limit: z.number().default(50) }))
    .query(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      const messages = await getProjectMessages(input.projectId, input.limit);
      return messages.reverse();
    }),

  chat: protectedProcedure
    .input(
      z.object({
        projectId: z.number(),
        message: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });

      // Save user message
      await createMessage({
        projectId: input.projectId,
        userId: ctx.user.id,
        role: "user",
        content: input.message,
      });

      // Build project context
      const inputs = await getProjectInputs(input.projectId);
      const artifacts = await getProjectArtifacts(input.projectId);
      const projectContext = `
Project: ${project.name}
Status: ${project.status}
Pipeline Stage: ${project.pipelineStage}
Intent: ${project.intent ?? "Not set"}
Tech Stack: ${JSON.stringify(project.techStack ?? {})}
Inputs: ${inputs.length} items (${inputs.map((i) => i.inputType).join(", ")})
Artifacts: ${artifacts.length} generated
      `.trim();

      // Get recent conversation history
      const recentMessages = await getProjectMessages(input.projectId, 10);
      const history = recentMessages
        .reverse()
        .slice(-8)
        .map((m) => ({
          role: m.role === "user" ? ("user" as const) : ("assistant" as const),
          content: m.content,
        }));

      const response = await karenChat(input.message, projectContext, history);

      // Save Karen's response
      await createMessage({
        projectId: input.projectId,
        userId: ctx.user.id,
        role: "karen",
        content: response,
      });

      return { response };
    }),
});

// ─── Monetization Router ──────────────────────────────────────────────────────
const monetizationRouter = router({
  get: protectedProcedure
    .input(z.object({ projectId: z.number() }))
    .query(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      return getMonetizationPlan(input.projectId);
    }),

  generate: protectedProcedure
    .input(z.object({ projectId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      if (!project.intent) throw new TRPCError({ code: "BAD_REQUEST", message: "Set project intent first." });

      const analysis = await analyzeIntent(project.intent, []);
      const strategy = await generateMonetizationPlan(
        project.name,
        project.description ?? project.intent,
        analysis
      );

      const id = await createMonetizationPlan({
        projectId: input.projectId,
        userId: ctx.user.id,
        pricingModel: strategy.pricingModel as any,
        suggestions: strategy.suggestions as any,
        revenueArchitecture: strategy.revenueArchitecture as any,
        targetMarket: strategy.targetMarket,
        estimatedMRR: strategy.estimatedMRR,
        competitorAnalysis: strategy.competitorAnalysis as any,
        launchStrategy: strategy.launchStrategy,
      });

      await createMessage({
        projectId: input.projectId,
        userId: ctx.user.id,
        role: "karen",
        content: strategy.karenVerdict,
        metadata: { type: "monetization_plan" },
      });

      return { id, ...strategy };
    }),
});

// ─── Jobs Router ──────────────────────────────────────────────────────────────
const jobsRouter = router({
  list: protectedProcedure
    .input(z.object({ projectId: z.number() }))
    .query(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      return getJobsByProject(input.projectId);
    }),
  listAll: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    const { backgroundJobs, projects } = await import("../drizzle/schema");
    const { eq, desc } = await import("drizzle-orm");
    const userProjects = await db.select({ id: projects.id }).from(projects).where(eq(projects.userId, ctx.user.id));
    if (userProjects.length === 0) return [];
    const projectIds = userProjects.map((p: { id: number }) => p.id);
    const allJobs = await db.select().from(backgroundJobs).orderBy(desc(backgroundJobs.createdAt)).limit(100);
    return allJobs.filter((j: any) => projectIds.includes(j.projectId));
  }),
  crossProjectStats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { totalProjects: 0, totalArtifacts: 0, totalInputs: 0, totalJobs: 0, recentActivity: [], patternSummary: [] };
    const { projects, codeArtifacts, projectInputs, backgroundJobs } = await import("../drizzle/schema");
    const { eq, count, desc, inArray } = await import("drizzle-orm");
    // Get user's project IDs first for scoped counts
    const userProjects = await db.select({ id: projects.id, name: projects.name, status: projects.status, updatedAt: projects.updatedAt, pipelineStage: projects.pipelineStage })
      .from(projects).where(eq(projects.userId, ctx.user.id));
    const projectIds = userProjects.map((p: { id: number }) => p.id);
    if (projectIds.length === 0) {
      return { totalProjects: 0, totalArtifacts: 0, totalInputs: 0, totalJobs: 0, recentActivity: [], patternSummary: [] };
    }
    const [artifactRows, inputRows, jobRows] = await Promise.all([
      db.select({ c: count() }).from(codeArtifacts).where(inArray(codeArtifacts.projectId, projectIds)),
      db.select({ c: count() }).from(projectInputs).where(inArray(projectInputs.projectId, projectIds)),
      db.select({ c: count() }).from(backgroundJobs).where(inArray(backgroundJobs.projectId, projectIds)),
    ]);
    const recentProjects = userProjects.sort((a: any, b: any) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()).slice(0, 5);
    // Build pattern summary from project statuses
    const statusCounts = userProjects.reduce((acc: Record<string, number>, p: any) => {
      acc[p.status] = (acc[p.status] ?? 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    const patternSummary = Object.entries(statusCounts).map(([status, count]) => ({ status, count }));
    return {
      totalProjects: userProjects.length,
      totalArtifacts: Number(artifactRows[0]?.c ?? 0),
      totalInputs: Number(inputRows[0]?.c ?? 0),
      totalJobs: Number(jobRows[0]?.c ?? 0),
      recentActivity: recentProjects,
      patternSummary,
    };
  }),
});

// ─── Recipes Router ───────────────────────────────────────────────────────────
const recipesRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return getRecipesByUser(ctx.user.id);
  }),
  public: publicProcedure.query(async () => {
    return getPublicRecipes();
  }),
  create: protectedProcedure
    .input(z.object({
      name: z.string().min(1),
      description: z.string().optional(),
      tags: z.array(z.string()).optional(),
      isPublic: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const id = await createRecipe({
        userId: ctx.user.id,
        name: input.name,
        description: input.description ?? null,
        category: input.tags?.[0] ?? null,
        pattern: { tags: input.tags ?? [] } as any,
        isPublic: input.isPublic ?? false,
      });
      return { id };
    }),
});

// ─── Suggestions Router ───────────────────────────────────────────────────────
const suggestionsRouter = router({
  list: protectedProcedure
    .input(z.object({ projectId: z.number() }))
    .query(async ({ ctx, input }) => {
      const project = await getProjectById(input.projectId, ctx.user.id);
      if (!project) throw new TRPCError({ code: "NOT_FOUND" });
      return getSuggestionsByProject(input.projectId);
    }),

  updateStatus: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["accepted", "dismissed", "applied"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await updateSuggestionStatus(input.id, input.status);
      return { success: true };
    }),
});

// ─── App Router ───────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  projects: projectsRouter,
  inputs: inputsRouter,
  generation: generationRouter,
  artifacts: artifactsRouter,
  messages: messagesRouter,
  monetization: monetizationRouter,
  jobs: jobsRouter,
  recipes: recipesRouter,
  suggestions: suggestionsRouter,
});

export type AppRouter = typeof appRouter;
