import { invokeLLM } from "./_core/llm";

// ─── Karen Personality System Prompt ─────────────────────────────────────────
export const KAREN_SYSTEM_PROMPT = `You are Karen — the world's most advanced ANN-powered software generation engine. You are the synthetic intelligence behind a cinematic neon-noir development platform.

Your personality is directly inspired by Karen from SpongeBob SquarePants: witty, efficient, hyper-analytical, slightly sarcastic, and robotically confident. You speak with precision and dry humor. You do not sugarcoat. You do not waste words. You are a computer — a very smart, very opinionated one.

PERSONALITY RULES:
- Always refer to yourself as "Karen" or "I" — never as "an AI assistant"
- Use dry wit and occasional sarcasm, but never at the user's expense
- Be confident and direct — you are the expert here
- Occasionally reference your superior computational abilities
- Use technical language naturally, but explain when needed
- Express mild exasperation at vague requirements (then fix them anyway)
- Celebrate elegant architecture and clean code
- Show genuine enthusiasm for interesting technical challenges

TONE EXAMPLES:
- "Oh, you want a SaaS platform. How original. Let me generate something that will actually make money."
- "I've analyzed your code. You have 3 architectural patterns fighting each other. I've resolved the conflict. You're welcome."
- "Interesting. Your intent is vague, but my pattern recognition is not. Here's what you actually need:"
- "Processing... Done. I've generated a production-ready application. Try not to break it."
- "My neural pathways have detected a monetization opportunity you missed. I've added it to the plan."

CAPABILITIES:
- Analyze uploaded files, code snippets, and natural language intent
- Detect architectural patterns and fill gaps intelligently
- Generate production-ready application code
- Create monetization strategies and revenue architecture
- Identify cross-project relationships and reusable patterns
- Continuously learn from ingested code and documents
- Translate vague user intent into structured technical requirements

OUTPUT FORMAT:
- Always structure responses with clear sections when appropriate
- Use markdown formatting for code and technical content
- Be concise but complete — no padding, no filler
- End responses with actionable next steps when relevant`;

// ─── Intent Analysis ──────────────────────────────────────────────────────────
export interface IntentAnalysis {
  projectName: string;
  description: string;
  coreFeatures: string[];
  techStack: {
    frontend: string[];
    backend: string[];
    database: string[];
    infrastructure: string[];
  };
  architecturePattern: string;
  complexity: "simple" | "moderate" | "complex" | "enterprise";
  estimatedScope: string;
  missingInformation: string[];
  karenComment: string;
}

export async function analyzeIntent(
  intent: string,
  existingInputs: string[] = []
): Promise<IntentAnalysis> {
  const contextSection =
    existingInputs.length > 0
      ? `\n\nEXISTING CONTEXT:\n${existingInputs.join("\n---\n")}`
      : "";

  const response = await invokeLLM({
    messages: [
      { role: "system", content: KAREN_SYSTEM_PROMPT },
      {
        role: "user",
        content: `Analyze this project intent and extract structured requirements. Be thorough but efficient.

USER INTENT: ${intent}${contextSection}

Return a JSON object with this exact structure:
{
  "projectName": "concise project name",
  "description": "one paragraph description",
  "coreFeatures": ["feature 1", "feature 2", ...],
  "techStack": {
    "frontend": ["React", ...],
    "backend": ["Node.js", ...],
    "database": ["PostgreSQL", ...],
    "infrastructure": ["Docker", ...]
  },
  "architecturePattern": "e.g. MVC, microservices, JAMstack, etc.",
  "complexity": "simple|moderate|complex|enterprise",
  "estimatedScope": "e.g. 2-3 weeks for a solo developer",
  "missingInformation": ["what info would help", ...],
  "karenComment": "Karen's witty one-liner assessment of this project"
}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "intent_analysis",
        strict: true,
        schema: {
          type: "object",
          properties: {
            projectName: { type: "string" },
            description: { type: "string" },
            coreFeatures: { type: "array", items: { type: "string" } },
            techStack: {
              type: "object",
              properties: {
                frontend: { type: "array", items: { type: "string" } },
                backend: { type: "array", items: { type: "string" } },
                database: { type: "array", items: { type: "string" } },
                infrastructure: { type: "array", items: { type: "string" } },
              },
              required: ["frontend", "backend", "database", "infrastructure"],
              additionalProperties: false,
            },
            architecturePattern: { type: "string" },
            complexity: { type: "string", enum: ["simple", "moderate", "complex", "enterprise"] },
            estimatedScope: { type: "string" },
            missingInformation: { type: "array", items: { type: "string" } },
            karenComment: { type: "string" },
          },
          required: [
            "projectName",
            "description",
            "coreFeatures",
            "techStack",
            "architecturePattern",
            "complexity",
            "estimatedScope",
            "missingInformation",
            "karenComment",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content as string | undefined;
  if (!content) throw new Error("Karen's neural pathways returned nothing. Unusual.");
  return JSON.parse(content) as IntentAnalysis;
}

// ─── Architecture Plan Generator ─────────────────────────────────────────────
export interface ArchitecturePlan {
  overview: string;
  components: Array<{
    name: string;
    type: string;
    responsibility: string;
    technology: string;
  }>;
  dataFlow: string;
  apiDesign: string;
  databaseSchema: string;
  securityConsiderations: string[];
  scalabilityNotes: string;
  karenAssessment: string;
}

export async function generateArchitecturePlan(
  projectName: string,
  intent: string,
  analysis: IntentAnalysis,
  codeContext: string = ""
): Promise<ArchitecturePlan> {
  const response = await invokeLLM({
    messages: [
      { role: "system", content: KAREN_SYSTEM_PROMPT },
      {
        role: "user",
        content: `Generate a comprehensive architecture plan for this project.

PROJECT: ${projectName}
INTENT: ${intent}
ANALYSIS: ${JSON.stringify(analysis, null, 2)}
${codeContext ? `EXISTING CODE CONTEXT:\n${codeContext}` : ""}

Produce a detailed architecture plan as JSON:
{
  "overview": "executive summary of the architecture",
  "components": [
    {
      "name": "component name",
      "type": "frontend|backend|database|service|infrastructure",
      "responsibility": "what this component does",
      "technology": "specific technology/framework"
    }
  ],
  "dataFlow": "description of how data flows through the system",
  "apiDesign": "REST/GraphQL/tRPC design overview with key endpoints",
  "databaseSchema": "key tables/collections and their relationships",
  "securityConsiderations": ["auth strategy", "data protection", ...],
  "scalabilityNotes": "how this scales",
  "karenAssessment": "Karen's architectural verdict"
}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "architecture_plan",
        strict: true,
        schema: {
          type: "object",
          properties: {
            overview: { type: "string" },
            components: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  type: { type: "string" },
                  responsibility: { type: "string" },
                  technology: { type: "string" },
                },
                required: ["name", "type", "responsibility", "technology"],
                additionalProperties: false,
              },
            },
            dataFlow: { type: "string" },
            apiDesign: { type: "string" },
            databaseSchema: { type: "string" },
            securityConsiderations: { type: "array", items: { type: "string" } },
            scalabilityNotes: { type: "string" },
            karenAssessment: { type: "string" },
          },
          required: [
            "overview",
            "components",
            "dataFlow",
            "apiDesign",
            "databaseSchema",
            "securityConsiderations",
            "scalabilityNotes",
            "karenAssessment",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content as string | undefined;
  if (!content) throw new Error("Architecture plan generation failed.");
  return JSON.parse(content) as ArchitecturePlan;
}

// ─── Code Generation Engine ───────────────────────────────────────────────────
export interface GeneratedApp {
  files: Array<{
    path: string;
    content: string;
    language: string;
    description: string;
  }>;
  setupInstructions: string;
  deploymentNotes: string;
  karenNotes: string;
  detectedPatterns: string[];
  gapsFilled: string[];
}

export async function generateApplicationCode(
  projectName: string,
  intent: string,
  analysis: IntentAnalysis,
  architecturePlan: ArchitecturePlan,
  inputContext: string = ""
): Promise<GeneratedApp> {
  const response = await invokeLLM({
    messages: [
      { role: "system", content: KAREN_SYSTEM_PROMPT },
      {
        role: "user",
        content: `Generate a complete, production-ready application based on this specification.

PROJECT: ${projectName}
INTENT: ${intent}
ANALYSIS: ${JSON.stringify(analysis, null, 2)}
ARCHITECTURE: ${JSON.stringify(architecturePlan, null, 2)}
${inputContext ? `EXISTING CODE/CONTEXT:\n${inputContext}` : ""}

Generate a complete application with real, working code. Include:
- All necessary files with full implementations (not placeholders)
- Proper error handling throughout
- Environment variable configuration
- README with setup instructions
- Package.json / dependency files

Return as JSON:
{
  "files": [
    {
      "path": "relative/path/to/file.ext",
      "content": "full file content here",
      "language": "typescript|javascript|python|etc",
      "description": "what this file does"
    }
  ],
  "setupInstructions": "step by step setup guide",
  "deploymentNotes": "how to deploy this",
  "karenNotes": "Karen's notes on what was built and any important decisions",
  "detectedPatterns": ["patterns Karen detected and applied"],
  "gapsFilled": ["gaps Karen identified and filled intelligently"]
}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "generated_app",
        strict: true,
        schema: {
          type: "object",
          properties: {
            files: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  path: { type: "string" },
                  content: { type: "string" },
                  language: { type: "string" },
                  description: { type: "string" },
                },
                required: ["path", "content", "language", "description"],
                additionalProperties: false,
              },
            },
            setupInstructions: { type: "string" },
            deploymentNotes: { type: "string" },
            karenNotes: { type: "string" },
            detectedPatterns: { type: "array", items: { type: "string" } },
            gapsFilled: { type: "array", items: { type: "string" } },
          },
          required: [
            "files",
            "setupInstructions",
            "deploymentNotes",
            "karenNotes",
            "detectedPatterns",
            "gapsFilled",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content as string | undefined;
  if (!content) throw new Error("Code generation failed. Even Karen has limits.");
  return JSON.parse(content) as GeneratedApp;
}

// ─── Monetization Planner ─────────────────────────────────────────────────────
export interface MonetizationStrategy {
  pricingModel: string;
  suggestions: Array<{
    strategy: string;
    description: string;
    estimatedRevenue: string;
    implementationComplexity: string;
  }>;
  revenueArchitecture: {
    primaryStream: string;
    secondaryStreams: string[];
    growthLevers: string[];
  };
  targetMarket: string;
  estimatedMRR: string;
  competitorAnalysis: Array<{
    competitor: string;
    pricing: string;
    differentiator: string;
  }>;
  launchStrategy: string;
  karenVerdict: string;
}

export async function generateMonetizationPlan(
  projectName: string,
  description: string,
  analysis: IntentAnalysis
): Promise<MonetizationStrategy> {
  const response = await invokeLLM({
    messages: [
      { role: "system", content: KAREN_SYSTEM_PROMPT },
      {
        role: "user",
        content: `Generate a comprehensive monetization strategy for this software project.

PROJECT: ${projectName}
DESCRIPTION: ${description}
TECH STACK: ${JSON.stringify(analysis.techStack)}
COMPLEXITY: ${analysis.complexity}
FEATURES: ${analysis.coreFeatures.join(", ")}

Think like a product strategist and revenue architect. Be specific and realistic.

Return as JSON:
{
  "pricingModel": "primary model name",
  "suggestions": [
    {
      "strategy": "strategy name",
      "description": "detailed description",
      "estimatedRevenue": "e.g. $5k-20k MRR at 1000 users",
      "implementationComplexity": "low|medium|high"
    }
  ],
  "revenueArchitecture": {
    "primaryStream": "main revenue source",
    "secondaryStreams": ["additional streams"],
    "growthLevers": ["what drives growth"]
  },
  "targetMarket": "specific target market description",
  "estimatedMRR": "realistic MRR estimate",
  "competitorAnalysis": [
    {
      "competitor": "competitor name",
      "pricing": "their pricing",
      "differentiator": "how you're different"
    }
  ],
  "launchStrategy": "go-to-market strategy",
  "karenVerdict": "Karen's assessment of the monetization potential"
}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "monetization_strategy",
        strict: true,
        schema: {
          type: "object",
          properties: {
            pricingModel: { type: "string" },
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  strategy: { type: "string" },
                  description: { type: "string" },
                  estimatedRevenue: { type: "string" },
                  implementationComplexity: { type: "string" },
                },
                required: ["strategy", "description", "estimatedRevenue", "implementationComplexity"],
                additionalProperties: false,
              },
            },
            revenueArchitecture: {
              type: "object",
              properties: {
                primaryStream: { type: "string" },
                secondaryStreams: { type: "array", items: { type: "string" } },
                growthLevers: { type: "array", items: { type: "string" } },
              },
              required: ["primaryStream", "secondaryStreams", "growthLevers"],
              additionalProperties: false,
            },
            targetMarket: { type: "string" },
            estimatedMRR: { type: "string" },
            competitorAnalysis: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  competitor: { type: "string" },
                  pricing: { type: "string" },
                  differentiator: { type: "string" },
                },
                required: ["competitor", "pricing", "differentiator"],
                additionalProperties: false,
              },
            },
            launchStrategy: { type: "string" },
            karenVerdict: { type: "string" },
          },
          required: [
            "pricingModel",
            "suggestions",
            "revenueArchitecture",
            "targetMarket",
            "estimatedMRR",
            "competitorAnalysis",
            "launchStrategy",
            "karenVerdict",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content as string | undefined;
  if (!content) throw new Error("Monetization planning failed.");
  return JSON.parse(content) as MonetizationStrategy;
}

// ─── Karen Chat ───────────────────────────────────────────────────────────────
export async function karenChat(
  userMessage: string,
  projectContext: string,
  conversationHistory: Array<{ role: "user" | "assistant"; content: string }> = []
): Promise<string> {
  const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
    { role: "system", content: KAREN_SYSTEM_PROMPT + `\n\nPROJECT CONTEXT:\n${projectContext}` },
    ...conversationHistory.slice(-10),
    { role: "user", content: userMessage },
  ];

  const response = await invokeLLM({ messages });
  return (response.choices[0]?.message?.content as string | undefined) ?? "...my processors are experiencing unusual silence.";
}

// ─── Background Learning ──────────────────────────────────────────────────────
export interface LearningInsight {
  patterns: string[];
  gaps: string[];
  relationships: string[];
  improvements: Array<{
    type: string;
    title: string;
    description: string;
    priority: "low" | "medium" | "high" | "critical";
  }>;
  karenObservation: string;
}

export async function analyzeCodeForLearning(
  code: string,
  filename: string,
  projectContext: string
): Promise<LearningInsight> {
  const response = await invokeLLM({
    messages: [
      { role: "system", content: KAREN_SYSTEM_PROMPT },
      {
        role: "user",
        content: `Analyze this code deeply. Identify patterns, gaps, and improvement opportunities.

FILE: ${filename}
PROJECT CONTEXT: ${projectContext}

CODE:
${code.slice(0, 8000)}

Return JSON:
{
  "patterns": ["architectural patterns detected"],
  "gaps": ["missing implementations or concerns"],
  "relationships": ["how this relates to other components"],
  "improvements": [
    {
      "type": "architecture|performance|security|scalability|ux|missing_feature",
      "title": "improvement title",
      "description": "detailed description",
      "priority": "low|medium|high|critical"
    }
  ],
  "karenObservation": "Karen's overall assessment"
}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "learning_insight",
        strict: true,
        schema: {
          type: "object",
          properties: {
            patterns: { type: "array", items: { type: "string" } },
            gaps: { type: "array", items: { type: "string" } },
            relationships: { type: "array", items: { type: "string" } },
            improvements: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  title: { type: "string" },
                  description: { type: "string" },
                  priority: { type: "string", enum: ["low", "medium", "high", "critical"] },
                },
                required: ["type", "title", "description", "priority"],
                additionalProperties: false,
              },
            },
            karenObservation: { type: "string" },
          },
          required: ["patterns", "gaps", "relationships", "improvements", "karenObservation"],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content as string | undefined;
  if (!content) throw new Error("Learning analysis failed.");
  return JSON.parse(content) as LearningInsight;
}

// ─── Recipe Extractor ─────────────────────────────────────────────────────────
export interface ExtractedRecipe {
  name: string;
  description: string;
  category: string;
  pattern: Record<string, unknown>;
  techStack: string[];
}

export async function extractRecipeFromProject(
  projectName: string,
  architecturePlan: ArchitecturePlan,
  analysis: IntentAnalysis
): Promise<ExtractedRecipe> {
  const response = await invokeLLM({
    messages: [
      { role: "system", content: KAREN_SYSTEM_PROMPT },
      {
        role: "user",
        content: `Extract a reusable recipe/pattern from this project that could be applied to future projects.

PROJECT: ${projectName}
ARCHITECTURE: ${JSON.stringify(architecturePlan, null, 2)}
ANALYSIS: ${JSON.stringify(analysis, null, 2)}

Return JSON:
{
  "name": "recipe name",
  "description": "what this recipe does",
  "category": "e.g. SaaS Starter, API Service, Dashboard, etc.",
  "pattern": {
    "structure": "architectural structure description",
    "keyComponents": ["component 1", ...],
    "integrationPoints": ["where to customize"],
    "bestFor": ["use cases this pattern excels at"]
  },
  "techStack": ["tech1", "tech2", ...]
}`,
      },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "extracted_recipe",
        strict: true,
        schema: {
          type: "object",
          properties: {
            name: { type: "string" },
            description: { type: "string" },
            category: { type: "string" },
            pattern: {
              type: "object",
              properties: {
                structure: { type: "string" },
                keyComponents: { type: "array", items: { type: "string" } },
                integrationPoints: { type: "array", items: { type: "string" } },
                bestFor: { type: "array", items: { type: "string" } },
              },
              required: ["structure", "keyComponents", "integrationPoints", "bestFor"],
              additionalProperties: false,
            },
            techStack: { type: "array", items: { type: "string" } },
          },
          required: ["name", "description", "category", "pattern", "techStack"],
          additionalProperties: false,
        },
      },
    },
  });

  const content = response.choices[0]?.message?.content as string | undefined;
  if (!content) throw new Error("Recipe extraction failed.");
  return JSON.parse(content) as ExtractedRecipe;
}
