#!/bin/bash

# Neural Brain Startup Script

echo "🧠 Starting AI Self-Builder Neural Brain..."
echo "================================================"

# Check if Python is installed
if ! command -v python &> /dev/null; then
    echo "❌ Python is not installed"
    exit 1
fi

# Check if required packages are installed
echo "Checking dependencies..."
python -c "import fastapi, torch, sentence_transformers" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "⚠️  Installing dependencies..."
    pip install -q -r requirements.txt
fi

# Set environment variables
export ENV=${ENV:-development}
export HOST=${HOST:-0.0.0.0}
export PORT=${PORT:-8001}
export CORS_ORIGINS=${CORS_ORIGINS:-*}

echo "Environment: $ENV"
echo "Host: $HOST"
echo "Port: $PORT"
echo ""

# Start the neural brain
if [ "$ENV" = "production" ]; then
    echo "🚀 Starting in production mode..."
    uvicorn main:app --host $HOST --port $PORT --workers 4
else
    echo "🚀 Starting in development mode..."
    python main.py
fi
