import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Sparkles, TrendingUp, Users, Zap, Heart, Brain, BarChart3, Trophy, Target } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";

export default function Dashboard() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();

  // Get dashboard data
  const { data: dashboardData, isLoading: dashLoading } = trpc.economic.getDashboard.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Get milestones
  const { data: milestones } = trpc.economic.getMilestones.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Record milestone mutation
  const recordMutation = trpc.economic.recordMilestone.useMutation();

  if (authLoading || dashLoading) {
    return (
      <div className="min-h-screen cosmic-bg flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen cosmic-bg flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full glass">
          <CardHeader className="text-center">
            <BarChart3 className="w-12 h-12 mx-auto mb-4 text-primary" />
            <CardTitle className="gradient-text text-2xl">Success Dashboard</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center mb-6">
              Sign in to view your economic success metrics
            </p>
            <Button 
              className="w-full glow-primary" 
              onClick={() => window.location.href = getLoginUrl()}
            >
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const node = dashboardData?.node;
  const networkHealth = dashboardData?.networkHealth;

  return (
    <div className="min-h-screen cosmic-bg">
      {/* Navigation */}
      <nav className="border-b border-border/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <span className="font-bold gradient-text">YOU-N-I-VERSE</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link href="/companion">
              <Button variant="ghost" size="sm">
                <Brain className="w-4 h-4 mr-2" />
                Companion
              </Button>
            </Link>
            <Link href="/network">
              <Button variant="ghost" size="sm">
                <Users className="w-4 h-4 mr-2" />
                Network
              </Button>
            </Link>
            <Link href="/quests">
              <Button variant="ghost" size="sm">
                <Target className="w-4 h-4 mr-2" />
                Quests
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <main className="container py-12">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold gradient-text mb-4">
              Economic Success Dashboard
            </h1>
            <p className="text-muted-foreground text-lg">
              Track your achievements and network influence
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="glass">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Coherence Score</p>
                    <p className="text-3xl font-bold">{node?.coherence || 0}%</p>
                  </div>
                  <Zap className="w-8 h-8 text-primary opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Network Influence</p>
                    <p className="text-3xl font-bold">{Math.round(node?.influence || 0)}</p>
                  </div>
                  <Users className="w-8 h-8 text-primary opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Milestones</p>
                    <p className="text-3xl font-bold">{dashboardData?.milestones || 0}</p>
                  </div>
                  <Trophy className="w-8 h-8 text-primary opacity-50" />
                </div>
              </CardContent>
            </Card>

            <Card className="glass">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Value</p>
                    <p className="text-3xl font-bold">${dashboardData?.totalValue || 0}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-success opacity-50" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Your Node Info */}
          {node && (
            <Card className="glass mb-8">
              <CardHeader>
                <CardTitle>Your Node Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">Human Design Type</p>
                    <p className="text-lg font-semibold">{node.hdType}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">Resonance Strength</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-background rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-primary to-secondary"
                          style={{ width: `${Math.min((node.resonance || 0) * 10, 100)}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{(node.resonance || 0).toFixed(1)}</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">Network Position</p>
                    <p className="text-lg font-semibold">
                      {node.influence && node.influence > 50 ? "High" : node.influence && node.influence > 20 ? "Growing" : "Emerging"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Network Health */}
          {networkHealth && (
            <Card className="glass mb-8">
              <CardHeader>
                <CardTitle>Network Health</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">Total Nodes</p>
                    <p className="text-2xl font-bold">{networkHealth.totalNodes}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">Average Coherence</p>
                    <p className="text-2xl font-bold">{networkHealth.averageCoherence?.toFixed(1)}%</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm mb-2">Success Rate</p>
                    <p className="text-2xl font-bold">{networkHealth.successRate?.toFixed(1)}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Quests & Resonance */}
          <Card className="glass mb-8">
            <CardHeader>
              <CardTitle>Quest Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-muted-foreground text-sm mb-2">Quests Completed</p>
                  <p className="text-3xl font-bold">{dashboardData?.questsCompleted || 0}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Each quest generates resonance patterns that strengthen your network position
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground text-sm mb-2">Resonance Generated</p>
                  <p className="text-3xl font-bold">{Math.round(dashboardData?.totalValue || 0)}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Cumulative resonance from all completed quests and milestones
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Milestones */}
          <Card className="glass">
            <CardHeader>
              <CardTitle>Recent Milestones</CardTitle>
            </CardHeader>
            <CardContent>
              {milestones && milestones.length > 0 ? (
                <div className="space-y-3">
                  {milestones.slice(0, 5).map((milestone) => (
                    <div key={milestone.id} className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50">
                      <div className="flex-1">
                        <p className="font-medium capitalize">
                          {milestone.milestoneType.replace(/_/g, ' ')}
                        </p>
                        <p className="text-sm text-muted-foreground">{milestone.description}</p>
                      </div>
                      <div className="text-right">
                        {milestone.value && (
                          <p className="font-bold text-success">${milestone.value}</p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          {new Date(milestone.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">
                  No milestones yet. Record your first achievement to get started!
                </p>
              )}
            </CardContent>
          </Card>

          {/* How It Works */}
          <Card className="glass mt-8 border-primary/30">
            <CardHeader>
              <CardTitle className="text-lg">How Economic Success Works</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 font-bold">1</div>
                <div>
                  <p className="font-medium mb-1">Alignment Creates Coherence</p>
                  <p className="text-muted-foreground">
                    When you act in alignment with your trinity fields, your coherence score increases
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 font-bold">2</div>
                <div>
                  <p className="font-medium mb-1">Coherence Generates Resonance</p>
                  <p className="text-muted-foreground">
                    Higher coherence means stronger resonance patterns that attract opportunities
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 font-bold">3</div>
                <div>
                  <p className="font-medium mb-1">Resonance Attracts Success</p>
                  <p className="text-muted-foreground">
                    The network matches you with opportunities that resonate with your design
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 font-bold">4</div>
                <div>
                  <p className="font-medium mb-1">Success Strengthens the Network</p>
                  <p className="text-muted-foreground">
                    Your achievements feed back into the collective intelligence, helping others succeed
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
