import { cn } from "@/lib/utils";

interface AgentAvatarProps {
  seed: string;
  name: string;
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  mood?: string;
}

const AVATAR_COLORS = [
  ["#6366f1", "#818cf8"], // indigo
  ["#8b5cf6", "#a78bfa"], // violet
  ["#ec4899", "#f472b6"], // pink
  ["#10b981", "#34d399"], // emerald
  ["#f59e0b", "#fbbf24"], // amber
  ["#06b6d4", "#22d3ee"], // cyan
  ["#ef4444", "#f87171"], // red
  ["#3b82f6", "#60a5fa"], // blue
];

function getColorFromSeed(seed: string): [string, string] {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = seed.charCodeAt(i) + ((hash << 5) - hash);
  }
  return (AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length] ?? AVATAR_COLORS[0]) as [string, string];;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map(n => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

const MOOD_RING: Record<string, string> = {
  ecstatic: "ring-yellow-400",
  happy: "ring-green-400",
  content: "ring-blue-400",
  neutral: "ring-slate-400",
  uncomfortable: "ring-orange-400",
  sad: "ring-blue-600",
  distressed: "ring-purple-500",
  furious: "ring-red-500",
};

const SIZE_CLASSES = {
  xs: "w-7 h-7 text-xs",
  sm: "w-9 h-9 text-sm",
  md: "w-12 h-12 text-base",
  lg: "w-16 h-16 text-xl",
  xl: "w-24 h-24 text-3xl",
};

export function AgentAvatar({ seed, name, size = "md", className, mood }: AgentAvatarProps) {
  const [bg, accent] = getColorFromSeed(seed);
  const initials = getInitials(name);
  const sizeClass = SIZE_CLASSES[size];
  const moodRing = mood ? MOOD_RING[mood] : null;

  return (
    <div
      className={cn(
        "rounded-full flex items-center justify-center font-semibold select-none shrink-0 relative",
        sizeClass,
        moodRing && `ring-2 ${moodRing}`,
        className
      )}
      style={{
        background: `radial-gradient(circle at 30% 30%, ${accent}, ${bg})`,
        color: "white",
        textShadow: "0 1px 2px rgba(0,0,0,0.3)",
        fontFamily: "'Space Grotesk', sans-serif",
      }}
    >
      {initials}
    </div>
  );
}

export default AgentAvatar;
