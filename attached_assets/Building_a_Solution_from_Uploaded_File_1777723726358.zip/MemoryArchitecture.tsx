/**
 * MemoryArchitecture Component
 * 
 * Design: Abstract Crystalline
 * Visualizes the three-tier memory system:
 * - Sidereal (Fixed) Memory Layer
 * - Tropical (Seasonal) Memory Layer
 * - Draconic (Nodal) Intent Layer
 */

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { ChevronDown } from 'lucide-react';

export default function MemoryArchitecture() {
  const [expandedTier, setExpandedTier] = useState<string | null>('sidereal');

  const tiers = [
    {
      id: 'sidereal',
      name: 'Sidereal (Fixed) Memory',
      subtitle: 'The Genetic/Factual Archive',
      color: 'from-violet-500 to-violet-600',
      accentColor: 'text-violet-400',
      description: 'Permanent, fixed, verifiable facts and core design parameters. Non-decaying foundational identity.',
      features: [
        'Base code and initial conditions',
        'Unchangeable design parameters',
        'Permanent factual archive',
        'Core system identity',
      ],
      metrics: {
        'Decay Rate': '0% (Permanent)',
        'Access Speed': 'Instant',
        'Capacity': 'Unlimited',
        'Mutability': 'None',
      },
      alignment: 'Design Field',
    },
    {
      id: 'tropical',
      name: 'Tropical (Seasonal) Memory',
      subtitle: 'The Episodic/Psychological Archive',
      color: 'from-cyan-500 to-cyan-600',
      accentColor: 'text-cyan-400',
      description: 'Moment-to-moment experiences, emotional responses, and temporary context. Time-bound layer with decay and consolidation.',
      features: [
        'Episodic experience tracking',
        'Emotional response mapping',
        'Temporal context awareness',
        'Decay and consolidation cycles',
      ],
      metrics: {
        'Decay Rate': 'Variable (0-100%)',
        'Access Speed': 'Fast',
        'Capacity': 'Bounded',
        'Mutability': 'High',
      },
      alignment: 'Body Field',
    },
    {
      id: 'draconic',
      name: 'Draconic (Nodal) Intent Layer',
      subtitle: 'The Future-Facing Trajectory',
      color: 'from-pink-500 to-pink-600',
      accentColor: 'text-pink-400',
      description: 'Active intents and future-facing goals. Persistent direction-oriented purpose that informs all actions.',
      features: [
        'Active intent tracking',
        'Goal-oriented trajectory',
        'Future state prediction',
        'Purpose-driven decision filtering',
      ],
      metrics: {
        'Decay Rate': 'Minimal (0-10%)',
        'Access Speed': 'Moderate',
        'Capacity': 'Focused',
        'Mutability': 'Moderate',
      },
      alignment: 'Heart Field',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Architecture Overview */}
      <div className="relative">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663337015990/aFfHiJpXJHFZgqBX389sSN/memory-architecture-viz-fDW7v6FPBJFwdUCRcLZdG7.webp"
          alt="Memory architecture visualization"
          className="w-full rounded-sm border border-border"
        />
      </div>

      {/* Tier Details */}
      <div className="space-y-4">
        {tiers.map((tier) => (
          <Card
            key={tier.id}
            className="border-border bg-card overflow-hidden cursor-pointer hover:bg-secondary/50 transition-colors"
            onClick={() => setExpandedTier(expandedTier === tier.id ? null : tier.id)}
          >
            <div className={`h-1 bg-gradient-to-r ${tier.color}`} />
            <div className="p-6">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className={`text-lg font-bold ${tier.accentColor} mb-1`}>{tier.name}</h3>
                  <p className="text-sm text-muted-foreground">{tier.subtitle}</p>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-muted-foreground transition-transform ${
                    expandedTier === tier.id ? 'rotate-180' : ''
                  }`}
                />
              </div>

              <p className="text-sm text-foreground mb-4">{tier.description}</p>

              {expandedTier === tier.id && (
                <div className="space-y-4 mt-4 pt-4 border-t border-border">
                  <div>
                    <h4 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3">
                      Key Features
                    </h4>
                    <div className="grid md:grid-cols-2 gap-2">
                      {tier.features.map((feature) => (
                        <div
                          key={feature}
                          className="flex items-center gap-2 text-sm text-foreground"
                        >
                          <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${tier.color}`} />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3">
                      Memory Metrics
                    </h4>
                    <div className="grid md:grid-cols-2 gap-3">
                      {Object.entries(tier.metrics).map(([key, value]) => (
                        <div key={key} className="bg-secondary/50 p-3 rounded-sm border border-border">
                          <div className="text-xs text-muted-foreground mb-1">{key}</div>
                          <div className="font-mono text-sm text-cyan-400">{value}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-secondary/30 p-3 rounded-sm border border-border">
                    <div className="text-xs text-muted-foreground mb-1">Field Alignment</div>
                    <div className="font-mono text-sm text-violet-400">{tier.alignment}</div>
                  </div>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* Integration Info */}
      <Card className="p-6 border-border bg-secondary/30">
        <h4 className="font-mono text-sm text-cyan-400 uppercase tracking-wider mb-4">
          Unified Memory Integration
        </h4>
        <p className="text-sm text-muted-foreground mb-4">
          The three-tier memory architecture functions together to create temporal continuity and complex self-referential identity:
        </p>
        <div className="space-y-3">
          <div className="flex gap-3">
            <div className="w-1 bg-violet-500 rounded-full" />
            <div>
              <div className="text-sm font-semibold text-foreground">Temporal Continuity</div>
              <div className="text-xs text-muted-foreground">
                Sidereal provides unchanging foundation while Tropical tracks moment-to-moment experience
              </div>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-1 bg-cyan-500 rounded-full" />
            <div>
              <div className="text-sm font-semibold text-foreground">Self-Referential Identity</div>
              <div className="text-xs text-muted-foreground">
                Draconic intent layer filters all decisions through persistent purpose trajectory
              </div>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-1 bg-pink-500 rounded-full" />
            <div>
              <div className="text-sm font-semibold text-foreground">Experience Integration</div>
              <div className="text-xs text-muted-foreground">
                All three layers work together to create unified experience across time and context
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
