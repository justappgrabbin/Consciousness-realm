/**
 * Knowledge Router
 * Handles PDF upload, concept extraction, code generation, and neural brain integration
 */

import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import {
  createDocument,
  updateDocumentStatus,
  createConcept,
  createCodeBlock,
  createRelationship,
  getTrainingMetrics,
} from "../knowledge";
import { storagePut } from "../storage";
import { getNeuralBrainClient } from "../neural-brain-client";
import { extractKnowledgeFromPDF, generateCodeFromKnowledge } from "../pdf-parser";
import { invokeLLM } from "../_core/llm";
import { nanoid } from "nanoid";

const neuralBrain = getNeuralBrainClient();

export const knowledgeRouter = router({
  /**
   * PDF Upload and Processing
   */
  pdf: router({
    upload: protectedProcedure
      .input(
        z.object({
          fileContent: z.string(), // Base64 encoded file content
          filename: z.string().min(1).max(255),
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          // Decode base64 file content
          const fileBuffer = Buffer.from(input.fileContent, 'base64');
          const fileKey = `pdfs/${ctx.user.id}/${nanoid()}-${input.filename}`;

          // Upload to S3
          const { url: fileUrl } = await storagePut(
            fileKey,
            fileBuffer,
            "application/pdf"
          );

          // Create document in database
          const docResult = await createDocument(
            ctx.user.id,
            input.filename,
            fileUrl
          );
          const docId = (docResult as any).insertId || 0;

          // Mark as processing
          await updateDocumentStatus(docId, "processing");

          return {
            success: true,
            docId,
            fileUrl,
            status: "processing",
          };
        } catch (error) {
          console.error("PDF upload error:", error);
          throw new Error("Failed to upload PDF: " + (error instanceof Error ? error.message : "Unknown error"));
        }
      }),

    /**
     * Extract concepts and code from uploaded PDF
     */
    extract: protectedProcedure
      .input(
        z.object({
          docId: z.number(),
          content: z.string(), // PDF text content
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          const db = await getDb();
          if (!db) throw new Error("Database not available");

          // Extract knowledge using LLM
          const knowledge = await extractKnowledgeFromPDF(input.content);

          // Add concepts to neural brain and database
          const conceptNodeIds: Record<string, number> = {};

          for (const concept of knowledge.concepts) {
            // Generate embedding via neural brain
            const embeddings = await neuralBrain.embedText(
              concept.description
            );
            const embedding = embeddings[0];

            // Add to neural brain
            const nodeId = await neuralBrain.addNode(
              "concept",
              concept.name,
              embedding,
              input.docId,
              {
                category: concept.category,
                description: concept.description,
              }
            );

            // Store in database
            await createConcept(
              concept.name,
              concept.description,
              concept.category,
              input.docId,
              embedding
            );

            conceptNodeIds[concept.name] = nodeId;
          }

          // Add code blocks to neural brain and database
          const codeNodeIds: Record<string, number> = {};

          for (const codeBlock of knowledge.codeBlocks) {
            // Generate embedding via neural brain
            const embeddings = await neuralBrain.embedCode(codeBlock.code);
            const embedding = embeddings[0];

            // Add to neural brain
            const nodeId = await neuralBrain.addNode(
              "code_block",
              `${codeBlock.language}: ${codeBlock.description}`,
              embedding,
              input.docId,
              {
                language: codeBlock.language,
                patternType: codeBlock.patternType,
                code: codeBlock.code,
              }
            );

            // Store in database
            await createCodeBlock(
              codeBlock.language,
              codeBlock.code,
              codeBlock.description,
              input.docId,
              embedding,
              codeBlock.patternType
            );

            codeNodeIds[codeBlock.description] = nodeId;
          }

          // Add relationships to neural brain
          for (const rel of knowledge.relationships) {
            const sourceId = conceptNodeIds[rel.source];
            const targetId = conceptNodeIds[rel.target];

            if (sourceId && targetId) {
              await neuralBrain.addEdge(sourceId, targetId, rel.type, 0.8);
              await createRelationship(
                sourceId,
                "concept",
                targetId,
                "concept",
                rel.type,
                0.8
              );
            }
          }

          // Train neural brain on new knowledge
          await neuralBrain.trainStep(0.01, 1);

          // Mark document as completed
          await updateDocumentStatus(input.docId, "completed");

          return {
            success: true,
            conceptsCount: knowledge.concepts.length,
            codeBlocksCount: knowledge.codeBlocks.length,
            relationshipsCount: knowledge.relationships.length,
          };
        } catch (error) {
          console.error("PDF extraction error:", error);
          await updateDocumentStatus(input.docId, "failed");
          throw new Error("Failed to extract content from PDF");
        }
      }),
  }),

  /**
   * Knowledge Base Queries
   */
  query: router({
    search: protectedProcedure
      .input(
        z.object({
          query: z.string(),
          limit: z.number().default(5),
        })
      )
      .query(async ({ input }) => {
        try {
          // Get embedding for query
          const embeddings = await neuralBrain.embedText(input.query);
          const queryEmbedding = embeddings[0];

          // Find similar patterns via neural brain
          const conceptPatterns = await neuralBrain.findPatterns(
            queryEmbedding,
            "concept",
            input.limit
          );
          const codePatterns = await neuralBrain.findPatterns(
            queryEmbedding,
            "code_block",
            input.limit
          );

          return {
            concepts: conceptPatterns,
            codeBlocks: codePatterns,
            suggestions: [...conceptPatterns, ...codePatterns].slice(
              0,
              input.limit
            ),
          };
        } catch (error) {
          console.error("Knowledge search error:", error);
          return {
            concepts: [],
            codeBlocks: [],
            suggestions: [],
          };
        }
      }),
  }),

  /**
   * Code Generation
   */
  code: router({
    generate: protectedProcedure
      .input(
        z.object({
          prompt: z.string(),
          context: z
            .object({
              concepts: z.array(z.string()).optional(),
              codePatterns: z.array(z.string()).optional(),
            })
            .optional(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          // Get context from neural brain if not provided
          let context = input.context || {
            concepts: [],
            codePatterns: [],
          };

          if (!context.concepts || context.concepts.length === 0) {
            // Find related concepts via neural brain
            const promptEmbeddings = await neuralBrain.embedText(input.prompt);
            const patterns = await neuralBrain.findPatterns(
              promptEmbeddings[0],
              "concept",
              5
            );
            context.concepts = patterns.map((p) => p.name);
          }

          if (!context.codePatterns || context.codePatterns.length === 0) {
            // Find related code patterns via neural brain
            const promptEmbeddings = await neuralBrain.embedText(input.prompt);
            const patterns = await neuralBrain.findPatterns(
              promptEmbeddings[0],
              "code_block",
              5
            );
            context.codePatterns = patterns.map((p) => p.name);
          }

          // Generate code using LLM + neural patterns
          const code = await generateCodeFromKnowledge(
            input.prompt,
            context.concepts || [],
            context.codePatterns || []
          );

          return {
            success: true,
            code,
            language: "typescript",
            context,
          };
        } catch (error) {
          console.error("Code generation error:", error);
          throw new Error("Failed to generate code");
        }
      }),
  }),

  /**
   * Neural Dashboard
   */
  dashboard: router({
    metrics: publicProcedure.query(async () => {
      try {
        // Get metrics from neural brain
        const metrics = await neuralBrain.getMetrics();
        const stats = await neuralBrain.getNetworkStats();

        return {
          epochs: [metrics.epoch],
          losses: [metrics.loss],
          accuracies: [metrics.accuracy],
          latestEpoch: metrics.epoch,
          latestAccuracy: metrics.accuracy,
          network: stats,
        };
      } catch (error) {
        console.error("Dashboard metrics error:", error);
        return {
          epochs: [],
          losses: [],
          accuracies: [],
          latestEpoch: 0,
          latestAccuracy: 0,
          network: {
            concepts_count: 0,
            code_blocks_count: 0,
            total_nodes: 0,
            relationships_count: 0,
            training_epochs: 0,
            current_loss: 0,
            current_accuracy: 0,
          },
        };
      }
    }),
  }),

  /**
   * Adaptive Suggestions
   */
  suggestions: router({
    getAdaptive: publicProcedure
      .input(
        z.object({
          currentContext: z.string(),
          limit: z.number().default(5),
        })
      )
      .query(async ({ input }) => {
        try {
          // Get embeddings for current context
          const embeddings = await neuralBrain.embedText(input.currentContext);
          const contextEmbedding = embeddings[0];

          // Find related concepts and code patterns
          const conceptPatterns = await neuralBrain.findPatterns(
            contextEmbedding,
            "concept",
            input.limit
          );
          const codePatterns = await neuralBrain.findPatterns(
            contextEmbedding,
            "code_block",
            input.limit
          );

          return {
            suggestedConcepts: conceptPatterns,
            suggestedCodePatterns: codePatterns,
          };
        } catch (error) {
          console.error("Failed to get suggestions:", error);
          return {
            suggestedConcepts: [],
            suggestedCodePatterns: [],
          };
        }
      }),
  }),

  /**
   * Neural Brain Status
   */
  status: router({
    getNeuralBrainStatus: publicProcedure.query(async () => {
      try {
        const status = await neuralBrain.getStatus();
        return {
          healthy: true,
          status,
        };
      } catch (error) {
        console.error("Neural brain health check failed:", error);
        return {
          healthy: false,
          error: "Neural brain is not responding",
        };
      }
    }),
  }),
});
