/**
 * Neural Brain Client
 * Communicates with the FastAPI neural brain microservice
 */

import axios, { AxiosInstance } from "axios";
import { ENV } from "./_core/env";

interface EmbeddingResponse {
  embeddings: number[][];
  embedding_dim: number;
}

interface PatternMatch {
  node_id: number;
  name: string;
  type: string;
  similarity: number;
}

interface FindPatternsResponse {
  matches: PatternMatch[];
  query_count: number;
}

interface TrainingMetrics {
  epoch: number;
  loss: number;
  accuracy: number;
  concepts_count: number;
  code_blocks_count: number;
  relationships_count: number;
}

class NeuralBrainClient {
  private client: AxiosInstance;
  private baseURL: string;

  constructor() {
    this.baseURL = process.env.NEURAL_BRAIN_URL || "http://localhost:8001";
    
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: 30000,
    });
  }

  /**
   * Check if neural brain is healthy
   */
  async health(): Promise<boolean> {
    try {
      const response = await this.client.get("/health");
      return response.status === 200;
    } catch (error) {
      console.warn("[NeuralBrain] Health check failed:", error);
      return false;
    }
  }

  /**
   * Get neural brain status
   */
  async getStatus() {
    try {
      const response = await this.client.get("/status");
      return response.data;
    } catch (error) {
      console.error("[NeuralBrain] Failed to get status:", error);
      throw error;
    }
  }

  /**
   * Generate embeddings for text
   */
  async embedText(text: string | string[]): Promise<number[][]> {
    try {
      const response = await this.client.post<EmbeddingResponse>(
        "/api/embeddings/text",
        { text }
      );
      return response.data.embeddings;
    } catch (error) {
      console.error("[NeuralBrain] Failed to embed text:", error);
      throw error;
    }
  }

  /**
   * Generate embeddings for code
   */
  async embedCode(code: string | string[]): Promise<number[][]> {
    try {
      const response = await this.client.post<EmbeddingResponse>(
        "/api/embeddings/code",
        { code }
      );
      return response.data.embeddings;
    } catch (error) {
      console.error("[NeuralBrain] Failed to embed code:", error);
      throw error;
    }
  }

  /**
   * Add a node (concept or code block) to the network
   */
  async addNode(
    nodeType: "concept" | "code_block",
    name: string,
    embedding: number[],
    sourceDocId?: number,
    metadata?: Record<string, any>
  ): Promise<number> {
    try {
      const response = await this.client.post("/api/patterns/add-node", {
        node_type: nodeType,
        name,
        embedding,
        source_doc_id: sourceDocId,
        metadata,
      });
      return response.data.node_id;
    } catch (error) {
      console.error("[NeuralBrain] Failed to add node:", error);
      throw error;
    }
  }

  /**
   * Add an edge (relationship) between nodes
   */
  async addEdge(
    sourceId: number,
    targetId: number,
    relationshipType: string,
    confidence: number = 0.5
  ): Promise<void> {
    try {
      await this.client.post("/api/patterns/add-edge", {
        source_id: sourceId,
        target_id: targetId,
        relationship_type: relationshipType,
        confidence,
      });
    } catch (error) {
      console.error("[NeuralBrain] Failed to add edge:", error);
      throw error;
    }
  }

  /**
   * Find isomorphic patterns matching an embedding
   */
  async findPatterns(
    embedding: number[],
    nodeType?: string,
    topK: number = 5
  ): Promise<PatternMatch[]> {
    try {
      const response = await this.client.post<FindPatternsResponse>(
        "/api/patterns/find-patterns",
        {
          embedding,
          node_type: nodeType,
          top_k: topK,
        }
      );
      return response.data.matches;
    } catch (error) {
      console.error("[NeuralBrain] Failed to find patterns:", error);
      throw error;
    }
  }

  /**
   * Get related nodes in the knowledge graph
   */
  async getRelatedNodes(nodeId: number, depth: number = 2) {
    try {
      const response = await this.client.get(
        `/api/patterns/related/${nodeId}?depth=${depth}`
      );
      return response.data.related_nodes;
    } catch (error) {
      console.error("[NeuralBrain] Failed to get related nodes:", error);
      throw error;
    }
  }

  /**
   * Get network statistics
   */
  async getNetworkStats() {
    try {
      const response = await this.client.get("/api/patterns/network-stats");
      return response.data;
    } catch (error) {
      console.error("[NeuralBrain] Failed to get network stats:", error);
      throw error;
    }
  }

  /**
   * Perform a training step
   */
  async trainStep(learningRate: number = 0.01, numSteps: number = 1): Promise<TrainingMetrics> {
    try {
      const response = await this.client.post<TrainingMetrics>(
        "/api/training/step",
        {
          learning_rate: learningRate,
          num_steps: numSteps,
        }
      );
      return response.data;
    } catch (error) {
      console.error("[NeuralBrain] Failed to perform training step:", error);
      throw error;
    }
  }

  /**
   * Get current training metrics
   */
  async getMetrics(): Promise<TrainingMetrics> {
    try {
      const response = await this.client.get<TrainingMetrics>(
        "/api/training/metrics"
      );
      return response.data;
    } catch (error) {
      console.error("[NeuralBrain] Failed to get metrics:", error);
      throw error;
    }
  }

  /**
   * Export the entire network
   */
  async exportNetwork() {
    try {
      const response = await this.client.get("/api/training/network-export");
      return response.data;
    } catch (error) {
      console.error("[NeuralBrain] Failed to export network:", error);
      throw error;
    }
  }
}

// Singleton instance
let neuralBrainClient: NeuralBrainClient | null = null;

export function getNeuralBrainClient(): NeuralBrainClient {
  if (!neuralBrainClient) {
    neuralBrainClient = new NeuralBrainClient();
  }
  return neuralBrainClient;
}

export default NeuralBrainClient;
