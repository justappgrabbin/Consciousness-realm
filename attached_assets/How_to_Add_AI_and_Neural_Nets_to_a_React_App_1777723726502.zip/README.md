# AI Self-Builder React App

An intelligent, self-learning application powered by a Python neural brain that ingests PDFs, learns isomorphic relationships between concepts and code, and generates AI-driven components with adaptive suggestions.

## 🧠 Architecture

The application consists of three integrated components:

### 1. **React Frontend** (`client/`)
- Modern, elegant UI with dark theme
- PDF upload with drag-and-drop
- Chat interface for code generation
- Real-time neural dashboard
- Adaptive suggestions based on learned patterns

### 2. **Express Backend** (`server/`)
- tRPC API with type-safe procedures
- PDF processing and LLM integration
- Knowledge base management
- Neural brain coordination
- MySQL database persistence

### 3. **FastAPI Neural Brain** (`../neural-brain/`)
- Sentence Transformers for semantic embeddings
- Isomorphic network for pattern learning
- Graph-based knowledge representation
- Real-time training and metrics

## 🚀 Quick Start

### Prerequisites
- Node.js 22+
- Python 3.9+
- MySQL 8.0+
- Manus account (for OAuth and LLM access)

### 1. Start the Neural Brain

```bash
cd ../neural-brain
./start.sh
# Or: python main.py
```

The neural brain will initialize on `http://localhost:8001`

### 2. Configure Environment

Create `.env` in the project root:

```env
# Database
DATABASE_URL=mysql://user:password@localhost:3306/ai_self_builder

# OAuth
VITE_APP_ID=your_manus_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# Neural Brain
NEURAL_BRAIN_URL=http://localhost:8001

# LLM
BUILT_IN_FORGE_API_KEY=your_api_key
BUILT_IN_FORGE_API_URL=https://api.manus.im

# Other
JWT_SECRET=your_secret_key
OWNER_OPEN_ID=your_open_id
```

### 3. Install Dependencies

```bash
pnpm install
```

### 4. Setup Database

```bash
pnpm drizzle-kit migrate
```

### 5. Start Development Server

```bash
pnpm dev
```

The app will start on `http://localhost:3000`

## 📚 Features

### PDF Knowledge Ingestion
- Upload PDFs containing concepts, architecture, and code
- LLM-powered extraction of concepts, code blocks, and relationships
- Automatic neural brain training on new knowledge

### Isomorphic Pattern Learning
- Identifies structural equivalences between different domains
- Learns from semantic embeddings and code patterns
- Builds a knowledge graph of relationships

### Intelligent Code Generation
- Generate React components, hooks, and API endpoints
- Context-aware suggestions based on learned patterns
- Informed by both LLM reasoning and neural brain associations

### Neural Dashboard
- Real-time training metrics (loss, accuracy)
- Network statistics (nodes, relationships, epochs)
- Visual charts for monitoring learning progress

### Adaptive Suggestions
- Proactive recommendations based on current context
- Powered by isomorphic pattern matching
- Learns from user interactions

## 🛠️ Development

### Project Structure

```
client/
├── src/
│   ├── pages/          # Page components
│   ├── components/     # Reusable UI components
│   ├── lib/           # tRPC client, utilities
│   ├── hooks/         # Custom React hooks
│   └── contexts/      # React contexts
server/
├── routers/           # tRPC procedure routers
├── db.ts             # Database helpers
├── knowledge.ts      # Knowledge base functions
├── neural-brain-client.ts  # Neural brain HTTP client
├── pdf-parser.ts     # PDF extraction utilities
└── _core/            # Framework utilities
drizzle/
├── schema.ts         # Database schema
└── migrations/       # SQL migrations
```

### Key Files

- `server/routers/knowledge.ts` - Knowledge management procedures
- `server/neural-brain-client.ts` - Neural brain integration
- `server/pdf-parser.ts` - PDF processing and extraction
- `client/src/pages/Home.tsx` - Landing page
- `client/src/pages/ChatInterface.tsx` - Code generation chat
- `client/src/pages/NeuralDashboard.tsx` - Training metrics dashboard
- `client/src/pages/PDFUploader.tsx` - PDF upload interface

### Testing

```bash
# Run tests
pnpm test

# Watch mode
pnpm test:watch

# Coverage
pnpm test:coverage
```

### Type Checking

```bash
pnpm check
```

### Formatting

```bash
pnpm format
```

## 📖 Usage

### 1. Upload a PDF

1. Click "Upload PDF" on the home page
2. Drag and drop or select a PDF file
3. Wait for processing (extraction and neural training)
4. View extracted concepts and code patterns

### 2. Generate Code

1. Go to "Neural Chat"
2. Describe the code you want to generate
3. The neural brain finds related patterns
4. LLM generates code informed by learned patterns
5. Copy and use the generated code

### 3. Monitor Training

1. Go to "Neural Dashboard"
2. View real-time training metrics
3. Monitor accuracy and loss trends
4. See network statistics (concepts, patterns, relationships)

### 4. Get Suggestions

1. Type in the chat interface
2. Adaptive suggestions appear based on context
3. Click suggestions to generate related code

## 🔌 API Endpoints

### tRPC Procedures

**PDF Management**:
- `knowledge.pdf.upload` - Upload PDF to S3
- `knowledge.pdf.extract` - Extract and process knowledge

**Code Generation**:
- `knowledge.code.generate` - Generate code with neural context

**Search & Suggestions**:
- `knowledge.query.search` - Search knowledge base
- `knowledge.suggestions.getAdaptive` - Get adaptive suggestions

**Monitoring**:
- `knowledge.dashboard.metrics` - Get training metrics
- `knowledge.status.getNeuralBrainStatus` - Check neural brain health

### Neural Brain REST API

See `/home/ubuntu/neural-brain/README.md` for complete API documentation.

## 🧪 Testing

### Unit Tests

```bash
# Run all tests
pnpm test

# Run specific test file
pnpm test server/routers/knowledge.test.ts

# Watch mode
pnpm test:watch
```

### Integration Testing

1. Start neural brain: `cd ../neural-brain && ./start.sh`
2. Start app: `pnpm dev`
3. Upload a PDF and verify:
   - Concepts are extracted
   - Code blocks are identified
   - Neural brain receives embeddings
   - Dashboard shows metrics

## 🚀 Deployment

### Build

```bash
pnpm build
```

### Production

```bash
# Set environment
export ENV=production

# Start server
pnpm start
```

### Docker (Optional)

See `docker-compose.yml` for containerized deployment.

## 📊 Performance

- **Embedding Generation**: ~1ms per text (CPU)
- **Pattern Matching**: O(n) similarity search
- **Training Step**: O(e) where e = edges

For production with millions of nodes, consider:
- Vector database (Pinecone, Weaviate, Milvus)
- GPU acceleration for embeddings
- Caching layer (Redis)
- Database indexing

## 🔒 Security

- OAuth 2.0 authentication via Manus
- JWT session tokens
- Secure S3 file storage
- SQL injection prevention via Drizzle ORM
- CORS configuration
- Environment variable secrets

## 📝 License

MIT

## 🤝 Contributing

1. Create a feature branch
2. Make your changes
3. Add tests for new features
4. Run `pnpm check` and `pnpm test`
5. Submit a pull request

## 📞 Support

For issues or questions:
1. Check the logs in both services
2. Verify environment variables
3. Ensure neural brain is running
4. Review integration guide at `/home/ubuntu/INTEGRATION_GUIDE.md`

## 🎯 Roadmap

- [ ] Knowledge graph visualization (D3.js)
- [ ] User favorites and history
- [ ] Code sharing and collaboration
- [ ] Advanced pattern discovery
- [ ] GPU support for neural brain
- [ ] Vector database integration
- [ ] Mobile app
- [ ] API rate limiting and quotas

## 🙏 Acknowledgments

- Manus platform for OAuth and LLM integration
- Sentence Transformers for embeddings
- React and TypeScript communities
- shadcn/ui for beautiful components
