"""
Synthia LLaMA Brain - Local AI Intelligence Layer
Adds consciousness-aware decision making to the code synthesizer

Supports: TinyLlama (1.1B), Phi-2 (2.7B), CodeLlama-7B
All run locally, no API keys needed
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json

class SynthiaAI:
    """
    Local LLaMA-powered intelligence for Synthia
    Makes smart decisions about code organization and integration
    """
    
    def __init__(self, model_name: str = "TinyLlama/TinyLlama-1.1B-Chat-v1.0", 
                 device: str = "auto"):
        """
        Initialize the AI brain
        
        Args:
            model_name: HuggingFace model ID
                - "TinyLlama/TinyLlama-1.1B-Chat-v1.0" (fastest, 1.1GB)
                - "microsoft/phi-2" (smarter, 2.7GB)
                - "codellama/CodeLlama-7b-Instruct-hf" (best for code, 7GB)
            device: "auto", "cpu", "cuda", or "mps" (Mac M1/M2)
        """
        self.model_name = model_name
        self.device = device
        self.model = None
        self.tokenizer = None
        self.loaded = False
        
        print(f"🧠 Synthia AI initializing with {model_name}")
        print("   (Model will load on first use)")
    
    def _lazy_load(self):
        """Load model only when first needed to save memory"""
        if self.loaded:
            return
        
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            import torch
            
            print(f"📥 Loading {self.model_name}...")
            print("   (First run will download ~1-7GB depending on model)")
            
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_name,
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                device_map=self.device,
                low_cpu_mem_usage=True
            )
            
            self.loaded = True
            print("✅ Model loaded successfully")
            
        except ImportError:
            print("❌ Transformers not installed!")
            print("   Install with: pip install transformers torch")
            raise
        except Exception as e:
            print(f"❌ Failed to load model: {e}")
            print("   Try a smaller model or check your GPU/RAM")
            raise
    
    def _generate(self, prompt: str, max_tokens: int = 256, 
                  temperature: float = 0.7) -> str:
        """Core generation function"""
        self._lazy_load()
        
        # Format prompt for chat models
        if "TinyLlama" in self.model_name:
            formatted_prompt = f"<|system|>\nYou are Synthia, an AI that understands code structure and consciousness systems.</s>\n<|user|>\n{prompt}</s>\n<|assistant|>"
        elif "phi" in self.model_name.lower():
            formatted_prompt = f"Instruct: {prompt}\nOutput:"
        else:
            formatted_prompt = prompt
        
        inputs = self.tokenizer(formatted_prompt, return_tensors="pt").to(self.model.device)
        
        outputs = self.model.generate(
            **inputs,
            max_new_tokens=max_tokens,
            temperature=temperature,
            do_sample=True,
            top_p=0.95,
            repetition_penalty=1.1
        )
        
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract just the response part
        if "<|assistant|>" in response:
            response = response.split("<|assistant|>")[-1].strip()
        elif "Output:" in response:
            response = response.split("Output:")[-1].strip()
        
        return response
    
    def suggest_merge_strategy(self, files: List[Path]) -> Dict:
        """
        Analyze files and suggest best stitching strategy
        
        Returns:
            {
                'strategy': 'namespace' | 'merge' | 'bridge',
                'confidence': 0.0-1.0,
                'reasoning': str,
                'warnings': List[str]
            }
        """
        file_info = []
        for f in files[:5]:  # Limit to first 5 for prompt size
            try:
                content = f.read_text(encoding='utf-8', errors='ignore')[:500]
                file_info.append(f"{f.name}: {len(content)} chars")
            except:
                file_info.append(f"{f.name}: unreadable")
        
        prompt = f"""Analyze these Python files and suggest the best integration strategy:

Files to integrate:
{chr(10).join(file_info)}

Choose ONE strategy:
1. NAMESPACE - Wrap each file in isolated class (safest, no conflicts)
2. MERGE - Intelligently combine into one file (requires conflict resolution)
3. BRIDGE - Dynamic loader with unified API (most flexible)

Respond in JSON format:
{{
    "strategy": "namespace|merge|bridge",
    "confidence": 0.8,
    "reasoning": "Brief explanation",
    "warnings": ["potential issue 1", "potential issue 2"]
}}
"""
        
        try:
            response = self._generate(prompt, max_tokens=200)
            
            # Try to parse JSON from response
            import re
            json_match = re.search(r'\{[^}]+\}', response, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
            else:
                # Fallback if no JSON
                result = {
                    'strategy': 'namespace',
                    'confidence': 0.5,
                    'reasoning': response[:200],
                    'warnings': ['Could not parse structured response']
                }
            
            return result
            
        except Exception as e:
            return {
                'strategy': 'namespace',  # Safe default
                'confidence': 0.3,
                'reasoning': f"AI error: {e}",
                'warnings': ['Using safe default strategy']
            }
    
    def resolve_naming_conflict(self, name: str, contexts: List[str]) -> List[str]:
        """
        Suggest better names when multiple files have same function/class
        
        Args:
            name: The conflicting name (e.g., "calculate")
            contexts: List of context strings from each file
        
        Returns:
            List of suggested unique names, one per context
        """
        contexts_str = "\n".join([f"{i+1}. {ctx[:100]}" for i, ctx in enumerate(contexts[:3])])
        
        prompt = f"""Two or more files have a function/class named "{name}".
Suggest unique, descriptive names based on context:

{contexts_str}

Respond with JSON array of new names:
["descriptive_name_1", "descriptive_name_2", ...]
"""
        
        try:
            response = self._generate(prompt, max_tokens=100)
            
            import re
            json_match = re.search(r'\[.+\]', response, re.DOTALL)
            if json_match:
                suggestions = json.loads(json_match.group())
                return suggestions
            else:
                # Fallback: simple prefixing
                return [f"variant_{i+1}_{name}" for i in range(len(contexts))]
                
        except Exception as e:
            print(f"⚠️  AI naming failed: {e}")
            return [f"version_{i+1}_{name}" for i in range(len(contexts))]
    
    def explain_resonance(self, file1_name: str, file1_content: str,
                         file2_name: str, file2_content: str) -> Dict:
        """
        Explain how two files resonate in consciousness framework terms
        Uses your 9-body system language (Mind, Heart, Body, etc.)
        
        Returns:
            {
                'resonance_score': 0.0-1.0,
                'field_alignment': str,
                'explanation': str,
                'merge_recommended': bool
            }
        """
        # Truncate content
        content1 = file1_content[:300]
        content2 = file2_content[:300]
        
        prompt = f"""Analyze how these two code modules resonate in the 9-body consciousness system:

FILE 1: {file1_name}
{content1}

FILE 2: {file2_name}
{content2}

Consider:
- Do they serve the same consciousness field? (Mind, Heart, Body, Soul, Spirit, Shadow, Light, Void, Unity)
- Is there harmonic alignment or dissonance?
- Should they merge or remain separate?

Respond in JSON:
{{
    "resonance_score": 0.7,
    "field_alignment": "Mind-Heart bridge",
    "explanation": "Both process emotional data but from different perspectives",
    "merge_recommended": true
}}
"""
        
        try:
            response = self._generate(prompt, max_tokens=200)
            
            import re
            json_match = re.search(r'\{[^}]+\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            else:
                return {
                    'resonance_score': 0.5,
                    'field_alignment': 'Unknown',
                    'explanation': response[:200],
                    'merge_recommended': False
                }
        
        except Exception as e:
            return {
                'resonance_score': 0.0,
                'field_alignment': 'Error',
                'explanation': str(e),
                'merge_recommended': False
            }
    
    def generate_bridge_code(self, module_names: List[str], 
                            module_purposes: List[str]) -> str:
        """
        Generate integration bridge code for multiple modules
        
        Args:
            module_names: ['chart_calc', 'resonance_engine', ...]
            module_purposes: ['Calculate charts', 'Compute waveforms', ...]
        
        Returns:
            Python code as string
        """
        modules_info = "\n".join([
            f"- {name}: {purpose}" 
            for name, purpose in zip(module_names, module_purposes)
        ])
        
        prompt = f"""Generate Python code for a bridge class that integrates these modules:

{modules_info}

Requirements:
- Create a unified interface
- Allow calling functions from any module
- Include error handling
- Add docstrings

Write clean, working Python code:
"""
        
        try:
            response = self._generate(prompt, max_tokens=400, temperature=0.3)
            
            # Extract code block if present
            import re
            code_match = re.search(r'```python\n(.*?)```', response, re.DOTALL)
            if code_match:
                return code_match.group(1)
            
            # Return full response if no code block
            return response
            
        except Exception as e:
            # Return template on failure
            return f'''class IntegrationBridge:
    """Auto-generated bridge (AI generation failed: {e})"""
    
    def __init__(self):
        self.modules = {{}}
        # TODO: Load modules - {', '.join(module_names)}
    
    def call(self, module_name, function_name, *args, **kwargs):
        """Call a function from any module"""
        module = self.modules.get(module_name)
        if module and hasattr(module, function_name):
            return getattr(module, function_name)(*args, **kwargs)
        raise AttributeError(f"{{function_name}} not found in {{module_name}}")
'''
    
    def analyze_consciousness_system(self, files: List[Path]) -> Dict:
        """
        High-level analysis of how files map to 9-body consciousness fields
        
        Returns:
            {
                'field_mapping': {'mind': [...], 'heart': [...], ...},
                'coherence_score': 0.0-1.0,
                'recommendations': [...]
            }
        """
        file_summaries = []
        for f in files[:10]:
            try:
                content = f.read_text(encoding='utf-8', errors='ignore')
                # Extract just imports and first few lines
                lines = content.split('\n')[:15]
                summary = '\n'.join(lines)
                file_summaries.append(f"{f.name}:\n{summary}\n")
            except:
                file_summaries.append(f"{f.name}: [unreadable]\n")
        
        prompt = f"""Map these Python files to the 9-body consciousness system:

FIELDS: Mind, Heart, Body, Soul, Spirit, Shadow, Light, Void, Unity

FILES:
{''.join(file_summaries)}

Respond in JSON:
{{
    "field_mapping": {{
        "mind": ["file1.py", "file2.py"],
        "heart": ["file3.py"],
        ...
    }},
    "coherence_score": 0.8,
    "recommendations": [
        "Move file X to Y field",
        "Merge files A and B - same resonance"
    ]
}}
"""
        
        try:
            response = self._generate(prompt, max_tokens=400)
            
            import re
            json_match = re.search(r'\{.+\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            
            return {
                'field_mapping': {},
                'coherence_score': 0.0,
                'recommendations': ['Could not analyze - response not in JSON format']
            }
            
        except Exception as e:
            return {
                'field_mapping': {},
                'coherence_score': 0.0,
                'recommendations': [f'Analysis failed: {e}']
            }
    
    def chat(self, message: str) -> str:
        """
        General chat interface - ask Synthia anything
        Useful for getting advice during organization
        """
        prompt = f"""You are Synthia, an AI assistant for the Synthesis Intelligence Field framework.
You help developers organize code into consciousness-based module systems.

User: {message}

Synthia:"""
        
        try:
            return self._generate(prompt, max_tokens=300)
        except Exception as e:
            return f"Sorry, I encountered an error: {e}"


# Convenience functions for quick usage
def quick_strategy(files: List[Path], model: str = "TinyLlama/TinyLlama-1.1B-Chat-v1.0") -> str:
    """Quick strategy suggestion without full initialization"""
    ai = SynthiaAI(model_name=model)
    result = ai.suggest_merge_strategy(files)
    return result['strategy']


def quick_rename(name: str, contexts: List[str], 
                model: str = "TinyLlama/TinyLlama-1.1B-Chat-v1.0") -> List[str]:
    """Quick name suggestions"""
    ai = SynthiaAI(model_name=model)
    return ai.resolve_naming_conflict(name, contexts)


# Example usage and testing
if __name__ == "__main__":
    print("🌟 Synthia AI Brain - Local Intelligence\n")
    
    # Check if transformers is installed
    try:
        import transformers
        import torch
        print("✅ Dependencies installed")
        print(f"   PyTorch: {torch.__version__}")
        print(f"   Transformers: {transformers.__version__}")
        print(f"   CUDA available: {torch.cuda.is_available()}")
        
        # Initialize
        print("\n🧠 Initializing Synthia AI...")
        ai = SynthiaAI()
        
        # Test chat
        print("\n💬 Testing chat interface:")
        response = ai.chat("What's the best way to organize a consciousness system?")
        print(f"Synthia: {response[:200]}...")
        
        print("\n✅ Synthia AI is ready!")
        print("\nUsage:")
        print("  ai = SynthiaAI()")
        print("  ai.suggest_merge_strategy([file1, file2])")
        print("  ai.resolve_naming_conflict('calculate', [ctx1, ctx2])")
        print("  ai.explain_resonance('mind.py', content1, 'heart.py', content2)")
        
    except ImportError as e:
        print("❌ Missing dependencies!")
        print("\nInstall with:")
        print("  pip install transformers torch")
        print("\nOptional (for GPU acceleration):")
        print("  pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118")
        print(f"\nError: {e}")
