import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Sparkles, Brain, Heart, Zap, ArrowRight, MapPin } from "lucide-react";
import { Link, useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Calculate() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  const [birthDate, setBirthDate] = useState("");
  const [birthTime, setBirthTime] = useState("");
  const [location, setLocationInput] = useState("");
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [locationSearching, setLocationSearching] = useState(false);
  
  const calculateMutation = trpc.node.calculate.useMutation({
    onSuccess: () => {
      setLocation("/companion");
    }
  });

  // Simple geocoding using a free API
  const searchLocation = async () => {
    if (!location.trim()) return;
    setLocationSearching(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}`
      );
      const data = await response.json();
      if (data && data.length > 0) {
        setLatitude(parseFloat(data[0].lat));
        setLongitude(parseFloat(data[0].lon));
        setLocationInput(data[0].display_name);
      }
    } catch (error) {
      console.error("Location search failed:", error);
    }
    setLocationSearching(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!birthDate || !birthTime || latitude === null || longitude === null) {
      return;
    }
    
    calculateMutation.mutate({
      birthDate,
      birthTime,
      latitude,
      longitude,
      location
    });
  };

  const canSubmit = birthDate && birthTime && latitude !== null && longitude !== null;

  if (authLoading) {
    return (
      <div className="min-h-screen cosmic-bg flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen cosmic-bg flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full glass">
          <CardHeader className="text-center">
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-primary" />
            <CardTitle className="gradient-text text-2xl">Begin Your Journey</CardTitle>
            <CardDescription>
              Sign in to calculate your Trinity Fields and join the resonance network
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              className="w-full glow-primary" 
              onClick={() => window.location.href = getLoginUrl()}
            >
              Sign In to Continue
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen cosmic-bg">
      {/* Navigation */}
      <nav className="border-b border-border/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <span className="font-bold gradient-text">YOU-N-I-VERSE</span>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Welcome, {user?.name}</span>
          </div>
        </div>
      </nav>

      <main className="container py-12">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold gradient-text mb-4">
              Calculate Your Trinity Fields
            </h1>
            <p className="text-muted-foreground text-lg">
              Enter your birth data to generate your unique resonance signature and join the network
            </p>
          </div>

          {/* Trinity Field Explanation */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
            <Card className="glass border-2 body-field">
              <CardContent className="pt-6 text-center">
                <Zap className="w-8 h-8 mx-auto mb-2" style={{ color: 'oklch(0.6 0.22 25)' }} />
                <h3 className="font-semibold mb-1">Body Field</h3>
                <p className="text-xs text-muted-foreground">
                  Design (-88° arc) - Your unconscious, physical design
                </p>
              </CardContent>
            </Card>
            <Card className="glass border-2 mind-field">
              <CardContent className="pt-6 text-center">
                <Brain className="w-8 h-8 mx-auto mb-2" style={{ color: 'oklch(0.6 0.2 220)' }} />
                <h3 className="font-semibold mb-1">Mind Field</h3>
                <p className="text-xs text-muted-foreground">
                  Sidereal (-24°) - Your conscious mental processing
                </p>
              </CardContent>
            </Card>
            <Card className="glass border-2 heart-field">
              <CardContent className="pt-6 text-center">
                <Heart className="w-8 h-8 mx-auto mb-2" style={{ color: 'oklch(0.6 0.22 320)' }} />
                <h3 className="font-semibold mb-1">Heart Field</h3>
                <p className="text-xs text-muted-foreground">
                  Draconic (Node rotation) - Your soul purpose
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Birth Data Form */}
          <Card className="glass">
            <CardHeader>
              <CardTitle>Birth Information</CardTitle>
              <CardDescription>
                Your exact birth data determines your unique position in the resonance network
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="birthDate">Birth Date</Label>
                    <Input
                      id="birthDate"
                      type="date"
                      value={birthDate}
                      onChange={(e) => setBirthDate(e.target.value)}
                      className="bg-input"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="birthTime">Birth Time</Label>
                    <Input
                      id="birthTime"
                      type="time"
                      value={birthTime}
                      onChange={(e) => setBirthTime(e.target.value)}
                      className="bg-input"
                      required
                    />
                    <p className="text-xs text-muted-foreground">
                      As accurate as possible for precise calculations
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Birth Location</Label>
                  <div className="flex gap-2">
                    <Input
                      id="location"
                      type="text"
                      placeholder="City, Country"
                      value={location}
                      onChange={(e) => setLocationInput(e.target.value)}
                      className="bg-input flex-1"
                      required
                    />
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={searchLocation}
                      disabled={locationSearching || !location.trim()}
                    >
                      {locationSearching ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <MapPin className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                  {latitude !== null && longitude !== null && (
                    <p className="text-xs text-success flex items-center gap-1">
                      <span className="status-dot success w-2 h-2" />
                      Coordinates: {latitude.toFixed(4)}°, {longitude.toFixed(4)}°
                    </p>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full glow-primary"
                  disabled={!canSubmit || calculateMutation.isPending}
                >
                  {calculateMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Calculating Trinity Fields...
                    </>
                  ) : (
                    <>
                      Calculate & Enter Network
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>

                {calculateMutation.error && (
                  <p className="text-destructive text-sm text-center">
                    {calculateMutation.error.message}
                  </p>
                )}
              </form>
            </CardContent>
          </Card>

          {/* Privacy Notice */}
          <p className="text-center text-xs text-muted-foreground mt-8">
            Your birth data generates a unique graph address. Personal information stays private 
            while contributing anonymized resonance patterns to the collective intelligence.
          </p>
        </div>
      </main>
    </div>
  );
}
