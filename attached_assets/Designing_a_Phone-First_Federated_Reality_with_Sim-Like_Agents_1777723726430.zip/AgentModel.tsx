import { useRef, useEffect, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { Group, Vector3 } from "three";
import { trpc } from "@/lib/trpc";

interface AgentModelProps {
  agent: any;
  index: number;
  totalAgents: number;
  onClick: () => void;
}

export default function AgentModel({ agent, index, totalAgents, onClick }: AgentModelProps) {
  const groupRef = useRef<Group>(null);
  const [mood, setMood] = useState<any>(null);
  const [targetPosition, setTargetPosition] = useState<Vector3>(new Vector3());
  const [currentPosition, setCurrentPosition] = useState<Vector3>(new Vector3());
  const [isMoving, setIsMoving] = useState(false);

  const { data: moodData } = trpc.agents.mood.useQuery({ id: agent.id }, {
    refetchInterval: 8000,
  });

  useEffect(() => {
    if (moodData) {
      setMood(moodData);
    }
  }, [moodData]);

  // Distribute agents in a circle around the district center
  useEffect(() => {
    const angle = (index / Math.max(totalAgents, 1)) * Math.PI * 2;
    const radius = 8 + Math.random() * 3;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;
    const newPos = new Vector3(x, 0.5, z);
    setTargetPosition(newPos);
    if (currentPosition.length() === 0) {
      setCurrentPosition(newPos.clone());
    }
  }, [index, totalAgents]);

  // Animate movement towards target
  useFrame(() => {
    if (!groupRef.current) return;

    const speed = 0.05;
    const distance = currentPosition.distanceTo(targetPosition);

    if (distance > 0.1) {
      const direction = targetPosition.clone().sub(currentPosition).normalize();
      currentPosition.add(direction.multiplyScalar(speed));
      setIsMoving(true);
    } else {
      setIsMoving(false);
      // Occasionally pick a new random target
      if (Math.random() < 0.02) {
        const angle = Math.random() * Math.PI * 2;
        const radius = 6 + Math.random() * 4;
        setTargetPosition(new Vector3(Math.cos(angle) * radius, 0.5, Math.sin(angle) * radius));
      }
    }

    groupRef.current.position.copy(currentPosition);

    // Gentle bobbing animation
    groupRef.current.position.y += Math.sin(Date.now() * 0.001 + index) * 0.01;

    // Rotate towards movement direction
    if (isMoving) {
      const direction = targetPosition.clone().sub(currentPosition);
      if (direction.length() > 0) {
        const angle = Math.atan2(direction.x, direction.z);
        groupRef.current.rotation.y = angle;
      }
    }
  });

  // Get mood color
  const getMoodColor = () => {
    if (!mood) return 0x6366f1;
    const moodColors: Record<string, number> = {
      ecstatic: 0xfbbf24,
      happy: 0x34d399,
      content: 0x60a5fa,
      neutral: 0x9ca3af,
      uncomfortable: 0xf97316,
      sad: 0x8b5cf6,
      distressed: 0xef4444,
      furious: 0xdc2626,
    };
    return moodColors[mood.mood] ?? 0x6366f1;
  };

  const moodColor = getMoodColor();

  return (
    <group ref={groupRef} onClick={onClick}>
      {/* Agent body (simple capsule) */}
      <mesh castShadow receiveShadow>
        <capsuleGeometry args={[0.3, 1, 8, 16]} />
        <meshStandardMaterial
          color={moodColor}
          emissive={moodColor}
          emissiveIntensity={0.3}
          metalness={0.3}
          roughness={0.7}
        />
      </mesh>

      {/* Agent head */}
      <mesh position={[0, 0.7, 0]} castShadow receiveShadow>
        <sphereGeometry args={[0.25, 16, 16]} />
        <meshStandardMaterial
          color={moodColor}
          emissive={moodColor}
          emissiveIntensity={0.4}
          metalness={0.2}
          roughness={0.6}
        />
      </mesh>

      {/* Mood aura (glowing ring) */}
      <mesh position={[0, 0.5, 0]} rotation={[Math.PI / 2.5, 0, 0]}>
        <torusGeometry args={[0.6, 0.08, 16, 32]} />
        <meshStandardMaterial
          color={moodColor}
          emissive={moodColor}
          emissiveIntensity={0.6}
          transparent
          opacity={0.6}
        />
      </mesh>

      {/* Activity indicator (small rotating cube above head) */}
      <mesh position={[0, 1.2, 0]} scale={0.15}>
        <boxGeometry />
        <meshStandardMaterial
          color={0x818cf8}
          emissive={0x6366f1}
          emissiveIntensity={0.8}
        />
      </mesh>

      {/* Name label (positioned above) */}
      <group position={[0, 1.5, 0]}>
        <mesh>
          <planeGeometry args={[1.2, 0.3]} />
          <meshStandardMaterial
            color={0x000000}
            transparent
            opacity={0.7}
          />
        </mesh>
      </group>
    </group>
  );
}
