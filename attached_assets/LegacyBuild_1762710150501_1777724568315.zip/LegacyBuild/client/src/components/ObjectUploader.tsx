import { useRef, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface ObjectUploaderProps {
  maxNumberOfFiles?: number;
  maxFileSize?: number;
  onGetUploadParameters: () => Promise<{
    method: "PUT";
    url: string;
  }>;
  onComplete?: (result: { successful: Array<{ name: string; type: string; size: number; uploadURL: string }> }) => void;
  buttonClassName?: string;
  children: ReactNode;
}

export function ObjectUploader({
  maxNumberOfFiles = 10,
  maxFileSize = 104857600,
  onGetUploadParameters,
  onComplete,
  buttonClassName,
  children,
}: ObjectUploaderProps) {
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    
    if (selectedFiles.length === 0) return;
    
    if (selectedFiles.length > maxNumberOfFiles) {
      toast({
        title: "Too many files",
        description: `Maximum ${maxNumberOfFiles} files allowed`,
        variant: "destructive",
      });
      return;
    }
    
    const tooLargeFiles = selectedFiles.filter(f => f.size > maxFileSize);
    if (tooLargeFiles.length > 0) {
      toast({
        title: "Files too large",
        description: `Some files exceed ${(maxFileSize / 1024 / 1024).toFixed(0)}MB limit`,
        variant: "destructive",
      });
      return;
    }
    
    setUploading(true);
    const successful: Array<{ name: string; type: string; size: number; uploadURL: string }> = [];
    
    try {
      for (const file of selectedFiles) {
        const { url } = await onGetUploadParameters();
        
        const response = await fetch(url, {
          method: "PUT",
          body: file,
          headers: {
            "Content-Type": file.type || "application/octet-stream",
          },
        });
        
        if (response.ok) {
          successful.push({
            name: file.name,
            type: file.type,
            size: file.size,
            uploadURL: url,
          });
        }
      }
      
      onComplete?.({ successful });
      
      toast({
        title: "Upload complete",
        description: `${successful.length} file(s) uploaded successfully`,
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "There was an error uploading your files",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div>
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleFileSelect}
        accept=".js,.jsx,.ts,.tsx,.py,.pdf,.epub,.zip,.txt,.md,.json,.css,.html,.java,.cpp,.c,.go,.rs,.rb,.php"
      />
      <Button 
        onClick={() => fileInputRef.current?.click()} 
        className={buttonClassName} 
        disabled={uploading}
        data-testid="button-upload-files"
      >
        {uploading ? "Uploading..." : children}
      </Button>
    </div>
  );
}
