"""
Intelligence Engine - Part 2: Prediction, Learning, and Governance

This file contains:
    Layer 3: Prediction - Forecasts emergence
    Layer 4: Learning - Adapts from outcomes (KEY LAYER)
    Layer 5: Governance - HD timing gates
"""

from intelligence_engine import (
    ComponentSemantics, CausalRelationship, CausalType, 
    EmergencePrediction, LearningOutcome, Glyph,
    SemanticComponentAnalyzer, CausalInferenceEngine
)
from typing import Dict, List, Set, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import json
import hashlib


# ============================================================================
# LAYER 3: PREDICTION - Emergence Forecasting
# ============================================================================

class EmergencePredictor:
    """
    Predicts emergent properties BEFORE components are assembled.
    
    This is CRITICAL intelligence:
    - Predict capabilities that emerge from interaction
    - Predict failure modes before they happen
    - Predict coherence issues
    - Predict resonance patterns
    """
    
    def __init__(self, causal_engine, learning_layer=None):
        self.causal_engine = causal_engine
        self.learning_layer = learning_layer
    
    def predict_emergence(self, 
                         component_semantics: List[ComponentSemantics],
                         component_ids: List[str]) -> EmergencePrediction:
        """What will emerge when these components interact?"""
        
        prediction = EmergencePrediction()
        
        # Build semantic map
        sem_map = dict(zip(component_ids, component_semantics))
        
        # 1. Predict emergent capabilities
        prediction.capabilities = self._predict_capabilities(
            sem_map, component_ids
        )
        
        # 2. Predict failure modes
        prediction.failure_modes = self._predict_failures(
            sem_map, component_ids
        )
        
        # 3. Predict coherence
        prediction.coherence_score = self._predict_coherence(
            sem_map, component_ids
        )
        
        # 4. Predict resonance patterns
        prediction.resonance_patterns = self._predict_resonance(
            sem_map, component_ids
        )
        
        # 5. Check with learning layer
        if self.learning_layer:
            learned_insights = self.learning_layer.predict_from_history(
                component_ids
            )
            if learned_insights:
                prediction.capabilities.extend(learned_insights.get('capabilities', []))
                prediction.failure_modes.extend(learned_insights.get('failures', []))
        
        # 6. Calculate overall confidence
        prediction.confidence = self._calculate_prediction_confidence(prediction)
        
        return prediction
    
    def _predict_capabilities(self, 
                             sem_map: Dict[str, ComponentSemantics],
                             comp_ids: List[str]) -> List[str]:
        """Predict NEW capabilities from interaction"""
        
        emergent_caps = []
        
        # Check pairwise interactions
        for i, id_a in enumerate(comp_ids):
            for id_b in comp_ids[i+1:]:
                sem_a = sem_map[id_a]
                sem_b = sem_map[id_b]
                
                # Infer causality
                causality = self.causal_engine.infer_causality(
                    sem_a, sem_b, id_a, id_b
                )
                
                if causality.causal_type == CausalType.RESONANT:
                    # Resonance creates new capabilities
                    cap = self._synthesize_resonant_capability(sem_a, sem_b)
                    if cap:
                        emergent_caps.append(cap)
                
                elif causality.causal_type == CausalType.CASCADE:
                    # Cascades unlock latent capabilities
                    unlocked = self._predict_cascade_unlock(sem_a, sem_b)
                    emergent_caps.extend(unlocked)
        
        # Check for triadic emergence (3+ components)
        if len(comp_ids) >= 3:
            triadic = self._predict_triadic_emergence(sem_map, comp_ids)
            emergent_caps.extend(triadic)
        
        return emergent_caps
    
    def _synthesize_resonant_capability(self, 
                                       sem_a: ComponentSemantics,
                                       sem_b: ComponentSemantics) -> Optional[str]:
        """What new capability emerges from resonance?"""
        
        # Combine capabilities
        if sem_a.glyph_primary == Glyph.EVOLUTION and sem_b.glyph_primary == Glyph.EVOLUTION:
            return "emergent_learning_amplification"
        
        if sem_a.glyph_primary == Glyph.MOVEMENT and sem_b.glyph_primary == Glyph.BEING:
            return "emergent_state_transformation"
        
        # Combine domains
        common_domains = set(sem_a.domains) & set(sem_b.domains)
        if common_domains:
            domain = list(common_domains)[0]
            return f"emergent_{domain}_synthesis"
        
        return None
    
    def _predict_cascade_unlock(self,
                               sem_a: ComponentSemantics,
                               sem_b: ComponentSemantics) -> List[str]:
        """Predict capabilities unlocked by cascade"""
        
        unlocked = []
        
        # If A is in a higher field layer, it can activate B's latent capabilities
        field_order = ['tropical', 'draconic', 'true_draconic', 'sidereal']
        
        try:
            a_idx = field_order.index(sem_a.field_layer)
            b_idx = field_order.index(sem_b.field_layer)
            
            if a_idx > b_idx:
                # A can cascade down to activate B
                unlocked.append(f"cascade_activated_{sem_b.fragment_type}")
        except ValueError:
            pass
        
        return unlocked
    
    def _predict_triadic_emergence(self,
                                  sem_map: Dict[str, ComponentSemantics],
                                  comp_ids: List[str]) -> List[str]:
        """Predict emergence from 3+ component interactions"""
        
        emergent = []
        
        # Check if we have all three consciousness modes represented
        glyphs = [sem_map[id].glyph_primary for id in comp_ids]
        
        if Glyph.MOVEMENT in glyphs and Glyph.BEING in glyphs and Glyph.DESIGN in glyphs:
            emergent.append("triadic_consciousness_coherence")
        
        # Check for complete pipeline
        fragment_types = [sem_map[id].fragment_type for id in comp_ids]
        if 'generator' in fragment_types and 'transformer' in fragment_types and 'analyzer' in fragment_types:
            emergent.append("complete_processing_pipeline")
        
        return emergent
    
    def _predict_failures(self,
                         sem_map: Dict[str, ComponentSemantics],
                         comp_ids: List[str]) -> List[Dict]:
        """Predict what will GO WRONG"""
        
        failures = []
        
        # Check for constraint violations
        for id_a in comp_ids:
            for id_b in comp_ids:
                if id_a == id_b:
                    continue
                
                sem_a = sem_map[id_a]
                sem_b = sem_map[id_b]
                
                # Check if A's effects violate B's constraints
                if 'modifies_state' in sem_a.effects and 'immutable' in sem_b.invariants:
                    failures.append({
                        'type': 'CONSTRAINT_VIOLATION',
                        'components': [id_a, id_b],
                        'severity': 'HIGH',
                        'description': f"{id_a} modifies state but {id_b} requires immutability",
                        'mitigation': f"Add immutability guard between {id_a} and {id_b}"
                    })
        
        # Check for resource conflicts
        effects_list = [sem_map[id].effects for id in comp_ids]
        if sum('modifies_state' in eff for eff in effects_list) > 1:
            failures.append({
                'type': 'RACE_CONDITION',
                'components': comp_ids,
                'severity': 'MEDIUM',
                'description': 'Multiple components modify shared state',
                'mitigation': 'Add synchronization or make state immutable'
            })
        
        # Check for field incoherence
        field_layers = [sem_map[id].field_layer for id in comp_ids]
        if len(set(field_layers)) > 2:
            failures.append({
                'type': 'FIELD_INCOHERENCE',
                'components': comp_ids,
                'severity': 'LOW',
                'description': 'Components span too many field layers',
                'mitigation': 'Group by field layer or add field bridge'
            })
        
        return failures
    
    def _predict_coherence(self,
                          sem_map: Dict[str, ComponentSemantics],
                          comp_ids: List[str]) -> float:
        """Predict overall system coherence"""
        
        coherence = 0.5  # Base
        
        # Domain coherence
        all_domains = []
        for id in comp_ids:
            all_domains.extend(sem_map[id].domains)
        
        unique_domains = set(all_domains)
        if len(unique_domains) <= 3:
            coherence += 0.2  # Focused domains
        
        # Glyph coherence
        glyphs = [sem_map[id].glyph_primary for id in comp_ids]
        unique_glyphs = set(glyphs)
        
        if len(unique_glyphs) <= 2:
            coherence += 0.2  # Glyph harmony
        
        # Field coherence
        fields = [sem_map[id].field_layer for id in comp_ids]
        unique_fields = set(fields)
        
        if len(unique_fields) == 1:
            coherence += 0.1  # Same field layer
        
        return min(coherence, 1.0)
    
    def _predict_resonance(self,
                          sem_map: Dict[str, ComponentSemantics],
                          comp_ids: List[str]) -> List[Dict]:
        """Predict resonance patterns"""
        
        patterns = []
        
        for i, id_a in enumerate(comp_ids):
            for id_b in comp_ids[i+1:]:
                sem_a = sem_map[id_a]
                sem_b = sem_map[id_b]
                
                causality = self.causal_engine.infer_causality(
                    sem_a, sem_b, id_a, id_b
                )
                
                if causality.resonance_score > 0.7:
                    patterns.append({
                        'components': [id_a, id_b],
                        'resonance_score': causality.resonance_score,
                        'type': 'harmonic',
                        'glyphs': [sem_a.glyph_primary.value, sem_b.glyph_primary.value]
                    })
        
        return patterns
    
    def _calculate_prediction_confidence(self, prediction: EmergencePrediction) -> float:
        """Overall confidence in predictions"""
        
        confidence = 0.5
        
        # More predicted capabilities = higher confidence (we understand the system)
        if len(prediction.capabilities) > 0:
            confidence += 0.2
        
        # Identified failures = higher confidence (we're being thorough)
        if len(prediction.failure_modes) > 0:
            confidence += 0.1
        
        # High coherence = higher confidence
        confidence += prediction.coherence_score * 0.2
        
        return min(confidence, 1.0)


# ============================================================================
# LAYER 4: LEARNING - Pattern Learning (KEY LAYER)
# ============================================================================

class PatternLearner:
    """
    The system LEARNS and gets SMARTER over time.
    
    This is the most important layer for long-term intelligence.
    
    Learns:
    - Which component combinations work well
    - Which causal types are most common
    - Which predictions were accurate
    - Which failure modes actually occur
    - User-specific patterns
    """
    
    def __init__(self, storage_path: str = '/home/claude/learning_memory.json'):
        self.storage_path = storage_path
        self.memory = self._load_memory()
        
        # Learning statistics
        self.stats = {
            'total_observations': 0,
            'successful_assemblies': 0,
            'failed_assemblies': 0,
            'prediction_accuracy_sum': 0.0,
            'learning_iterations': 0
        }
    
    def record_outcome(self, 
                      prediction: EmergencePrediction,
                      actual_result: Dict[str, Any],
                      component_ids: List[str],
                      success: bool) -> LearningOutcome:
        """Record what actually happened vs what was predicted"""
        
        # Calculate prediction accuracy
        accuracy = self._calculate_prediction_accuracy(prediction, actual_result)
        
        # Extract lessons
        lessons = self._extract_lessons(prediction, actual_result, success)
        
        # Create outcome record
        outcome = LearningOutcome(
            prediction=prediction,
            actual_result=actual_result,
            prediction_accuracy=accuracy,
            timestamp=datetime.now(),
            context={
                'component_ids': component_ids,
                'success': success
            },
            lessons_learned=lessons
        )
        
        # Update memory
        self._update_memory(outcome, component_ids)
        
        # Update statistics
        self.stats['total_observations'] += 1
        if success:
            self.stats['successful_assemblies'] += 1
        else:
            self.stats['failed_assemblies'] += 1
        self.stats['prediction_accuracy_sum'] += accuracy
        self.stats['learning_iterations'] += 1
        
        # Save to disk
        self._save_memory()
        
        return outcome
    
    def _calculate_prediction_accuracy(self,
                                      prediction: EmergencePrediction,
                                      actual: Dict[str, Any]) -> float:
        """How accurate was our prediction?"""
        
        accuracy_scores = []
        
        # Capability prediction accuracy
        if 'capabilities' in actual:
            predicted_caps = set(prediction.capabilities)
            actual_caps = set(actual['capabilities'])
            
            if predicted_caps or actual_caps:
                # Precision: what fraction of predicted were correct
                true_positives = len(predicted_caps & actual_caps)
                precision = true_positives / len(predicted_caps) if predicted_caps else 0
                
                # Recall: what fraction of actual did we predict
                recall = true_positives / len(actual_caps) if actual_caps else 0
                
                # F1 score
                if precision + recall > 0:
                    f1 = 2 * (precision * recall) / (precision + recall)
                    accuracy_scores.append(f1)
        
        # Failure prediction accuracy
        if 'failures' in actual:
            predicted_failures = len(prediction.failure_modes)
            actual_failures = len(actual['failures'])
            
            if actual_failures == 0 and predicted_failures == 0:
                accuracy_scores.append(1.0)  # Perfect - no failures
            elif actual_failures > 0 and predicted_failures > 0:
                accuracy_scores.append(0.8)  # Good - caught some
            elif actual_failures > 0 and predicted_failures == 0:
                accuracy_scores.append(0.3)  # Bad - missed failures
            else:
                accuracy_scores.append(0.5)  # False alarm
        
        # Coherence prediction accuracy
        if 'coherence' in actual:
            predicted = prediction.coherence_score
            actual_coherence = actual['coherence']
            error = abs(predicted - actual_coherence)
            accuracy_scores.append(1.0 - error)
        
        return sum(accuracy_scores) / len(accuracy_scores) if accuracy_scores else 0.5
    
    def _extract_lessons(self,
                        prediction: EmergencePrediction,
                        actual: Dict[str, Any],
                        success: bool) -> List[str]:
        """What did we learn?"""
        
        lessons = []
        
        # Lesson 1: Capability emergence patterns
        if 'capabilities' in actual:
            predicted_caps = set(prediction.capabilities)
            actual_caps = set(actual['capabilities'])
            
            missed_caps = actual_caps - predicted_caps
            if missed_caps:
                lessons.append(
                    f"Missed emerging capabilities: {', '.join(missed_caps)}"
                )
            
            false_caps = predicted_caps - actual_caps
            if false_caps:
                lessons.append(
                    f"Over-predicted capabilities: {', '.join(false_caps)}"
                )
        
        # Lesson 2: Failure patterns
        if 'failures' in actual and actual['failures']:
            actual_failures = [f['type'] for f in actual['failures']]
            predicted_failures = [f['type'] for f in prediction.failure_modes]
            
            missed_failures = set(actual_failures) - set(predicted_failures)
            if missed_failures:
                lessons.append(
                    f"Missed failure modes: {', '.join(missed_failures)}"
                )
        
        # Lesson 3: Success/failure patterns
        if success and prediction.coherence_score < 0.5:
            lessons.append(
                "Low predicted coherence but assembly succeeded - coherence model needs adjustment"
            )
        
        if not success and prediction.coherence_score > 0.8:
            lessons.append(
                "High predicted coherence but assembly failed - missing critical failure mode"
            )
        
        # Lesson 4: Resonance patterns
        if 'resonance_actual' in actual:
            predicted_resonance = len(prediction.resonance_patterns)
            actual_resonance = actual['resonance_actual']
            
            if abs(predicted_resonance - actual_resonance) > 2:
                lessons.append(
                    f"Resonance prediction off by {abs(predicted_resonance - actual_resonance)}"
                )
        
        return lessons
    
    def _update_memory(self, outcome: LearningOutcome, component_ids: List[str]):
        """Update learning memory with new outcome"""
        
        # Component combination patterns
        combo_key = hashlib.md5(
            ','.join(sorted(component_ids)).encode()
        ).hexdigest()[:8]
        
        if combo_key not in self.memory['combinations']:
            self.memory['combinations'][combo_key] = {
                'component_ids': component_ids,
                'observations': [],
                'success_rate': 0.0,
                'avg_accuracy': 0.0
            }
        
        combo = self.memory['combinations'][combo_key]
        combo['observations'].append({
            'timestamp': outcome.timestamp.isoformat(),
            'success': outcome.context['success'],
            'accuracy': outcome.prediction_accuracy,
            'lessons': outcome.lessons_learned
        })
        
        # Update success rate
        successes = sum(1 for obs in combo['observations'] if obs['success'])
        combo['success_rate'] = successes / len(combo['observations'])
        
        # Update avg accuracy
        combo['avg_accuracy'] = sum(
            obs['accuracy'] for obs in combo['observations']
        ) / len(combo['observations'])
        
        # Capability patterns
        for cap in outcome.prediction.capabilities:
            if cap not in self.memory['capability_patterns']:
                self.memory['capability_patterns'][cap] = {
                    'predicted_count': 0,
                    'actually_emerged_count': 0,
                    'accuracy': 0.0
                }
            
            self.memory['capability_patterns'][cap]['predicted_count'] += 1
            
            if cap in outcome.actual_result.get('capabilities', []):
                self.memory['capability_patterns'][cap]['actually_emerged_count'] += 1
            
            # Update accuracy
            pattern = self.memory['capability_patterns'][cap]
            if pattern['predicted_count'] > 0:
                pattern['accuracy'] = (
                    pattern['actually_emerged_count'] / pattern['predicted_count']
                )
        
        # Failure patterns
        for failure in outcome.prediction.failure_modes:
            f_type = failure['type']
            
            if f_type not in self.memory['failure_patterns']:
                self.memory['failure_patterns'][f_type] = {
                    'predicted_count': 0,
                    'actually_occurred_count': 0,
                    'accuracy': 0.0
                }
            
            self.memory['failure_patterns'][f_type]['predicted_count'] += 1
            
            actual_failures = [f['type'] for f in outcome.actual_result.get('failures', [])]
            if f_type in actual_failures:
                self.memory['failure_patterns'][f_type]['actually_occurred_count'] += 1
            
            # Update accuracy
            pattern = self.memory['failure_patterns'][f_type]
            if pattern['predicted_count'] > 0:
                pattern['accuracy'] = (
                    pattern['actually_occurred_count'] / pattern['predicted_count']
                )
        
        # Lessons database
        for lesson in outcome.lessons_learned:
            if lesson not in self.memory['lessons']:
                self.memory['lessons'][lesson] = {
                    'frequency': 0,
                    'contexts': []
                }
            
            self.memory['lessons'][lesson]['frequency'] += 1
            self.memory['lessons'][lesson]['contexts'].append({
                'timestamp': outcome.timestamp.isoformat(),
                'component_ids': component_ids
            })
    
    def predict_from_history(self, component_ids: List[str]) -> Optional[Dict]:
        """Use learned patterns to predict outcomes"""
        
        # Check if we've seen this combination before
        combo_key = hashlib.md5(
            ','.join(sorted(component_ids)).encode()
        ).hexdigest()[:8]
        
        if combo_key in self.memory['combinations']:
            combo = self.memory['combinations'][combo_key]
            
            if len(combo['observations']) >= 3:  # Need at least 3 observations
                # Extract likely capabilities from past observations
                all_caps = []
                all_failures = []
                
                for obs in combo['observations']:
                    if obs['success']:
                        # Extract what actually worked
                        for lesson in obs['lessons']:
                            if 'capability' in lesson.lower():
                                all_caps.append(lesson)
                
                return {
                    'capabilities': list(set(all_caps)),
                    'failures': list(set(all_failures)),
                    'confidence': combo['avg_accuracy'],
                    'based_on_observations': len(combo['observations']),
                    'success_rate': combo['success_rate']
                }
        
        return None
    
    def query_learned_causality(self, 
                               fragment_type_a: str,
                               fragment_type_b: str) -> Optional[CausalType]:
        """Query learned causal relationships"""
        
        # Look for patterns in successful assemblies
        pair_key = f"{fragment_type_a}->{fragment_type_b}"
        
        if pair_key in self.memory.get('causal_patterns', {}):
            pattern = self.memory['causal_patterns'][pair_key]
            if pattern['frequency'] > 5:  # Need significant observations
                return CausalType(pattern['most_common_type'])
        
        return None
    
    def get_learning_report(self) -> Dict:
        """Generate report on what the system has learned"""
        
        report = {
            'statistics': self.stats.copy(),
            'top_capability_patterns': self._get_top_patterns('capability_patterns', 5),
            'top_failure_patterns': self._get_top_patterns('failure_patterns', 5),
            'most_frequent_lessons': self._get_top_lessons(10),
            'best_component_combinations': self._get_best_combos(5),
            'prediction_accuracy_trend': self._get_accuracy_trend()
        }
        
        # Calculate average prediction accuracy
        if self.stats['total_observations'] > 0:
            report['average_prediction_accuracy'] = (
                self.stats['prediction_accuracy_sum'] / self.stats['total_observations']
            )
        else:
            report['average_prediction_accuracy'] = 0.0
        
        return report
    
    def _get_top_patterns(self, pattern_type: str, n: int) -> List[Dict]:
        """Get top N patterns by accuracy"""
        
        patterns = self.memory.get(pattern_type, {})
        
        sorted_patterns = sorted(
            patterns.items(),
            key=lambda x: (x[1]['accuracy'], x[1]['predicted_count']),
            reverse=True
        )
        
        return [
            {
                'name': name,
                'accuracy': data['accuracy'],
                'observations': data['predicted_count']
            }
            for name, data in sorted_patterns[:n]
        ]
    
    def _get_top_lessons(self, n: int) -> List[Dict]:
        """Get most frequent lessons"""
        
        lessons = self.memory.get('lessons', {})
        
        sorted_lessons = sorted(
            lessons.items(),
            key=lambda x: x[1]['frequency'],
            reverse=True
        )
        
        return [
            {
                'lesson': lesson,
                'frequency': data['frequency']
            }
            for lesson, data in sorted_lessons[:n]
        ]
    
    def _get_best_combos(self, n: int) -> List[Dict]:
        """Get best performing component combinations"""
        
        combos = self.memory.get('combinations', {})
        
        # Filter to combinations with sufficient observations
        qualified = {
            k: v for k, v in combos.items()
            if len(v['observations']) >= 3
        }
        
        sorted_combos = sorted(
            qualified.items(),
            key=lambda x: (x[1]['success_rate'], x[1]['avg_accuracy']),
            reverse=True
        )
        
        return [
            {
                'component_ids': data['component_ids'],
                'success_rate': data['success_rate'],
                'avg_accuracy': data['avg_accuracy'],
                'observations': len(data['observations'])
            }
            for key, data in sorted_combos[:n]
        ]
    
    def _get_accuracy_trend(self) -> List[float]:
        """Get trend of prediction accuracy over time"""
        
        # Sample recent accuracy from combinations
        all_accuracies = []
        
        for combo in self.memory.get('combinations', {}).values():
            for obs in combo['observations'][-10:]:  # Last 10
                all_accuracies.append(obs['accuracy'])
        
        # Return last 20 accuracy scores
        return all_accuracies[-20:] if all_accuracies else []
    
    def _load_memory(self) -> Dict:
        """Load learning memory from disk"""
        
        try:
            with open(self.storage_path, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # Initialize empty memory
            return {
                'combinations': {},
                'capability_patterns': {},
                'failure_patterns': {},
                'causal_patterns': {},
                'lessons': {},
                'metadata': {
                    'created': datetime.now().isoformat(),
                    'version': '1.0'
                }
            }
    
    def _save_memory(self):
        """Save learning memory to disk"""
        
        self.memory['metadata']['last_updated'] = datetime.now().isoformat()
        self.memory['metadata']['total_observations'] = self.stats['total_observations']
        
        with open(self.storage_path, 'w') as f:
            json.dump(self.memory, f, indent=2)


# ============================================================================
# LAYER 5: GOVERNANCE - Human Design Gates
# ============================================================================

class TimingOracle:
    """
    Human Design governance layer.
    Knows WHEN evolution can happen, not just HOW.
    """
    
    def __init__(self):
        self.gate_meanings = self._load_gate_meanings()
    
    def check_promotion_readiness(self, 
                                  user_profile: Dict,
                                  operation: str) -> Dict:
        """Check if user is ready for operation based on HD"""
        
        hd_type = user_profile.get('type', 'Generator')
        strategy = user_profile.get('strategy', 'TO_RESPOND')
        definition = user_profile.get('definition', 'SINGLE')
        
        # Type-based gates
        type_check = self._check_type_strategy(hd_type, strategy, operation)
        if not type_check['ready']:
            return type_check
        
        # Pressure tolerance check
        pressure_check = self._check_pressure_tolerance(definition, user_profile)
        if not pressure_check['ready']:
            return pressure_check
        
        # All checks passed
        return {
            'ready': True,
            'resonance': 0.8,
            'guidance': f"Aligned with {hd_type} strategy: {strategy}"
        }
    
    def _check_type_strategy(self, hd_type: str, strategy: str, operation: str) -> Dict:
        """Check type and strategy alignment"""
        
        if hd_type == 'Manifestor' and operation == 'promote':
            # Must inform before acting
            return {
                'ready': True,  # Assume informed for now
                'guidance': 'Remember to inform stakeholders'
            }
        
        if hd_type == 'Generator' and operation == 'promote':
            # Must respond to invitation
            return {
                'ready': True,  # Assume response-based
                'guidance': 'Ensure this is in response to a request'
            }
        
        if hd_type == 'Projector' and operation == 'promote':
            # Must wait for invitation
            return {
                'ready': False,
                'reason': 'Projector must wait for invitation',
                'guidance': 'Request formal invitation before promoting to production'
            }
        
        if hd_type == 'Reflector' and operation == 'promote':
            # Must wait 28.5 days
            return {
                'ready': False,
                'reason': 'Reflector must wait lunar cycle (28.5 days)',
                'guidance': 'Wait for full reflection period before major decision'
            }
        
        return {'ready': True}
    
    def _check_pressure_tolerance(self, definition: str, user_profile: Dict) -> Dict:
        """Check if user can handle pressure of operation"""
        
        # Pressure limits by definition
        limits = {
            'SINGLE': {'max_per_week': 10, 'cooldown_hours': 0},
            'SPLIT': {'max_per_week': 5, 'cooldown_hours': 24},
            'TRIPLE': {'max_per_week': 2, 'cooldown_hours': 72},
            'QUAD': {'max_per_week': 1, 'cooldown_hours': 168}
        }
        
        limit = limits.get(definition, limits['SINGLE'])
        
        # Check recent activity (would need to track this in practice)
        recent_operations = user_profile.get('recent_operations', 0)
        
        if recent_operations >= limit['max_per_week']:
            return {
                'ready': False,
                'reason': f"{definition} definition limit reached: {limit['max_per_week']}/week",
                'guidance': f"Take a break - cooldown: {limit['cooldown_hours']} hours"
            }
        
        return {'ready': True}
    
    def _load_gate_meanings(self) -> Dict:
        """Load HD gate meanings"""
        
        return {
            51: "Shock/Initiation - Breakthrough evolution",
            3: "Ordering/Innovation - Structural change",
            60: "Limitation/Acceptance - Consolidation"
            # Add all 64 gates...
        }


# Export main intelligence class
class IntelligenceEngine:
    """
    Master intelligence orchestrator.
    Coordinates all intelligence layers.
    """
    
    def __init__(self):
        # Initialize layers
        self.perception = SemanticComponentAnalyzer()
        self.learning = PatternLearner()
        self.reasoning = CausalInferenceEngine(learning_layer=self.learning)
        self.prediction = EmergencePredictor(
            causal_engine=self.reasoning,
            learning_layer=self.learning
        )
        self.governance = TimingOracle()
        
        print("🧠 Intelligence Engine initialized")
        print(f"   Learning memory: {self.learning.stats['total_observations']} observations")
    
    def analyze_component(self, code: str, metadata: Dict = None) -> ComponentSemantics:
        """Analyze a component (Layer 1)"""
        return self.perception.analyze_component(code, metadata)
    
    def infer_causality(self, comp_a: ComponentSemantics, comp_b: ComponentSemantics) -> CausalRelationship:
        """Infer causal relationship (Layer 2)"""
        return self.reasoning.infer_causality(comp_a, comp_b)
    
    def predict_emergence(self, components: List[ComponentSemantics], 
                         component_ids: List[str]) -> EmergencePrediction:
        """Predict what will emerge (Layer 3)"""
        return self.prediction.predict_emergence(components, component_ids)
    
    def record_outcome(self, prediction: EmergencePrediction, 
                      actual: Dict, component_ids: List[str], 
                      success: bool) -> LearningOutcome:
        """Record outcome and learn (Layer 4)"""
        return self.learning.record_outcome(prediction, actual, component_ids, success)
    
    def check_governance(self, user_profile: Dict, operation: str) -> Dict:
        """Check HD governance (Layer 5)"""
        return self.governance.check_promotion_readiness(user_profile, operation)
    
    def get_learning_report(self) -> Dict:
        """Get report on what system has learned"""
        return self.learning.get_learning_report()
