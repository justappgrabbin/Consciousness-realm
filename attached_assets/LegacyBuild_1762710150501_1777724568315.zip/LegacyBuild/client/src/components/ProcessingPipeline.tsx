import { CheckCircle2, Circle, Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";

interface PipelineStep {
  label: string;
  status: "pending" | "in-progress" | "completed";
}

interface ProcessingPipelineProps {
  currentStep: number;
}

export function ProcessingPipeline({ currentStep }: ProcessingPipelineProps) {
  const steps: PipelineStep[] = [
    { label: "Upload", status: currentStep > 0 ? "completed" : currentStep === 0 ? "in-progress" : "pending" },
    { label: "Analyze", status: currentStep > 1 ? "completed" : currentStep === 1 ? "in-progress" : "pending" },
    { label: "Sort", status: currentStep > 2 ? "completed" : currentStep === 2 ? "in-progress" : "pending" },
    { label: "Unify", status: currentStep > 3 ? "completed" : currentStep === 3 ? "in-progress" : "pending" },
    { label: "Generate", status: currentStep > 4 ? "completed" : currentStep === 4 ? "in-progress" : "pending" },
  ];

  return (
    <Card className="p-6" data-testid="pipeline-processing">
      <h3 className="text-lg font-semibold mb-6">Processing Pipeline</h3>
      
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={step.label} className="flex items-center flex-1">
            <div className="flex flex-col items-center gap-2">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                step.status === "completed"
                  ? "bg-primary text-primary-foreground"
                  : step.status === "in-progress"
                  ? "bg-primary/20 text-primary"
                  : "bg-muted text-muted-foreground"
              }`}>
                {step.status === "completed" && <CheckCircle2 className="w-5 h-5" />}
                {step.status === "in-progress" && <Loader2 className="w-5 h-5 animate-spin" />}
                {step.status === "pending" && <Circle className="w-5 h-5" />}
              </div>
              <span className={`text-sm font-medium ${
                step.status === "pending" ? "text-muted-foreground" : ""
              }`}>
                {step.label}
              </span>
            </div>
            
            {index < steps.length - 1 && (
              <div className={`flex-1 h-0.5 mx-2 ${
                steps[index + 1].status !== "pending" ? "bg-primary" : "bg-border"
              }`} />
            )}
          </div>
        ))}
      </div>
    </Card>
  );
}
