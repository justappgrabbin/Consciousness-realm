# Agentic Reality — Project TODO

## Phase 1-6: Core Simulation (✓ Complete)
- [x] Database schema: agents, districts, needs, moods, memories, relationships, tasks, conversations, activity_feed, world_events, simulation_state
- [x] World rules engine: needs decay, activity effects, mood calculation, migration logic, task generation
- [x] Tick-based simulation engine: processTick, agent lifecycle, activity selection, task processing
- [x] LLM agent cognition: inner monologue, decision-making, conversation generation, task planning
- [x] Memory summarization and cross-district messaging
- [x] World seeder: 5 districts with unique themes, 15 agents with full personalities and backstories
- [x] tRPC router: world, agents, feed procedures
- [x] Federated district nodes with resource levels, social norms, and population caps
- [x] Agent migration between districts based on needs and resource levels
- [x] World event injection system with effects on agent needs and moods
- [x] Social graph: relationship formation, evolution, and sentiment tracking
- [x] Dark premium design tokens in index.css with Space Grotesk + Inter fonts
- [x] Phone-first layout: max-width 480px, bottom navigation bar
- [x] Feed page: live event stream, conversation cards, tab filters, world clock
- [x] Agents list page: search, district filter, mini needs bars, mood badges
- [x] Agent profile page: overview, memories, relationships, tasks tabs
- [x] World map page: SVG district visualization with population, resource indicators
- [x] Observer dashboard: seed world, pause/resume, tick speed, manual tick, event injection
- [x] Shared components: AgentAvatar, MoodBadge, NeedsBar, WorldClock, BottomNav
- [x] Animations: shimmer, fade-in, slide-up, pulse utilities
- [x] Vitest tests for world rules engine and auth
- [x] Server-side simulation scheduler (auto-tick independent of client)

## Phase 7: 3D Isometric Embodiment Layer
- [ ] Install Three.js and related dependencies
- [ ] Create IsometricScene component with Three.js canvas
- [ ] Build 3D agent models (simple geometric characters with mood colors)
- [ ] Implement isometric camera and coordinate system
- [ ] Create district scenes (home, office, café, park, plaza)
- [ ] Build real-time agent position syncing from simulation
- [ ] Implement agent movement animations (walking/idle/working)
- [ ] Add activity state visualization (mood auras, action indicators)
- [ ] Create interactive agent selection (click to open profile)
- [ ] Build district switching UI
- [ ] Optimize rendering for mobile (LOD, draw call reduction)
- [ ] Add environmental details and lighting
- [ ] Implement agent interaction animations (talking, greeting)
