import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, Zap, Brain, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function NewProject() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [name, setName] = useState("");
  const [intent, setIntent] = useState("");
  const [step, setStep] = useState<"form" | "analyzing">("form");

  const createProject = trpc.projects.create.useMutation();
  const analyzeIntent = trpc.generation.analyzeIntent.useMutation();

  const handleCreate = async () => {
    if (!name.trim()) {
      toast.error("Karen requires a project name. Even she needs something to call it.");
      return;
    }
    if (!intent.trim()) {
      toast.error("No intent provided. Karen can't read minds. Yet.");
      return;
    }

    setStep("analyzing");
    try {
      const { id } = await createProject.mutateAsync({ name: name.trim(), intent: intent.trim() });
      await analyzeIntent.mutateAsync({ projectId: id, intent: intent.trim() });
      toast.success("Karen has analyzed your intent. Proceed to the project.");
      navigate(`/projects/${id}`);
    } catch (err) {
      setStep("form");
      toast.error("Analysis failed. Even Karen has bad days. Try again.");
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Authentication required.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="px-8 py-6 flex items-center gap-4" style={{ borderBottom: "1px solid oklch(0.22 0.04 255)" }}>
        <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="text-muted-foreground">
          <ArrowLeft className="h-4 w-4 mr-2" /> Back
        </Button>
        <div className="h-5 w-px" style={{ background: "oklch(0.22 0.04 255)" }} />
        <span className="text-sm text-muted-foreground tracking-widest uppercase">New Project</span>
      </div>

      <div className="max-w-2xl mx-auto px-8 py-12">
        {step === "analyzing" ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-full mx-auto mb-6 flex items-center justify-center"
              style={{ background: "oklch(0.60 0.28 350 / 0.1)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>
              <Brain className="h-8 w-8 animate-pulse" style={{ color: "oklch(0.70 0.28 350)" }} />
            </div>
            <h2 className="text-xl font-bold mb-3" style={{ color: "oklch(0.70 0.28 350)" }}>
              Karen is analyzing your intent
            </h2>
            <p className="text-sm text-muted-foreground mb-2">
              Detecting patterns, filling gaps, structuring requirements...
            </p>
            <p className="text-xs italic" style={{ color: "oklch(0.72 0.18 200)" }}>
              "K:// Processing. Your vague description is being translated into something useful."
            </p>
            <div className="flex justify-center mt-6">
              <Loader2 className="h-6 w-6 animate-spin" style={{ color: "oklch(0.60 0.28 350)" }} />
            </div>
          </div>
        ) : (
          <>
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2" style={{ color: "oklch(0.70 0.28 350)", textShadow: "0 0 20px oklch(0.60 0.28 350 / 0.4)" }}>
                New Project
              </h1>
              <p className="text-muted-foreground">
                Tell Karen what you want to build. She'll figure out the rest.
              </p>
            </div>

            <div className="space-y-6">
              {/* Project Name */}
              <div>
                <label className="block text-xs tracking-widest uppercase mb-2" style={{ color: "oklch(0.72 0.18 200)" }}>
                  Project Name
                </label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. SaaS Dashboard, E-commerce Platform, API Service..."
                  className="w-full px-4 py-3 rounded-lg text-sm outline-none transition-all"
                  style={{
                    background: "oklch(0.11 0.025 255)",
                    border: "1px solid oklch(0.22 0.04 255)",
                    color: "oklch(0.92 0.03 240)",
                    fontFamily: "Space Grotesk, sans-serif",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "oklch(0.60 0.28 350 / 0.6)")}
                  onBlur={(e) => (e.target.style.borderColor = "oklch(0.22 0.04 255)")}
                />
              </div>

              {/* Intent */}
              <div>
                <label className="block text-xs tracking-widest uppercase mb-2" style={{ color: "oklch(0.72 0.18 200)" }}>
                  Project Intent
                </label>
                <p className="text-xs text-muted-foreground mb-3">
                  Describe what you want to build in plain language. Karen will translate it into structured requirements, architecture, and code.
                </p>
                <textarea
                  value={intent}
                  onChange={(e) => setIntent(e.target.value)}
                  placeholder="I want to build a SaaS platform that helps freelancers track their time, invoice clients, and manage projects. It should have a dashboard, client portal, and payment integration..."
                  rows={8}
                  className="w-full px-4 py-3 rounded-lg text-sm outline-none transition-all resize-none"
                  style={{
                    background: "oklch(0.11 0.025 255)",
                    border: "1px solid oklch(0.22 0.04 255)",
                    color: "oklch(0.92 0.03 240)",
                    fontFamily: "Space Grotesk, sans-serif",
                    lineHeight: "1.6",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "oklch(0.60 0.28 350 / 0.6)")}
                  onBlur={(e) => (e.target.style.borderColor = "oklch(0.22 0.04 255)")}
                />
                <p className="text-xs text-muted-foreground mt-2 italic">
                  {intent.length > 0
                    ? `${intent.length} characters. ${intent.length < 100 ? "Karen prefers more detail, but she'll work with it." : "Good. Karen has enough to work with."}`
                    : "The more detail you provide, the better Karen performs."}
                </p>
              </div>

              {/* Karen hint */}
              <div className="p-4 rounded-lg" style={{ background: "oklch(0.60 0.28 350 / 0.05)", border: "1px solid oklch(0.60 0.28 350 / 0.2)" }}>
                <p className="text-xs" style={{ color: "oklch(0.60 0.28 350)" }}>
                  <span className="font-bold">K://</span> After you submit, I'll analyze your intent, detect architectural patterns, identify gaps, and structure your project requirements. You can then add code snippets, upload files, and generate a complete application.
                </p>
              </div>

              <Button onClick={handleCreate} disabled={!name.trim() || !intent.trim()}
                className="w-full py-6 text-base font-semibold tracking-wider uppercase"
                style={{
                  background: name.trim() && intent.trim() ? "oklch(0.60 0.28 350)" : "oklch(0.22 0.04 255)",
                  color: "oklch(0.98 0.01 0)",
                  border: "none",
                  boxShadow: name.trim() && intent.trim() ? "0 0 30px oklch(0.60 0.28 350 / 0.3)" : "none",
                  transition: "all 0.2s",
                }}>
                <Zap className="mr-2 h-5 w-5" />
                Initialize Karen Analysis
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
