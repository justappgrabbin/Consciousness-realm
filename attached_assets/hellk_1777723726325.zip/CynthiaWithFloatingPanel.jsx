// 🧬 CYNTHIA with UNO Floating Panel
// Blank paper → Floating draggable control panel → Upload ZIPs → Chat with AI → Preview → Deploy

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  TextInput,
  Alert,
  ActivityIndicator,
  Dimensions,
  Modal,
  Image
} from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import RNFS from 'react-native-fs';
import { MessageSquare, Link, Eye, X, Minus, Upload, Send, Cloud, Folder, Menu, Settings, FileCode } from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

/**
 * ============================================================================
 * FLOATING PANEL WRAPPER
 * ============================================================================
 */

const FloatingPanel = ({ title, icon: Icon, children, onClose, onMinimize, isMinimized, defaultPos }) => {
  const [position, setPosition] = useState(defaultPos || { x: 10, y: 60 });
  const panelRef = useRef(null);

  if (isMinimized) return null;

  return (
    <View
      ref={panelRef}
      style={[
        styles.floatingPanel,
        { left: position.x, top: position.y }
      ]}
    >
      {/* Header */}
      <View style={styles.panelHeader}>
        <View style={styles.panelHeaderLeft}>
          <Icon size={18} color="#C084FC" />
          <Text style={styles.panelTitle}>{title}</Text>
        </View>
        <View style={styles.panelHeaderButtons}>
          {onMinimize && (
            <TouchableOpacity onPress={onMinimize} style={styles.headerButton}>
              <Minus size={14} color="#D1D5DB" />
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={onClose} style={styles.headerButtonClose}>
            <X size={14} color="#D1D5DB" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Content */}
      <ScrollView style={styles.panelContent}>
        {children}
      </ScrollView>
    </View>
  );
};

/**
 * ============================================================================
 * CHAT TAB
 * ============================================================================
 */

const ChatTab = ({ llama, isLoading, setIsLoading }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [provider, setProvider] = useState('llama');
  const [apiKey, setApiKey] = useState('');

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMsg = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    const userInput = input;
    setInput('');
    setIsLoading(true);

    try {
      if (provider === 'llama') {
        // Use local LLaMA
        let response = '';
        for await (const token of llama.generate(userInput, {
          temperature: 0.7,
          maxTokens: 512
        })) {
          response += token;
        }
        setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      } else if (provider === 'openai') {
        // OpenAI API
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [{ role: 'user', content: userInput }]
          })
        });
        const data = await res.json();
        const response = data?.choices?.[0]?.message?.content || 'No response';
        setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      } else if (provider === 'minimax') {
        // MiniMax API
        const res = await fetch('https://api.minimax.chat/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: 'abab6.5s-chat',
            messages: [{ role: 'user', content: userInput }]
          })
        });
        const data = await res.json();
        const response = data?.choices?.[0]?.message?.content || 'No response';
        setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      }
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: `❌ ${error.message}` }]);
    }

    setIsLoading(false);
  };

  return (
    <View style={styles.tabContent}>
      {/* Provider selector */}
      <View style={styles.chatControls}>
        <View style={styles.providerSelector}>
          {['llama', 'openai', 'minimax', 'custom'].map(p => (
            <TouchableOpacity
              key={p}
              onPress={() => setProvider(p)}
              style={[
                styles.providerButton,
                provider === p && styles.providerButtonActive
              ]}
            >
              <Text style={[
                styles.providerText,
                provider === p && styles.providerTextActive
              ]}>
                {p}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {provider !== 'llama' && (
          <TextInput
            style={styles.apiKeyInput}
            value={apiKey}
            onChangeText={setApiKey}
            placeholder="API Key"
            placeholderTextColor="#666"
            secureTextEntry
          />
        )}
      </View>

      {/* Messages */}
      <ScrollView style={styles.messagesContainer}>
        {messages.map((msg, i) => (
          <View
            key={i}
            style={[
              styles.messageBubble,
              msg.role === 'user' ? styles.userMessage : styles.assistantMessage
            ]}
          >
            <Text style={styles.messageText}>{msg.content}</Text>
          </View>
        ))}
        {isLoading && (
          <View style={styles.loadingMessage}>
            <ActivityIndicator size="small" color="#C084FC" />
            <Text style={styles.loadingText}>Thinking...</Text>
          </View>
        )}
      </ScrollView>

      {/* Input */}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.chatInput}
          value={input}
          onChangeText={setInput}
          placeholder="Ask anything..."
          placeholderTextColor="#666"
          multiline
        />
        <TouchableOpacity
          onPress={sendMessage}
          disabled={isLoading}
          style={[styles.sendButton, isLoading && styles.sendButtonDisabled]}
        >
          <Send size={18} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

/**
 * ============================================================================
 * UPLOAD TAB
 * ============================================================================
 */

const UploadTab = ({ onUploadZIP, uploadedFiles, onAnalyze, projectName, setProjectName, projectDescription, setProjectDescription }) => {
  return (
    <View style={styles.tabContent}>
      <Text style={styles.tabTitle}>📦 Project Setup</Text>

      <Text style={styles.label}>Project Name</Text>
      <TextInput
        style={styles.input}
        value={projectName}
        onChangeText={setProjectName}
        placeholder="My Amazing App"
        placeholderTextColor="#666"
      />

      <Text style={styles.label}>Description</Text>
      <TextInput
        style={[styles.input, styles.textArea]}
        value={projectDescription}
        onChangeText={setProjectDescription}
        placeholder="What does this app do?"
        placeholderTextColor="#666"
        multiline
        numberOfLines={4}
      />

      <TouchableOpacity
        style={styles.uploadButton}
        onPress={onUploadZIP}
      >
        <Upload size={20} color="#fff" />
        <Text style={styles.uploadButtonText}>Upload ZIP Projects</Text>
      </TouchableOpacity>

      {Object.keys(uploadedFiles).length > 0 && (
        <>
          <View style={styles.uploadedInfo}>
            <Text style={styles.uploadedCount}>
              {Object.keys(uploadedFiles).length} files uploaded
            </Text>
          </View>

          <TouchableOpacity
            style={styles.analyzeButton}
            onPress={onAnalyze}
          >
            <FileCode size={20} color="#fff" />
            <Text style={styles.analyzeButtonText}>Analyze & Stitch</Text>
          </TouchableOpacity>
        </>
      )}

      <View style={styles.instructionsBox}>
        <Text style={styles.instructionsTitle}>📖 How to Use</Text>
        <Text style={styles.instructionsText}>
          1. Give your project a name{'\n'}
          2. Upload ZIP files containing your code{'\n'}
          3. Cynthia will analyze with glyphs{'\n'}
          4. Confirm the stitch plan{'\n'}
          5. AI fills gaps and creates your app!
        </Text>
      </View>
    </View>
  );
};

/**
 * ============================================================================
 * PREVIEW TAB
 * ============================================================================
 */

const PreviewTab = ({ currentApp, onRequestEvolution }) => {
  const [mediaFiles, setMediaFiles] = useState([]);

  const handleUploadMedia = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.images, DocumentPicker.types.video],
        allowMultiSelection: true
      });

      setMediaFiles(prev => [...prev, ...result]);
      Alert.alert('✅ Media Uploaded', `${result.length} file(s) added`);
    } catch (error) {
      if (!DocumentPicker.isCancel(error)) {
        Alert.alert('Error', error.message);
      }
    }
  };

  if (!currentApp) {
    return (
      <View style={styles.tabContent}>
        <View style={styles.emptyState}>
          <Folder size={48} color="#666" />
          <Text style={styles.emptyStateText}>No app created yet</Text>
          <Text style={styles.emptyStateSubtext}>
            Upload ZIPs and create your app first
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.tabContent}>
      <Text style={styles.tabTitle}>👁️ {currentApp.name}</Text>
      <Text style={styles.tabSubtitle}>v{currentApp.version}</Text>

      <View style={styles.previewCard}>
        <Text style={styles.previewLabel}>
          📦 {Object.keys(currentApp.files).length} files
        </Text>
        <Text style={styles.previewLabel}>
          🧬 Created: {new Date(currentApp.createdAt).toLocaleDateString()}
        </Text>
      </View>

      <TouchableOpacity
        style={styles.mediaButton}
        onPress={handleUploadMedia}
      >
        <Upload size={20} color="#fff" />
        <Text style={styles.mediaButtonText}>Upload Photos/Videos</Text>
      </TouchableOpacity>

      {mediaFiles.length > 0 && (
        <ScrollView horizontal style={styles.mediaPreview}>
          {mediaFiles.map((file, i) => (
            <View key={i} style={styles.mediaThumbnail}>
              <Text style={styles.mediaName}>{file.name}</Text>
            </View>
          ))}
        </ScrollView>
      )}

      <TouchableOpacity
        style={styles.evolveButton}
        onPress={() => onRequestEvolution('minor', 'Add new feature')}
      >
        <Text style={styles.evolveButtonText}>✨ Request Evolution</Text>
      </TouchableOpacity>
    </View>
  );
};

/**
 * ============================================================================
 * DEPLOY TAB
 * ============================================================================
 */

const DeployTab = ({ currentApp }) => {
  const [deployTarget, setDeployTarget] = useState('netlify');
  const [token, setToken] = useState('');
  const [status, setStatus] = useState('');

  const handleDeploy = () => {
    if (!currentApp) {
      Alert.alert('Error', 'No app to deploy');
      return;
    }

    setStatus(`Deploying to ${deployTarget}...`);
    setTimeout(() => {
      setStatus(`✅ Deployed to ${deployTarget}!`);
      Alert.alert('Success', `App deployed to ${deployTarget}`);
    }, 2000);
  };

  return (
    <View style={styles.tabContent}>
      <Text style={styles.tabTitle}>🚀 Deploy</Text>

      <Text style={styles.label}>Platform</Text>
      <View style={styles.deployOptions}>
        {['netlify', 'vercel', 'github'].map(platform => (
          <TouchableOpacity
            key={platform}
            onPress={() => setDeployTarget(platform)}
            style={[
              styles.deployOption,
              deployTarget === platform && styles.deployOptionActive
            ]}
          >
            <Text style={[
              styles.deployOptionText,
              deployTarget === platform && styles.deployOptionTextActive
            ]}>
              {platform}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>API Token</Text>
      <TextInput
        style={styles.input}
        value={token}
        onChangeText={setToken}
        placeholder={`${deployTarget} token`}
        placeholderTextColor="#666"
        secureTextEntry
      />

      <TouchableOpacity
        style={styles.deployButton}
        onPress={handleDeploy}
      >
        <Cloud size={20} color="#fff" />
        <Text style={styles.deployButtonText}>
          Deploy to {deployTarget}
        </Text>
      </TouchableOpacity>

      {status && (
        <View style={styles.statusBox}>
          <Text style={styles.statusText}>{status}</Text>
        </View>
      )}

      {currentApp && (
        <View style={styles.projectInfo}>
          <Text style={styles.projectInfoLabel}>Current Project:</Text>
          <Text style={styles.projectInfoValue}>{currentApp.name}</Text>
        </View>
      )}
    </View>
  );
};

/**
 * ============================================================================
 * MAIN CYNTHIA APP
 * ============================================================================
 */

export default function CynthiaWithPanel() {
  // App state
  const [appState, setAppState] = useState('void'); // void, analyzing, confirming, live
  const [currentApp, setCurrentApp] = useState(null);

  // Panel state
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [currentTab, setCurrentTab] = useState('upload');
  const [minimized, setMinimized] = useState(false);

  // Project data
  const [projectName, setProjectName] = useState('Untitled App');
  const [projectDescription, setProjectDescription] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState({});
  const [glyphAnalysis, setGlyphAnalysis] = useState(null);

  // Loading
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');

  // LLaMA (mock for now)
  const llama = useRef({
    generate: async function* (prompt, options) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      yield* 'This is a mock response from LLaMA. Install llama.rn for real AI.'.split(' ');
    }
  }).current;

  /**
   * Upload ZIP
   */
  const handleUploadZIP = async () => {
    try {
      const result = await DocumentPicker.pick({
        type: [DocumentPicker.types.zip],
        allowMultiSelection: true
      });

      setLoading(true);
      setLoadingMessage('Extracting ZIPs...');

      // Simulate extraction
      const files = {};
      result.forEach((file, i) => {
        files[`file${i}.js`] = `// Content from ${file.name}`;
      });

      setUploadedFiles(files);
      setLoading(false);

      Alert.alert('✅ ZIPs Uploaded', `${result.length} project(s) added`);
    } catch (error) {
      setLoading(false);
      if (!DocumentPicker.isCancel(error)) {
        Alert.alert('Error', error.message);
      }
    }
  };

  /**
   * Analyze & Stitch
   */
  const handleAnalyze = async () => {
    setAppState('analyzing');
    setLoading(true);
    setLoadingMessage('Analyzing with glyphs...');

    await new Promise(resolve => setTimeout(resolve, 2000));

    setGlyphAnalysis({
      totalFiles: Object.keys(uploadedFiles).length,
      compatibility: 'good',
      glyphs: []
    });

    setAppState('confirming');
    setLoading(false);

    Alert.alert(
      '📊 Analysis Complete',
      'Files analyzed! Ready to stitch?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Stitch!', onPress: handleStitch }
      ]
    );
  };

  /**
   * Stitch & Create App
   */
  const handleStitch = async () => {
    setAppState('stitching');
    setLoading(true);
    setLoadingMessage('Stitching with AI...');

    await new Promise(resolve => setTimeout(resolve, 3000));

    const app = {
      name: projectName,
      description: projectDescription,
      files: uploadedFiles,
      createdAt: Date.now(),
      version: '1.0.0'
    };

    setCurrentApp(app);
    setAppState('live');
    setLoading(false);

    Alert.alert('🎉 App Created!', `${projectName} is now live!`);
  };

  /**
   * Request Evolution
   */
  const handleRequestEvolution = (type, description) => {
    Alert.alert(
      '✨ Evolution Request',
      `Type: ${type}\nDescription: ${description}`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Approve', onPress: () => Alert.alert('✅', 'Evolution approved!') }
      ]
    );
  };

  /**
   * RENDER
   */

  return (
    <View style={styles.container}>
      {/* VOID STATE - Blank paper */}
      {appState === 'void' && (
        <View style={styles.voidContainer}>
          <Text style={styles.voidSymbol}>∅</Text>
        </View>
      )}

      {/* ANALYZING/LOADING */}
      {loading && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>{loadingMessage}</Text>
        </View>
      )}

      {/* LIVE APP */}
      {appState === 'live' && currentApp && !isPanelOpen && (
        <View style={styles.liveApp}>
          <Text style={styles.liveTitle}>{currentApp.name}</Text>
          <Text style={styles.liveSubtitle}>Your app is running!</Text>
        </View>
      )}

      {/* FLOATING CONTROL PANEL */}
      {!minimized && (
        <View style={styles.panelContainer}>
          {isPanelOpen ? (
            <FloatingPanel
              title="UNO Control"
              icon={Settings}
              onClose={() => setIsPanelOpen(false)}
              onMinimize={() => setMinimized(true)}
              defaultPos={{ x: 10, y: 10 }}
            >
              {/* Tab Selector */}
              <View style={styles.tabSelector}>
                {['upload', 'chat', 'preview', 'deploy'].map(tab => (
                  <TouchableOpacity
                    key={tab}
                    onPress={() => setCurrentTab(tab)}
                    style={[
                      styles.tab,
                      currentTab === tab && styles.tabActive
                    ]}
                  >
                    <Text style={[
                      styles.tabText,
                      currentTab === tab && styles.tabTextActive
                    ]}>
                      {tab}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Tab Content */}
              {currentTab === 'upload' && (
                <UploadTab
                  onUploadZIP={handleUploadZIP}
                  uploadedFiles={uploadedFiles}
                  onAnalyze={handleAnalyze}
                  projectName={projectName}
                  setProjectName={setProjectName}
                  projectDescription={projectDescription}
                  setProjectDescription={setProjectDescription}
                />
              )}

              {currentTab === 'chat' && (
                <ChatTab
                  llama={llama}
                  isLoading={loading}
                  setIsLoading={setLoading}
                />
              )}

              {currentTab === 'preview' && (
                <PreviewTab
                  currentApp={currentApp}
                  onRequestEvolution={handleRequestEvolution}
                />
              )}

              {currentTab === 'deploy' && (
                <DeployTab currentApp={currentApp} />
              )}
            </FloatingPanel>
          ) : (
            <TouchableOpacity
              style={styles.floatingButton}
              onPress={() => setIsPanelOpen(true)}
            >
              <Menu size={24} color="#fff" />
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* Restore button if minimized */}
      {minimized && (
        <TouchableOpacity
          style={styles.restoreButton}
          onPress={() => setMinimized(false)}
        >
          <Text style={styles.restoreButtonText}>⚙️</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

/**
 * ============================================================================
 * STYLES
 * ============================================================================
 */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000'
  },

  // Void state
  voidContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff'
  },
  voidSymbol: {
    fontSize: 120,
    color: '#e0e0e0'
  },

  // Live app
  liveApp: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0a0a0a'
  },
  liveTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8
  },
  liveSubtitle: {
    fontSize: 16,
    color: '#666'
  },

  // Loading
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  },
  loadingText: {
    marginTop: 20,
    fontSize: 16,
    color: '#fff'
  },

  // Floating panel
  panelContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    pointerEvents: 'box-none'
  },
  floatingPanel: {
    position: 'absolute',
    width: width - 20,
    maxWidth: 400,
    maxHeight: height * 0.8,
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#8B5CF6',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 16,
    elevation: 16
  },
  panelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#7C3AED',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14
  },
  panelHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8
  },
  panelTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff'
  },
  panelHeaderButtons: {
    flexDirection: 'row',
    gap: 8
  },
  headerButton: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center'
  },
  headerButtonClose: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.2)',
    justifyContent: 'center',
    alignItems: 'center'
  },
  panelContent: {
    padding: 16
  },

  // Tabs
  tabSelector: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16
  },
  tab: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#2a2a2a',
    alignItems: 'center'
  },
  tabActive: {
    backgroundColor: '#8B5CF6'
  },
  tabText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
    textTransform: 'capitalize'
  },
  tabTextActive: {
    color: '#fff'
  },
  tabContent: {
    gap: 12
  },
  tabTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff'
  },
  tabSubtitle: {
    fontSize: 14,
    color: '#999',
    marginTop: -8
  },

  // Forms
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#C084FC',
    marginBottom: 6
  },
  input: {
    backgroundColor: '#2a2a2a',
    padding: 12,
    borderRadius: 8,
    color: '#fff',
    fontSize: 14,
    borderWidth: 1,
    borderColor: '#444'
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top'
  },

  // Upload
  uploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#8B5CF6',
    padding: 14,
    borderRadius: 12
  },
  uploadButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold'
  },
  uploadedInfo: {
    backgroundColor: '#2a2a2a',
    padding: 12,
    borderRadius: 8
  },
  uploadedCount: {
    color: '#22C55E',
    fontSize: 12,
    fontWeight: '600'
  },
  analyzeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#22C55E',
    padding: 14,
    borderRadius: 12
  },
  analyzeButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold'
  },

  // Instructions
  instructionsBox: {
    backgroundColor: '#1E3A8A',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#3B82F6'
  },
  instructionsTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#93C5FD',
    marginBottom: 8
  },
  instructionsText: {
    fontSize: 12,
    color: '#DBEAFE',
    lineHeight: 18
  },

  // Chat
  chatControls: {
    gap: 8
  },
  providerSelector: {
    flexDirection: 'row',
    gap: 6
  },
  providerButton: {
    flex: 1,
    paddingVertical: 6,
    borderRadius: 6,
    backgroundColor: '#2a2a2a',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#444'
  },
  providerButtonActive: {
    backgroundColor: '#8B5CF6',
    borderColor: '#8B5CF6'
  },
  providerText: {
    fontSize: 11,
    color: '#666',
    textTransform: 'capitalize'
  },
  providerTextActive: {
    color: '#fff',
    fontWeight: '600'
  },
  apiKeyInput: {
    backgroundColor: '#2a2a2a',
    padding: 10,
    borderRadius: 8,
    color: '#fff',
    fontSize: 12,
    borderWidth: 1,
    borderColor: '#444'
  },
  messagesContainer: {
    height: 200,
    backgroundColor: '#0a0a0a',
    borderRadius: 8,
    padding: 8
  },
  messageBubble: {
    padding: 10,
    borderRadius: 12,
    marginBottom: 8,
    maxWidth: '85%'
  },
  userMessage: {
    backgroundColor: '#7C3AED',
    alignSelf: 'flex-end'
  },
  assistantMessage: {
    backgroundColor: '#2a2a2a',
    alignSelf: 'flex-start'
  },
  messageText: {
    color: '#fff',
    fontSize: 13,
    lineHeight: 18
  },
  loadingMessage: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 10
  },
  loadingText: {
    color: '#C084FC',
    fontSize: 12
  },
  inputRow: {
    flexDirection: 'row',
    gap: 8
  },
  chatInput: {
    flex: 1,
    backgroundColor: '#2a2a2a',
    padding: 10,
    borderRadius: 8,
    color: '#fff',
    fontSize: 13,
    maxHeight: 80,
    borderWidth: 1,
    borderColor: '#444'
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#8B5CF6',
    justifyContent: 'center',
    alignItems: 'center'
  },
  sendButtonDisabled: {
    backgroundColor: '#666'
  },

  // Preview
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40
  },
  emptyStateText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#666',
    marginTop: 12
  },
  emptyStateSubtext: {
    fontSize: 12,
    color: '#444',
    marginTop: 4
  },
  previewCard: {
    backgroundColor: '#2a2a2a',
    padding: 12,
    borderRadius: 8
  },
  previewLabel: {
    color: '#fff',
    fontSize: 13,
    marginBottom: 4
  },
  mediaButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#3B82F6',
    padding: 12,
    borderRadius: 12
  },
  mediaButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold'
  },
  mediaPreview: {
    flexDirection: 'row',
    gap: 8
  },
  mediaThumbnail: {
    width: 80,
    height: 80,
    backgroundColor: '#2a2a2a',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center'
  },
  mediaName: {
    color: '#666',
    fontSize: 10,
    textAlign: 'center'
  },
  evolveButton: {
    backgroundColor: '#22C55E',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center'
  },
  evolveButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold'
  },

  // Deploy
  deployOptions: {
    flexDirection: 'row',
    gap: 8
  },
  deployOption: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    backgroundColor: '#2a2a2a',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#444'
  },
  deployOptionActive: {
    backgroundColor: '#22C55E',
    borderColor: '#22C55E'
  },
  deployOptionText: {
    fontSize: 12,
    color: '#666',
    textTransform: 'capitalize',
    fontWeight: '600'
  },
  deployOptionTextActive: {
    color: '#fff'
  },
  deployButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#22C55E',
    padding: 14,
    borderRadius: 12
  },
  deployButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold'
  },
  statusBox: {
    backgroundColor: '#2a2a2a',
    padding: 12,
    borderRadius: 8
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    textAlign: 'center'
  },
  projectInfo: {
    backgroundColor: '#1E3A8A',
    padding: 12,
    borderRadius: 8
  },
  projectInfoLabel: {
    fontSize: 11,
    color: '#93C5FD',
    marginBottom: 4
  },
  projectInfoValue: {
    fontSize: 13,
    color: '#fff',
    fontWeight: '600'
  },

  // Floating button
  floatingButton: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#8B5CF6',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 8
  },
  restoreButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#8B5CF6',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6
  },
  restoreButtonText: {
    fontSize: 24
  }
});
