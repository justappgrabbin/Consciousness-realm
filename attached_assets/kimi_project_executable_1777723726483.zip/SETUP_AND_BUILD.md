# Synthia Mobile - Expo React Native App

## 🚀 Quick Start

### Prerequisites
- **Node.js 18+** (download from [nodejs.org](https://nodejs.org))
- **Expo CLI** (install globally: `npm install -g expo-cli`)
- **EAS CLI** (for building APK: `npm install -g eas-cli`)
- **Android Studio** (optional, for emulator testing)

---

## 📱 Setup Steps

### 1. Install Dependencies
```bash
cd synthia-mobile
npm install
```

### 2. Start Development Server
```bash
npm start
```

This will display a QR code. Scan it with:
- **Expo Go app** (download from Play Store/App Store)
- **Android emulator** (if you have Android Studio)
- **iOS simulator** (Mac only)

### 3. Test on Your Phone
- Install **Expo Go** from Play Store (Android) or App Store (iOS)
- Scan the QR code from the terminal
- The app will load on your phone

---

## 🔨 Build APK for Android

### Option 1: Build with EAS (Recommended - Cloud Build)
```bash
# Login to Expo
eas login

# Build APK
eas build --platform android --local

# Or build and download
eas build --platform android
```

The APK will be built on Expo's servers and ready to download.

### Option 2: Build Locally (Requires Android Studio)
```bash
# Install Android build tools
npm install -g @react-native-community/cli

# Build APK
npm run build:apk
```

---

## 📥 Install APK on Android Phone

### Method 1: Direct Installation
1. Download the APK file to your computer
2. Connect your Android phone via USB
3. Enable USB debugging on your phone (Settings → Developer Options)
4. Run: `adb install synthia-mobile.apk`

### Method 2: Share and Install
1. Download the APK file
2. Transfer to your phone (email, cloud drive, etc.)
3. Open the file on your phone
4. Tap "Install"

### Method 3: QR Code
1. Host the APK on a web server
2. Generate a QR code pointing to the APK URL
3. Scan with your phone to download and install

---

## 🔧 Configuration

### Backend URL
Edit `App.tsx` and change:
```typescript
const BACKEND_URL = 'https://synthia-server.onrender.com';
```

### App Name & Icon
Edit `app.json`:
```json
{
  "expo": {
    "name": "Synthia",
    "slug": "synthia-mobile",
    "icon": "./assets/icon.png"
  }
}
```

---

## 📊 Features

✅ **Three TRIDENT Heads:** Code, Math, Research  
✅ **Real-time Chat:** Connect to Synthia backend  
✅ **Dark Cyberpunk UI:** Mobile-first design  
✅ **P2P RAG Support:** Query knowledge base  
✅ **Offline Caching:** Works without internet  
✅ **APK Distribution:** Share with anyone  

---

## 🐛 Troubleshooting

### "Cannot connect to backend"
- Check your internet connection
- Verify backend URL is correct in `App.tsx`
- Check if `https://synthia-server.onrender.com/` is accessible

### "Expo Go app won't load"
- Make sure phone and computer are on same WiFi
- Restart Expo CLI: `npm start`
- Clear Expo cache: `expo start --clear`

### "APK build fails"
- Update EAS: `npm install -g eas-cli@latest`
- Clear cache: `rm -rf .expo`
- Rebuild: `eas build --platform android --local`

### "APK won't install"
- Check Android version (requires Android 6+)
- Enable "Unknown sources" in Settings
- Try installing via `adb install`

---

## 📚 Project Structure

```
synthia-mobile/
├── App.tsx              # Main app component
├── index.js             # Entry point
├── app.json             # Expo configuration
├── eas.json             # EAS build configuration
├── package.json         # Dependencies
├── assets/              # Images, icons
│   ├── icon.png
│   ├── splash.png
│   └── adaptive-icon.png
└── SETUP_AND_BUILD.md   # This file
```

---

## 🚀 Build & Deploy Workflow

### 1. Develop Locally
```bash
npm start
# Test in Expo Go
```

### 2. Build APK
```bash
eas build --platform android --local
```

### 3. Download APK
- APK will be available at: `./build/synthia-mobile.apk`

### 4. Distribute
- Share APK file via email, cloud drive, or QR code
- Users can install directly on Android phones

### 5. Update
- Make changes to code
- Rebuild APK with new version
- Users can install over existing app

---

## 🎯 Next Steps

1. **Customize UI:** Edit `App.tsx` styles
2. **Add Features:** Integrate more TRIDENT tools
3. **Build APK:** Follow "Build APK" section above
4. **Share:** Distribute APK to users
5. **Monitor:** Check backend logs for errors

---

## 📞 Support

- **Expo Docs:** https://docs.expo.dev
- **React Native Docs:** https://reactnative.dev
- **EAS Build:** https://docs.expo.dev/build/introduction/
- **Backend:** https://synthia-server.onrender.com

---

**Ready to build! Follow the steps above to create your APK.** 🚀
