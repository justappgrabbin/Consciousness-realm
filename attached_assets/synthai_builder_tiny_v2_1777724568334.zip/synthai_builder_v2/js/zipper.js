
// Minimal ZIP (store-only) writer.
// Credits: Simplified from public-domain snippets; no compression, files < 4GB.
export async function makeZip(files) {
  // files: [{name: 'path/to/file', data: Uint8Array}]
  const enc = new TextEncoder();
  let fileRecords = [];
  let fileDataParts = [];
  let offset = 0;

  function crc32(buf) {
    // Simple CRC32
    let table = (crc32.table ||= (() => {
      let c, t = new Uint32Array(256);
      for (let n = 0; n < 256; n++) {
        c = n;
        for (let k = 0; k < 8; k++) {
          c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        }
        t[n] = c >>> 0;
      }
      return t;
    })());
    let crc = 0 ^ (-1);
    for (let i = 0; i < buf.length; i++) {
      crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xFF];
    }
    return (crc ^ (-1)) >>> 0;
  }

  for (const f of files) {
    const nameBytes = enc.encode(f.name);
    const data = f.data;
    const csum = crc32(data);
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const view = new DataView(localHeader.buffer);
    let p = 0;
    // Local file header signature
    view.setUint32(p, 0x04034b50, true); p += 4;
    view.setUint16(p, 20, true); p += 2; // version needed
    view.setUint16(p, 0, true); p += 2;  // flags
    view.setUint16(p, 0, true); p += 2;  // method = store
    view.setUint16(p, 0, true); p += 2;  // time
    view.setUint16(p, 0, true); p += 2;  // date
    view.setUint32(p, csum, true); p += 4; // crc32
    view.setUint32(p, data.length, true); p += 4; // comp size
    view.setUint32(p, data.length, true); p += 4; // uncomp size
    view.setUint16(p, nameBytes.length, true); p += 2; // name len
    view.setUint16(p, 0, true); p += 2; // extra len
    localHeader.set(nameBytes, 30);

    fileDataParts.push(localHeader, data);

    fileRecords.push({
      nameBytes,
      csum,
      compSize: data.length,
      uncompSize: data.length,
      offset
    });
    offset += localHeader.length + data.length;
  }

  // Central directory
  const cdParts = [];
  let cdSize = 0;
  for (const r of fileRecords) {
    const cd = new Uint8Array(46 + r.nameBytes.length);
    const view = new DataView(cd.buffer);
    let p = 0;
    view.setUint32(p, 0x02014b50, true); p += 4; // sig
    view.setUint16(p, 20, true); p += 2; // ver made
    view.setUint16(p, 20, true); p += 2; // ver needed
    view.setUint16(p, 0, true); p += 2;  // flags
    view.setUint16(p, 0, true); p += 2;  // method
    view.setUint16(p, 0, true); p += 2;  // time
    view.setUint16(p, 0, true); p += 2;  // date
    view.setUint32(p, r.csum, true); p += 4;
    view.setUint32(p, r.compSize, true); p += 4;
    view.setUint32(p, r.uncompSize, true); p += 4;
    view.setUint16(p, r.nameBytes.length, true); p += 2;
    view.setUint16(p, 0, true); p += 2; // extra
    view.setUint16(p, 0, true); p += 2; // comment
    view.setUint16(p, 0, true); p += 2; // disk start
    view.setUint16(p, 0, true); p += 2; // int attrs
    view.setUint32(p, 0, true); p += 4; // ext attrs
    view.setUint32(p, r.offset, true); p += 4; // offset of local header
    cd.set(r.nameBytes, 46);
    cdParts.push(cd);
    cdSize += cd.length;
  }

  const centralDirOffset = offset;
  const fileCount = fileRecords.length;
  const end = new Uint8Array(22);
  const endView = new DataView(end.buffer);
  endView.setUint32(0, 0x06054b50, true); // EOCD
  // disk numbers all zero
  endView.setUint16(8, fileCount, true);
  endView.setUint16(10, fileCount, true);
  endView.setUint32(12, cdSize, true);
  endView.setUint32(16, centralDirOffset, true);
  // comment length 0

  const blob = new Blob([...fileDataParts, ...cdParts, end], {type: 'application/zip'});
  return blob;
}
