# AI Self-Builder Integration Guide

## Architecture Overview

The AI Self-Builder application consists of three main components:

1. **React Frontend** (`/home/ubuntu/ai-self-builder-react/client`)
   - User interface for PDF upload, chat, code preview, and neural dashboard
   - Communicates with Express backend via tRPC

2. **Express Backend** (`/home/ubuntu/ai-self-builder-react/server`)
   - tRPC API server
   - Handles PDF upload to S3, LLM calls, database operations
   - Communicates with neural brain via HTTP

3. **FastAPI Neural Brain** (`/home/ubuntu/neural-brain`)
   - Python microservice with PyTorch and Sentence Transformers
   - Generates embeddings, learns isomorphic patterns, provides intelligent suggestions
   - Runs independently on port 8001

## Running the Application

### Step 1: Start the Neural Brain

```bash
cd /home/ubuntu/neural-brain

# Option A: Using the startup script
./start.sh

# Option B: Direct Python
python main.py

# Option C: Production mode with uvicorn
ENV=production uvicorn main:app --host 0.0.0.0 --port 8001 --workers 4
```

The neural brain will start on `http://localhost:8001` and output:
```
🧠 Initializing Neural Brain...
✓ Embedding model loaded
✓ Isomorphic network initialized
🧠 Neural Brain ready!
```

### Step 2: Configure the React App Backend

Set the neural brain URL in the Express backend environment:

```bash
cd /home/ubuntu/ai-self-builder-react

# Add to .env or set environment variable
export NEURAL_BRAIN_URL=http://localhost:8001
```

### Step 3: Start the React App

```bash
cd /home/ubuntu/ai-self-builder-react

# Development mode
pnpm dev

# The app will start on http://localhost:3000
```

## Data Flow

### PDF Upload & Knowledge Extraction

```
User uploads PDF
    ↓
React Frontend (PDFUploader.tsx)
    ↓
Express Backend (knowledge.ts router)
    ↓
S3 Storage (file upload)
    ↓
LLM Extraction (concepts, code blocks, relationships)
    ↓
Neural Brain: Generate Embeddings
    ↓
Neural Brain: Add Nodes & Edges
    ↓
Neural Brain: Training Step
    ↓
MySQL Database (persist knowledge)
    ↓
React Dashboard (display metrics)
```

### Code Generation

```
User enters prompt
    ↓
React Frontend (ChatInterface.tsx)
    ↓
Express Backend (knowledge.ts router)
    ↓
Neural Brain: Find Similar Patterns
    ↓
LLM: Generate Code (with context)
    ↓
React Frontend (display generated code)
```

### Adaptive Suggestions

```
User views dashboard
    ↓
React Frontend (NeuralDashboard.tsx)
    ↓
Express Backend (suggestions router)
    ↓
Neural Brain: Find Related Patterns
    ↓
React Frontend (display suggestions)
```

## API Contracts

### Neural Brain Client (TypeScript)

Located in `/home/ubuntu/ai-self-builder-react/server/neural-brain-client.ts`

```typescript
// Singleton instance
const neuralBrain = getNeuralBrainClient();

// Generate embeddings
const embeddings = await neuralBrain.embedText("text");
const codeEmbeddings = await neuralBrain.embedCode("code");

// Add knowledge
const nodeId = await neuralBrain.addNode("concept", "name", embedding);
await neuralBrain.addEdge(sourceId, targetId, "relationship");

// Find patterns
const patterns = await neuralBrain.findPatterns(embedding, "concept", 5);

// Training
const metrics = await neuralBrain.trainStep(0.01, 1);
const currentMetrics = await neuralBrain.getMetrics();
```

### tRPC Procedures

**PDF Upload & Extraction**:
```typescript
trpc.knowledge.pdf.upload.useMutation()
trpc.knowledge.pdf.extract.useMutation()
```

**Code Generation**:
```typescript
trpc.knowledge.code.generate.useMutation()
```

**Search & Suggestions**:
```typescript
trpc.knowledge.query.search.useQuery()
trpc.knowledge.suggestions.getAdaptive.useQuery()
```

**Dashboard**:
```typescript
trpc.knowledge.dashboard.metrics.useQuery()
```

## Environment Variables

### React App Backend (.env)

```env
# Database
DATABASE_URL=mysql://user:password@localhost:3306/ai_self_builder

# OAuth
VITE_APP_ID=your_manus_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# Neural Brain
NEURAL_BRAIN_URL=http://localhost:8001

# Other
JWT_SECRET=your_secret
OWNER_OPEN_ID=your_open_id
```

### Neural Brain (.env)

```env
# Server
ENV=development
HOST=0.0.0.0
PORT=8001
CORS_ORIGINS=*

# Models
EMBEDDING_MODEL=all-MiniLM-L6-v2
EMBEDDING_DIM=384

# Integration
REACT_APP_URL=http://localhost:3000
```

## Troubleshooting

### Neural Brain Not Responding

1. Check if the service is running:
```bash
curl http://localhost:8001/health
```

2. Check logs:
```bash
# If running with start.sh, check console output
# If running with uvicorn, check stderr
```

3. Verify Python dependencies:
```bash
cd /home/ubuntu/neural-brain
python -c "import fastapi, torch, sentence_transformers; print('OK')"
```

### Database Connection Issues

1. Verify MySQL is running
2. Check DATABASE_URL in .env
3. Run migrations:
```bash
cd /home/ubuntu/ai-self-builder-react
pnpm drizzle-kit migrate
```

### LLM API Errors

1. Verify BUILT_IN_FORGE_API_KEY is set
2. Check BUILT_IN_FORGE_API_URL is correct
3. Test LLM directly:
```bash
curl -X POST https://api.manus.im/v1/chat/completions \
  -H "Authorization: Bearer $BUILT_IN_FORGE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "Hello"}]}'
```

## Performance Optimization

### Neural Brain

- **Embedding Generation**: ~1ms per text (CPU)
- **Pattern Matching**: O(n) similarity search (in-memory)
- **Training Step**: O(e) where e = number of edges

For production with millions of nodes:
1. Use vector database (Pinecone, Weaviate, Milvus)
2. Implement caching layer
3. Use GPU for embedding generation
4. Batch operations

### React App

- Use React Query for caching (already configured via tRPC)
- Implement code splitting for large components
- Use Web Workers for heavy computations
- Lazy load the neural dashboard

## Deployment

### Local Development

```bash
# Terminal 1: Neural Brain
cd /home/ubuntu/neural-brain
./start.sh

# Terminal 2: React App
cd /home/ubuntu/ai-self-builder-react
pnpm dev
```

### Docker Deployment

See `docker-compose.yml` (to be created) for containerized deployment.

### Production Checklist

- [ ] Set ENV=production in both services
- [ ] Use production database (not SQLite)
- [ ] Enable HTTPS/TLS
- [ ] Set up proper CORS origins
- [ ] Configure logging and monitoring
- [ ] Set up backups for MySQL
- [ ] Use vector database for neural brain
- [ ] Enable caching (Redis)
- [ ] Set up CI/CD pipeline
- [ ] Monitor error rates and performance

## Next Steps

1. **Seed with Mew.pdf**: Upload and process the initial knowledge document
2. **Implement visualizations**: Add D3.js knowledge graph visualization
3. **Add user features**: Favorites, history, sharing
4. **Optimize performance**: Vector database, caching, GPU support
5. **Deploy to production**: Docker, Kubernetes, cloud platform

## Support

For issues or questions:
1. Check the logs in both services
2. Verify all environment variables are set
3. Ensure all dependencies are installed
4. Test each component independently
5. Review the architecture documentation
