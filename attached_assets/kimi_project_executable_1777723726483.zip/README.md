# Synthia Mobile - React Native Expo App

A mobile-first Expo React Native application that connects to the **Synthia TRIDENT backend** running on Render.

## 🎯 Features

- **Three Specialist Heads:** Code, Math, Research
- **Real-Time Chat:** Instant responses from TRIDENT
- **P2P RAG Support:** Access distributed knowledge base
- **Dark Cyberpunk UI:** Mobile-optimized interface
- **Offline Support:** Cache messages locally
- **APK Distribution:** Share as standalone Android app

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development
```bash
npm start
```

### 3. Test on Phone
- Install **Expo Go** from Play Store
- Scan QR code from terminal
- App loads on your phone

### 4. Build APK
```bash
eas build --platform android --local
```

The APK will be ready to install on any Android phone.

## 📱 What You Get

✅ Mobile-first React Native app  
✅ Connects to `https://synthia-server.onrender.com/`  
✅ Three TRIDENT heads (Code, Math, Research)  
✅ Real-time chat interface  
✅ Dark cyberpunk theme  
✅ Builds into standalone APK  
✅ Works on Android 6+  

## 📚 Documentation

- **Setup & Build:** See [SETUP_AND_BUILD.md](./SETUP_AND_BUILD.md)
- **Expo Docs:** https://docs.expo.dev
- **React Native:** https://reactnative.dev

## 🔧 Configuration

Backend URL is set in `App.tsx`:
```typescript
const BACKEND_URL = 'https://synthia-server.onrender.com';
```

Change this if your backend is hosted elsewhere.

## 📦 Distribution

### Share APK
1. Build APK: `eas build --platform android --local`
2. Download the APK file
3. Share via email, cloud drive, or QR code
4. Users can install directly on Android phones

### Update App
1. Make changes to code
2. Rebuild APK with new version number
3. Users can install over existing app

## 🎨 Customization

Edit `App.tsx` to:
- Change colors and theme
- Add new features
- Modify UI layout
- Add more TRIDENT tools

## 🐛 Troubleshooting

**Can't connect to backend?**
- Check internet connection
- Verify backend URL in `App.tsx`
- Test: `curl https://synthia-server.onrender.com/`

**APK won't install?**
- Requires Android 6+
- Enable "Unknown sources" in Settings
- Try: `adb install synthia-mobile.apk`

**Expo Go won't load?**
- Restart CLI: `npm start`
- Clear cache: `expo start --clear`
- Check WiFi connection

## 📞 Support

- Expo: https://docs.expo.dev
- React Native: https://reactnative.dev
- Backend: https://synthia-server.onrender.com

---

**Ready to build your APK!** Follow [SETUP_AND_BUILD.md](./SETUP_AND_BUILD.md) for step-by-step instructions.
