import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Upload, FileArchive, CheckCircle2, Sparkles, Loader2 } from "lucide-react";
import type { Project } from "@shared/schema";

interface ExtractedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  objectPath: string;
  aiSummary?: string;
}

export default function Unzipper() {
  const { toast } = useToast();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [extractedFiles, setExtractedFiles] = useState<ExtractedFile[]>([]);
  const [selectedFileIds, setSelectedFileIds] = useState<Set<string>>(new Set());
  const [uploading, setUploading] = useState(false);
  const [analyzingFiles, setAnalyzingFiles] = useState(false);

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  const uploadUrlMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/objects/upload', {}) as unknown as { uploadURL: string };
      return response;
    },
  });

  const createProjectMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/projects', {
        name: selectedFile?.name.replace('.zip', '') || "ZIP Extraction",
        description: "Extracted from ZIP file",
        processingMode: "balanced",
        aiCommentaryDepth: 3,
      }) as any;
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.name.endsWith('.zip')) {
      setSelectedFile(file);
      setExtractedFiles([]);
      setSelectedFileIds(new Set());
    } else {
      toast({
        title: "Invalid file",
        description: "Please select a ZIP file",
        variant: "destructive",
      });
    }
  };

  const handleExtract = async () => {
    if (!selectedFile) return;

    setUploading(true);
    try {
      // Create temporary project for extraction
      const project = await createProjectMutation.mutateAsync();
      
      // Get upload URL
      const { uploadURL } = await uploadUrlMutation.mutateAsync();
      
      // Upload ZIP file
      const uploadResponse = await fetch(uploadURL, {
        method: "PUT",
        body: selectedFile,
        headers: {
          "Content-Type": "application/zip",
        },
      });

      if (!uploadResponse.ok) {
        throw new Error("Upload failed");
      }

      // Register and extract (objectPath will be normalized by server)
      const extractResponse = await apiRequest('POST', '/api/files', {
        projectId: project.id,
        name: selectedFile.name,
        type: "application/zip",
        size: selectedFile.size,
        objectPath: uploadURL, // Server will normalize this
      }) as any;

      const files = extractResponse.files || [];
      setExtractedFiles(files);
      
      // Select all by default
      setSelectedFileIds(new Set(files.map((f: ExtractedFile) => f.id)));
      
      toast({
        title: "ZIP extracted",
        description: `Found ${files.length} files`,
      });

      // Analyze files with AI
      analyzeFiles(files);
    } catch (error) {
      console.error("Extraction error:", error);
      toast({
        title: "Extraction failed",
        description: "There was an error extracting your ZIP file",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const analyzeFiles = async (files: ExtractedFile[]) => {
    setAnalyzingFiles(true);
    try {
      // Group files by type for batch analysis
      const codeFiles = files.filter(f => 
        f.type.includes('javascript') || 
        f.type.includes('python') || 
        f.type.includes('java') ||
        f.type.includes('text')
      );

      // Quick AI summary for each file type
      const analyzedFiles = files.map(file => {
        const ext = file.name.split('.').pop()?.toLowerCase();
        let summary = "";
        
        if (file.type.includes('javascript') || ext === 'js' || ext === 'jsx' || ext === 'ts' || ext === 'tsx') {
          summary = "JavaScript/TypeScript code file";
        } else if (file.type.includes('python') || ext === 'py') {
          summary = "Python code file";
        } else if (file.type.includes('pdf')) {
          summary = "PDF document - could contain book/documentation";
        } else if (file.type.includes('epub')) {
          summary = "EPUB book file";
        } else if (ext === 'json') {
          summary = "JSON data/config file";
        } else if (ext === 'md') {
          summary = "Markdown documentation";
        } else if (ext === 'html') {
          summary = "HTML template/page";
        } else if (ext === 'css') {
          summary = "CSS stylesheet";
        } else {
          summary = `${file.type.split('/')[1] || 'Unknown'} file`;
        }

        return { ...file, aiSummary: summary };
      });

      setExtractedFiles(analyzedFiles);
    } catch (error) {
      console.error("Analysis error:", error);
    } finally {
      setAnalyzingFiles(false);
    }
  };

  const toggleFileSelection = (fileId: string) => {
    const newSelection = new Set(selectedFileIds);
    if (newSelection.has(fileId)) {
      newSelection.delete(fileId);
    } else {
      newSelection.add(fileId);
    }
    setSelectedFileIds(newSelection);
  };

  const selectAll = () => {
    setSelectedFileIds(new Set(extractedFiles.map(f => f.id)));
  };

  const selectNone = () => {
    setSelectedFileIds(new Set());
  };

  const handleAddToProject = async () => {
    if (selectedFileIds.size === 0) {
      toast({
        title: "No files selected",
        description: "Please select at least one file to add",
        variant: "destructive",
      });
      return;
    }

    queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    queryClient.invalidateQueries({ queryKey: ['/api/files'] });

    toast({
      title: "Files added to project",
      description: `${selectedFileIds.size} files are ready for processing`,
    });

    // Navigate to process page
    window.location.href = '/process';
  };

  const getFileIcon = (type: string) => {
    if (type.includes('javascript') || type.includes('typescript')) return '📄';
    if (type.includes('python')) return '🐍';
    if (type.includes('pdf')) return '📕';
    if (type.includes('epub')) return '📚';
    if (type.includes('json')) return '⚙️';
    if (type.includes('html')) return '🌐';
    if (type.includes('css')) return '🎨';
    return '📄';
  };

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 max-w-6xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Smart ZIP Extractor</h1>
          <p className="text-muted-foreground">
            Upload a ZIP file, see what's inside with AI insights, and choose which files to add
          </p>
        </div>

        <Card className="p-6">
          <div className="space-y-6">
            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <FileArchive className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              
              <input
                type="file"
                accept=".zip"
                onChange={handleFileSelect}
                className="hidden"
                id="zip-input"
                data-testid="input-zip-file"
              />
              
              <label htmlFor="zip-input">
                <Button variant="outline" asChild>
                  <span>
                    <Upload className="w-4 h-4 mr-2" />
                    Select ZIP File
                  </span>
                </Button>
              </label>
              
              {selectedFile && (
                <div className="mt-4">
                  <p className="text-sm text-muted-foreground">Selected:</p>
                  <p className="font-medium">{selectedFile.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              )}
            </div>

            {selectedFile && extractedFiles.length === 0 && (
              <Button 
                onClick={handleExtract} 
                disabled={uploading}
                className="w-full"
                data-testid="button-extract"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Extracting...
                  </>
                ) : (
                  "Extract & Analyze Files"
                )}
              </Button>
            )}
          </div>
        </Card>

        {extractedFiles.length > 0 && (
          <>
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  <h2 className="text-xl font-semibold">
                    Found {extractedFiles.length} Files
                  </h2>
                  {analyzingFiles && (
                    <Badge variant="secondary">
                      <Sparkles className="w-3 h-3 mr-1" />
                      Analyzing...
                    </Badge>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={selectAll} data-testid="button-select-all">
                    Select All
                  </Button>
                  <Button variant="outline" size="sm" onClick={selectNone} data-testid="button-select-none">
                    Select None
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2 max-h-96 overflow-y-auto mb-4">
                {extractedFiles.map((file) => (
                  <div 
                    key={file.id}
                    className="flex items-start gap-3 p-3 rounded-lg border bg-card hover-elevate cursor-pointer"
                    onClick={() => toggleFileSelection(file.id)}
                    data-testid={`file-${file.id}`}
                  >
                    <Checkbox
                      checked={selectedFileIds.has(file.id)}
                      onCheckedChange={() => toggleFileSelection(file.id)}
                      data-testid={`checkbox-${file.id}`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{getFileIcon(file.type)}</span>
                        <p className="font-medium truncate">{file.name}</p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {file.aiSummary || file.type} • {(file.size / 1024).toFixed(1)} KB
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground">
                    {selectedFileIds.size} of {extractedFiles.length} files selected
                  </p>
                </div>
                <Button 
                  onClick={handleAddToProject}
                  disabled={selectedFileIds.size === 0}
                  className="w-full"
                  data-testid="button-add-to-project"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Add Selected Files to Project
                </Button>
              </div>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
