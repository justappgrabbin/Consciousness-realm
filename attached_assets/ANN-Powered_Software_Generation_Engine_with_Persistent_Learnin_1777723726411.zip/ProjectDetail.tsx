import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation, useParams } from "wouter";
import {
  ArrowLeft,
  Zap,
  Brain,
  Code2,
  Upload,
  MessageSquare,
  DollarSign,
  Eye,
  Download,
  Plus,
  Send,
  Loader2,
  FileText,
  X,
  ChevronRight,
  Package,
  AlertCircle,
  CheckCircle,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import SyntaxHighlighter from "react-syntax-highlighter";
import { atomOneDark } from "react-syntax-highlighter/dist/esm/styles/hljs";

const TABS = [
  { id: "inputs", label: "Inputs", icon: Upload },
  { id: "chat", label: "Karen Chat", icon: MessageSquare },
  { id: "generate", label: "Generate", icon: Zap },
  { id: "artifacts", label: "Artifacts", icon: Package },
  { id: "monetize", label: "Monetize", icon: DollarSign },
] as const;

type Tab = (typeof TABS)[number]["id"];

const PIPELINE_STAGES = ["ingest", "analyze", "generate", "preview", "deploy"] as const;

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const projectId = parseInt(id ?? "0");
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>("inputs");

  const { data: project, isLoading, refetch: refetchProject } = trpc.projects.get.useQuery(
    { id: projectId },
    { enabled: isAuthenticated && !!projectId }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" style={{ color: "oklch(0.60 0.28 350)" }} />
          <p className="text-xs tracking-widest uppercase text-muted-foreground">Loading project...</p>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Project not found. Karen checked twice.</p>
          <Button onClick={() => navigate("/dashboard")}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  const stageIndex = PIPELINE_STAGES.indexOf(project.pipelineStage as any);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="px-8 py-4 flex items-center justify-between shrink-0"
        style={{ borderBottom: "1px solid oklch(0.22 0.04 255)", background: "oklch(0.10 0.025 255 / 0.9)", backdropFilter: "blur(12px)" }}>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="text-muted-foreground">
            <ArrowLeft className="h-4 w-4 mr-2" /> Dashboard
          </Button>
          <div className="h-5 w-px" style={{ background: "oklch(0.22 0.04 255)" }} />
          <div>
            <h1 className="font-bold text-sm">{project.name}</h1>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-xs px-2 py-0.5 rounded-full"
                style={{
                  background: project.status === "complete" ? "oklch(0.72 0.18 200 / 0.1)" : "oklch(0.60 0.28 350 / 0.1)",
                  color: project.status === "complete" ? "oklch(0.72 0.18 200)" : "oklch(0.70 0.28 350)",
                  border: `1px solid ${project.status === "complete" ? "oklch(0.72 0.18 200 / 0.3)" : "oklch(0.60 0.28 350 / 0.3)"}`,
                }}>
                {project.status}
              </span>
            </div>
          </div>
        </div>

        {/* Suggestions Link */}
        <button onClick={() => navigate(`/projects/${projectId}/suggestions`)}
          className="hidden md:flex items-center gap-2 text-xs px-3 py-1.5 rounded transition-colors"
          style={{ background: "oklch(0.72 0.18 200 / 0.08)", color: "oklch(0.72 0.18 200)", border: "1px solid oklch(0.72 0.18 200 / 0.2)" }}
          onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "oklch(0.72 0.18 200 / 0.15)"; }}
          onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "oklch(0.72 0.18 200 / 0.08)"; }}>
          <Eye className="h-3 w-3" /> Suggestions
        </button>
        {/* Pipeline */}
        <div className="hidden lg:flex items-center gap-1">
          {PIPELINE_STAGES.map((stage, i) => (
            <div key={stage} className="flex items-center gap-1">
              <div className="text-xs px-2 py-1 rounded"
                style={{
                  background: i < stageIndex ? "oklch(0.72 0.18 200 / 0.1)" : i === stageIndex ? "oklch(0.60 0.28 350 / 0.15)" : "oklch(0.14 0.025 255)",
                  color: i < stageIndex ? "oklch(0.72 0.18 200)" : i === stageIndex ? "oklch(0.70 0.28 350)" : "oklch(0.40 0.04 255)",
                  border: `1px solid ${i < stageIndex ? "oklch(0.72 0.18 200 / 0.3)" : i === stageIndex ? "oklch(0.60 0.28 350 / 0.4)" : "oklch(0.22 0.04 255)"}`,
                }}>
                {stage}
              </div>
              {i < PIPELINE_STAGES.length - 1 && (
                <ChevronRight className="h-3 w-3 text-muted-foreground" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="px-8 flex gap-1 shrink-0" style={{ borderBottom: "1px solid oklch(0.22 0.04 255)" }}>
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-2 px-4 py-3 text-xs tracking-wider uppercase transition-colors relative"
              style={{ color: isActive ? "oklch(0.70 0.28 350)" : "oklch(0.55 0.04 255)" }}>
              <Icon className="h-3.5 w-3.5" />
              {tab.label}
              {isActive && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5"
                  style={{ background: "oklch(0.60 0.28 350)" }} />
              )}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === "inputs" && <InputsTab projectId={projectId} project={project} />}
        {activeTab === "chat" && <ChatTab projectId={projectId} project={project} />}
        {activeTab === "generate" && <GenerateTab projectId={projectId} project={project} onGenerated={() => { refetchProject(); setActiveTab("artifacts"); }} />}
        {activeTab === "artifacts" && <ArtifactsTab projectId={projectId} />}
        {activeTab === "monetize" && <MonetizeTab projectId={projectId} project={project} />}
      </div>
    </div>
  );
}

// ─── Inputs Tab ───────────────────────────────────────────────────────────────
function InputsTab({ projectId, project }: { projectId: number; project: any }) {
  const [codeContent, setCodeContent] = useState("");
  const [codeLang, setCodeLang] = useState("typescript");
  const [codeFilename, setCodeFilename] = useState("");
  const [inputMode, setInputMode] = useState<"code" | "file">("code");
  const fileRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();

  const { data: inputs, isLoading } = trpc.inputs.list.useQuery({ projectId });
  const addCode = trpc.inputs.addCodeSnippet.useMutation({
    onSuccess: () => {
      utils.inputs.list.invalidate({ projectId });
      setCodeContent("");
      toast.success("K:// Code ingested. Analyzing patterns...");
    },
  });
  const uploadFile = trpc.inputs.uploadFile.useMutation({
    onSuccess: () => {
      utils.inputs.list.invalidate({ projectId });
      toast.success("K:// File uploaded and queued for analysis.");
    },
  });
  const deleteInput = trpc.inputs.delete.useMutation({
    onSuccess: () => utils.inputs.list.invalidate({ projectId }),
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const content = ev.target?.result as string;
      await uploadFile.mutateAsync({
        projectId,
        filename: file.name,
        mimeType: file.type || "text/plain",
        content,
        fileSize: file.size,
        language: file.name.split(".").pop() ?? "text",
      });
    };
    reader.readAsText(file);
  };

  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-1">Input Ingestion</h2>
        <p className="text-sm text-muted-foreground">Feed Karen your code, files, and context. She'll analyze everything.</p>
      </div>

      {/* Intent display */}
      {project.intent && (
        <div className="mb-6 p-4 rounded-lg" style={{ background: "oklch(0.60 0.28 350 / 0.05)", border: "1px solid oklch(0.60 0.28 350 / 0.2)" }}>
          <p className="text-xs tracking-widest uppercase mb-2" style={{ color: "oklch(0.60 0.28 350)" }}>Project Intent</p>
          <p className="text-sm text-muted-foreground">{project.intent}</p>
        </div>
      )}

      {/* Input mode toggle */}
      <div className="flex gap-2 mb-6">
        <button onClick={() => setInputMode("code")}
          className="px-4 py-2 text-xs tracking-wider uppercase rounded transition-all"
          style={{
            background: inputMode === "code" ? "oklch(0.60 0.28 350 / 0.15)" : "oklch(0.11 0.025 255)",
            color: inputMode === "code" ? "oklch(0.70 0.28 350)" : "oklch(0.55 0.04 255)",
            border: `1px solid ${inputMode === "code" ? "oklch(0.60 0.28 350 / 0.4)" : "oklch(0.22 0.04 255)"}`,
          }}>
          <Code2 className="h-3 w-3 inline mr-2" /> Code Snippet
        </button>
        <button onClick={() => setInputMode("file")}
          className="px-4 py-2 text-xs tracking-wider uppercase rounded transition-all"
          style={{
            background: inputMode === "file" ? "oklch(0.60 0.28 350 / 0.15)" : "oklch(0.11 0.025 255)",
            color: inputMode === "file" ? "oklch(0.70 0.28 350)" : "oklch(0.55 0.04 255)",
            border: `1px solid ${inputMode === "file" ? "oklch(0.60 0.28 350 / 0.4)" : "oklch(0.22 0.04 255)"}`,
          }}>
          <Upload className="h-3 w-3 inline mr-2" /> Upload File
        </button>
      </div>

      {inputMode === "code" ? (
        <div className="mb-6 space-y-3">
          <div className="flex gap-3">
            <input value={codeFilename} onChange={(e) => setCodeFilename(e.target.value)} placeholder="filename.ts (optional)"
              className="flex-1 px-3 py-2 rounded text-xs outline-none"
              style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)", color: "oklch(0.92 0.03 240)" }} />
            <select value={codeLang} onChange={(e) => setCodeLang(e.target.value)}
              className="px-3 py-2 rounded text-xs outline-none"
              style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)", color: "oklch(0.92 0.03 240)" }}>
              {["typescript", "javascript", "python", "rust", "go", "java", "sql", "html", "css", "json", "yaml", "shell"].map((l) => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
          </div>
          <textarea value={codeContent} onChange={(e) => setCodeContent(e.target.value)}
            placeholder="Paste your code here..."
            rows={10}
            className="w-full px-4 py-3 rounded-lg text-xs outline-none resize-none"
            style={{
              background: "oklch(0.08 0.02 255)",
              border: "1px solid oklch(0.22 0.04 255)",
              color: "oklch(0.82 0.06 200)",
              fontFamily: "JetBrains Mono, monospace",
              lineHeight: "1.6",
            }} />
          <Button onClick={() => addCode.mutateAsync({ projectId, content: codeContent, language: codeLang, filename: codeFilename || undefined })}
            disabled={!codeContent.trim() || addCode.isPending}
            style={{ background: "oklch(0.60 0.28 350)", color: "oklch(0.98 0.01 0)", border: "none" }}>
            {addCode.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
            Ingest Code
          </Button>
        </div>
      ) : (
        <div className="mb-6">
          <div className="border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-all"
            style={{ borderColor: "oklch(0.22 0.04 255)" }}
            onClick={() => fileRef.current?.click()}
            onMouseEnter={(e) => (e.currentTarget.style.borderColor = "oklch(0.60 0.28 350 / 0.5)")}
            onMouseLeave={(e) => (e.currentTarget.style.borderColor = "oklch(0.22 0.04 255)")}>
            <Upload className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
            <p className="text-sm font-medium mb-1">Drop files or click to upload</p>
            <p className="text-xs text-muted-foreground">Text files, code, documents — Karen reads everything</p>
            <input ref={fileRef} type="file" className="hidden" accept=".ts,.tsx,.js,.jsx,.py,.rs,.go,.java,.sql,.html,.css,.json,.yaml,.yml,.md,.txt,.env" onChange={handleFileUpload} />
          </div>
          {uploadFile.isPending && (
            <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
              <Loader2 className="h-3 w-3 animate-spin" /> Uploading and queuing for analysis...
            </div>
          )}
        </div>
      )}

      {/* Existing inputs */}
      <div>
        <h3 className="text-xs tracking-widest uppercase mb-3 text-muted-foreground">Ingested Inputs ({inputs?.length ?? 0})</h3>
        {isLoading ? (
          <div className="space-y-2">{[1, 2].map((i) => <div key={i} className="h-12 rounded animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />)}</div>
        ) : inputs?.length === 0 ? (
          <p className="text-xs text-muted-foreground italic">K:// No inputs yet. Feed me something to analyze.</p>
        ) : (
          <div className="space-y-2">
            {inputs?.map((input) => (
              <div key={input.id} className="flex items-center gap-3 px-4 py-3 rounded-lg"
                style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
                <FileText className="h-4 w-4 shrink-0" style={{ color: "oklch(0.70 0.22 255)" }} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{input.filename ?? input.inputType}</p>
                  <p className="text-xs text-muted-foreground">{input.inputType} · {input.language ?? "unknown"}</p>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-full shrink-0"
                  style={{
                    background: input.embeddingStatus === "done" ? "oklch(0.72 0.18 200 / 0.1)" : "oklch(0.60 0.28 350 / 0.1)",
                    color: input.embeddingStatus === "done" ? "oklch(0.72 0.18 200)" : "oklch(0.70 0.28 350)",
                    border: `1px solid ${input.embeddingStatus === "done" ? "oklch(0.72 0.18 200 / 0.3)" : "oklch(0.60 0.28 350 / 0.3)"}`,
                  }}>
                  {input.embeddingStatus}
                </span>
                <button onClick={() => deleteInput.mutateAsync({ id: input.id, projectId })}
                  className="text-muted-foreground hover:text-destructive transition-colors">
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        )}
       </div>

      {/* Unified Context Panel */}
      {inputs && inputs.length > 0 && (
        <div className="mt-6">
          <h3 className="text-xs tracking-widest uppercase mb-3" style={{ color: "oklch(0.72 0.18 200)" }}>Fused Context Preview</h3>
          <div className="p-4 rounded-lg" style={{ background: "oklch(0.08 0.02 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
            <p className="text-xs font-mono mb-3" style={{ color: "oklch(0.60 0.28 350)" }}>K:// Context synthesis — {inputs.length} input{inputs.length !== 1 ? 's' : ''} fused</p>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="p-3 rounded" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.18 0.03 255)" }}>
                <p className="text-xs text-muted-foreground mb-1">Languages Detected</p>
                <div className="flex flex-wrap gap-1">
                  {Array.from(new Set(inputs.map((i: any) => i.language).filter(Boolean))).map((lang: any) => (
                    <span key={lang} className="text-xs px-2 py-0.5 rounded" style={{ background: "oklch(0.55 0.22 255 / 0.1)", color: "oklch(0.70 0.22 255)", border: "1px solid oklch(0.55 0.22 255 / 0.3)" }}>{lang}</span>
                  ))}
                </div>
              </div>
              <div className="p-3 rounded" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.18 0.03 255)" }}>
                <p className="text-xs text-muted-foreground mb-1">Input Types</p>
                <div className="flex flex-wrap gap-1">
                  {Array.from(new Set(inputs.map((i: any) => i.inputType))).map((type: any) => (
                    <span key={type} className="text-xs px-2 py-0.5 rounded" style={{ background: "oklch(0.60 0.28 350 / 0.1)", color: "oklch(0.70 0.28 350)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>{type}</span>
                  ))}
                </div>
              </div>
            </div>
            <div className="text-xs text-muted-foreground">
              <span className="font-mono" style={{ color: "oklch(0.72 0.18 200)" }}>STATUS:</span> {inputs.filter((i: any) => i.embeddingStatus === 'done').length}/{inputs.length} inputs analyzed · Ready for generation
            </div>
          </div>
        </div>
      )}

      {/* Code Preview with Syntax Highlighting */}
      {inputs && inputs.filter((i: any) => i.inputType === 'code_snippet').length > 0 && (
        <div className="mt-6">
          <h3 className="text-xs tracking-widest uppercase mb-3 text-muted-foreground">Code Preview</h3>
          <div className="space-y-3">
            {inputs.filter((i: any) => i.inputType === 'code_snippet').slice(0, 2).map((input: any) => (
              <div key={input.id}>
                <p className="text-xs font-mono mb-1" style={{ color: "oklch(0.55 0.04 255)" }}>{input.filename ?? input.language}</p>
                <div className="rounded-lg overflow-hidden" style={{ border: "1px solid oklch(0.22 0.04 255)" }}>
                  <SyntaxHighlighter
                    language={input.language ?? 'typescript'}
                    style={atomOneDark}
                    customStyle={{ margin: 0, background: 'oklch(0.08 0.02 255)', fontSize: '11px', maxHeight: '200px' }}
                    showLineNumbers
                  >
                    {String(input.content ?? '').slice(0, 500)}
                  </SyntaxHighlighter>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
// ─── Chat Tab ─────────────────────────────────────────────────────────────────
function ChatTab({ projectId, project }: { projectId: number; project: any }) {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const utils = trpc.useUtils();

  const { data: messages, isLoading } = trpc.messages.list.useQuery({ projectId });
  const chat = trpc.messages.chat.useMutation({
    onSuccess: () => {
      utils.messages.list.invalidate({ projectId });
      setMessage("");
    },
    onError: () => toast.error("Karen is momentarily unavailable. Unusual."),
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!message.trim() || chat.isPending) return;
    chat.mutate({ projectId, message: message.trim() });
  };

  return (
    <div className="flex flex-col h-full" style={{ height: "calc(100vh - 140px)" }}>
      {/* Messages */}
      <div className="flex-1 overflow-auto p-8 space-y-4">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="h-6 w-6 animate-spin" style={{ color: "oklch(0.60 0.28 350)" }} />
          </div>
        ) : messages?.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center"
                style={{ background: "oklch(0.60 0.28 350 / 0.1)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>
                <MessageSquare className="h-6 w-6" style={{ color: "oklch(0.70 0.28 350)" }} />
              </div>
              <p className="text-sm text-muted-foreground mb-1">Start a conversation with Karen</p>
              <p className="text-xs italic" style={{ color: "oklch(0.72 0.18 200)" }}>
                "K:// I'm ready. Ask me anything about your project."
              </p>
            </div>
          </div>
        ) : (
          <>
            {messages?.map((msg) => (
              <div key={msg.id} className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                {/* Avatar */}
                <div className="w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-xs font-bold"
                  style={{
                    background: msg.role === "karen" ? "oklch(0.60 0.28 350 / 0.2)" : "oklch(0.55 0.22 255 / 0.2)",
                    color: msg.role === "karen" ? "oklch(0.70 0.28 350)" : "oklch(0.70 0.22 255)",
                    border: `1px solid ${msg.role === "karen" ? "oklch(0.60 0.28 350 / 0.3)" : "oklch(0.55 0.22 255 / 0.3)"}`,
                  }}>
                  {msg.role === "karen" ? "K" : "U"}
                </div>
                {/* Bubble */}
                <div className="max-w-xl rounded-lg px-4 py-3"
                  style={{
                    background: msg.role === "karen" ? "oklch(0.11 0.025 255)" : "oklch(0.55 0.22 255 / 0.1)",
                    border: `1px solid ${msg.role === "karen" ? "oklch(0.22 0.04 255)" : "oklch(0.55 0.22 255 / 0.3)"}`,
                  }}>
                  {msg.role === "karen" && (
                    <p className="text-xs mb-1 font-mono" style={{ color: "oklch(0.60 0.28 350)" }}>K://</p>
                  )}
                  <div className="text-sm leading-relaxed">
                    <Streamdown>{String(msg.content)}</Streamdown>
                  </div>
                </div>
              </div>
            ))}
            {chat.isPending && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-xs font-bold"
                  style={{ background: "oklch(0.60 0.28 350 / 0.2)", color: "oklch(0.70 0.28 350)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>K</div>
                <div className="px-4 py-3 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
                  <p className="text-xs font-mono mb-1" style={{ color: "oklch(0.60 0.28 350)" }}>K://</p>
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div key={i} className="w-1.5 h-1.5 rounded-full animate-bounce"
                        style={{ background: "oklch(0.60 0.28 350)", animationDelay: `${i * 0.15}s` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input */}
      <div className="p-4 shrink-0" style={{ borderTop: "1px solid oklch(0.22 0.04 255)" }}>
        <div className="flex gap-3 max-w-4xl mx-auto">
          <input value={message} onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
            placeholder="Ask Karen anything about your project..."
            className="flex-1 px-4 py-3 rounded-lg text-sm outline-none"
            style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)", color: "oklch(0.92 0.03 240)" }}
            onFocus={(e) => (e.target.style.borderColor = "oklch(0.60 0.28 350 / 0.6)")}
            onBlur={(e) => (e.target.style.borderColor = "oklch(0.22 0.04 255)")} />
          <Button onClick={handleSend} disabled={!message.trim() || chat.isPending}
            style={{ background: "oklch(0.60 0.28 350)", color: "oklch(0.98 0.01 0)", border: "none" }}>
            {chat.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Generate Tab ─────────────────────────────────────────────────────────────
function GenerateTab({ projectId, project, onGenerated }: { projectId: number; project: any; onGenerated: () => void }) {
  const [step, setStep] = useState<"idle" | "architecture" | "code" | "done">("idle");
  const utils = trpc.useUtils();

  const genArch = trpc.generation.generateArchitecture.useMutation({
    onSuccess: () => {
      utils.projects.get.invalidate({ id: projectId });
      setStep("code");
    },
    onError: (e) => { setStep("idle"); toast.error(e.message); },
  });

  const genCode = trpc.generation.generateCode.useMutation({
    onSuccess: () => {
      utils.projects.get.invalidate({ id: projectId });
      setStep("done");
      toast.success("K:// Generation complete. Your application has been packaged.");
      onGenerated();
    },
    onError: (e) => { setStep("idle"); toast.error(e.message); },
  });

  const handleGenerate = async () => {
    if (!project.intent) {
      toast.error("K:// No intent detected. Set project intent first.");
      return;
    }
    setStep("architecture");
    await genArch.mutateAsync({ projectId });
  };

  const archPlan = project.architecturePlan as any;

  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-1">ANN Code Generation</h2>
        <p className="text-sm text-muted-foreground">Karen will analyze all inputs, detect patterns, fill gaps, and generate a production-ready application.</p>
      </div>

      {/* Generation Steps */}
      <div className="space-y-4 mb-8">
        <GenerationStep
          number={1}
          title="Intent Analysis"
          description="Natural language translated to structured requirements"
          status={project.intent ? "complete" : "pending"}
        />
        <GenerationStep
          number={2}
          title="Architecture Planning"
          description="Components, data flow, API design, and database schema"
          status={archPlan ? "complete" : step === "architecture" ? "active" : "pending"}
        />
        <GenerationStep
          number={3}
          title="Code Generation"
          description="Production-ready application files with full implementations"
          status={project.status === "complete" ? "complete" : step === "code" ? "active" : "pending"}
        />
        <GenerationStep
          number={4}
          title="Artifact Packaging"
          description="Files packaged, uploaded to S3, preview scaffold rendered"
          status={project.status === "complete" ? "complete" : step === "done" ? "active" : "pending"}
        />
      </div>

      {/* Architecture Plan Preview */}
      {archPlan && (
        <div className="mb-6 p-5 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
          <h3 className="text-xs tracking-widest uppercase mb-3" style={{ color: "oklch(0.72 0.18 200)" }}>Architecture Plan</h3>
          <p className="text-sm text-muted-foreground mb-3">{archPlan.overview}</p>
          <div className="grid grid-cols-2 gap-2">
            {archPlan.components?.slice(0, 6).map((c: any, i: number) => (
              <div key={i} className="px-3 py-2 rounded text-xs"
                style={{ background: "oklch(0.09 0.02 255)", border: "1px solid oklch(0.18 0.03 255)" }}>
                <span style={{ color: "oklch(0.70 0.28 350)" }}>{c.name}</span>
                <span className="text-muted-foreground ml-2">{c.technology}</span>
              </div>
            ))}
          </div>
          {archPlan.karenAssessment && (
            <div className="mt-3 p-3 rounded" style={{ background: "oklch(0.60 0.28 350 / 0.05)", border: "1px solid oklch(0.60 0.28 350 / 0.2)" }}>
              <p className="text-xs" style={{ color: "oklch(0.60 0.28 350)" }}>
                <span className="font-bold">K://</span> {archPlan.karenAssessment}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Action */}
      {project.status === "complete" ? (
        <div className="p-4 rounded-lg flex items-center gap-3"
          style={{ background: "oklch(0.72 0.18 200 / 0.08)", border: "1px solid oklch(0.72 0.18 200 / 0.3)" }}>
          <CheckCircle className="h-5 w-5 shrink-0" style={{ color: "oklch(0.72 0.18 200)" }} />
          <div>
            <p className="text-sm font-medium" style={{ color: "oklch(0.72 0.18 200)" }}>Generation Complete</p>
            <p className="text-xs text-muted-foreground">View your artifacts in the Artifacts tab.</p>
          </div>
        </div>
      ) : step === "architecture" ? (
        <div className="p-4 rounded-lg flex items-center gap-3"
          style={{ background: "oklch(0.60 0.28 350 / 0.05)", border: "1px solid oklch(0.60 0.28 350 / 0.2)" }}>
          <Loader2 className="h-5 w-5 animate-spin shrink-0" style={{ color: "oklch(0.60 0.28 350)" }} />
          <div>
            <p className="text-sm font-medium" style={{ color: "oklch(0.60 0.28 350)" }}>Generating Architecture Plan...</p>
            <p className="text-xs text-muted-foreground">Karen is designing your system architecture.</p>
          </div>
        </div>
      ) : step === "code" ? (
        <div className="space-y-3">
          <div className="p-4 rounded-lg flex items-center gap-3"
            style={{ background: "oklch(0.60 0.28 350 / 0.05)", border: "1px solid oklch(0.60 0.28 350 / 0.2)" }}>
            <CheckCircle className="h-5 w-5 shrink-0" style={{ color: "oklch(0.72 0.18 200)" }} />
            <p className="text-sm" style={{ color: "oklch(0.72 0.18 200)" }}>Architecture plan generated. Ready to generate code.</p>
          </div>
          <Button onClick={() => genCode.mutateAsync({ projectId })} disabled={genCode.isPending}
            className="w-full py-5 text-sm font-semibold tracking-wider uppercase"
            style={{ background: "oklch(0.60 0.28 350)", color: "oklch(0.98 0.01 0)", border: "none", boxShadow: "0 0 20px oklch(0.60 0.28 350 / 0.3)" }}>
            {genCode.isPending ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Generating Application...</> : <><Zap className="h-4 w-4 mr-2" /> Generate Application Code</>}
          </Button>
        </div>
      ) : (
        <Button onClick={handleGenerate} disabled={!project.intent || genArch.isPending}
          className="w-full py-5 text-sm font-semibold tracking-wider uppercase"
          style={{
            background: project.intent ? "oklch(0.60 0.28 350)" : "oklch(0.22 0.04 255)",
            color: "oklch(0.98 0.01 0)",
            border: "none",
            boxShadow: project.intent ? "0 0 20px oklch(0.60 0.28 350 / 0.3)" : "none",
          }}>
          <Brain className="h-4 w-4 mr-2" />
          {!project.intent ? "Set Project Intent First" : "Start Generation Pipeline"}
        </Button>
      )}
    </div>
  );
}

function GenerationStep({ number, title, description, status }: { number: number; title: string; description: string; status: "pending" | "active" | "complete" }) {
  return (
    <div className="flex items-start gap-4 p-4 rounded-lg"
      style={{
        background: status === "complete" ? "oklch(0.72 0.18 200 / 0.05)" : status === "active" ? "oklch(0.60 0.28 350 / 0.05)" : "oklch(0.11 0.025 255)",
        border: `1px solid ${status === "complete" ? "oklch(0.72 0.18 200 / 0.2)" : status === "active" ? "oklch(0.60 0.28 350 / 0.3)" : "oklch(0.22 0.04 255)"}`,
      }}>
      <div className="w-7 h-7 rounded-full shrink-0 flex items-center justify-center text-xs font-bold"
        style={{
          background: status === "complete" ? "oklch(0.72 0.18 200 / 0.2)" : status === "active" ? "oklch(0.60 0.28 350 / 0.2)" : "oklch(0.16 0.02 255)",
          color: status === "complete" ? "oklch(0.72 0.18 200)" : status === "active" ? "oklch(0.70 0.28 350)" : "oklch(0.45 0.04 255)",
          border: `1px solid ${status === "complete" ? "oklch(0.72 0.18 200 / 0.4)" : status === "active" ? "oklch(0.60 0.28 350 / 0.4)" : "oklch(0.22 0.04 255)"}`,
        }}>
        {status === "complete" ? "✓" : status === "active" ? "⟳" : number}
      </div>
      <div>
        <p className="text-sm font-medium">{title}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

// ─── Artifacts Tab ────────────────────────────────────────────────────────────
function ArtifactsTab({ projectId }: { projectId: number }) {
  const { data: artifacts, isLoading } = trpc.artifacts.list.useQuery({ projectId });
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-1">Generated Artifacts</h2>
        <p className="text-sm text-muted-foreground">Everything Karen has produced for this project.</p>
      </div>

      {isLoading ? (
        <div className="space-y-3">{[1, 2].map((i) => <div key={i} className="h-20 rounded animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />)}</div>
      ) : artifacts?.length === 0 ? (
        <div className="text-center py-12">
          <Package className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
          <p className="text-sm text-muted-foreground mb-1">No artifacts yet</p>
          <p className="text-xs italic" style={{ color: "oklch(0.72 0.18 200)" }}>
            "K:// Run the generation pipeline first. I can't produce artifacts from nothing."
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {artifacts?.map((artifact) => {
            const meta = artifact.metadata as any;
            return (
              <div key={artifact.id} className="rounded-lg p-5"
                style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs px-2 py-0.5 rounded"
                        style={{ background: "oklch(0.60 0.28 350 / 0.1)", color: "oklch(0.70 0.28 350)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>
                        {artifact.artifactType}
                      </span>
                      <span className="text-xs text-muted-foreground">v{artifact.version}</span>
                    </div>
                    <h3 className="font-medium text-sm">{artifact.name}</h3>
                  </div>
                  <div className="flex gap-2">
                    {artifact.s3Url && (
                      <a href={artifact.s3Url} target="_blank" rel="noopener noreferrer">
                        <Button size="sm" variant="outline"
                          style={{ borderColor: "oklch(0.72 0.18 200 / 0.4)", color: "oklch(0.72 0.18 200)" }}>
                          <Download className="h-3 w-3 mr-1" /> Download
                        </Button>
                      </a>
                    )}
                    {meta?.previewUrl && (
                      <Button size="sm" variant="outline" onClick={() => setPreviewUrl(previewUrl === meta.previewUrl ? null : meta.previewUrl)}
                        style={{ borderColor: "oklch(0.60 0.28 350 / 0.4)", color: "oklch(0.70 0.28 350)" }}>
                        <Eye className="h-3 w-3 mr-1" /> {previewUrl === meta.previewUrl ? 'Close' : 'Preview'}
                      </Button>
                    )}
                  </div>
                </div>

                {artifact.content && (
                  <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{artifact.content}</p>
                )}

                {meta?.fileCount && (
                  <div className="flex gap-4 text-xs text-muted-foreground">
                    <span>{meta.fileCount} files generated</span>
                    {meta.detectedPatterns?.length > 0 && <span>{meta.detectedPatterns.length} patterns applied</span>}
                    {meta.gapsFilled?.length > 0 && <span>{meta.gapsFilled.length} gaps filled</span>}
                  </div>
                )}

                {/* File tree preview */}
                {artifact.fileTree && Array.isArray(artifact.fileTree) && artifact.fileTree.length > 0 && (
                  <div className="mt-3 p-3 rounded"
                    style={{ background: "oklch(0.08 0.02 255)", border: "1px solid oklch(0.18 0.03 255)", fontFamily: "JetBrains Mono, monospace" }}>
                    {(artifact.fileTree as string[]).slice(0, 8).map((f: string, i: number) => (
                      <div key={i} className="text-xs py-0.5" style={{ color: "oklch(0.82 0.06 200)" }}>
                        {f}
                      </div>
                    ))}
                    {(artifact.fileTree as string[]).length > 8 && (
                      <div className="text-xs text-muted-foreground">...and {(artifact.fileTree as string[]).length - 8} more files</div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Live Preview Iframe */}
      {previewUrl && (
        <div className="mt-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs tracking-widest uppercase" style={{ color: "oklch(0.72 0.18 200)" }}>Live Preview</h3>
            <button onClick={() => setPreviewUrl(null)} className="text-xs text-muted-foreground hover:text-foreground">
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="rounded-lg overflow-hidden" style={{ border: "1px solid oklch(0.60 0.28 350 / 0.3)", boxShadow: "0 0 20px oklch(0.60 0.28 350 / 0.1)" }}>
            <div className="px-4 py-2 flex items-center gap-2" style={{ background: "oklch(0.11 0.025 255)", borderBottom: "1px solid oklch(0.22 0.04 255)" }}>
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full" style={{ background: "oklch(0.58 0.22 25)" }} />
                <div className="w-3 h-3 rounded-full" style={{ background: "oklch(0.72 0.18 80)" }} />
                <div className="w-3 h-3 rounded-full" style={{ background: "oklch(0.72 0.18 140)" }} />
              </div>
              <div className="flex-1 px-3 py-1 rounded text-xs font-mono text-muted-foreground" style={{ background: "oklch(0.08 0.02 255)" }}>
                {previewUrl}
              </div>
              <a href={previewUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-muted-foreground hover:text-foreground">
                <Eye className="h-3 w-3" />
              </a>
            </div>
            <iframe
              src={previewUrl}
              className="w-full"
              style={{ height: "500px", border: "none", background: "oklch(0.98 0.01 0)" }}
              title="Live Preview"
              sandbox="allow-scripts allow-same-origin allow-forms"
              onError={() => toast.error('K:// Preview failed to load. The URL may be blocked or invalid.')}
            />
          </div>
        </div>
      )}
    </div>
  );
}
// ─── Monetize Tab ─────────────────────────────────────────────────────────────────
function MonetizeTab({ projectId, project }: { projectId: number; project: any }) {
  const utils = trpc.useUtils();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: plan, isLoading } = trpc.monetization.get.useQuery({ projectId }) as { data: any; isLoading: boolean };
  const generate = trpc.monetization.generate.useMutation({
    onSuccess: () => {
      utils.monetization.get.invalidate({ projectId });
      toast.success("K:// Monetization strategy generated. Time to make money.");
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="p-8 max-w-4xl">
      <div className="mb-6">
        <h2 className="text-lg font-bold mb-1">Monetization Planner</h2>
        <p className="text-sm text-muted-foreground">Karen generates revenue architecture and pricing strategy as part of your build.</p>
      </div>

      {isLoading ? (
        <div className="space-y-3">{[1, 2, 3].map((i) => <div key={i} className="h-24 rounded animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />)}</div>
      ) : !plan ? (
        <div className="text-center py-12">
          <DollarSign className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
          <p className="text-sm text-muted-foreground mb-2">No monetization plan yet</p>
          <p className="text-xs italic mb-6" style={{ color: "oklch(0.72 0.18 200)" }}>
            "K:// You built something. Now let me tell you how to make money from it."
          </p>
          <Button onClick={() => generate.mutateAsync({ projectId })} disabled={generate.isPending || !project.intent}
            style={{ background: "oklch(0.60 0.28 350)", color: "oklch(0.98 0.01 0)", border: "none" }}>
            {generate.isPending ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Analyzing Revenue Potential...</> : <><DollarSign className="h-4 w-4 mr-2" /> Generate Monetization Plan</>}
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Header */}
          <div className="p-5 rounded-lg"
            style={{ background: "oklch(0.60 0.28 350 / 0.05)", border: "1px solid oklch(0.60 0.28 350 / 0.2)" }}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs tracking-widest uppercase mb-1" style={{ color: "oklch(0.60 0.28 350)" }}>Primary Model</p>
                <h3 className="text-xl font-bold">{String(plan.pricingModel ?? "")}</h3>
                <p className="text-sm text-muted-foreground mt-1">{String(plan.targetMarket ?? "")}</p>
              </div>
              <div className="text-right">
                <p className="text-xs tracking-widest uppercase mb-1 text-muted-foreground">Est. MRR</p>
                <p className="text-xl font-bold" style={{ color: "oklch(0.72 0.18 200)" }}>{String(plan.estimatedMRR ?? "")}</p>
              </div>
            </div>
          </div>

          {/* Revenue Architecture */}
          {plan.revenueArchitecture && (
            <div className="p-5 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
              <h3 className="text-xs tracking-widest uppercase mb-3" style={{ color: "oklch(0.72 0.18 200)" }}>Revenue Architecture</h3>
              <p className="text-sm font-medium mb-2">{String((plan.revenueArchitecture as any).primaryStream ?? "")}</p>
              <div className="space-y-1">
                {((plan.revenueArchitecture as any).secondaryStreams ?? []).map((s: string, i: number) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                    <div className="w-1 h-1 rounded-full" style={{ background: "oklch(0.55 0.22 255)" }} />
                    {String(s)}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Suggestions */}
          <div>
            <h3 className="text-xs tracking-widest uppercase mb-3 text-muted-foreground">Monetization Strategies</h3>
            <div className="space-y-3">
              {((plan.suggestions as any[]) ?? []).map((s, i) => (
                <div key={i} className="p-4 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <h4 className="text-sm font-medium">{String(s.strategy ?? "")}</h4>
                    <div className="flex gap-2 shrink-0">
                      <span className="text-xs px-2 py-0.5 rounded"
                        style={{ background: "oklch(0.72 0.18 200 / 0.1)", color: "oklch(0.72 0.18 200)", border: "1px solid oklch(0.72 0.18 200 / 0.3)" }}>
                        {String(s.estimatedRevenue ?? "")}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded"
                        style={{ background: "oklch(0.55 0.22 255 / 0.1)", color: "oklch(0.70 0.22 255)", border: "1px solid oklch(0.55 0.22 255 / 0.3)" }}>
                        {String(s.implementationComplexity ?? "")}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">{String(s.description ?? "")}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Launch Strategy */}
          {plan.launchStrategy && (
            <div className="p-5 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
              <h3 className="text-xs tracking-widest uppercase mb-3" style={{ color: "oklch(0.72 0.18 200)" }}>Launch Strategy</h3>
              <p className="text-sm text-muted-foreground">{String(plan.launchStrategy ?? "")}</p>
            </div>
          )}

          <div className="flex gap-3 flex-wrap">
            <Button onClick={() => generate.mutateAsync({ projectId })} disabled={generate.isPending} variant="outline" size="sm"
              style={{ borderColor: "oklch(0.22 0.04 255)", color: "oklch(0.55 0.04 255)" }}>
              {generate.isPending ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : <RefreshCw className="h-3 w-3 mr-2" />}
              Regenerate Plan
            </Button>
            <Button
              variant="outline" size="sm"
              style={{ borderColor: "oklch(0.72 0.18 200 / 0.4)", color: "oklch(0.72 0.18 200)" }}
              onClick={() => {
                const exportData = {
                  project: project.name,
                  pricingModel: plan.pricingModel,
                  targetMarket: plan.targetMarket,
                  estimatedMRR: plan.estimatedMRR,
                  revenueArchitecture: plan.revenueArchitecture,
                  suggestions: plan.suggestions,
                  launchStrategy: plan.launchStrategy,
                  exportedAt: new Date().toISOString(),
                  exportedBy: "Karen ANN Engine",
                };
                const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${project.name.replace(/[^a-zA-Z0-9-_]/g, '-').toLowerCase()}-monetization-plan.json`;
                a.click();
                URL.revokeObjectURL(url);
                toast.success('K:// Monetization plan exported. Go make money.');
              }}>
              <Download className="h-3 w-3 mr-2" /> Export Plan
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}


