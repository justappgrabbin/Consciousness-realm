import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import NotFound from "@/pages/not-found";
import Upload from "@/pages/Upload";
import WriteCode from "@/pages/WriteCode";
import Unzipper from "@/pages/Unzipper";
import PlanReview from "@/pages/PlanReview";
import Process from "@/pages/Process";
import Reports from "@/pages/Reports";
import Output from "@/pages/Output";
import DownloadPage from "@/pages/Download";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Upload} />
      <Route path="/write" component={WriteCode} />
      <Route path="/unzip" component={Unzipper} />
      <Route path="/plan/:id" component={PlanReview} />
      <Route path="/process" component={Process} />
      <Route path="/reports" component={Reports} />
      <Route path="/output" component={Output} />
      <Route path="/download" component={DownloadPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider style={style as React.CSSProperties}>
          <div className="flex h-screen w-full">
            <AppSidebar />
            <div className="flex flex-col flex-1 overflow-hidden">
              <header className="flex items-center justify-between p-4 border-b bg-background">
                <SidebarTrigger data-testid="button-sidebar-toggle" />
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">Legacy</span>
                  <span className="text-xs text-muted-foreground">Smart App Assembly Line</span>
                </div>
              </header>
              <main className="flex-1 overflow-auto bg-background">
                <Router />
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
