import React from 'react';

const App = () => {
  return (
    <div>
      <h1>NineBody Sandbox Game</h1>
    </div>
  );
};

export default App;