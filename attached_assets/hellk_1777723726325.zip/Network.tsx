import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Sparkles, Brain, Heart, Zap, Network as NetworkIcon, Users, Activity, Radio } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";

interface NetworkNode {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  bodyGate: number;
  mindGate: number;
  heartGate: number;
  hdType: string;
  coherence: number;
  isUser: boolean;
}

interface NetworkEdge {
  source: string;
  target: string;
  strength: number;
  resonanceType: string;
}

export default function Network() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const [nodes, setNodes] = useState<NetworkNode[]>([]);
  const [edges, setEdges] = useState<NetworkEdge[]>([]);
  const [selectedNode, setSelectedNode] = useState<NetworkNode | null>(null);
  const [physicsEnabled, setPhysicsEnabled] = useState(true);

  // Get user's node
  const { data: userNode } = trpc.node.getMyNode.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Get network data
  const { data: networkData, isLoading: networkLoading } = trpc.network.getTopology.useQuery();

  // Get network metrics
  const { data: metrics } = trpc.network.getMetrics.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Initialize network visualization
  useEffect(() => {
    if (!networkData) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const width = canvas.offsetWidth;
    const height = canvas.offsetHeight;

    // Create nodes from network data
    const networkNodes: NetworkNode[] = networkData.nodes.map((node) => ({
      id: node.id,
      x: width / 2 + (Math.random() - 0.5) * width * 0.8,
      y: height / 2 + (Math.random() - 0.5) * height * 0.8,
      vx: 0,
      vy: 0,
      bodyGate: node.bodyGate || 1,
      mindGate: node.mindGate || 1,
      heartGate: node.heartGate || 1,
      hdType: node.hdType || "Unknown",
      coherence: node.coherence || 50,
      isUser: userNode?.graphAddress === node.id
    }));

    // Create edges from connections
    const networkEdges: NetworkEdge[] = networkData.edges.map((edge) => ({
      source: edge.source,
      target: edge.target,
      strength: edge.strength ?? 0.5,
      resonanceType: edge.type ?? "harmonic"
    }));

    setNodes(networkNodes);
    setEdges(networkEdges);
  }, [networkData, userNode]);

  // Physics simulation and rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || nodes.length === 0) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resizeCanvas();

    const width = canvas.offsetWidth;
    const height = canvas.offsetHeight;

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw background grid
      ctx.strokeStyle = "rgba(102, 126, 234, 0.1)";
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 50) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 50) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Physics simulation
      if (physicsEnabled) {
        // Apply forces
        nodes.forEach((node, i) => {
          // Repulsion from other nodes
          nodes.forEach((other, j) => {
            if (i === j) return;
            const dx = node.x - other.x;
            const dy = node.y - other.y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            const force = 1000 / (dist * dist);
            node.vx += (dx / dist) * force * 0.1;
            node.vy += (dy / dist) * force * 0.1;
          });

          // Attraction to center
          const centerX = width / 2;
          const centerY = height / 2;
          node.vx += (centerX - node.x) * 0.001;
          node.vy += (centerY - node.y) * 0.001;

          // Damping
          node.vx *= 0.9;
          node.vy *= 0.9;

          // Update position
          node.x += node.vx;
          node.y += node.vy;

          // Boundary constraints
          node.x = Math.max(30, Math.min(width - 30, node.x));
          node.y = Math.max(30, Math.min(height - 30, node.y));
        });

        // Edge attraction
        edges.forEach(edge => {
          const source = nodes.find(n => n.id === edge.source);
          const target = nodes.find(n => n.id === edge.target);
          if (!source || !target) return;

          const dx = target.x - source.x;
          const dy = target.y - source.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = (dist - 100) * 0.01 * edge.strength;

          source.vx += (dx / dist) * force;
          source.vy += (dy / dist) * force;
          target.vx -= (dx / dist) * force;
          target.vy -= (dy / dist) * force;
        });
      }

      // Draw edges
      edges.forEach(edge => {
        const source = nodes.find(n => n.id === edge.source);
        const target = nodes.find(n => n.id === edge.target);
        if (!source || !target) return;

        const gradient = ctx.createLinearGradient(source.x, source.y, target.x, target.y);
        gradient.addColorStop(0, `rgba(102, 126, 234, ${edge.strength * 0.5})`);
        gradient.addColorStop(1, `rgba(118, 75, 162, ${edge.strength * 0.5})`);

        ctx.beginPath();
        ctx.strokeStyle = gradient;
        ctx.lineWidth = edge.strength * 3;
        ctx.moveTo(source.x, source.y);
        ctx.lineTo(target.x, target.y);
        ctx.stroke();
      });

      // Draw nodes
      nodes.forEach(node => {
        const radius = node.isUser ? 20 : 12 + (node.coherence / 20);
        
        // Glow effect
        const glowGradient = ctx.createRadialGradient(
          node.x, node.y, 0,
          node.x, node.y, radius * 2
        );
        
        if (node.isUser) {
          glowGradient.addColorStop(0, "rgba(102, 126, 234, 0.8)");
          glowGradient.addColorStop(0.5, "rgba(102, 126, 234, 0.3)");
          glowGradient.addColorStop(1, "rgba(102, 126, 234, 0)");
        } else {
          const hue = (node.heartGate * 5.625) % 360;
          glowGradient.addColorStop(0, `hsla(${hue}, 70%, 60%, 0.6)`);
          glowGradient.addColorStop(0.5, `hsla(${hue}, 70%, 60%, 0.2)`);
          glowGradient.addColorStop(1, `hsla(${hue}, 70%, 60%, 0)`);
        }
        
        ctx.beginPath();
        ctx.fillStyle = glowGradient;
        ctx.arc(node.x, node.y, radius * 2, 0, Math.PI * 2);
        ctx.fill();

        // Node body
        const nodeGradient = ctx.createRadialGradient(
          node.x - radius * 0.3, node.y - radius * 0.3, 0,
          node.x, node.y, radius
        );
        
        if (node.isUser) {
          nodeGradient.addColorStop(0, "#8b5cf6");
          nodeGradient.addColorStop(1, "#6366f1");
        } else {
          const hue = (node.heartGate * 5.625) % 360;
          nodeGradient.addColorStop(0, `hsl(${hue}, 70%, 65%)`);
          nodeGradient.addColorStop(1, `hsl(${hue}, 70%, 45%)`);
        }

        ctx.beginPath();
        ctx.fillStyle = nodeGradient;
        ctx.arc(node.x, node.y, radius, 0, Math.PI * 2);
        ctx.fill();

        // Node border
        ctx.strokeStyle = node.isUser ? "#fff" : "rgba(255,255,255,0.3)";
        ctx.lineWidth = node.isUser ? 3 : 1;
        ctx.stroke();

        // Gate numbers
        if (node.isUser || radius > 14) {
          ctx.fillStyle = "#fff";
          ctx.font = `${node.isUser ? 10 : 8}px sans-serif`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(`${node.heartGate}`, node.x, node.y);
        }
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [nodes, edges, physicsEnabled]);

  // Handle canvas click
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Find clicked node
    const clickedNode = nodes.find(node => {
      const dx = node.x - x;
      const dy = node.y - y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      return dist < 20;
    });

    setSelectedNode(clickedNode || null);
  };

  if (authLoading || networkLoading) {
    return (
      <div className="min-h-screen cosmic-bg flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen cosmic-bg flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full glass">
          <CardHeader className="text-center">
            <NetworkIcon className="w-12 h-12 mx-auto mb-4 text-primary" />
            <CardTitle className="gradient-text text-2xl">Resonance Network</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center mb-6">
              Sign in to view the network topology
            </p>
            <Button 
              className="w-full glow-primary" 
              onClick={() => window.location.href = getLoginUrl()}
            >
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen cosmic-bg flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-border/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <span className="font-bold gradient-text">YOU-N-I-VERSE</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link href="/companion">
              <Button variant="ghost" size="sm">
                <Brain className="w-4 h-4 mr-2" />
                Companion
              </Button>
            </Link>
            <Link href="/quests">
              <Button variant="ghost" size="sm">
                <Zap className="w-4 h-4 mr-2" />
                Quests
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <Activity className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="flex-1 container py-4 flex gap-4">
        {/* Sidebar - Network Stats */}
        <aside className="hidden lg:block w-72 space-y-4">
          <Card className="glass">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Network Metrics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground text-sm">Total Nodes</span>
                <span className="font-bold">{metrics?.totalNodes || nodes.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground text-sm">Active Connections</span>
                <span className="font-bold">{metrics?.totalConnections || edges.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground text-sm">Avg Coherence</span>
                <span className="font-bold">{metrics?.averageCoherence?.toFixed(1) || "50"}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground text-sm">Network Health</span>
                <span className="font-bold text-success">{metrics?.networkResonance?.toFixed(1) || "75"}%</span>
              </div>
            </CardContent>
          </Card>

          <Card className="glass">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Radio className="w-4 h-4" />
                Broadcast Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="status-dot success" />
                <span className="text-sm">Your node is broadcasting</span>
              </div>
              <p className="text-xs text-muted-foreground">
                When you go offline, nearby resonant nodes will cache your intent and match opportunities for you.
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Set Broadcast Intent
              </Button>
            </CardContent>
          </Card>

          <Card className="glass">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Controls</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button 
                variant={physicsEnabled ? "default" : "outline"} 
                size="sm" 
                className="w-full"
                onClick={() => setPhysicsEnabled(!physicsEnabled)}
              >
                {physicsEnabled ? "Pause Physics" : "Resume Physics"}
              </Button>
            </CardContent>
          </Card>

          {selectedNode && (
            <Card className="glass border-primary">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">
                  {selectedNode.isUser ? "Your Node" : "Selected Node"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Type</span>
                  <span>{selectedNode.hdType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Body Gate</span>
                  <span>{selectedNode.bodyGate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Mind Gate</span>
                  <span>{selectedNode.mindGate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Heart Gate</span>
                  <span>{selectedNode.heartGate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Coherence</span>
                  <span>{selectedNode.coherence}%</span>
                </div>
              </CardContent>
            </Card>
          )}
        </aside>

        {/* Main Network Visualization */}
        <main className="flex-1">
          <Card className="glass h-full">
            <CardHeader className="border-b border-border/50 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <NetworkIcon className="w-6 h-6 text-primary" />
                  <div>
                    <CardTitle>Resonance Network Topology</CardTitle>
                    <p className="text-xs text-muted-foreground">
                      Self-organizing graph • Nodes connect through resonant frequencies
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span>{nodes.length} nodes</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-muted-foreground" />
                    <span>{edges.length} connections</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0 h-[calc(100%-80px)]">
              <canvas
                ref={canvasRef}
                className="network-canvas w-full h-full cursor-crosshair"
                onClick={handleCanvasClick}
              />
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
