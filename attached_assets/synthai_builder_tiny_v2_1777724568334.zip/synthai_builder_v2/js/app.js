
import { makeZip } from './zipper.js';
import { Gates, Channels, generateResonanceSentence } from './hd_engine.js';
import { TinyClient } from './tiny_client.js';

const $ = (s, r=document)=>r.querySelector(s);
const $$ = (s, r=document)=>Array.from(r.querySelectorAll(s));

function textFile(name, content) {
  return { name, data: new TextEncoder().encode(content) };
}

function nowStamp(){
  const d = new Date();
  return d.toISOString().replace(/[:.]/g,'-');
}

function uiLog(msg){
  const out = $('#log');
  out.value += `[${new Date().toLocaleTimeString()}] ${msg}\n`;
  out.scrollTop = out.scrollHeight;
}

async function loadFile(file) {
  const buf = await file.arrayBuffer();
  return new Uint8Array(buf);
}

async function gatherProject() {
  const name = $('#projectName').value.trim() || 'synthai-project';
  const template = $('#templatePick').value;
  const hdName = $('#hdName').value.trim() || 'Player One';
  const field = $('#fieldPick').value;
  const gate = $('#gatePick').value;
  const line = $('#linePick').value;

  const manifest = {
    name,
    createdAt: new Date().toISOString(),
    template,
    hd: { name: hdName, field, gate, line }
  };

  // Minimal HTML game shell
  const indexHtml = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${name}</title>
  <style>
    html,body {margin:0;padding:0;font-family:system-ui,Segoe UI,Roboto;}
    .wrap{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px}
    .btn{padding:10px 16px;border:1px solid #999;border-radius:12px;cursor:pointer}
    .pill{padding:6px 10px;border-radius:999px;background:#eee}
    .card{border:1px solid #ddd;border-radius:16px;padding:16px;max-width:680px;box-shadow:0 10px 24px rgba(0,0,0,.06)}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>${name}</h1>
      <p class="pill">HD Seed: ${field} • Gate ${gate}.${line}</p>
      <div id="scene"></div>
      <button id="speak" class="btn">Speak Resonance</button>
    </div>
  </div>
<script>
  const sentence = ${JSON.stringify(generateResonanceSentence({gate, line, field}))};
  document.getElementById('scene').textContent = sentence;
  document.getElementById('speak').onclick = () => {
    const u = new SpeechSynthesisUtterance(sentence);
    speechSynthesis.speak(u);
  };
</script>
</body>
</html>`;

  const files = [
    textFile(`${name}/index.html`, indexHtml),
    textFile(`${name}/manifest.json`, JSON.stringify(manifest, null, 2)),
    textFile(`${name}/README.txt`, "Open index.html in any modern browser. No bash required.\n")
  ];

  // user uploads to include
  for (const inp of $$('.asset-input')) {
    if (inp.files && inp.files[0]) {
      const data = await loadFile(inp.files[0]);
      files.push({ name: `${name}/assets/${inp.files[0].name}`, data });
    }
  }

  return { name, files };
}

async function buildZip() {
  uiLog("Packaging project… no bash, just vibes.");
  const { name, files } = await gatherProject();
  const blob = await makeZip(files);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${name}-${nowStamp()}.zip`;
  a.click();
  uiLog("Export complete. Ship it.");
}

// TinyLlama demo chat
let tiny = null;
async function initTinyIfWanted() {
  const mode = $('#modelMode').value;
  if (mode !== 'tiny') {
    uiLog("Model mode: Remote or None. TinyLlama not loaded.");
    return;
  }
  tiny = new TinyClient(uiLog);
  const ok = await tiny.init();
  if (!ok) {
    uiLog("TinyLlama unavailable (no WebGPU or WebLLM). Falling back.");
    tiny = null;
  }
}

async function tinySend() {
  const inp = $('#chatInput').value.trim();
  if (!inp) return;
  $('#chatInput').value = '';
  const out = $('#chatOut');
  out.value += `You: ${inp}\n`;
  try {
    if (!tiny) {
      out.value += `SynthAI: (TinyLlama not active here. Use Remote/API or enable WebGPU)\n`;
      return;
    }
    const resp = await tiny.ask(inp, "You are SynthAI, bash-free, concise, HD-aware.");
    out.value += `SynthAI: ${resp}\n`;
    out.scrollTop = out.scrollHeight;
  } catch (e) {
    out.value += `SynthAI: [error] ${e.message}\n`;
  }
}

window.addEventListener('DOMContentLoaded', () => {
  $('#exportBtn').addEventListener('click', buildZip);
  $('#modelMode').addEventListener('change', initTinyIfWanted);
  $('#chatSend').addEventListener('click', tinySend);
  uiLog("SynthAI Builder ready. Select model mode to enable TinyLlama in-browser chat.");
});
