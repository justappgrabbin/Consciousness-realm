// 🚀 ULTIMATE SYSTEM - React Native Edition
// Full feature parity with web version

import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Modal,
  Alert,
  Dimensions,
  Platform,
  ActivityIndicator
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import JSZip from 'jszip';

const { width, height } = Dimensions.get('window');

// ============================================================================
// ZIP PROCESSOR
// ============================================================================

class ZipProcessor {
  async unzip(uri) {
    try {
      // Read file as base64
      const base64 = await FileSystem.readAsStringAsync(uri, {
        encoding: FileSystem.EncodingType.Base64
      });
      
      // Convert to binary
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      
      // Extract ZIP
      const zip = await JSZip.loadAsync(bytes);
      const files = {};
      
      for (const [filename, zipEntry] of Object.entries(zip.files)) {
        if (!zipEntry.dir) {
          const content = await zipEntry.async('string');
          files[filename] = {
            name: filename,
            content,
            type: this.detectType(filename),
            size: content.length
          };
        }
      }
      
      return { 
        success: true, 
        files, 
        count: Object.keys(files).length,
        analysis: this.analyzeFiles(files)
      };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  async createZip(files) {
    try {
      const zip = new JSZip();
      
      Object.entries(files).forEach(([path, content]) => {
        zip.file(path, content);
      });
      
      const base64 = await zip.generateAsync({ type: 'base64' });
      
      // Save to file system
      const fileUri = FileSystem.cacheDirectory + 'project.zip';
      await FileSystem.writeAsStringAsync(fileUri, base64, {
        encoding: FileSystem.EncodingType.Base64
      });
      
      return { success: true, uri: fileUri };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  detectType(filename) {
    const ext = filename.split('.').pop().toLowerCase();
    const types = {
      'js': 'javascript', 'jsx': 'react', 'ts': 'typescript', 'tsx': 'react-ts',
      'py': 'python', 'html': 'html', 'css': 'css', 'json': 'json',
      'md': 'markdown', 'txt': 'text'
    };
    return types[ext] || 'unknown';
  }

  analyzeFiles(files) {
    const analysis = {
      totalFiles: Object.keys(files).length,
      languages: new Set(),
      components: [],
      imports: new Set()
    };

    Object.values(files).forEach(file => {
      analysis.languages.add(file.type);
      
      // Detect React components
      if (file.content.includes('export default') || 
          file.content.includes('export function')) {
        analysis.components.push(file.name);
      }

      // Extract imports
      const importMatches = file.content.match(/import .+ from ['"](.+)['"]/g);
      if (importMatches) {
        importMatches.forEach(imp => {
          const match = imp.match(/from ['"](.+)['"]/);
          if (match) analysis.imports.add(match[1]);
        });
      }
    });

    analysis.languages = Array.from(analysis.languages);
    analysis.imports = Array.from(analysis.imports);

    return analysis;
  }
}

// ============================================================================
// CODE RUNNER
// ============================================================================

class CodeRunner {
  constructor() {
    this.output = [];
  }

  async run(code, language = 'javascript') {
    this.output = [];
    
    const customConsole = {
      log: (...args) => this.capture('log', args),
      error: (...args) => this.capture('error', args),
      warn: (...args) => this.capture('warn', args)
    };

    try {
      if (language === 'javascript') {
        // Create sandboxed function
        const wrappedCode = `
          (function(console) {
            ${code}
          })(customConsole)
        `;
        
        // Execute
        const fn = new Function('customConsole', wrappedCode);
        fn(customConsole);
        
        return { success: true, output: this.output };
      }
      return { success: false, error: `${language} not supported yet` };
    } catch (error) {
      this.capture('error', [error.message]);
      return { success: false, error: error.message, output: this.output };
    }
  }

  capture(type, args) {
    this.output.push({
      type,
      message: args.map(a => 
        typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)
      ).join(' '),
      timestamp: Date.now()
    });
  }
}

// ============================================================================
// CODE SNATCHER
// ============================================================================

class CodeSnatcher {
  snatchProject(projectData) {
    const files = {};

    // Generate App.js
    files['App.js'] = this.generateApp(projectData);
    
    // Generate package.json
    files['package.json'] = JSON.stringify({
      name: projectData.name || 'morphing-app',
      version: '1.0.0',
      description: projectData.description,
      main: 'node_modules/expo/AppEntry.js',
      scripts: {
        start: 'expo start',
        android: 'expo start --android',
        ios: 'expo start --ios',
        web: 'expo start --web'
      },
      dependencies: {
        'expo': '~49.0.0',
        'react': '18.2.0',
        'react-native': '0.72.6'
      }
    }, null, 2);

    // Generate README
    files['README.md'] = this.generateReadme(projectData);

    // Add component files
    if (projectData.components) {
      projectData.components.forEach(comp => {
        files[`src/components/${comp.name}.js`] = comp.code || this.generateComponent(comp);
      });
    }

    return files;
  }

  generateApp(data) {
    return `import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>${data.name}</Text>
      <Text style={styles.description}>${data.description}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10
  },
  description: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center'
  }
});`;
  }

  generateComponent(comp) {
    return `import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ${comp.name}() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>${comp.name}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#1a1a1a',
    borderRadius: 8
  },
  text: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold'
  }
});`;
  }

  generateReadme(data) {
    return `# ${data.name}

${data.description}

**Auto-generated by Ultimate System**

## Setup
\`\`\`bash
npm install
npm start
\`\`\`

## Features
${data.components ? data.components.map(c => `- ${c.name}`).join('\n') : ''}

---
Generated: ${new Date().toISOString()}
`;
  }
}

// ============================================================================
// DEPLOYMENT AGENT
// ============================================================================

class DeploymentAgent {
  constructor() {
    this.history = [];
  }

  async deployToGitHub(files, config) {
    const deployment = {
      id: Date.now(),
      platform: 'github',
      status: 'simulated',
      timestamp: Date.now(),
      url: `https://github.com/${config.username}/${config.repo}`,
      fileCount: Object.keys(files).length
    };
    
    this.history.push(deployment);
    
    return {
      success: true,
      deployment,
      message: `Would create repo: ${config.username}/${config.repo}`
    };
  }

  async deployToVercel(files, config) {
    const deployment = {
      id: Date.now(),
      platform: 'vercel',
      status: 'simulated',
      timestamp: Date.now(),
      url: `https://${config.project}.vercel.app`
    };
    
    this.history.push(deployment);
    
    return {
      success: true,
      deployment,
      message: `Would deploy to: ${deployment.url}`
    };
  }

  async deployToNetlify(files, config) {
    const deployment = {
      id: Date.now(),
      platform: 'netlify',
      status: 'simulated',
      timestamp: Date.now(),
      url: `https://${config.site}.netlify.app`
    };
    
    this.history.push(deployment);
    
    return {
      success: true,
      deployment,
      message: `Would deploy to: ${deployment.url}`
    };
  }

  getHistory() {
    return this.history;
  }
}

// ============================================================================
// GLYPH ENGINE
// ============================================================================

class GlyphEngine {
  constructor() {
    this.glyphTypes = {
      CONTAINER: { symbol: '◻', color: '#60A5FA', meaning: 'Container' },
      FLOW: { symbol: '→', color: '#34D399', meaning: 'Flow' },
      TRANSFORM: { symbol: '⚡', color: '#FBBF24', meaning: 'Transform' },
      STATE: { symbol: '○', color: '#A78BFA', meaning: 'State' },
      INTENT: { symbol: '◇', color: '#F472B6', meaning: 'Intent' }
    };
  }

  analyze(code) {
    const glyphs = [];
    
    if (code.match(/function|class|const.*=>/)) {
      glyphs.push({ type: 'CONTAINER', pos: 0 });
    }
    if (code.match(/useState|useReducer|this\.state/)) {
      glyphs.push({ type: 'STATE', pos: code.indexOf('useState') });
    }
    if (code.match(/map|filter|reduce/)) {
      glyphs.push({ type: 'TRANSFORM', pos: 0 });
    }
    if (code.match(/useEffect|fetch|axios/)) {
      glyphs.push({ type: 'FLOW', pos: 0 });
    }
    
    return glyphs;
  }
}

// ============================================================================
// MAIN ULTIMATE SYSTEM
// ============================================================================

export default function UltimateSystemRN() {
  // State
  const [project, setProject] = useState({
    name: 'Untitled Project',
    description: 'A morphing application',
    files: {},
    components: []
  });

  const [mode, setMode] = useState('home'); // home, runner, canvas, deploy
  const [showPortal, setShowPortal] = useState(false);
  const [currentCode, setCurrentCode] = useState('// Write your code\nconsole.log("Hello World!");');
  const [runnerOutput, setRunnerOutput] = useState([]);
  const [uploadedFiles, setUploadedFiles] = useState({});
  const [loading, setLoading] = useState(false);

  // Engines
  const [zipProcessor] = useState(new ZipProcessor());
  const [codeRunner] = useState(new CodeRunner());
  const [codeSnatcher] = useState(new CodeSnatcher());
  const [deployAgent] = useState(new DeploymentAgent());
  const [glyphEngine] = useState(new GlyphEngine());

  // Upload ZIP
  const handleZipUpload = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/zip',
        copyToCacheDirectory: true
      });

      if (result.type === 'success') {
        setLoading(true);
        const extracted = await zipProcessor.unzip(result.uri);
        setLoading(false);

        if (extracted.success) {
          setUploadedFiles(extracted.files);
          setProject(prev => ({ ...prev, files: extracted.files }));
          
          Alert.alert(
            '✅ ZIP Extracted!',
            `Files: ${extracted.count}\n` +
            `Languages: ${extracted.analysis.languages.join(', ')}\n` +
            `Components: ${extracted.analysis.components.length}`
          );
        } else {
          Alert.alert('Error', extracted.error);
        }
      }
    } catch (error) {
      setLoading(false);
      Alert.alert('Error', error.message);
    }
  };

  // Run code
  const handleRunCode = async () => {
    setLoading(true);
    const result = await codeRunner.run(currentCode);
    setLoading(false);
    setRunnerOutput(result.output || [{ type: 'error', message: result.error }]);
  };

  // Snatch code
  const handleSnatch = () => {
    const files = codeSnatcher.snatchProject(project);
    setProject(prev => ({ ...prev, snatchedFiles: files }));
    Alert.alert(
      '🕵️ Code Snatched!',
      `Generated ${Object.keys(files).length} files\n\nReady to deploy or download!`
    );
  };

  // Download ZIP
  const handleDownload = async () => {
    try {
      setLoading(true);
      const files = project.snatchedFiles || codeSnatcher.snatchProject(project);
      const result = await zipProcessor.createZip(files);
      setLoading(false);

      if (result.success) {
        const canShare = await Sharing.isAvailableAsync();
        if (canShare) {
          await Sharing.shareAsync(result.uri);
        } else {
          Alert.alert('Success', `ZIP saved to: ${result.uri}`);
        }
      } else {
        Alert.alert('Error', result.error);
      }
    } catch (error) {
      setLoading(false);
      Alert.alert('Error', error.message);
    }
  };

  // Deploy
  const handleDeploy = async (platform) => {
    const files = project.snatchedFiles || codeSnatcher.snatchProject(project);
    let result;

    const config = {
      username: 'your-username',
      repo: project.name.toLowerCase().replace(/\s/g, '-'),
      project: project.name.toLowerCase().replace(/\s/g, '-'),
      site: project.name.toLowerCase().replace(/\s/g, '-')
    };

    switch (platform) {
      case 'github':
        result = await deployAgent.deployToGitHub(files, config);
        break;
      case 'vercel':
        result = await deployAgent.deployToVercel(files, config);
        break;
      case 'netlify':
        result = await deployAgent.deployToNetlify(files, config);
        break;
    }

    if (result.success) {
      Alert.alert(
        '🚀 Deployment Ready!',
        `${result.message}\n\nURL: ${result.deployment.url}\n\n(Simulated - would actually deploy in production)`
      );
    }
  };

  // ========== RENDER ==========

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.headerIcon}>🌱</Text>
          <View>
            <Text style={styles.headerTitle}>{project.name}</Text>
            <Text style={styles.headerSubtitle}>
              {Object.keys(uploadedFiles).length} files
            </Text>
          </View>
        </View>
        <TouchableOpacity
          onPress={() => setShowPortal(true)}
          style={styles.gearButton}
        >
          <Text style={styles.gearIcon}>⚙️</Text>
        </TouchableOpacity>
      </View>

      {/* Mode Selector */}
      <View style={styles.modeSelector}>
        {['home', 'runner', 'canvas', 'deploy'].map(m => (
          <TouchableOpacity
            key={m}
            onPress={() => setMode(m)}
            style={[styles.modeButton, mode === m && styles.modeButtonActive]}
          >
            <Text style={[styles.modeText, mode === m && styles.modeTextActive]}>
              {m.charAt(0).toUpperCase() + m.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Content */}
      <ScrollView style={styles.content}>
        {mode === 'home' && (
          <View style={styles.homeContent}>
            {/* Upload Section */}
            <View style={styles.card}>
              <Text style={styles.cardTitle}>📦 Upload ZIP</Text>
              <TouchableOpacity
                onPress={handleZipUpload}
                style={styles.uploadButton}
              >
                <Text style={styles.uploadButtonText}>Select ZIP File</Text>
              </TouchableOpacity>
              {Object.keys(uploadedFiles).length > 0 && (
                <Text style={styles.fileCount}>
                  {Object.keys(uploadedFiles).length} files loaded
                </Text>
              )}
            </View>

            {/* Quick Actions */}
            <View style={styles.card}>
              <Text style={styles.cardTitle}>⚡ Quick Actions</Text>
              <View style={styles.actionGrid}>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => setMode('runner')}
                >
                  <Text style={styles.actionIcon}>▶️</Text>
                  <Text style={styles.actionLabel}>Run Code</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={handleSnatch}
                >
                  <Text style={styles.actionIcon}>🕵️</Text>
                  <Text style={styles.actionLabel}>Snatch</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={handleDownload}
                >
                  <Text style={styles.actionIcon}>💾</Text>
                  <Text style={styles.actionLabel}>Download</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => setMode('deploy')}
                >
                  <Text style={styles.actionIcon}>🚀</Text>
                  <Text style={styles.actionLabel}>Deploy</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}

        {mode === 'runner' && (
          <View style={styles.runnerContent}>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>▶️ Code Runner</Text>
              
              <TextInput
                style={styles.codeEditor}
                value={currentCode}
                onChangeText={setCurrentCode}
                multiline
                placeholder="Write JavaScript code..."
                placeholderTextColor="#666"
                autoCapitalize="none"
                autoCorrect={false}
                spellCheck={false}
                textAlignVertical="top"
              />

              <TouchableOpacity
                onPress={handleRunCode}
                style={styles.runButton}
              >
                <Text style={styles.runButtonText}>▶️ Run Code</Text>
              </TouchableOpacity>

              {runnerOutput.length > 0 && (
                <View style={styles.output}>
                  <Text style={styles.outputTitle}>Output:</Text>
                  {runnerOutput.map((out, i) => (
                    <Text
                      key={i}
                      style={[
                        styles.outputLine,
                        out.type === 'error' && styles.outputError,
                        out.type === 'warn' && styles.outputWarn
                      ]}
                    >
                      [{out.type}] {out.message}
                    </Text>
                  ))}
                </View>
              )}
            </View>
          </View>
        )}

        {mode === 'canvas' && (
          <View style={styles.canvasContent}>
            <Text style={styles.sectionTitle}>📊 Project Canvas</Text>
            {Object.entries(uploadedFiles).map(([name, file]) => {
              const glyphs = glyphEngine.analyze(file.content);
              return (
                <View key={name} style={styles.fileCard}>
                  <Text style={styles.fileName}>{name}</Text>
                  <Text style={styles.fileType}>{file.type}</Text>
                  <View style={styles.glyphRow}>
                    {glyphs.slice(0, 5).map((g, i) => {
                      const glyph = glyphEngine.glyphTypes[g.type];
                      return (
                        <View
                          key={i}
                          style={[
                            styles.glyph,
                            { backgroundColor: glyph.color + '20' }
                          ]}
                        >
                          <Text style={{ color: glyph.color }}>
                            {glyph.symbol}
                          </Text>
                        </View>
                      );
                    })}
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {mode === 'deploy' && (
          <View style={styles.deployContent}>
            <Text style={styles.sectionTitle}>🚀 Deploy Project</Text>

            <TouchableOpacity
              onPress={() => handleDeploy('github')}
              style={[styles.deployButton, { backgroundColor: '#24292e' }]}
            >
              <Text style={styles.deployIcon}>🐙</Text>
              <View style={styles.deployInfo}>
                <Text style={styles.deployTitle}>Deploy to GitHub</Text>
                <Text style={styles.deployDesc}>Create repo and push</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => handleDeploy('vercel')}
              style={[styles.deployButton, { backgroundColor: '#000' }]}
            >
              <Text style={styles.deployIcon}>▲</Text>
              <View style={styles.deployInfo}>
                <Text style={styles.deployTitle}>Deploy to Vercel</Text>
                <Text style={styles.deployDesc}>Instant deployment</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => handleDeploy('netlify')}
              style={[styles.deployButton, { backgroundColor: '#00C7B7' }]}
            >
              <Text style={styles.deployIcon}>🌊</Text>
              <View style={styles.deployInfo}>
                <Text style={styles.deployTitle}>Deploy to Netlify</Text>
                <Text style={styles.deployDesc}>Continuous deployment</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleDownload}
              style={[styles.deployButton, { backgroundColor: '#8B5CF6' }]}
            >
              <Text style={styles.deployIcon}>💾</Text>
              <View style={styles.deployInfo}>
                <Text style={styles.deployTitle}>Download ZIP</Text>
                <Text style={styles.deployDesc}>Get complete bundle</Text>
              </View>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>

      {/* Portal Modal */}
      <Modal
        visible={showPortal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowPortal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.portal}>
            <View style={styles.portalHeader}>
              <Text style={styles.portalTitle}>⚙️ Project Settings</Text>
              <TouchableOpacity onPress={() => setShowPortal(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.portalContent}>
              <Text style={styles.label}>Project Name</Text>
              <TextInput
                style={styles.input}
                value={project.name}
                onChangeText={(text) => setProject(prev => ({ ...prev, name: text }))}
                placeholder="Enter project name"
                placeholderTextColor="#666"
              />

              <Text style={styles.label}>Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={project.description}
                onChangeText={(text) => setProject(prev => ({ ...prev, description: text }))}
                placeholder="Describe your project"
                placeholderTextColor="#666"
                multiline
                numberOfLines={4}
              />

              <TouchableOpacity
                onPress={() => {
                  setShowPortal(false);
                  Alert.alert('Saved', 'Project settings updated!');
                }}
                style={styles.saveButton}
              >
                <Text style={styles.saveButtonText}>💾 Save Settings</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Loading Overlay */}
      {loading && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>Processing...</Text>
        </View>
      )}
    </View>
  );
}

// ============================================================================
// STYLES
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a'
  },
  header: {
    backgroundColor: '#1a1a1a',
    paddingTop: Platform.OS === 'ios' ? 50 : 30,
    paddingBottom: 15,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#8B5CF6'
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12
  },
  headerIcon: {
    fontSize: 32
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff'
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#999'
  },
  gearButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#8B5CF6',
    alignItems: 'center',
    justifyContent: 'center'
  },
  gearIcon: {
    fontSize: 24
  },
  modeSelector: {
    flexDirection: 'row',
    backgroundColor: '#1a1a1a',
    padding: 10,
    gap: 8
  },
  modeButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#2a2a2a',
    alignItems: 'center'
  },
  modeButtonActive: {
    backgroundColor: '#8B5CF6'
  },
  modeText: {
    color: '#999',
    fontSize: 12,
    fontWeight: '600'
  },
  modeTextActive: {
    color: '#fff'
  },
  content: {
    flex: 1
  },
  homeContent: {
    padding: 16,
    gap: 16
  },
  card: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#333',
    marginBottom: 16
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 12
  },
  uploadButton: {
    backgroundColor: '#8B5CF6',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center'
  },
  uploadButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  },
  fileCount: {
    color: '#999',
    fontSize: 12,
    marginTop: 8,
    textAlign: 'center'
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12
  },
  actionButton: {
    width: (width - 80) / 2,
    backgroundColor: '#2a2a2a',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#444'
  },
  actionIcon: {
    fontSize: 32,
    marginBottom: 8
  },
  actionLabel: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600'
  },
  runnerContent: {
    padding: 16
  },
  codeEditor: {
    backgroundColor: '#0d1117',
    color: '#fff',
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    fontSize: 14,
    padding: 12,
    borderRadius: 8,
    minHeight: 200,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#333'
  },
  runButton: {
    backgroundColor: '#22C55E',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 12
  },
  runButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  },
  output: {
    backgroundColor: '#0d1117',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333'
  },
  outputTitle: {
    color: '#999',
    fontSize: 12,
    marginBottom: 8,
    fontWeight: 'bold'
  },
  outputLine: {
    color: '#22C55E',
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    fontSize: 12,
    marginBottom: 4
  },
  outputError: {
    color: '#EF4444'
  },
  outputWarn: {
    color: '#F59E0B'
  },
  canvasContent: {
    padding: 16
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 16
  },
  fileCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#8B5CF6'
  },
  fileName: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4
  },
  fileType: {
    color: '#999',
    fontSize: 12,
    marginBottom: 8
  },
  glyphRow: {
    flexDirection: 'row',
    gap: 6
  },
  glyph: {
    width: 32,
    height: 32,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center'
  },
  deployContent: {
    padding: 16
  },
  deployButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12
  },
  deployIcon: {
    fontSize: 40,
    marginRight: 16
  },
  deployInfo: {
    flex: 1
  },
  deployTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4
  },
  deployDesc: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'flex-end'
  },
  portal: {
    backgroundColor: '#1a1a1a',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: height * 0.8,
    borderTopWidth: 2,
    borderTopColor: '#8B5CF6'
  },
  portalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#333'
  },
  portalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff'
  },
  closeButton: {
    fontSize: 24,
    color: '#999'
  },
  portalContent: {
    padding: 20
  },
  label: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8
  },
  input: {
    backgroundColor: '#2a2a2a',
    color: '#fff',
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#444'
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top'
  },
  saveButton: {
    backgroundColor: '#8B5CF6',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold'
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.8)',
    alignItems: 'center',
    justifyContent: 'center'
  },
  loadingText: {
    color: '#fff',
    marginTop: 12,
    fontSize: 16
  }
});
