"""
Intelligence Engine - The Brain of the Ontological Causal Graph

This is the master intelligence system that makes the causal graph THINK.

Architecture:
    Layer 1: Perception - Understands component semantics
    Layer 2: Reasoning - Infers causal relationships  
    Layer 3: Prediction - Forecasts emergence
    Layer 4: Learning - Adapts from outcomes
    Layer 5: Governance - Knows when NOT to act

The system learns and improves with every operation.
"""

import json
import hashlib
from typing import Dict, List, Set, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import ast
import re


# ============================================================================
# CORE DATA STRUCTURES
# ============================================================================

class Glyph(Enum):
    """5-dimensional consciousness glyphs"""
    MOVEMENT = '∞'      # Dynamic, transformative
    EVOLUTION = '△'     # Adaptive, learning
    BEING = '○'         # State-holding, identity
    DESIGN = '◇'        # Pattern, structure
    SPACE = '□'         # Container, boundary


class CausalType(Enum):
    """Types of causation in consciousness systems"""
    # Classical
    EFFICIENT = 'efficient'      # A directly causes B
    FORMAL = 'formal'            # A provides pattern for B
    MATERIAL = 'material'        # A provides substance for B
    FINAL = 'final'              # A provides purpose for B
    
    # Consciousness
    RESONANT = 'resonant'        # Harmonic coupling
    COLLAPSE = 'collapse'        # Potential → Actual
    PHASE = 'phase'              # Phase transition
    FIELD = 'field'              # Field modulation
    CASCADE = 'cascade'          # Cascade propagation


@dataclass
class ComponentSemantics:
    """Deep semantic understanding of a component"""
    purpose: str
    capabilities: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    effects: List[str] = field(default_factory=list)
    invariants: List[str] = field(default_factory=list)
    
    # Consciousness mapping
    glyph_primary: Glyph = Glyph.BEING
    glyph_scores: Dict[Glyph, float] = field(default_factory=dict)
    domains: List[str] = field(default_factory=list)
    field_layer: str = 'tropical'
    
    # Foundry mapping
    fragment_type: str = 'unknown'
    quality_potential: float = 0.5
    mutation_risk: float = 0.5
    
    # Confidence
    confidence: float = 0.5


@dataclass
class CausalRelationship:
    """A causal link between components"""
    exists: bool
    source_id: str = ''
    target_id: str = ''
    causal_type: Optional[CausalType] = None
    strength: float = 0.0
    mechanism: str = ''
    conditions: List[str] = field(default_factory=list)
    confidence: float = 0.0
    
    # Resonance metrics
    resonance_score: float = 0.0
    field_alignment: Dict[str, float] = field(default_factory=dict)


@dataclass
class EmergencePrediction:
    """Predicted emergent properties"""
    capabilities: List[str] = field(default_factory=list)
    failure_modes: List[Dict] = field(default_factory=list)
    coherence_score: float = 0.0
    resonance_patterns: List[Dict] = field(default_factory=list)
    governance_signals: List[Dict] = field(default_factory=list)
    confidence: float = 0.0


@dataclass
class LearningOutcome:
    """Record of what happened vs what was predicted"""
    prediction: EmergencePrediction
    actual_result: Dict[str, Any]
    prediction_accuracy: float
    timestamp: datetime
    context: Dict[str, Any]
    lessons_learned: List[str] = field(default_factory=list)


# ============================================================================
# LAYER 1: PERCEPTION - Semantic Understanding
# ============================================================================

class SemanticComponentAnalyzer:
    """
    Deeply understands component semantics.
    Goes beyond syntax to comprehend PURPOSE.
    """
    
    def __init__(self):
        self.purpose_patterns = self._load_purpose_patterns()
        self.capability_patterns = self._load_capability_patterns()
        
    def analyze_component(self, code: str, metadata: Dict = None) -> ComponentSemantics:
        """
        Extract semantic understanding of component.
        """
        metadata = metadata or {}
        
        # Parse code structure
        try:
            tree = ast.parse(code)
        except:
            # If not valid Python, try to extract text patterns
            tree = None
        
        # Extract semantic features
        semantics = ComponentSemantics(
            purpose=self._infer_purpose(code, tree, metadata),
            capabilities=self._extract_capabilities(code, tree),
            constraints=self._extract_constraints(code, tree),
            dependencies=self._find_dependencies(code, tree),
            effects=self._analyze_side_effects(code, tree),
            invariants=self._detect_invariants(code, tree)
        )
        
        # Map to consciousness glyphs
        glyph_mapping = self._map_to_glyphs(semantics)
        semantics.glyph_primary = glyph_mapping['primary']
        semantics.glyph_scores = glyph_mapping['scores']
        
        # Map to domains
        semantics.domains = self._map_to_domains(semantics)
        semantics.field_layer = self._classify_field_layer(semantics)
        
        # Assess quality and mutation risk
        semantics.fragment_type = self._classify_fragment_type(semantics)
        semantics.quality_potential = self._assess_quality_potential(semantics)
        semantics.mutation_risk = self._calculate_mutation_risk(semantics)
        
        # Calculate overall confidence
        semantics.confidence = self._calculate_confidence(semantics)
        
        return semantics
    
    def _infer_purpose(self, code: str, tree: Optional[ast.AST], metadata: Dict) -> str:
        """Infer the teleological purpose of this component"""
        
        # Check metadata first
        if metadata.get('purpose'):
            return metadata['purpose']
        
        # Extract from docstrings
        if tree:
            docstring = ast.get_docstring(tree)
            if docstring:
                # First line of docstring is often the purpose
                purpose = docstring.split('\n')[0].strip()
                if purpose:
                    return purpose
        
        # Extract from class/function names
        purpose_hints = []
        
        # Look for key verbs in code
        verbs = ['create', 'build', 'generate', 'transform', 'calculate', 
                'process', 'analyze', 'manage', 'control', 'coordinate']
        
        for verb in verbs:
            if verb in code.lower():
                purpose_hints.append(verb)
        
        # Look for domain terms
        if 'chart' in code.lower():
            purpose_hints.append('chart_handling')
        if 'gate' in code.lower():
            purpose_hints.append('gate_processing')
        if 'consciousness' in code.lower():
            purpose_hints.append('consciousness_computation')
        
        if purpose_hints:
            return f"Component that {', '.join(purpose_hints)}"
        
        return "General purpose component"
    
    def _extract_capabilities(self, code: str, tree: Optional[ast.AST]) -> List[str]:
        """What can this component DO?"""
        
        capabilities = []
        
        if tree:
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # Function name suggests capability
                    func_name = node.name
                    
                    # Remove common prefixes
                    func_name = func_name.replace('_', ' ').replace('get_', '').replace('set_', '')
                    
                    capabilities.append(f"can_{func_name}")
        
        # Pattern-based extraction
        if 'calculate' in code.lower():
            capabilities.append('can_calculate')
        if 'transform' in code.lower():
            capabilities.append('can_transform')
        if 'generate' in code.lower():
            capabilities.append('can_generate')
        if 'analyze' in code.lower():
            capabilities.append('can_analyze')
        
        return list(set(capabilities))  # Remove duplicates
    
    def _extract_constraints(self, code: str, tree: Optional[ast.AST]) -> List[str]:
        """What are this component's limitations?"""
        
        constraints = []
        
        # Look for validation code
        if 'if not' in code or 'assert' in code:
            constraints.append('has_input_validation')
        
        # Look for type hints
        if tree:
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and node.returns:
                    constraints.append('has_type_constraints')
                    break
        
        # Look for bounds checking
        if 'max' in code.lower() or 'min' in code.lower():
            constraints.append('has_bounds')
        
        return constraints
    
    def _find_dependencies(self, code: str, tree: Optional[ast.AST]) -> List[str]:
        """What does this component NEED?"""
        
        dependencies = []
        
        if tree:
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        dependencies.append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        dependencies.append(node.module)
        
        return dependencies
    
    def _analyze_side_effects(self, code: str, tree: Optional[ast.AST]) -> List[str]:
        """What does this component CHANGE?"""
        
        effects = []
        
        # Look for state modifications
        if 'self.' in code and '=' in code:
            effects.append('modifies_state')
        
        # Look for I/O
        if 'print' in code or 'write' in code:
            effects.append('produces_output')
        if 'open' in code or 'read' in code:
            effects.append('reads_external')
        
        # Look for network calls
        if 'request' in code.lower() or 'fetch' in code.lower():
            effects.append('network_io')
        
        return effects
    
    def _detect_invariants(self, code: str, tree: Optional[ast.AST]) -> List[str]:
        """What does this component PRESERVE?"""
        
        invariants = []
        
        # Look for immutability markers
        if 'final' in code.lower() or 'const' in code.lower():
            invariants.append('immutable')
        
        # Look for validation that preserves properties
        if 'validate' in code.lower():
            invariants.append('maintains_validity')
        
        return invariants
    
    def _map_to_glyphs(self, semantics: ComponentSemantics) -> Dict:
        """Map component to 5D glyph system"""
        
        scores = {
            Glyph.MOVEMENT: 0.0,
            Glyph.EVOLUTION: 0.0,
            Glyph.BEING: 0.0,
            Glyph.DESIGN: 0.0,
            Glyph.SPACE: 0.0
        }
        
        # Movement: transformative, dynamic
        if 'transform' in semantics.purpose.lower():
            scores[Glyph.MOVEMENT] += 0.6
        if 'modifies_state' in semantics.effects:
            scores[Glyph.MOVEMENT] += 0.3
        if 'can_transform' in semantics.capabilities:
            scores[Glyph.MOVEMENT] += 0.4
        
        # Evolution: adaptive, learning
        if 'learn' in semantics.purpose.lower() or 'adapt' in semantics.purpose.lower():
            scores[Glyph.EVOLUTION] += 0.7
        if 'can_analyze' in semantics.capabilities:
            scores[Glyph.EVOLUTION] += 0.3
        
        # Being: state-holding, identity
        if semantics.invariants:
            scores[Glyph.BEING] += 0.5
        if 'state' in semantics.purpose.lower() or 'identity' in semantics.purpose.lower():
            scores[Glyph.BEING] += 0.6
        if not semantics.effects:  # Pure function
            scores[Glyph.BEING] += 0.2
        
        # Design: pattern, structure
        if 'pattern' in semantics.purpose.lower() or 'structure' in semantics.purpose.lower():
            scores[Glyph.DESIGN] += 0.7
        if 'has_type_constraints' in semantics.constraints:
            scores[Glyph.DESIGN] += 0.3
        
        # Space: container, boundary
        if 'has_bounds' in semantics.constraints:
            scores[Glyph.SPACE] += 0.4
        if 'container' in semantics.purpose.lower():
            scores[Glyph.SPACE] += 0.6
        
        # Default to Being if no strong signals
        if max(scores.values()) < 0.3:
            scores[Glyph.BEING] = 0.5
        
        primary = max(scores.items(), key=lambda x: x[1])[0]
        
        return {
            'primary': primary,
            'scores': scores
        }
    
    def _map_to_domains(self, semantics: ComponentSemantics) -> List[str]:
        """Map to consciousness domains"""
        
        domains = []
        
        # Based on purpose keywords
        purpose_lower = semantics.purpose.lower()
        
        if 'chart' in purpose_lower:
            domains.append('identity')
        if 'gate' in purpose_lower:
            domains.append('activation')
        if 'calculate' in purpose_lower or 'compute' in purpose_lower:
            domains.append('cognition')
        if 'transform' in purpose_lower:
            domains.append('transformation')
        if 'generate' in purpose_lower or 'create' in purpose_lower:
            domains.append('manifestation')
        
        if not domains:
            domains.append('general')
        
        return domains
    
    def _classify_field_layer(self, semantics: ComponentSemantics) -> str:
        """Classify to 4-field layer system"""
        
        # Tropical: structural, DNA-like
        if semantics.glyph_primary == Glyph.DESIGN:
            return 'tropical'
        
        # Draconic: emotional, RNA-like
        if semantics.glyph_primary == Glyph.MOVEMENT:
            return 'draconic'
        
        # True Draconic: adaptive, tRNA-like
        if semantics.glyph_primary == Glyph.EVOLUTION:
            return 'true_draconic'
        
        # Sidereal: mental, mRNA-like
        if 'cognition' in semantics.domains:
            return 'sidereal'
        
        return 'tropical'  # Default
    
    def _classify_fragment_type(self, semantics: ComponentSemantics) -> str:
        """Classify fragment type for Foundry"""
        
        if 'can_generate' in semantics.capabilities:
            return 'generator'
        if 'can_transform' in semantics.capabilities:
            return 'transformer'
        if 'can_analyze' in semantics.capabilities:
            return 'analyzer'
        if semantics.glyph_primary == Glyph.BEING:
            return 'state_holder'
        
        return 'component'
    
    def _assess_quality_potential(self, semantics: ComponentSemantics) -> float:
        """Assess potential for production quality"""
        
        score = 0.5  # Base
        
        # Positive factors
        if semantics.invariants:
            score += 0.1
        if semantics.constraints:
            score += 0.1
        if 'has_type_constraints' in semantics.constraints:
            score += 0.1
        if semantics.confidence > 0.7:
            score += 0.1
        
        # Negative factors
        if 'modifies_state' in semantics.effects and not semantics.constraints:
            score -= 0.1
        if not semantics.capabilities:
            score -= 0.1
        
        return min(max(score, 0.0), 1.0)
    
    def _calculate_mutation_risk(self, semantics: ComponentSemantics) -> float:
        """Calculate risk of breaking changes"""
        
        risk = 0.5  # Base
        
        # High risk factors
        if semantics.effects:
            risk += 0.2
        if not semantics.constraints:
            risk += 0.1
        if semantics.dependencies:
            risk += 0.1
        
        # Low risk factors
        if semantics.invariants:
            risk -= 0.2
        if 'immutable' in semantics.invariants:
            risk -= 0.2
        if semantics.glyph_primary == Glyph.BEING:
            risk -= 0.1
        
        return min(max(risk, 0.0), 1.0)
    
    def _calculate_confidence(self, semantics: ComponentSemantics) -> float:
        """Overall confidence in semantic analysis"""
        
        confidence = 0.5
        
        # More features = higher confidence
        if semantics.purpose and semantics.purpose != "General purpose component":
            confidence += 0.1
        if semantics.capabilities:
            confidence += 0.1
        if semantics.constraints:
            confidence += 0.1
        if semantics.domains:
            confidence += 0.1
        if semantics.invariants:
            confidence += 0.1
        
        return min(confidence, 1.0)
    
    def _load_purpose_patterns(self) -> Dict:
        """Load patterns for purpose inference"""
        return {
            'calculation': ['calculate', 'compute', 'determine'],
            'transformation': ['transform', 'convert', 'modify'],
            'generation': ['generate', 'create', 'build'],
            'analysis': ['analyze', 'evaluate', 'assess']
        }
    
    def _load_capability_patterns(self) -> Dict:
        """Load patterns for capability extraction"""
        return {
            'computation': ['calculate', 'compute'],
            'transformation': ['transform', 'convert'],
            'creation': ['create', 'generate'],
            'validation': ['validate', 'verify', 'check']
        }


# ============================================================================
# LAYER 2: REASONING - Causal Inference
# ============================================================================

class CausalInferenceEngine:
    """
    Infers causal relationships between components.
    Understands WHY components connect, not just THAT they connect.
    """
    
    def __init__(self, learning_layer=None):
        self.learning_layer = learning_layer
        self.glyph_causality_matrix = self._build_glyph_matrix()
    
    def infer_causality(self, comp_a_sem: ComponentSemantics, 
                       comp_b_sem: ComponentSemantics,
                       comp_a_id: str = 'A',
                       comp_b_id: str = 'B') -> CausalRelationship:
        """Infer causal relationship from A to B"""
        
        # Check interface compatibility
        interface_match = self._check_interface_compatibility(
            comp_a_sem.capabilities,
            comp_b_sem.dependencies
        )
        
        if not interface_match['compatible']:
            return CausalRelationship(
                exists=False,
                source_id=comp_a_id,
                target_id=comp_b_id
            )
        
        # Infer causal type
        causal_type = self._infer_causal_type(comp_a_sem, comp_b_sem)
        
        # Calculate strength
        strength = self._calculate_causal_strength(
            comp_a_sem, comp_b_sem, interface_match
        )
        
        # Explain mechanism
        mechanism = self._explain_mechanism(comp_a_sem, comp_b_sem, causal_type)
        
        # Find conditions
        conditions = self._find_activation_conditions(comp_a_sem, comp_b_sem)
        
        # Calculate confidence
        confidence = self._calculate_confidence(
            interface_match, strength, comp_a_sem, comp_b_sem
        )
        
        # Calculate resonance
        resonance = self._calculate_resonance(comp_a_sem, comp_b_sem)
        
        # Check field alignment
        field_align = self._check_field_alignment(comp_a_sem, comp_b_sem)
        
        return CausalRelationship(
            exists=True,
            source_id=comp_a_id,
            target_id=comp_b_id,
            causal_type=causal_type,
            strength=strength,
            mechanism=mechanism,
            conditions=conditions,
            confidence=confidence,
            resonance_score=resonance,
            field_alignment=field_align
        )
    
    def _check_interface_compatibility(self, capabilities: List[str], 
                                     dependencies: List[str]) -> Dict:
        """Check if A's outputs match B's inputs"""
        
        # Simple heuristic: look for common terms
        cap_terms = set(' '.join(capabilities).lower().split())
        dep_terms = set(' '.join(dependencies).lower().split())
        
        overlap = cap_terms & dep_terms
        
        return {
            'compatible': len(overlap) > 0 or len(dependencies) == 0,
            'overlap_score': len(overlap) / max(len(cap_terms), 1)
        }
    
    def _infer_causal_type(self, comp_a: ComponentSemantics, 
                          comp_b: ComponentSemantics) -> CausalType:
        """WHY does A cause B?"""
        
        a_glyph = comp_a.glyph_primary
        b_glyph = comp_b.glyph_primary
        
        # Glyph-based inference using matrix
        glyph_pair = (a_glyph, b_glyph)
        if glyph_pair in self.glyph_causality_matrix:
            return self.glyph_causality_matrix[glyph_pair]
        
        # Behavior-based inference
        if 'can_transform' in comp_a.capabilities:
            return CausalType.EFFICIENT
        
        if comp_a.glyph_primary == Glyph.DESIGN:
            return CausalType.FORMAL
        
        if comp_a.glyph_primary == Glyph.SPACE:
            return CausalType.MATERIAL
        
        # Check for learning patterns
        if self.learning_layer:
            learned_type = self.learning_layer.query_learned_causality(
                comp_a.fragment_type, comp_b.fragment_type
            )
            if learned_type:
                return learned_type
        
        return CausalType.EFFICIENT  # Default
    
    def _calculate_causal_strength(self, comp_a: ComponentSemantics,
                                  comp_b: ComponentSemantics,
                                  interface_match: Dict) -> float:
        """How strong is the causal link?"""
        
        strength = 0.5  # Base
        
        # Interface compatibility boosts strength
        strength += interface_match['overlap_score'] * 0.3
        
        # Glyph compatibility
        if self._glyphs_compatible(comp_a.glyph_primary, comp_b.glyph_primary):
            strength += 0.2
        
        # Domain overlap
        domain_overlap = len(set(comp_a.domains) & set(comp_b.domains))
        strength += domain_overlap * 0.1
        
        return min(strength, 1.0)
    
    def _explain_mechanism(self, comp_a: ComponentSemantics,
                          comp_b: ComponentSemantics,
                          causal_type: CausalType) -> str:
        """HOW does the causation work?"""
        
        if causal_type == CausalType.COLLAPSE:
            return (
                f"Component A ({comp_a.fragment_type}) transforms dynamic flow "
                f"into stable state that B ({comp_b.fragment_type}) uses as identity."
            )
        
        if causal_type == CausalType.RESONANT:
            return (
                f"Components share harmonic frequencies - they mutually "
                f"reinforce patterns at {comp_a.field_layer} layer."
            )
        
        if causal_type == CausalType.CASCADE:
            return (
                f"A triggers phase transition that cascades through B's "
                f"field layers, activating latent capabilities."
            )
        
        if causal_type == CausalType.EFFICIENT:
            return (
                f"A's output ({', '.join(comp_a.capabilities[:2])}) flows "
                f"directly into B's processing."
            )
        
        return f"Causal relationship of type {causal_type.value}"
    
    def _find_activation_conditions(self, comp_a: ComponentSemantics,
                                   comp_b: ComponentSemantics) -> List[str]:
        """When does this causation activate?"""
        
        conditions = []
        
        if comp_a.constraints:
            conditions.append("A must satisfy its constraints")
        
        if comp_b.dependencies:
            conditions.append("B's dependencies must be met")
        
        if 'modifies_state' in comp_a.effects:
            conditions.append("A must have write access")
        
        return conditions
    
    def _calculate_confidence(self, interface_match: Dict, strength: float,
                             comp_a: ComponentSemantics,
                             comp_b: ComponentSemantics) -> float:
        """Confidence in this causal inference"""
        
        confidence = 0.5
        
        # Strong interface match = high confidence
        if interface_match['compatible']:
            confidence += 0.2
        
        # High strength = high confidence  
        confidence += strength * 0.2
        
        # Both components well-understood = high confidence
        avg_component_confidence = (comp_a.confidence + comp_b.confidence) / 2
        confidence += avg_component_confidence * 0.1
        
        return min(confidence, 1.0)
    
    def _calculate_resonance(self, comp_a: ComponentSemantics,
                            comp_b: ComponentSemantics) -> float:
        """Calculate resonance score"""
        
        # Simple resonance based on glyph compatibility
        if comp_a.glyph_primary == comp_b.glyph_primary:
            return 0.9  # Strong resonance
        
        if self._glyphs_compatible(comp_a.glyph_primary, comp_b.glyph_primary):
            return 0.7  # Moderate resonance
        
        return 0.3  # Weak resonance
    
    def _check_field_alignment(self, comp_a: ComponentSemantics,
                              comp_b: ComponentSemantics) -> Dict[str, float]:
        """Check alignment across field layers"""
        
        alignment = {}
        
        # Same field layer = perfect alignment
        if comp_a.field_layer == comp_b.field_layer:
            alignment[comp_a.field_layer] = 1.0
        else:
            alignment[comp_a.field_layer] = 0.5
            alignment[comp_b.field_layer] = 0.5
        
        return alignment
    
    def _glyphs_compatible(self, glyph_a: Glyph, glyph_b: Glyph) -> bool:
        """Check if glyphs are compatible"""
        
        compatible_pairs = [
            (Glyph.MOVEMENT, Glyph.BEING),
            (Glyph.DESIGN, Glyph.MOVEMENT),
            (Glyph.SPACE, Glyph.BEING),
            (Glyph.EVOLUTION, Glyph.EVOLUTION),
            (Glyph.DESIGN, Glyph.BEING)
        ]
        
        return (glyph_a, glyph_b) in compatible_pairs
    
    def _build_glyph_matrix(self) -> Dict[Tuple[Glyph, Glyph], CausalType]:
        """Build causal type matrix for glyph pairs"""
        
        return {
            (Glyph.MOVEMENT, Glyph.BEING): CausalType.COLLAPSE,
            (Glyph.DESIGN, Glyph.MOVEMENT): CausalType.FORMAL,
            (Glyph.SPACE, Glyph.BEING): CausalType.MATERIAL,
            (Glyph.EVOLUTION, Glyph.EVOLUTION): CausalType.RESONANT,
            (Glyph.MOVEMENT, Glyph.MOVEMENT): CausalType.CASCADE,
            (Glyph.DESIGN, Glyph.BEING): CausalType.FORMAL,
            (Glyph.BEING, Glyph.MOVEMENT): CausalType.EFFICIENT,
        }


# Continue in next file...
