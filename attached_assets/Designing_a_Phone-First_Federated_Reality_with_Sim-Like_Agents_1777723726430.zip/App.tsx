import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useParams } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { BottomNav } from "./components/BottomNav";
import Feed from "./pages/Feed";
import AgentsList from "./pages/AgentsList";
import AgentProfile from "./pages/AgentProfile";
import WorldMap from "./pages/WorldMap";
import Observer from "./pages/Observer";
import NotFound from "./pages/NotFound";

function AgentProfileWrapper() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0", 10);
  if (!id) return <NotFound />;
  return <AgentProfile id={id} />;
}

function Router() {
  return (
    <>
      <Switch>
        <Route path="/" component={Feed} />
        <Route path="/agents" component={AgentsList} />
        <Route path="/agents/:id" component={AgentProfileWrapper} />
        <Route path="/world" component={WorldMap} />
        <Route path="/observer" component={Observer} />
        <Route component={NotFound} />
      </Switch>
      <BottomNav />
    </>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster
            theme="dark"
            position="top-center"
            toastOptions={{
              style: {
                background: "oklch(0.14 0.015 260)",
                border: "1px solid oklch(0.25 0.015 260)",
                color: "oklch(0.95 0.005 260)",
              },
            }}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
