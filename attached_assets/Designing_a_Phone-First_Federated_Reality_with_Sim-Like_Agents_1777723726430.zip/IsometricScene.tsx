import { Canvas } from "@react-three/fiber";
import { PerspectiveCamera, OrbitControls, Environment } from "@react-three/drei";
import { useEffect, useRef, useState } from "react";
import { Vector3 } from "three";
import { trpc } from "@/lib/trpc";
import AgentModel from "./AgentModel";
import DistrictEnvironment from "./DistrictEnvironment";

interface IsometricSceneProps {
  districtId: number;
  onAgentClick?: (agentId: number) => void;
}

export default function IsometricScene({ districtId, onAgentClick }: IsometricSceneProps) {
  const cameraRef = useRef<any>(null);
  const [agents, setAgents] = useState<any[]>([]);
  const [district, setDistrict] = useState<any>(null);

  const { data: allAgents = [] } = trpc.agents.list.useQuery(undefined, {
    refetchInterval: 5000,
  });

  const { data: districtData } = trpc.world.district.useQuery({ id: districtId }, {
    refetchInterval: 5000,
  });

  useEffect(() => {
    if (districtData) {
      setDistrict(districtData);
    }
  }, [districtData]);

  useEffect(() => {
    const districtAgents = allAgents.filter(a => a.districtId === districtId);
    setAgents(districtAgents);
  }, [allAgents, districtId]);

  // Isometric camera setup: positioned at 45° angle
  const cameraPosition: [number, number, number] = [15, 15, 15];

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative">
      <Canvas
        camera={{
          position: cameraPosition,
          fov: 50,
          near: 0.1,
          far: 1000,
        }}
        style={{ width: "100%", height: "100%" }}
      >
        {/* Lighting */}
        <ambientLight intensity={0.6} />
        <directionalLight
          position={[20, 20, 10]}
          intensity={1.2}
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-far={50}
          shadow-camera-left={-30}
          shadow-camera-right={30}
          shadow-camera-top={30}
          shadow-camera-bottom={-30}
        />
        <pointLight position={[-10, 10, 5]} intensity={0.4} color="#6366f1" />

        {/* Environment */}
        <Environment preset="night" />

        {/* District environment (floor, buildings, etc.) */}
        <DistrictEnvironment district={district} />

        {/* Agent models */}
        {agents.map((agent, idx) => (
          <AgentModel
            key={agent.id}
            agent={agent}
            index={idx}
            totalAgents={agents.length}
            onClick={() => onAgentClick?.(agent.id)}
          />
        ))}

        {/* Camera controls */}
        <OrbitControls
          ref={cameraRef}
          enableDamping
          dampingFactor={0.05}
          autoRotate={false}
          minDistance={8}
          maxDistance={40}
          minPolarAngle={Math.PI / 6}
          maxPolarAngle={Math.PI / 2.2}
        />
      </Canvas>

      {/* District info overlay */}
      {district && (
        <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm rounded-lg px-4 py-3 border border-primary/30">
          <h3 className="text-sm font-semibold text-foreground">{district.name}</h3>
          <p className="text-xs text-muted-foreground mt-1">
            {agents.length} agent{agents.length !== 1 ? "s" : ""} present
          </p>
        </div>
      )}

      {/* Agent count */}
      <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-sm rounded-lg px-3 py-2 border border-primary/30 text-xs text-muted-foreground">
        {agents.length} / {allAgents.length} agents visible
      </div>
    </div>
  );
}
