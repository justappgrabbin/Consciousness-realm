/**
 * Knowledge Base Seeding
 * Handles initial seeding of the knowledge base with Mew.pdf on first run
 */

import { getDb } from "./db";
import { createDocument, updateDocumentStatus, createConcept, createCodeBlock, createRelationship } from "./knowledge";
import { getNeuralBrainClient } from "./neural-brain-client";
import { extractKnowledgeFromPDF } from "./pdf-parser";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

const neuralBrain = getNeuralBrainClient();

/**
 * Check if seeding has already been completed
 */
async function hasBeenSeeded(): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    // Check if any documents exist (indicating seeding has occurred)
    const result = await db.execute(
      "SELECT COUNT(*) as count FROM documents LIMIT 1"
    );
    
    // If we have any documents, seeding has occurred
    return (result as any)[0]?.count > 0;
  } catch (error) {
    console.error("[Seeding] Error checking seed status:", error);
    return false;
  }
}

/**
 * Seed the knowledge base with Mew.pdf
 * This runs automatically on first app startup
 */
export async function seedKnowledgeBase(): Promise<boolean> {
  try {
    // Check if already seeded
    const alreadySeeded = await hasBeenSeeded();
    if (alreadySeeded) {
      console.log("[Seeding] Knowledge base already seeded, skipping");
      return true;
    }

    console.log("[Seeding] Starting knowledge base seeding...");

    // Check if Mew.pdf exists
    const mewPdfPath = "/home/ubuntu/Mew.pdf";
    const fs = await import("fs").then((m) => m.promises);
    
    let fileExists = false;
    try {
      await fs.access(mewPdfPath);
      fileExists = true;
      console.log("[Seeding] Found Mew.pdf");
    } catch {
      console.log("[Seeding] Mew.pdf not found, seeding skipped");
      return true; // Not an error, just no file to seed
    }

    if (!fileExists) {
      return true;
    }

    // Read Mew.pdf
    const fileBuffer = await fs.readFile(mewPdfPath);
    const filename = "Mew.pdf";
    
    // Convert Buffer to string for PDF text extraction
    // In production, would use a proper PDF parser library
    const pdfText = fileBuffer.toString('utf-8', 0, Math.min(fileBuffer.length, 10000));

    // Create system user for seeding (admin user)
    const db = await getDb();
    if (!db) {
      console.error("[Seeding] Database not available");
      return false;
    }

    // Get or create system user
    const systemUserResult = await db.execute(
      "SELECT id FROM users WHERE openId = 'system-seeder' LIMIT 1"
    );

    let userId = 1; // Default to first user
    try {
      if (Array.isArray(systemUserResult) && systemUserResult.length > 0) {
        userId = (systemUserResult as any)[0].id;
      }
    } catch (e) {
      console.log("[Seeding] Using default user ID");
    }

    // Upload to S3
    const fileKey = `pdfs/seeding/${nanoid()}-${filename}`;
    const { url: fileUrl } = await storagePut(fileKey, fileBuffer, "application/pdf");

    console.log("[Seeding] Uploaded Mew.pdf to S3");

    // Create document record
    const docResult = await createDocument(userId, filename, fileUrl);
    const docId = (docResult as any).insertId || (docResult as any)[0]?.id || 1;

    // Mark as processing
    if (docId) {
      await updateDocumentStatus(docId, "processing");
    }

    // Extract knowledge using LLM
    console.log("[Seeding] Extracting knowledge from Mew.pdf...");
    const extractedKnowledge = await extractKnowledgeFromPDF(pdfText);

    if (!extractedKnowledge) {
      console.error("[Seeding] Failed to extract knowledge");
      await updateDocumentStatus(docId, "failed");
      return false;
    }

    // Store concepts in database
    console.log(`[Seeding] Storing ${extractedKnowledge.concepts.length} concepts...`);
    const conceptIds: number[] = [];

    for (const concept of extractedKnowledge.concepts) {
      try {
        // Generate embedding for concept
        const embeddings = await neuralBrain.embedText(concept.name);
        const embedding = embeddings[0] || [];

        // Create concept
        const conceptResult = await createConcept(
          concept.name,
          concept.description,
          concept.category,
          docId,
          embedding
        );

        conceptIds.push((conceptResult as any).insertId);
      } catch (error) {
        console.error(`[Seeding] Error storing concept ${concept.name}:`, error);
      }
    }

    // Store code blocks in database
    console.log(`[Seeding] Storing ${extractedKnowledge.codeBlocks.length} code blocks...`);
    const codeBlockIds: number[] = [];

    for (const codeBlock of extractedKnowledge.codeBlocks) {
      try {
        // Generate embedding for code
        const embeddings = await neuralBrain.embedCode(codeBlock.code);
        const embedding = embeddings[0] || [];

        // Create code block
        const codeResult = await createCodeBlock(
          codeBlock.language,
          codeBlock.code,
          codeBlock.description,
          docId,
          embedding,
          codeBlock.patternType
        );

        codeBlockIds.push((codeResult as any).insertId);
      } catch (error) {
        console.error(`[Seeding] Error storing code block:`, error);
      }
    }

    // Add nodes to neural brain
    console.log("[Seeding] Adding nodes to neural brain...");
    for (let i = 0; i < conceptIds.length; i++) {
      try {
        const concept = extractedKnowledge.concepts[i];
        const embeddings = await neuralBrain.embedText(concept.name);
        const embedding = embeddings[0] || [];

        await neuralBrain.addNode(
          "concept",
          concept.name,
          embedding,
          docId,
          { category: concept.category }
        );
      } catch (error) {
        console.error(`[Seeding] Error adding concept node:`, error);
      }
    }

    for (let i = 0; i < codeBlockIds.length; i++) {
      try {
        const codeBlock = extractedKnowledge.codeBlocks[i];
        const embeddings = await neuralBrain.embedCode(codeBlock.code);
        const embedding = embeddings[0] || [];

        await neuralBrain.addNode(
          "code_block",
          `${codeBlock.language}_${codeBlock.patternType}`,
          embedding,
          docId,
          { language: codeBlock.language, patternType: codeBlock.patternType }
        );
      } catch (error) {
        console.error(`[Seeding] Error adding code block node:`, error);
      }
    }

    // Store relationships (simplified - would need proper ID mapping in production)
    console.log(`[Seeding] Storing ${extractedKnowledge.relationships.length} relationships...`);
    for (const rel of extractedKnowledge.relationships) {
      try {
        // In production, would map source/target names to actual IDs
        // For now, skip relationship creation as it requires proper ID resolution
        console.log(`[Seeding] Relationship: ${rel.source} -> ${rel.target}`);
      } catch (error) {
        console.error(`[Seeding] Error storing relationship:`, error);
      }
    }

    // Train neural brain
    console.log("[Seeding] Training neural brain...");
    try {
      const trainingResult = await neuralBrain.trainStep();
      console.log("[Seeding] Neural brain training complete:", trainingResult);
    } catch (error) {
      console.error("[Seeding] Error training neural brain:", error);
    }

    // Mark document as completed
    await updateDocumentStatus(docId, "completed");

    console.log("[Seeding] ✓ Knowledge base seeding completed successfully!");
    return true;
  } catch (error) {
    console.error("[Seeding] Fatal error during seeding:", error);
    return false;
  }
}

/**
 * Initialize seeding on app startup
 */
export async function initializeSeeding(): Promise<void> {
  try {
    // Run seeding asynchronously (don't block app startup)
    setImmediate(async () => {
      await seedKnowledgeBase();
    });
  } catch (error) {
    console.error("[Seeding] Error initializing seeding:", error);
  }
}
