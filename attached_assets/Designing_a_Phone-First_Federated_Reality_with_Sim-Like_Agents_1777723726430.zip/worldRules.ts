/**
 * World Rules Engine
 * Physics-like constraints governing agent behavior:
 * - Scarcity, energy limits, social norms, and consequence chains
 */

import type { Agent, AgentNeeds, AgentMood as AgentMoodRow, District } from "../drizzle/schema";

// ─── Constants ─────────────────────────────────────────────────────────────────
export const NEEDS_DECAY_PER_TICK: Record<string, number> = {
  hunger: -3.5,    // Gets hungry over time
  energy: -2.0,    // Gets tired over time
  social: -1.5,    // Gets lonely over time
  fun: -1.8,       // Gets bored over time
  hygiene: -1.2,   // Gets dirty over time
  comfort: -0.8,   // Gets uncomfortable over time
};

export const NEEDS_RESTORE: Record<string, Record<string, number>> = {
  eating: { hunger: 35, comfort: 5 },
  sleeping: { energy: 40, comfort: 15, hygiene: -2 },
  socializing: { social: 25, fun: 15 },
  working: { fun: -8, energy: -10 },
  exercising: { energy: -12, fun: 10, hygiene: -15 },
  relaxing: { fun: 20, comfort: 15, energy: 8 },
  bathing: { hygiene: 40, comfort: 10 },
  creative: { fun: 25, social: 5 },
};

export const MOOD_THRESHOLDS = {
  ecstatic: 90,
  happy: 75,
  content: 60,
  neutral: 45,
  uncomfortable: 30,
  sad: 20,
  distressed: 10,
  furious: 0,
};

export const WORLD_HOURS_PER_TICK = 0.5; // Each tick advances world time by 30 min
export const TICKS_PER_DAY = 48; // 24 hours / 0.5 = 48 ticks per day

// ─── Need Calculation ──────────────────────────────────────────────────────────
export function applyNeedsDecay(needs: AgentNeeds, districtResourceLevel: number): Partial<AgentNeeds> {
  const scarcityMultiplier = 2 - districtResourceLevel; // Low resources = faster decay
  return {
    hunger: Math.max(0, needs.hunger + NEEDS_DECAY_PER_TICK.hunger * scarcityMultiplier),
    energy: Math.max(0, needs.energy + NEEDS_DECAY_PER_TICK.energy),
    social: Math.max(0, needs.social + NEEDS_DECAY_PER_TICK.social),
    fun: Math.max(0, needs.fun + NEEDS_DECAY_PER_TICK.fun),
    hygiene: Math.max(0, needs.hygiene + NEEDS_DECAY_PER_TICK.hygiene),
    comfort: Math.max(0, needs.comfort + NEEDS_DECAY_PER_TICK.comfort),
  };
}

export function applyActivityToNeeds(needs: AgentNeeds, activity: string): Partial<AgentNeeds> {
  const deltas = NEEDS_RESTORE[activity] ?? {};
  const updated: Partial<AgentNeeds> = {};
  for (const [key, delta] of Object.entries(deltas)) {
    const current = (needs as any)[key] ?? 50;
    (updated as any)[key] = Math.max(0, Math.min(100, current + delta));
  }
  return updated;
}

// ─── Mood Calculation ──────────────────────────────────────────────────────────
export function calculateMoodScore(needs: AgentNeeds): number {
  const weights = {
    hunger: 0.25,
    energy: 0.20,
    social: 0.18,
    fun: 0.15,
    hygiene: 0.12,
    comfort: 0.10,
  };
  return (
    needs.hunger * weights.hunger +
    needs.energy * weights.energy +
    needs.social * weights.social +
    needs.fun * weights.fun +
    needs.hygiene * weights.hygiene +
    needs.comfort * weights.comfort
  );
}

export function getMoodLabel(score: number): AgentMoodRow["mood"] {
  if (score >= MOOD_THRESHOLDS.ecstatic) return "ecstatic";
  if (score >= MOOD_THRESHOLDS.happy) return "happy";
  if (score >= MOOD_THRESHOLDS.content) return "content";
  if (score >= MOOD_THRESHOLDS.neutral) return "neutral";
  if (score >= MOOD_THRESHOLDS.uncomfortable) return "uncomfortable";
  if (score >= MOOD_THRESHOLDS.sad) return "sad";
  if (score >= MOOD_THRESHOLDS.distressed) return "distressed";
  return "furious";
}

export function getDominantEmotion(needs: AgentNeeds, personality: Agent["personality"]): string {
  const lowestNeed = Object.entries({
    hunger: needs.hunger,
    energy: needs.energy,
    social: needs.social,
    fun: needs.fun,
    hygiene: needs.hygiene,
    comfort: needs.comfort,
  }).sort(([, a], [, b]) => a - b)[0];

  if (!lowestNeed || lowestNeed[1] > 40) {
    // No critical need — personality-driven emotion
    if (personality.extraversion > 0.7) return "enthusiastic";
    if (personality.neuroticism > 0.7) return "anxious";
    if (personality.openness > 0.7) return "curious";
    return "calm";
  }

  const needEmotions: Record<string, string> = {
    hunger: "hungry",
    energy: "exhausted",
    social: "lonely",
    fun: "bored",
    hygiene: "uncomfortable",
    comfort: "restless",
  };
  return needEmotions[lowestNeed[0]] ?? "neutral";
}

// ─── Activity Selection ────────────────────────────────────────────────────────
export type ActivityChoice = {
  activity: string;
  location: string;
  reason: string;
  urgency: number;
};

export function selectActivityByNeeds(
  needs: AgentNeeds,
  worldHour: number,
  personality: Agent["personality"],
  district: District
): ActivityChoice {
  const candidates: ActivityChoice[] = [];

  // Critical survival needs take priority
  if (needs.hunger < 20) {
    candidates.push({ activity: "eating", location: "kitchen", reason: "Starving — must eat", urgency: 0.95 });
  }
  if (needs.energy < 15) {
    candidates.push({ activity: "sleeping", location: "bedroom", reason: "Exhausted — must sleep", urgency: 0.98 });
  }
  if (needs.hygiene < 20) {
    candidates.push({ activity: "bathing", location: "bathroom", reason: "Feeling very dirty", urgency: 0.80 });
  }

  // Time-of-day driven activities
  if (worldHour >= 7 && worldHour < 9 && needs.hunger < 70) {
    candidates.push({ activity: "eating", location: "kitchen", reason: "Morning breakfast time", urgency: 0.6 });
  }
  if (worldHour >= 22 || worldHour < 6) {
    candidates.push({ activity: "sleeping", location: "bedroom", reason: "Late night — time to sleep", urgency: 0.7 });
  }
  if (worldHour >= 9 && worldHour < 17) {
    candidates.push({ activity: "working", location: "workplace", reason: "Work hours", urgency: 0.65 });
  }

  // Social needs
  if (needs.social < 35 && worldHour >= 10 && worldHour < 22) {
    candidates.push({ activity: "socializing", location: "public_square", reason: "Feeling lonely", urgency: 0.55 });
  }

  // Fun needs
  if (needs.fun < 35) {
    const funActivity = personality.openness > 0.6 ? "creative" : "relaxing";
    candidates.push({ activity: funActivity, location: "leisure_area", reason: "Need some fun", urgency: 0.50 });
  }

  // Default activities by personality
  if (candidates.length === 0) {
    if (personality.conscientiousness > 0.6) {
      candidates.push({ activity: "working", location: "workplace", reason: "Being productive", urgency: 0.3 });
    } else if (personality.extraversion > 0.6) {
      candidates.push({ activity: "socializing", location: "cafe", reason: "Feeling social", urgency: 0.3 });
    } else {
      candidates.push({ activity: "relaxing", location: "home", reason: "Taking it easy", urgency: 0.2 });
    }
  }

  // Sort by urgency and pick the highest
  candidates.sort((a, b) => b.urgency - a.urgency);
  return candidates[0]!;
}

// ─── Social Norm Enforcement ───────────────────────────────────────────────────
export function checkSocialNormViolation(
  activity: string,
  worldHour: number,
  district: District
): { violated: boolean; consequence: string } {
  const strictness = district.socialNormStrictness;

  // Loud activities at night in strict districts
  if (strictness > 0.7 && (worldHour < 7 || worldHour > 22)) {
    if (["socializing", "creative"].includes(activity)) {
      return { violated: true, consequence: "Neighbors are disturbed by the noise" };
    }
  }

  // Working in creative districts
  if (district.theme === "creative" && activity === "working" && strictness < 0.3) {
    return { violated: false, consequence: "" };
  }

  return { violated: false, consequence: "" };
}

// ─── Migration Logic ───────────────────────────────────────────────────────────
export function shouldMigrate(
  agent: Agent,
  currentDistrict: District,
  allDistricts: District[]
): { should: boolean; targetDistrictId: number | null; reason: string } {
  // Only migrate occasionally (low probability)
  if (Math.random() > 0.02) return { should: false, targetDistrictId: null, reason: "" };

  // Check if current district is overcrowded
  if (currentDistrict.population >= currentDistrict.maxPopulation * 0.9) {
    const lessPopulated = allDistricts
      .filter(d => d.id !== currentDistrict.id && d.population < d.maxPopulation * 0.7)
      .sort((a, b) => a.population - b.population);
    if (lessPopulated.length > 0) {
      return {
        should: true,
        targetDistrictId: lessPopulated[0]!.id,
        reason: `${currentDistrict.name} is overcrowded`,
      };
    }
  }

  // Personality-driven migration
  const personality = agent.personality;
  if (personality.openness > 0.8 && Math.random() > 0.95) {
    const randomDistrict = allDistricts.filter(d => d.id !== currentDistrict.id)[
      Math.floor(Math.random() * (allDistricts.length - 1))
    ];
    if (randomDistrict) {
      return {
        should: true,
        targetDistrictId: randomDistrict.id,
        reason: "Craving a new adventure",
      };
    }
  }

  return { should: false, targetDistrictId: null, reason: "" };
}

// ─── Relationship Evolution ────────────────────────────────────────────────────
export function evolveRelationship(
  currentStrength: number,
  currentSentiment: number,
  interactionSentiment: number,
  interactionCount: number
): { strength: number; sentiment: number; type: string } {
  const newStrength = Math.min(1, currentStrength + 0.05 + (interactionCount > 10 ? 0.02 : 0));
  const newSentiment = Math.max(0, Math.min(1, currentSentiment * 0.8 + interactionSentiment * 0.2));

  let type = "acquaintance";
  if (newStrength > 0.7 && newSentiment > 0.7) type = "friend";
  else if (newStrength > 0.8 && newSentiment > 0.85) type = "romantic";
  else if (newStrength > 0.5 && newSentiment < 0.3) type = "rival";
  else if (newStrength > 0.3 && newSentiment < 0.2) type = "enemy";
  else if (newStrength > 0.4 && newSentiment > 0.5) type = "colleague";

  return { strength: newStrength, sentiment: newSentiment, type };
}

// ─── World Event Effects ───────────────────────────────────────────────────────
export function applyWorldEventToNeeds(
  needs: AgentNeeds,
  effects: WorldEvent["effects"]
): Partial<AgentNeeds> {
  if (!effects?.needsDeltas) return {};
  const updated: Partial<AgentNeeds> = {};
  for (const [key, delta] of Object.entries(effects.needsDeltas)) {
    const current = (needs as any)[key] ?? 50;
    (updated as any)[key] = Math.max(0, Math.min(100, current + (delta as number)));
  }
  return updated;
}

// ─── Task Generation ───────────────────────────────────────────────────────────
export function generateTasksForAgent(
  agent: Agent,
  worldDay: number,
  existingTaskCount: number
): Array<{ title: string; type: Task["type"]; priority: number; description: string }> {
  if (existingTaskCount >= 3) return []; // Max 3 pending tasks

  const tasks: Array<{ title: string; type: Task["type"]; priority: number; description: string }> = [];
  const personality = agent.personality;

  // Work tasks
  if (Math.random() < 0.4) {
    const workTasks = [
      { title: `Complete ${agent.job} project`, description: `Finish the current work assignment as a ${agent.job}`, priority: 0.7 },
      { title: "Attend team meeting", description: "Join colleagues for a coordination session", priority: 0.6 },
      { title: "Submit weekly report", description: "Compile and send the weekly progress report", priority: 0.65 },
    ];
    const task = workTasks[Math.floor(Math.random() * workTasks.length)]!;
    tasks.push({ ...task, type: "work" });
  }

  // Social tasks
  if (personality.extraversion > 0.5 && Math.random() < 0.3) {
    tasks.push({
      title: "Catch up with a friend",
      description: "Spend quality time with someone in the social circle",
      type: "social",
      priority: 0.5,
    });
  }

  // Personal tasks
  if (Math.random() < 0.25) {
    const personalTasks = [
      { title: "Go grocery shopping", description: "Restock food supplies", priority: 0.55 },
      { title: "Exercise routine", description: "Maintain physical fitness", priority: 0.45 },
      { title: "Read a book", description: "Expand knowledge and relax", priority: 0.35 },
    ];
    const task = personalTasks[Math.floor(Math.random() * personalTasks.length)]!;
    tasks.push({ ...task, type: "personal" });
  }

  return tasks;
}

// Re-export types needed
type Task = { type: "work" | "errand" | "social" | "personal" | "creative" | "survival" };
type WorldEvent = { effects: { needsDeltas?: Partial<Record<string, number>> } | null };
