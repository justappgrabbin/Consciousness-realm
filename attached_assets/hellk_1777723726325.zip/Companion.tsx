import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Sparkles, Brain, Heart, Zap, Send, Network, Target, BarChart3 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Streamdown } from "streamdown";
import { getLoginUrl } from "@/const";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  brainSource?: {
    deterministic: number;
    rag: number;
    convergence: number;
  };
}

export default function Companion() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Get user's node data
  const { data: nodeData, isLoading: nodeLoading } = trpc.node.getMyNode.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Get chat history
  const { data: chatHistory } = trpc.companion.getHistory.useQuery(undefined, {
    enabled: isAuthenticated && !!nodeData
  });

  // Chat mutation
  const chatMutation = trpc.companion.chat.useMutation({
    onSuccess: (data) => {
      const assistantMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: data.response,
        timestamp: new Date(),
        brainSource: {
          deterministic: 40,
          rag: 40,
          convergence: data.coherence || 50
        }
      };
      setMessages(prev => [...prev, assistantMessage]);
    }
  });

  // Load chat history
  useEffect(() => {
    if (chatHistory && Array.isArray(chatHistory)) {
      const formattedMessages: Message[] = chatHistory.map((msg: { id: number; role: string; content: string; createdAt: Date }) => ({
        id: msg.id.toString(),
        role: msg.role as "user" | "assistant",
        content: msg.content,
        timestamp: new Date(msg.createdAt)
      }));
      setMessages(formattedMessages);
    }
  }, [chatHistory]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim() || chatMutation.isPending) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    
    chatMutation.mutate({ message: input.trim() });
    setInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (authLoading || nodeLoading) {
    return (
      <div className="min-h-screen cosmic-bg flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen cosmic-bg flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full glass">
          <CardHeader className="text-center">
            <Brain className="w-12 h-12 mx-auto mb-4 text-primary" />
            <CardTitle className="gradient-text text-2xl">AI Companion</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center mb-6">
              Sign in to access your personal AI companion
            </p>
            <Button 
              className="w-full glow-primary" 
              onClick={() => window.location.href = getLoginUrl()}
            >
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!nodeData) {
    return (
      <div className="min-h-screen cosmic-bg flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full glass">
          <CardHeader className="text-center">
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-primary" />
            <CardTitle className="gradient-text text-2xl">Calculate First</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center mb-6">
              You need to calculate your Trinity Fields before accessing your AI companion
            </p>
            <Button 
              className="w-full glow-primary" 
              onClick={() => setLocation("/calculate")}
            >
              Calculate Trinity Fields
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen cosmic-bg flex flex-col">
      {/* Navigation */}
      <nav className="border-b border-border/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <span className="font-bold gradient-text">YOU-N-I-VERSE</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link href="/network">
              <Button variant="ghost" size="sm">
                <Network className="w-4 h-4 mr-2" />
                Network
              </Button>
            </Link>
            <Link href="/quests">
              <Button variant="ghost" size="sm">
                <Target className="w-4 h-4 mr-2" />
                Quests
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <BarChart3 className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="flex-1 container py-4 flex gap-4">
        {/* Sidebar - Trinity Fields */}
        <aside className="hidden lg:block w-72 space-y-4">
          <Card className="glass">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Your Trinity Fields</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3 p-2 rounded-lg bg-background/50">
                <Zap className="w-5 h-5" style={{ color: 'oklch(0.6 0.22 25)' }} />
                <div>
                  <p className="text-xs text-muted-foreground">Body (Gate {nodeData.bodyGate}.{nodeData.bodyLine})</p>
                  <p className="text-sm font-medium">{nodeData.gateInfo?.body?.name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-background/50">
                <Brain className="w-5 h-5" style={{ color: 'oklch(0.6 0.2 220)' }} />
                <div>
                  <p className="text-xs text-muted-foreground">Mind (Gate {nodeData.mindGate}.{nodeData.mindLine})</p>
                  <p className="text-sm font-medium">{nodeData.gateInfo?.mind?.name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-2 rounded-lg bg-background/50">
                <Heart className="w-5 h-5" style={{ color: 'oklch(0.6 0.22 320)' }} />
                <div>
                  <p className="text-xs text-muted-foreground">Heart (Gate {nodeData.heartGate}.{nodeData.heartLine})</p>
                  <p className="text-sm font-medium">{nodeData.gateInfo?.heart?.name}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="glass">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Your Design</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Type</span>
                  <span className="text-sm font-medium">{nodeData.hdType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Authority</span>
                  <span className="text-sm font-medium">{nodeData.hdAuthority}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground text-sm">Coherence</span>
                  <span className="text-sm font-medium">{nodeData.coherenceScore}%</span>
                </div>
              </div>
              <div className="mt-3">
                <div className="coherence-bar">
                  <div 
                    className="coherence-fill" 
                    style={{ width: `${nodeData.coherenceScore}%` }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="glass">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Dual-Brain Processing</CardTitle>
            </CardHeader>
            <CardContent className="text-xs text-muted-foreground space-y-2">
              <p>
                <strong className="text-foreground">Brain 1 (Deterministic):</strong> Your fixed Human Design pattern - gates, channels, and centers that define your unique energy flow.
              </p>
              <p>
                <strong className="text-foreground">Brain 2 (RAG):</strong> Retrieves relevant wisdom from the causal knowledge base based on your activated gates.
              </p>
              <p>
                <strong className="text-foreground">Convergence:</strong> Weighted combination at the Throat - coherent expression honoring your design.
              </p>
            </CardContent>
          </Card>
        </aside>

        {/* Main Chat Area */}
        <main className="flex-1 flex flex-col">
          <Card className="glass flex-1 flex flex-col">
            <CardHeader className="border-b border-border/50 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                    <Brain className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Your AI Companion</CardTitle>
                    <p className="text-xs text-muted-foreground">
                      Dual-brain processing • Resonance learning
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="status-dot success" />
                  <span className="text-xs text-muted-foreground">Online</span>
                </div>
              </div>
            </CardHeader>

            <ScrollArea className="flex-1 p-4" ref={scrollRef}>
              <div className="space-y-4">
                {messages.length === 0 && (
                  <div className="text-center py-12">
                    <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                    <h3 className="text-lg font-medium mb-2">Welcome to Your Private Node</h3>
                    <p className="text-muted-foreground text-sm max-w-md mx-auto">
                      I'm your personal AI companion, learning from our interactions through resonance patterns. 
                      Ask me anything about your design, seek guidance, or explore your potential.
                    </p>
                  </div>
                )}

                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`chat-message ${message.role}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        message.role === "user" 
                          ? "bg-primary/20" 
                          : "bg-gradient-to-br from-primary to-secondary"
                      }`}>
                        {message.role === "user" ? (
                          <span className="text-xs font-medium">
                            {user?.name?.charAt(0) || "U"}
                          </span>
                        ) : (
                          <Brain className="w-4 h-4 text-primary-foreground" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium">
                            {message.role === "user" ? user?.name : "AI Companion"}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {message.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="text-sm">
                          <Streamdown>{message.content}</Streamdown>
                        </div>
                        {message.brainSource && (
                          <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                            <span>Deterministic: {message.brainSource.deterministic}%</span>
                            <span>RAG: {message.brainSource.rag}%</span>
                            <span>Convergence: {message.brainSource.convergence}%</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {chatMutation.isPending && (
                  <div className="chat-message assistant">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                        <Brain className="w-4 h-4 text-primary-foreground" />
                      </div>
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm text-muted-foreground">Processing through dual brains...</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            <div className="p-4 border-t border-border/50">
              <div className="flex gap-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask your companion anything..."
                  className="bg-input"
                  disabled={chatMutation.isPending}
                />
                <Button 
                  onClick={handleSend}
                  disabled={!input.trim() || chatMutation.isPending}
                  className="glow-primary"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </main>
      </div>
    </div>
  );
}
