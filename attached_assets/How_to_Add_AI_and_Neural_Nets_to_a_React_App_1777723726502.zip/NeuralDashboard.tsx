import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Brain, TrendingUp, Zap, BookOpen } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface MetricsData {
  epoch: number;
  loss: number;
  accuracy: number;
}

export default function NeuralDashboard() {
  const [metricsData, setMetricsData] = useState<MetricsData[]>([]);

  const metricsQuery = trpc.knowledge.dashboard.metrics.useQuery(undefined, {
    refetchInterval: 5000,
  });

  useEffect(() => {
    if (metricsQuery.data?.epochs && metricsQuery.data.epochs.length > 0) {
      const data = metricsQuery.data.epochs.map((epoch, idx) => ({
        epoch,
        loss: metricsQuery.data.losses?.[idx] || 0,
        accuracy: (metricsQuery.data.accuracies?.[idx] || 0) * 100,
      }));
      setMetricsData(data);
    }
  }, [metricsQuery.data?.epochs]);

  const network = metricsQuery.data?.network;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Brain className="w-8 h-8 text-purple-400" />
            <h1 className="text-4xl font-bold text-white">Neural Dashboard</h1>
          </div>
          <p className="text-slate-400">
            Real-time monitoring of neural brain training and knowledge growth
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-white">
                <BookOpen className="w-5 h-5 text-blue-400" />
                Concepts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-400">
                {network?.concepts_count || 0}
              </div>
              <p className="text-sm text-slate-400 mt-1">Extracted concepts</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-white">
                <Zap className="w-5 h-5 text-yellow-400" />
                Code Patterns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-400">
                {network?.code_blocks_count || 0}
              </div>
              <p className="text-sm text-slate-400 mt-1">Learned patterns</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-white">
                <TrendingUp className="w-5 h-5 text-green-400" />
                Accuracy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-400">
                {metricsQuery.data?.latestAccuracy
                  ? (metricsQuery.data.latestAccuracy * 100).toFixed(1)
                  : 0}
                %
              </div>
              <p className="text-sm text-slate-400 mt-1">Training accuracy</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-white">
                <Brain className="w-5 h-5 text-purple-400" />
                Epoch
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-400">
                {metricsQuery.data?.latestEpoch || 0}
              </div>
              <p className="text-sm text-slate-400 mt-1">Training iterations</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Loss Chart */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Training Loss</CardTitle>
              <CardDescription>Loss trend over epochs</CardDescription>
            </CardHeader>
            <CardContent>
              {metricsData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={metricsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="epoch" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1e293b",
                        border: "1px solid #475569",
                        borderRadius: "8px",
                      }}
                      labelStyle={{ color: "#e2e8f0" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="loss"
                      stroke="#ef4444"
                      dot={false}
                      strokeWidth={2}
                      isAnimationActive={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-80 flex items-center justify-center text-slate-400">
                  <p>No training data yet</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Accuracy Chart */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Model Accuracy</CardTitle>
              <CardDescription>Accuracy trend over epochs</CardDescription>
            </CardHeader>
            <CardContent>
              {metricsData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={metricsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="epoch" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" domain={[0, 100]} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#1e293b",
                        border: "1px solid #475569",
                        borderRadius: "8px",
                      }}
                      labelStyle={{ color: "#e2e8f0" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="accuracy"
                      stroke="#10b981"
                      dot={false}
                      strokeWidth={2}
                      isAnimationActive={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-80 flex items-center justify-center text-slate-400">
                  <p>No training data yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Combined Chart */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Training Progress</CardTitle>
            <CardDescription>Loss and accuracy over time</CardDescription>
          </CardHeader>
          <CardContent>
            {metricsData.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={metricsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="epoch" stroke="#94a3b8" />
                  <YAxis yAxisId="left" stroke="#94a3b8" />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    stroke="#94a3b8"
                    domain={[0, 100]}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                    }}
                    labelStyle={{ color: "#e2e8f0" }}
                  />
                  <Legend />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="loss"
                    stroke="#ef4444"
                    name="Loss"
                    dot={false}
                    strokeWidth={2}
                    isAnimationActive={false}
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="accuracy"
                    stroke="#10b981"
                    name="Accuracy (%)"
                    dot={false}
                    strokeWidth={2}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-96 flex items-center justify-center text-slate-400">
                <p>No training data yet. Upload PDFs to start training the neural brain.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Network Statistics */}
        <Card className="bg-slate-800 border-slate-700 mt-8">
          <CardHeader>
            <CardTitle className="text-white">Network Statistics</CardTitle>
            <CardDescription>Current state of the isomorphic network</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="space-y-2">
                <p className="text-sm text-slate-400">Total Nodes</p>
                <p className="text-2xl font-bold text-blue-400">
                  {network?.total_nodes || 0}
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-slate-400">Relationships</p>
                <p className="text-2xl font-bold text-purple-400">
                  {network?.relationships_count || 0}
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-slate-400">Current Loss</p>
                <p className="text-2xl font-bold text-red-400">
                  {network?.current_loss?.toFixed(4) || "0.0000"}
                </p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-slate-400">Training Epochs</p>
                <p className="text-2xl font-bold text-green-400">
                  {network?.training_epochs || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
