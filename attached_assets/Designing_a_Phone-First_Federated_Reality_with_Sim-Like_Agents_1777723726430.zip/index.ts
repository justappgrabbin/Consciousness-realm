import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { processTick } from "../simulationEngine";
import { getSimulationState } from "../db";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    // Start the server-side simulation scheduler
    startSimulationScheduler();
  });
}

// ─── Server-Side Simulation Scheduler ─────────────────────────────────────────
// Runs the simulation tick loop on the server so the world advances
// even when no client is connected to the Observer page.
let simulationInterval: ReturnType<typeof setInterval> | null = null;

async function startSimulationScheduler() {
  // Initial delay to let the server fully initialize
  await new Promise(resolve => setTimeout(resolve, 3000));

  const runTick = async () => {
    try {
      const state = await getSimulationState();
      if (!state) return; // World not seeded yet
      if (state.paused) return; // Paused by observer

      const intervalMs = state.tickIntervalMs ?? 8000;

      // Reschedule if interval changed
      if (simulationInterval && intervalMs !== currentIntervalMs) {
        clearInterval(simulationInterval);
        simulationInterval = null;
        currentIntervalMs = intervalMs;
        scheduleNext();
        return;
      }

      await processTick();
    } catch (err) {
      console.error("[SimScheduler] Tick error:", err);
    }
  };

  let currentIntervalMs = 8000;

  const scheduleNext = () => {
    simulationInterval = setInterval(runTick, currentIntervalMs);
  };

  scheduleNext();
  console.log("[SimScheduler] Simulation scheduler started (interval:", currentIntervalMs, "ms)");
}

startServer().catch(console.error);
