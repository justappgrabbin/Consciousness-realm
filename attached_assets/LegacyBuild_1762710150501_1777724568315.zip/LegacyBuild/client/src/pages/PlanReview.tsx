import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Sparkles, Zap, Github, ArrowRight, CheckCircle2, Clock } from "lucide-react";
import type { Project, File as FileType } from "@shared/schema";

export default function PlanReview() {
  const [, params] = useRoute("/plan/:id");
  const projectId = params?.id;
  const { toast } = useToast();
  const [selectedMode, setSelectedMode] = useState<"quick" | "creative" | "pusher" | null>(null);

  const { data: project } = useQuery<Project>({
    queryKey: ['/api/projects', projectId],
    enabled: !!projectId,
  });

  const { data: files = [] } = useQuery<FileType[]>({
    queryKey: ['/api/files', projectId],
    enabled: !!projectId,
  });

  const confirmPlanMutation = useMutation({
    mutationFn: async (mode: string) => {
      // First, confirm the plan and save the mode
      await apiRequest('POST', `/api/projects/${projectId}/confirm-plan`, { mode });
      // Then, start the actual processing
      return await apiRequest('POST', `/api/projects/${projectId}/process`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', projectId] });
      toast({
        title: "Processing started",
        description: "Your application is being assembled",
      });
      window.location.href = `/process?id=${projectId}`;
    },
  });

  if (!project || !projectId) {
    return <div className="p-6">Loading...</div>;
  }

  const codeFiles = files.filter(f => 
    f.type.includes('javascript') || 
    f.type.includes('python') || 
    f.type.includes('java') ||
    f.type.includes('text')
  );

  const bookFiles = files.filter(f => f.type.includes('pdf') || f.type.includes('epub'));
  const otherFiles = files.filter(f => !codeFiles.includes(f) && !bookFiles.includes(f));

  const modes = [
    {
      id: "quick",
      name: "Quick Assembler",
      icon: Zap,
      description: "Fast assembly with basic optimization",
      features: [
        "Pattern detection and unification",
        "Basic code analysis",
        "Quick gap filling",
        "Standard output format"
      ],
      estimatedTime: "2-5 minutes",
      color: "text-blue-600",
    },
    {
      id: "creative",
      name: "Creative Assembler",
      icon: Sparkles,
      description: "Experimental AI with advanced features",
      features: [
        "Deep pattern analysis",
        "Creative code suggestions",
        "Architecture improvements",
        "Enhanced documentation",
        "Book reference extraction"
      ],
      estimatedTime: "10-20 minutes",
      color: "text-purple-600",
    },
    {
      id: "pusher",
      name: "Pusher Mode",
      icon: Github,
      description: "Assemble and push to GitHub",
      features: [
        "Quick assembly",
        "GitHub repository creation",
        "Automatic commit & push",
        "README generation"
      ],
      estimatedTime: "5-8 minutes",
      color: "text-green-600",
    },
  ];

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Review Your Plan</h1>
          <p className="text-muted-foreground">
            {project.name} - Choose how to assemble your application
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="p-6 lg:col-span-2">
            <h2 className="text-xl font-semibold mb-4">Project Contents</h2>
            
            <div className="space-y-4">
              {codeFiles.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary">{codeFiles.length}</Badge>
                    <h3 className="font-medium">Code Files</h3>
                  </div>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    {codeFiles.slice(0, 5).map(file => (
                      <div key={file.id} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3 h-3 text-green-600" />
                        {file.name}
                      </div>
                    ))}
                    {codeFiles.length > 5 && (
                      <div className="text-xs">+ {codeFiles.length - 5} more files</div>
                    )}
                  </div>
                </div>
              )}

              {bookFiles.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary">{bookFiles.length}</Badge>
                    <h3 className="font-medium">Books & Documentation</h3>
                  </div>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    {bookFiles.map(file => (
                      <div key={file.id} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3 h-3 text-blue-600" />
                        {file.name}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {otherFiles.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary">{otherFiles.length}</Badge>
                    <h3 className="font-medium">Other Files</h3>
                  </div>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    {otherFiles.map(file => (
                      <div key={file.id} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3 h-3" />
                        {file.name}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Quick Stats</h2>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Files:</span>
                <span className="font-medium">{files.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Code Files:</span>
                <span className="font-medium">{codeFiles.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Books:</span>
                <span className="font-medium">{bookFiles.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Size:</span>
                <span className="font-medium">
                  {(files.reduce((sum, f) => sum + f.size, 0) / 1024 / 1024).toFixed(2)} MB
                </span>
              </div>
            </div>
          </Card>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-4">Choose Assembly Mode</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {modes.map((mode) => (
              <Card
                key={mode.id}
                className={`p-6 cursor-pointer transition-all ${
                  selectedMode === mode.id
                    ? 'ring-2 ring-primary'
                    : 'hover-elevate'
                }`}
                onClick={() => setSelectedMode(mode.id as any)}
                data-testid={`mode-${mode.id}`}
              >
                <div className="flex items-center gap-3 mb-4">
                  <mode.icon className={`w-8 h-8 ${mode.color}`} />
                  <h3 className="text-lg font-semibold">{mode.name}</h3>
                </div>
                
                <p className="text-sm text-muted-foreground mb-4">
                  {mode.description}
                </p>

                <div className="space-y-2 mb-4">
                  {mode.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <CheckCircle2 className="w-3 h-3 text-green-600 flex-shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  {mode.estimatedTime}
                </div>
              </Card>
            ))}
          </div>
        </div>

        {selectedMode && (
          <Card className="p-6 bg-primary/5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold mb-1">Ready to start?</h3>
                <p className="text-sm text-muted-foreground">
                  This will begin the {selectedMode} assembly process
                </p>
              </div>
              <Button
                size="lg"
                onClick={() => confirmPlanMutation.mutate(selectedMode)}
                disabled={confirmPlanMutation.isPending}
                data-testid="button-confirm-plan"
              >
                {confirmPlanMutation.isPending ? "Starting..." : "Start Assembly"}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
