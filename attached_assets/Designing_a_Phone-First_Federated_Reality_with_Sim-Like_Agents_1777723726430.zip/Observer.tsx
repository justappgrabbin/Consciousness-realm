import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { WorldClock } from "@/components/WorldClock";
import { AgentAvatar } from "@/components/AgentAvatar";
import { MoodBadge } from "@/components/MoodBadge";
import { toast } from "sonner";

const SPEED_OPTIONS = [
  { label: "Slow", ms: 15000, icon: "🐢" },
  { label: "Normal", ms: 8000, icon: "🚶" },
  { label: "Fast", ms: 4000, icon: "🏃" },
  { label: "Turbo", ms: 2000, icon: "⚡" },
];

const EVENT_PRESETS: Array<{ title: string; description: string; type: "natural" | "social" | "economic" | "political" | "cultural" | "injected"; effects: { moodDelta?: number; needsDeltas?: Record<string, number> } }> = [
  { title: "Festival of Lights", description: "A dazzling festival erupts across the world, lifting everyone's spirits and bringing communities together.", type: "cultural", effects: { moodDelta: 20, needsDeltas: { fun: 30, social: 25 } } },
  { title: "Economic Boom", description: "A wave of prosperity sweeps through, creating new opportunities and reducing scarcity.", type: "economic", effects: { moodDelta: 15, needsDeltas: { comfort: 20 } } },
  { title: "Mysterious Blackout", description: "All power goes dark. Agents must adapt to the sudden disruption.", type: "natural", effects: { moodDelta: -15, needsDeltas: { comfort: -25, fun: -15 } } },
  { title: "Epidemic of Loneliness", description: "A strange social malaise spreads, making everyone feel disconnected.", type: "social", effects: { moodDelta: -10, needsDeltas: { social: -30 } } },
  { title: "Grand Feast", description: "A communal feast is declared. Food is abundant and free for all.", type: "cultural", effects: { needsDeltas: { hunger: 50, social: 20, fun: 15 } } },
  { title: "Heatwave", description: "Scorching temperatures make outdoor activities exhausting.", type: "natural", effects: { moodDelta: -8, needsDeltas: { energy: -20, comfort: -15 } } },
];

function StatCard({ label, value, icon, color }: { label: string; value: string | number; icon: string; color?: string }) {
  return (
    <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
      <div className="flex items-center gap-2 mb-1">
        <span className="text-lg">{icon}</span>
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <div className={cn("text-2xl font-bold", color ?? "text-foreground")} style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
        {value}
      </div>
    </div>
  );
}

export default function Observer() {
  const [, navigate] = useLocation();
  const [tickSpeed, setTickSpeed] = useState(8000);
  const [isRunning, setIsRunning] = useState(false);
  const [showEventForm, setShowEventForm] = useState(false);
  const [customEvent, setCustomEvent] = useState({ title: "", description: "", type: "social" as const });
  const tickIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const utils = trpc.useUtils();

  const { data: worldState, refetch: refetchState } = trpc.world.state.useQuery(undefined, {
    refetchInterval: 3000,
  });

  const { data: agents = [] } = trpc.agents.list.useQuery(undefined, {
    refetchInterval: 5000,
  });

  const { data: districts = [] } = trpc.world.districts.useQuery();
  const { data: recentEvents = [] } = trpc.world.recentEvents.useQuery(undefined, {
    refetchInterval: 5000,
  });

  const seedMutation = trpc.world.seed.useMutation({
    onSuccess: (data) => {
      if (data.seeded) {
        toast.success(`World seeded! ${data.message}`);
        utils.agents.list.invalidate();
        utils.world.districts.invalidate();
      } else {
        toast.info("World already populated");
      }
    },
    onError: () => toast.error("Failed to seed world"),
  });

  const pauseMutation = trpc.world.pause.useMutation({
    onSuccess: () => { refetchState(); toast.success("Simulation paused"); },
  });

  const resumeMutation = trpc.world.resume.useMutation({
    onSuccess: () => { refetchState(); toast.success("Simulation resumed"); },
  });

  const tickMutation = trpc.world.tick.useMutation({
    onSuccess: () => {
      utils.agents.list.invalidate();
      utils.feed.global.invalidate();
    },
  });

  const setSpeedMutation = trpc.world.setTickSpeed.useMutation();

  const injectEventMutation = trpc.world.injectEvent.useMutation({
    onSuccess: () => {
      toast.success("World event injected!");
      setShowEventForm(false);
      setCustomEvent({ title: "", description: "", type: "social" });
      utils.feed.global.invalidate();
      utils.world.recentEvents.invalidate();
    },
    onError: () => toast.error("Failed to inject event"),
  });

  // Auto-tick loop
  useEffect(() => {
    if (isRunning && !worldState?.paused) {
      tickIntervalRef.current = setInterval(() => {
        tickMutation.mutate();
      }, tickSpeed);
    }
    return () => {
      if (tickIntervalRef.current) clearInterval(tickIntervalRef.current);
    };
  }, [isRunning, tickSpeed, worldState?.paused]);

  const handleToggleSimulation = () => {
    if (worldState?.paused) {
      resumeMutation.mutate();
      setIsRunning(true);
    } else {
      pauseMutation.mutate();
      setIsRunning(false);
    }
  };

  const handleSpeedChange = (ms: number) => {
    setTickSpeed(ms);
    setSpeedMutation.mutate({ intervalMs: ms });
    if (tickIntervalRef.current) {
      clearInterval(tickIntervalRef.current);
      if (isRunning && !worldState?.paused) {
        tickIntervalRef.current = setInterval(() => tickMutation.mutate(), ms);
      }
    }
  };

  const handleManualTick = () => {
    tickMutation.mutate();
    toast.success("Manual tick processed");
  };

  const handleInjectPreset = (preset: typeof EVENT_PRESETS[0]) => {
    injectEventMutation.mutate({
      title: preset.title,
      description: preset.description,
      type: preset.type,
      effects: preset.effects,
    });
  };

  const handleInjectCustom = () => {
    if (!customEvent.title || !customEvent.description) {
      toast.error("Please fill in title and description");
      return;
    }
    injectEventMutation.mutate({
      title: customEvent.title,
      description: customEvent.description,
      type: customEvent.type,
    });
  };

  const moodCounts = agents.reduce((acc: Record<string, number>, _) => acc, {});
  const activeAgents = agents.filter(a => a.currentActivity !== "sleeping" && a.currentActivity !== "idle").length;

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-20 px-4 pt-12 pb-3"
        style={{ background: "oklch(0.08 0.01 260 / 0.95)", backdropFilter: "blur(20px)" }}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Observer
            </h1>
            <p className="text-xs text-muted-foreground">World control panel</p>
          </div>
          {worldState && (
            <WorldClock
              worldHour={worldState.worldHour}
              worldDay={worldState.worldDay}
              tick={worldState.tick}
              paused={worldState.paused}
              compact
            />
          )}
        </div>
      </div>

      <div className="flex-1 px-3 pb-24 pt-2 space-y-4">
        {/* Seed world if empty */}
        {agents.length === 0 && (
          <div className="rounded-2xl p-6 border border-primary/30 text-center"
            style={{ background: "oklch(0.12 0.02 280 / 0.5)" }}>
            <div className="text-5xl mb-3">🌱</div>
            <h3 className="font-bold text-foreground mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              The World is Empty
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Seed the world to populate it with {5} districts and {15} unique AI agents, each with their own personality, backstory, and goals.
            </p>
            <button
              onClick={() => seedMutation.mutate()}
              disabled={seedMutation.isPending}
              className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm disabled:opacity-50"
            >
              {seedMutation.isPending ? "Seeding world..." : "🌍 Seed the World"}
            </button>
          </div>
        )}

        {/* Simulation controls */}
        {agents.length > 0 && (
          <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Simulation Controls</h3>

            {/* Play/Pause */}
            <div className="flex gap-2 mb-3">
              <button
                onClick={handleToggleSimulation}
                disabled={pauseMutation.isPending || resumeMutation.isPending}
                className={cn(
                  "flex-1 py-3 rounded-xl font-semibold text-sm transition-all",
                  worldState?.paused
                    ? "bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30"
                    : "bg-amber-500/20 text-amber-400 border border-amber-500/30 hover:bg-amber-500/30"
                )}
              >
                {worldState?.paused ? "▶ Resume Simulation" : "⏸ Pause Simulation"}
              </button>
              <button
                onClick={handleManualTick}
                disabled={tickMutation.isPending}
                className="px-4 py-3 rounded-xl bg-secondary text-muted-foreground hover:text-foreground border border-border/40 text-sm font-medium"
              >
                ⏭ Tick
              </button>
            </div>

            {/* Speed control */}
            <div>
              <p className="text-xs text-muted-foreground mb-2">Tick Speed</p>
              <div className="grid grid-cols-4 gap-1.5">
                {SPEED_OPTIONS.map(opt => (
                  <button
                    key={opt.ms}
                    onClick={() => handleSpeedChange(opt.ms)}
                    className={cn(
                      "py-2 rounded-xl text-xs font-medium transition-all",
                      tickSpeed === opt.ms
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {opt.icon} {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* World stats */}
        {agents.length > 0 && (
          <div className="grid grid-cols-2 gap-2">
            <StatCard label="Total Agents" value={agents.length} icon="👥" />
            <StatCard label="Active Now" value={activeAgents} icon="⚡" color="text-green-400" />
            <StatCard label="Districts" value={districts.length} icon="🏙️" />
            <StatCard label="World Day" value={worldState?.worldDay ?? 1} icon="📅" color="text-primary" />
          </div>
        )}

        {/* District breakdown */}
        {districts.length > 0 && (
          <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Districts</h3>
            <div className="space-y-2">
              {districts.map(d => {
                const fillPct = d.population / Math.max(1, d.maxPopulation);
                return (
                  <div key={d.id} className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ background: d.color }} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-foreground truncate">{d.name}</span>
                        <span className="text-xs text-muted-foreground shrink-0">{d.population}/{d.maxPopulation}</span>
                      </div>
                      <div className="h-1 rounded-full overflow-hidden" style={{ background: "oklch(0.2 0.01 260)" }}>
                        <div className="h-full rounded-full transition-all" style={{ width: `${fillPct * 100}%`, background: d.color }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* World Event Injection */}
        {agents.length > 0 && (
          <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Inject World Event</h3>
              <button
                onClick={() => setShowEventForm(!showEventForm)}
                className="text-xs text-primary hover:text-primary/80"
              >
                {showEventForm ? "Use presets" : "Custom event"}
              </button>
            </div>

            {showEventForm ? (
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Event title..."
                  value={customEvent.title}
                  onChange={e => setCustomEvent(p => ({ ...p, title: e.target.value }))}
                  className="w-full rounded-xl px-3 py-2.5 text-sm bg-secondary border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/50"
                />
                <textarea
                  placeholder="Describe what happens in the world..."
                  value={customEvent.description}
                  onChange={e => setCustomEvent(p => ({ ...p, description: e.target.value }))}
                  rows={3}
                  className="w-full rounded-xl px-3 py-2.5 text-sm bg-secondary border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 resize-none"
                />
                <select
                  value={customEvent.type}
                  onChange={e => setCustomEvent(p => ({ ...p, type: e.target.value as any }))}
                  className="w-full rounded-xl px-3 py-2.5 text-sm bg-secondary border border-border/40 text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50"
                >
                  {["natural", "social", "economic", "political", "cultural"].map(t => (
                    <option key={t} value={t} className="bg-background capitalize">{t}</option>
                  ))}
                </select>
                <button
                  onClick={handleInjectCustom}
                  disabled={injectEventMutation.isPending}
                  className="w-full py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-semibold disabled:opacity-50"
                >
                  {injectEventMutation.isPending ? "Injecting..." : "🌍 Inject Event"}
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {EVENT_PRESETS.map(preset => (
                  <button
                    key={preset.title}
                    onClick={() => handleInjectPreset(preset)}
                    disabled={injectEventMutation.isPending}
                    className="rounded-xl p-3 text-left border border-border/40 hover:border-primary/40 transition-all active:scale-[0.97] disabled:opacity-50"
                    style={{ background: "oklch(0.17 0.015 260)" }}
                  >
                    <p className="text-xs font-semibold text-foreground mb-1">{preset.title}</p>
                    <p className="text-[10px] text-muted-foreground line-clamp-2">{preset.description}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Recent world events */}
        {recentEvents.length > 0 && (
          <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Recent World Events</h3>
            <div className="space-y-2">
              {recentEvents.map((e: any) => (
                <div key={e.id} className="flex items-start gap-2">
                  <span className="text-base shrink-0">🌍</span>
                  <div>
                    <p className="text-xs font-medium text-foreground">{e.title}</p>
                    <p className="text-[10px] text-muted-foreground">{e.description}</p>
                    <p className="text-[10px] text-muted-foreground/60 mt-0.5">Day {e.worldDay} · {e.resolved ? "Resolved" : "Active"}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Agent quick overview */}
        {agents.length > 0 && (
          <div className="rounded-2xl p-4 border border-border/40" style={{ background: "oklch(0.12 0.012 260)" }}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">All Agents</h3>
              <button onClick={() => navigate("/agents")} className="text-xs text-primary">View all →</button>
            </div>
            <div className="space-y-2">
              {agents.slice(0, 8).map(agent => (
                <button
                  key={agent.id}
                  onClick={() => navigate(`/agents/${agent.id}`)}
                  className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-secondary/50 transition-colors text-left"
                >
                  <AgentAvatar seed={agent.avatarSeed} name={agent.name} size="xs" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{agent.name}</p>
                    <p className="text-[10px] text-muted-foreground capitalize">{agent.currentActivity}</p>
                  </div>
                  <span className="text-xs text-muted-foreground shrink-0">{agent.job.split(" ")[0]}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
