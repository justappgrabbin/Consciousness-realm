import { describe, it, expect } from "vitest";
import {
  applyNeedsDecay,
  applyActivityToNeeds,
  calculateMoodScore,
  getMoodLabel,
  getDominantEmotion,
  selectActivityByNeeds,
  evolveRelationship,
  applyWorldEventToNeeds,
  WORLD_HOURS_PER_TICK,
} from "./worldRules";
import type { AgentNeeds } from "../drizzle/schema";

// ─── Helpers ───────────────────────────────────────────────────────────────────
function makeNeeds(overrides: Partial<AgentNeeds> = {}): AgentNeeds {
  return {
    id: 1,
    agentId: 1,
    hunger: 80,
    energy: 80,
    social: 70,
    fun: 70,
    hygiene: 80,
    comfort: 75,
    updatedAt: new Date(),
    ...overrides,
  };
}

const defaultPersonality = {
  openness: 0.7,
  conscientiousness: 0.7,
  extraversion: 0.5,
  agreeableness: 0.7,
  neuroticism: 0.4,
  traits: ["curious"],
};

const defaultDistrict = {
  id: 1,
  name: "Test District",
  description: "Test",
  theme: "urban",
  x: 50, y: 50,
  population: 5,
  maxPopulation: 20,
  resourceLevel: 1.0,
  socialNormStrictness: 0.5,
  rules: {},
  color: "#6366f1",
  createdAt: new Date(),
  updatedAt: new Date(),
};

// ─── Needs Decay ───────────────────────────────────────────────────────────────
describe("applyNeedsDecay", () => {
  it("decreases needs over time", () => {
    const needs = makeNeeds({ hunger: 80, energy: 80 });
    const decayed = applyNeedsDecay(needs, 1.0);
    expect(decayed.hunger).toBeLessThan(80);
    expect(decayed.energy).toBeLessThan(80);
  });

  it("clamps needs to 0 minimum", () => {
    const needs = makeNeeds({ hunger: 0, energy: 0, social: 0, fun: 0, hygiene: 0, comfort: 0 });
    const decayed = applyNeedsDecay(needs, 1.0);
    expect(decayed.hunger).toBeGreaterThanOrEqual(0);
    expect(decayed.energy).toBeGreaterThanOrEqual(0);
  });

  it("decays faster with lower resource level", () => {
    const needs = makeNeeds({ hunger: 80 });
    const highResource = applyNeedsDecay(needs, 1.0);
    const lowResource = applyNeedsDecay(needs, 0.3);
    expect(lowResource.hunger!).toBeLessThan(highResource.hunger!);
  });
});

// ─── Activity Effects ──────────────────────────────────────────────────────────
describe("applyActivityToNeeds", () => {
  it("eating increases hunger", () => {
    const needs = makeNeeds({ hunger: 30 });
    const result = applyActivityToNeeds(needs, "eating");
    expect(result.hunger).toBeGreaterThan(30);
  });

  it("sleeping increases energy", () => {
    const needs = makeNeeds({ energy: 20 });
    const result = applyActivityToNeeds(needs, "sleeping");
    expect(result.energy).toBeGreaterThan(20);
  });

  it("socializing increases social need", () => {
    const needs = makeNeeds({ social: 30 });
    const result = applyActivityToNeeds(needs, "socializing");
    expect(result.social).toBeGreaterThan(30);
  });

  it("clamps values to 100 maximum", () => {
    const needs = makeNeeds({ energy: 99 });
    const result = applyActivityToNeeds(needs, "sleeping");
    expect(result.energy).toBeLessThanOrEqual(100);
  });
});

// ─── Mood Calculation ──────────────────────────────────────────────────────────
describe("calculateMoodScore", () => {
  it("returns high score for high needs", () => {
    const needs = makeNeeds({ hunger: 90, energy: 90, social: 90, fun: 90, hygiene: 90, comfort: 90 });
    const score = calculateMoodScore(needs);
    expect(score).toBeGreaterThan(70);
  });

  it("returns low score for low needs", () => {
    const needs = makeNeeds({ hunger: 5, energy: 5, social: 5, fun: 5, hygiene: 5, comfort: 5 });
    const score = calculateMoodScore(needs);
    expect(score).toBeLessThan(30);
  });

  it("returns value between 0 and 100", () => {
    const needs = makeNeeds();
    const score = calculateMoodScore(needs);
    expect(score).toBeGreaterThanOrEqual(0);
    expect(score).toBeLessThanOrEqual(100);
  });
});

// ─── Mood Labels ───────────────────────────────────────────────────────────────
describe("getMoodLabel", () => {
  it("returns ecstatic for very high scores", () => {
    expect(getMoodLabel(95)).toBe("ecstatic");
  });

  it("returns happy for high scores", () => {
    expect(getMoodLabel(80)).toBe("happy");
  });

  it("returns sad for low scores", () => {
    expect(getMoodLabel(25)).toBe("sad");
  });

  it("returns distressed for very low scores", () => {
    expect(getMoodLabel(10)).toBe("distressed");
  });
});

// ─── Activity Selection ────────────────────────────────────────────────────────
describe("selectActivityByNeeds", () => {
  it("selects sleeping when energy is critically low at night", () => {
    const needs = makeNeeds({ energy: 5 });
    const result = selectActivityByNeeds(needs, 23, defaultPersonality, defaultDistrict as any);
    expect(result.activity).toBe("sleeping");
  });

  it("selects eating when hunger is critically low", () => {
    const needs = makeNeeds({ hunger: 5, energy: 70 });
    const result = selectActivityByNeeds(needs, 12, defaultPersonality, defaultDistrict as any);
    expect(result.activity).toBe("eating");
  });

  it("returns an activity and location", () => {
    const needs = makeNeeds();
    const result = selectActivityByNeeds(needs, 14, defaultPersonality, defaultDistrict as any);
    expect(result.activity).toBeTruthy();
    expect(result.location).toBeTruthy();
    expect(result.reason).toBeTruthy();
  });
});

// ─── Relationship Evolution ────────────────────────────────────────────────────
describe("evolveRelationship", () => {
  it("increases strength with positive interactions", () => {
    const result = evolveRelationship(0.2, 0.5, 0.9, 5);
    expect(result.strength).toBeGreaterThan(0.2);
  });

  it("decreases sentiment with negative interactions", () => {
    const result = evolveRelationship(0.5, 0.7, 0.1, 10);
    expect(result.sentiment).toBeLessThan(0.7);
  });

  it("upgrades to friend after many positive interactions", () => {
    const result = evolveRelationship(0.8, 0.85, 0.9, 20);
    expect(["friend", "romantic"]).toContain(result.type);
  });

  it("returns valid relationship type", () => {
    const validTypes = ["friend", "rival", "romantic", "colleague", "acquaintance", "family", "enemy"];
    const result = evolveRelationship(0.3, 0.5, 0.6, 3);
    expect(validTypes).toContain(result.type);
  });
});

// ─── World Event Effects ───────────────────────────────────────────────────────
describe("applyWorldEventToNeeds", () => {
  it("applies positive mood delta to needs", () => {
    const needs = makeNeeds({ fun: 50 });
    const effects = { moodDelta: 20, needsDeltas: { fun: 15 } };
    const result = applyWorldEventToNeeds(needs, effects);
    expect(result.fun).toBeGreaterThan(50);
  });

  it("applies negative needs deltas", () => {
    const needs = makeNeeds({ energy: 80 });
    const effects = { needsDeltas: { energy: -20 } };
    const result = applyWorldEventToNeeds(needs, effects);
    expect(result.energy).toBeLessThan(80);
  });

  it("clamps values within 0-100", () => {
    const needs = makeNeeds({ fun: 95 });
    const effects = { needsDeltas: { fun: 50 } };
    const result = applyWorldEventToNeeds(needs, effects);
    expect(result.fun).toBeLessThanOrEqual(100);
  });
});

// ─── World Clock ───────────────────────────────────────────────────────────────
describe("WORLD_HOURS_PER_TICK", () => {
  it("is a positive number", () => {
    expect(WORLD_HOURS_PER_TICK).toBeGreaterThan(0);
  });

  it("represents less than a full day per tick", () => {
    expect(WORLD_HOURS_PER_TICK).toBeLessThan(24);
  });
});
