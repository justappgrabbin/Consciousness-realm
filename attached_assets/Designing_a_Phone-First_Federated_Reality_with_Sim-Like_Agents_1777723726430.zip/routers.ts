import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  getAllAgents, getAgentById, getAllDistricts, getDistrictById,
  getSimulationState, upsertSimulationState, getActivityFeed, getAgentFeed,
  getAgentNeeds, getAgentMood, getAgentMemories, getAgentRelationships,
  getAgentTasks, getRecentConversations, getAgentConversations,
  getRecentWorldEvents, createWorldEvent, addFeedEvent,
  updateAgent,
} from "./db";
import { processTick } from "./simulationEngine";
import { seedWorld } from "./worldSeeder";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── World ───────────────────────────────────────────────────────────────────
  world: router({
    state: publicProcedure.query(async () => {
      return getSimulationState();
    }),

    districts: publicProcedure.query(async () => {
      return getAllDistricts();
    }),

    district: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getDistrictById(input.id);
      }),

    seed: publicProcedure.mutation(async () => {
      return seedWorld();
    }),

    pause: publicProcedure.mutation(async () => {
      await upsertSimulationState({ paused: true });
      return { paused: true };
    }),

    resume: publicProcedure.mutation(async () => {
      await upsertSimulationState({ paused: false });
      return { paused: false };
    }),

    tick: publicProcedure.mutation(async () => {
      return processTick();
    }),

    setTickSpeed: publicProcedure
      .input(z.object({ intervalMs: z.number().min(2000).max(30000) }))
      .mutation(async ({ input }) => {
        await upsertSimulationState({ tickIntervalMs: input.intervalMs });
        return { intervalMs: input.intervalMs };
      }),

    injectEvent: publicProcedure
      .input(z.object({
        title: z.string(),
        description: z.string(),
        type: z.enum(["natural", "social", "economic", "political", "cultural", "injected"]),
        districtId: z.number().optional(),
        effects: z.object({
          moodDelta: z.number().optional(),
          needsDeltas: z.record(z.string(), z.number()).optional(),
          resourceDelta: z.number().optional(),
        }).optional(),
      }))
      .mutation(async ({ input }) => {
        const state = await getSimulationState();
        const tick = state?.tick ?? 0;
        const worldDay = state?.worldDay ?? 1;
        const worldHour = state?.worldHour ?? 12;

        await createWorldEvent({
          title: input.title,
          description: input.description,
          type: input.type,
          districtId: input.districtId ?? null,
          affectedAgentIds: [],
          effects: input.effects ?? {},
          tick,
          worldDay,
          resolved: false,
        });

        await addFeedEvent({
          tick,
          worldDay,
          worldHour,
          agentId: null,
          districtId: input.districtId ?? null,
          type: "world_event",
          title: `🌍 ${input.title}`,
          content: input.description,
          emoji: "🌍",
          importance: 0.9,
        });

        return { success: true };
      }),

    recentEvents: publicProcedure.query(async () => {
      return getRecentWorldEvents(10);
    }),
  }),

  // ─── Agents ──────────────────────────────────────────────────────────────────
  agents: router({
    list: publicProcedure.query(async () => {
      return getAllAgents();
    }),

    get: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getAgentById(input.id);
      }),

    profile: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const [agent, needs, mood, memories, rawRelationships, tasks, rawConversations] = await Promise.all([
          getAgentById(input.id),
          getAgentNeeds(input.id),
          getAgentMood(input.id),
          getAgentMemories(input.id, 30),
          getAgentRelationships(input.id),
          getAgentTasks(input.id),
          getAgentConversations(input.id, 5),
        ]);
        const allAgents = await getAllAgents();
        const relationships = rawRelationships.map(r => {
          const otherId = r.agentAId === input.id ? r.agentBId : r.agentAId;
          const other = allAgents.find(a => a.id === otherId);
          return { ...r, otherAgent: other ?? null };
        });
        const conversations = rawConversations.map(c => {
          const otherId = c.agentAId === input.id ? c.agentBId : c.agentAId;
          const other = allAgents.find(a => a.id === otherId);
          return { ...c, otherAgent: other ?? null };
        });
        return { agent, needs, mood, memories, relationships, tasks, conversations };
      }),

    needs: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getAgentNeeds(input.id);
      }),

    mood: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getAgentMood(input.id);
      }),

    memories: publicProcedure
      .input(z.object({ id: z.number(), limit: z.number().optional() }))
      .query(async ({ input }) => {
        return getAgentMemories(input.id, input.limit ?? 20);
      }),

    relationships: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const rels = await getAgentRelationships(input.id);
        const allAgents = await getAllAgents();
        return rels.map(r => {
          const otherId = r.agentAId === input.id ? r.agentBId : r.agentAId;
          const other = allAgents.find(a => a.id === otherId);
          return { ...r, otherAgent: other ?? null };
        });
      }),

    tasks: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getAgentTasks(input.id);
      }),

    conversations: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const convos = await getAgentConversations(input.id, 10);
        const allAgents = await getAllAgents();
        return convos.map(c => {
          const otherId = c.agentAId === input.id ? c.agentBId : c.agentAId;
          const other = allAgents.find(a => a.id === otherId);
          return { ...c, otherAgent: other ?? null };
        });
      }),

    feed: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getAgentFeed(input.id, 20);
      }),
  }),

  // ─── Feed ─────────────────────────────────────────────────────────────────────
  feed: router({
    global: publicProcedure
      .input(z.object({ limit: z.number().optional() }))
      .query(async ({ input }) => {
        const feed = await getActivityFeed(input.limit ?? 50);
        const allAgents = await getAllAgents();
        const allDistricts = await getAllDistricts();
        return feed.map(item => ({
          ...item,
          agent: item.agentId ? allAgents.find(a => a.id === item.agentId) ?? null : null,
          district: item.districtId ? allDistricts.find(d => d.id === item.districtId) ?? null : null,
        }));
      }),

    conversations: publicProcedure.query(async () => {
      const convos = await getRecentConversations(10);
      const allAgents = await getAllAgents();
      return convos.map(c => ({
        ...c,
        agentA: allAgents.find(a => a.id === c.agentAId) ?? null,
        agentB: allAgents.find(a => a.id === c.agentBId) ?? null,
      }));
    }),
  }),
});

export type AppRouter = typeof appRouter;
