import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  filename: varchar("filename", { length: 255 }).notNull(),
  filePath: varchar("filePath", { length: 500 }),
  ingestionStatus: mysqlEnum("ingestionStatus", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

export const concepts = mysqlTable("concepts", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }),
  sourceDocId: int("sourceDocId"),
  embedding: text("embedding"), // JSON string of embedding vector
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Concept = typeof concepts.$inferSelect;
export type InsertConcept = typeof concepts.$inferInsert;

export const codeBlocks = mysqlTable("codeBlocks", {
  id: int("id").autoincrement().primaryKey(),
  language: varchar("language", { length: 50 }),
  code: text("code").notNull(),
  description: text("description"),
  sourceDocId: int("sourceDocId"),
  embedding: text("embedding"), // JSON string of embedding vector
  patternType: varchar("patternType", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CodeBlock = typeof codeBlocks.$inferSelect;
export type InsertCodeBlock = typeof codeBlocks.$inferInsert;

export const relationships = mysqlTable("relationships", {
  id: int("id").autoincrement().primaryKey(),
  sourceId: int("sourceId").notNull(),
  sourceType: mysqlEnum("sourceType", ["concept", "code_block"]).notNull(),
  targetId: int("targetId").notNull(),
  targetType: mysqlEnum("targetType", ["concept", "code_block"]).notNull(),
  relationshipType: varchar("relationshipType", { length: 100 }),
  confidence: text("confidence"), // Stored as string to preserve precision
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Relationship = typeof relationships.$inferSelect;
export type InsertRelationship = typeof relationships.$inferInsert;

export const trainingMetrics = mysqlTable("trainingMetrics", {
  id: int("id").autoincrement().primaryKey(),
  epoch: int("epoch").notNull(),
  loss: text("loss").notNull(), // Stored as string for precision
  accuracy: text("accuracy").notNull(),
  conceptsCount: int("conceptsCount"),
  codeBlocksCount: int("codeBlocksCount"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TrainingMetric = typeof trainingMetrics.$inferSelect;
export type InsertTrainingMetric = typeof trainingMetrics.$inferInsert;