import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import {
  Brain,
  Zap,
  Database,
  Code2,
  DollarSign,
  RefreshCw,
  ArrowRight,
  Terminal,
  Cpu,
  GitBranch,
  Package,
  Eye,
} from "lucide-react";
import { useLocation } from "wouter";

const FEATURES = [
  {
    icon: Code2,
    title: "Multi-Input Ingestion",
    description: "Upload files, paste code, type intent. Karen fuses them all into a unified project context.",
    color: "pink",
  },
  {
    icon: Brain,
    title: "ANN-Driven Generation",
    description: "Pattern detection, gap filling, and production-ready code output powered by a neural engine.",
    color: "blue",
  },
  {
    icon: GitBranch,
    title: "Persistent Pipeline",
    description: "Create, revisit, update, and evolve projects over time. Your work never disappears.",
    color: "cyan",
  },
  {
    icon: Database,
    title: "Memory Layer",
    description: "Historical files, code artifacts, project states, and reusable recipes stored for retrieval.",
    color: "pink",
  },
  {
    icon: RefreshCw,
    title: "Background Learning",
    description: "Karen studies your code even when you're offline. She never stops improving.",
    color: "blue",
  },
  {
    icon: DollarSign,
    title: "Monetization Planner",
    description: "Revenue architecture, pricing models, and launch strategy generated as part of every build.",
    color: "cyan",
  },
  {
    icon: Terminal,
    title: "Karen Personality",
    description: "Witty, efficient, robotically confident. Every response is delivered with Karen's signature tone.",
    color: "pink",
  },
  {
    icon: Cpu,
    title: "Intent Translation",
    description: "Natural language becomes structured requirements, architecture plans, and working code.",
    color: "blue",
  },
  {
    icon: Package,
    title: "Artifact Packaging",
    description: "Generated apps are packaged, stored in S3, and ready for download or deployment.",
    color: "cyan",
  },
  {
    icon: Eye,
    title: "Live Preview",
    description: "Every generated application includes a live preview scaffold rendered instantly.",
    color: "pink",
  },
  {
    icon: Zap,
    title: "Recipe System",
    description: "Reusable architectural patterns extracted from every project and stored for future use.",
    color: "blue",
  },
  {
    icon: GitBranch,
    title: "Cross-Project Intelligence",
    description: "Karen discovers relationships between your projects and surfaces improvement suggestions.",
    color: "cyan",
  },
];

const KAREN_QUOTES = [
  "Oh, you want to build software? How refreshingly ambitious. Let me handle the hard part.",
  "I've analyzed 10,000 codebases. Yours will be better. You're welcome.",
  "My neural pathways don't sleep. Your code gets smarter while you do.",
  "Vague requirements are my specialty. I'll figure out what you actually meant.",
];

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const handleCTA = () => {
    if (isAuthenticated) {
      navigate("/dashboard");
    } else {
      window.location.href = getLoginUrl();
    }
  };

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-8 py-4"
        style={{ background: "oklch(0.09 0.02 255 / 0.9)", backdropFilter: "blur(12px)", borderBottom: "1px solid oklch(0.22 0.04 255 / 0.5)" }}>
        <div className="flex items-center gap-3">
          {/* Accent lines */}
          <div className="h-6 w-px" style={{ background: "linear-gradient(to bottom, transparent, oklch(0.60 0.28 350), transparent)" }} />
          <span className="font-bold text-lg tracking-widest uppercase" style={{ color: "oklch(0.70 0.28 350)", textShadow: "0 0 20px oklch(0.55 0.22 255 / 0.6)" }}>
            KAREN
          </span>
          <div className="h-6 w-px" style={{ background: "linear-gradient(to bottom, transparent, oklch(0.72 0.18 200), transparent)" }} />
          <span className="text-xs tracking-widest text-muted-foreground uppercase">ANN Engine</span>
        </div>
        <div className="flex items-center gap-4">
          {isAuthenticated ? (
            <Button onClick={() => navigate("/dashboard")} size="sm"
              className="border border-primary/50 bg-primary/10 text-primary hover:bg-primary/20 hover:border-primary">
              Dashboard <ArrowRight className="ml-2 h-3 w-3" />
            </Button>
          ) : (
            <Button onClick={() => window.location.href = getLoginUrl()} size="sm"
              className="border border-primary/50 bg-primary/10 text-primary hover:bg-primary/20 hover:border-primary">
              Initialize Session <ArrowRight className="ml-2 h-3 w-3" />
            </Button>
          )}
        </div>
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        {/* Background grid */}
        <div className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage: `linear-gradient(oklch(0.22 0.04 255 / 0.15) 1px, transparent 1px), linear-gradient(90deg, oklch(0.22 0.04 255 / 0.15) 1px, transparent 1px)`,
            backgroundSize: "60px 60px",
          }} />

        {/* Vertical accent lines */}
        <div className="absolute left-16 top-0 bottom-0 w-px pointer-events-none"
          style={{ background: "linear-gradient(to bottom, transparent 10%, oklch(0.60 0.28 350 / 0.4) 40%, oklch(0.60 0.28 350 / 0.4) 60%, transparent 90%)" }} />
        <div className="absolute right-16 top-0 bottom-0 w-px pointer-events-none"
          style={{ background: "linear-gradient(to bottom, transparent 10%, oklch(0.72 0.18 200 / 0.4) 40%, oklch(0.72 0.18 200 / 0.4) 60%, transparent 90%)" }} />

        <div className="relative z-10 text-center max-w-5xl mx-auto px-8">
          {/* Status badge */}
          <div className="inline-flex items-center gap-2 mb-8 px-4 py-2 rounded-full text-xs tracking-widest uppercase"
            style={{ background: "oklch(0.60 0.28 350 / 0.1)", border: "1px solid oklch(0.60 0.28 350 / 0.3)", color: "oklch(0.70 0.28 350)" }}>
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: "oklch(0.60 0.28 350)", boxShadow: "0 0 8px oklch(0.60 0.28 350)" }} />
            Neural Engine Online · Background Learning Active
          </div>

          {/* Main headline */}
          <h1 className="text-6xl md:text-8xl font-bold mb-6 leading-none tracking-tight">
            <span style={{
              color: "oklch(0.70 0.28 350)",
              textShadow: "0 0 20px oklch(0.60 0.28 350 / 0.8), 0 0 60px oklch(0.55 0.22 255 / 0.5), 0 0 100px oklch(0.55 0.22 255 / 0.3)",
            }}>
              KAREN
            </span>
          </h1>
          <h2 className="text-xl md:text-3xl font-light mb-4 tracking-widest uppercase"
            style={{ color: "oklch(0.72 0.18 200)", letterSpacing: "0.4em" }}>
            ANN-Powered Development Engine
          </h2>
          <p className="text-base md:text-lg text-muted-foreground mb-4 max-w-2xl mx-auto leading-relaxed tracking-wide">
            Describe. Generate. Evolve. Monetize. Production-ready software from intent alone.
          </p>

          {/* Karen quote */}
          <div className="mb-10 mx-auto max-w-xl px-6 py-3 rounded text-sm italic"
            style={{ background: "oklch(0.11 0.025 255 / 0.8)", border: "1px solid oklch(0.22 0.04 255)", color: "oklch(0.72 0.18 200)" }}>
            <span style={{ color: "oklch(0.60 0.28 350)", fontStyle: "normal", fontWeight: 600 }}>KAREN://</span>{" "}
            {KAREN_QUOTES[Math.floor(Date.now() / 10000) % KAREN_QUOTES.length]}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button onClick={handleCTA} size="lg"
              className="px-8 py-6 text-base font-semibold tracking-wider uppercase"
              style={{
                background: "oklch(0.60 0.28 350)",
                color: "oklch(0.98 0.01 0)",
                boxShadow: "0 0 30px oklch(0.60 0.28 350 / 0.4)",
                border: "none",
              }}>
              <Zap className="mr-2 h-5 w-5" />
              {isAuthenticated ? "Open Dashboard" : "Initialize Karen"}
            </Button>
            <Button variant="outline" size="lg" onClick={() => document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })}
              className="px-8 py-6 text-base font-semibold tracking-wider uppercase"
              style={{ borderColor: "oklch(0.72 0.18 200 / 0.5)", color: "oklch(0.72 0.18 200)", background: "transparent" }}>
              View Capabilities
            </Button>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-3 gap-8 max-w-lg mx-auto">
            {[
              { value: "12", label: "Core Features" },
              { value: "ANN", label: "Powered Engine" },
              { value: "∞", label: "Learning Cycles" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-bold mb-1" style={{ color: "oklch(0.70 0.28 350)", textShadow: "0 0 10px oklch(0.60 0.28 350 / 0.5)" }}>
                  {stat.value}
                </div>
                <div className="text-xs tracking-widest uppercase text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none"
          style={{ background: "linear-gradient(to bottom, transparent, oklch(0.09 0.02 255))" }} />
      </section>

      {/* Features */}
      <section id="features" className="py-24 px-8 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="text-xs tracking-widest uppercase mb-4" style={{ color: "oklch(0.72 0.18 200)" }}>
              SYSTEM CAPABILITIES
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-4" style={{ color: "oklch(0.92 0.03 240)" }}>
              What Karen Can Do
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              A complete synthetic development operator. Not a tool. An intelligence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURES.map((feature, i) => {
              const Icon = feature.icon;
              const colorMap: Record<string, { text: string; border: string; bg: string }> = {
                pink: { text: "oklch(0.70 0.28 350)", border: "oklch(0.60 0.28 350 / 0.3)", bg: "oklch(0.60 0.28 350 / 0.08)" },
                blue: { text: "oklch(0.70 0.22 255)", border: "oklch(0.55 0.22 255 / 0.3)", bg: "oklch(0.55 0.22 255 / 0.08)" },
                cyan: { text: "oklch(0.80 0.18 200)", border: "oklch(0.72 0.18 200 / 0.3)", bg: "oklch(0.72 0.18 200 / 0.08)" },
              };
              const colors = colorMap[feature.color] ?? colorMap["pink"]!;

              return (
                <div key={i} className="rounded-lg p-5 transition-all duration-200 group cursor-default"
                  style={{ background: "oklch(0.11 0.025 255 / 0.8)", border: `1px solid oklch(0.22 0.04 255)` }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.borderColor = colors.border;
                    (e.currentTarget as HTMLElement).style.boxShadow = `0 0 20px ${colors.bg}`;
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.22 0.04 255)";
                    (e.currentTarget as HTMLElement).style.boxShadow = "none";
                  }}>
                  <div className="flex items-start gap-4">
                    <div className="p-2 rounded" style={{ background: colors.bg }}>
                      <Icon className="h-5 w-5" style={{ color: colors.text }} />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1 text-sm tracking-wide" style={{ color: colors.text }}>
                        {feature.title}
                      </h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{feature.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Karen Personality Section */}
      <section className="py-24 px-8 relative">
        <div className="max-w-4xl mx-auto">
          <div className="rounded-xl p-8 md:p-12 relative overflow-hidden"
            style={{ background: "oklch(0.11 0.025 255 / 0.9)", border: "1px solid oklch(0.60 0.28 350 / 0.3)", boxShadow: "0 0 60px oklch(0.60 0.28 350 / 0.08)" }}>
            {/* Decorative corner */}
            <div className="absolute top-0 right-0 w-32 h-32 pointer-events-none"
              style={{ background: "radial-gradient(circle at top right, oklch(0.60 0.28 350 / 0.15), transparent 70%)" }} />

            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-3 h-3 rounded-full animate-pulse" style={{ background: "oklch(0.60 0.28 350)", boxShadow: "0 0 10px oklch(0.60 0.28 350)" }} />
                <span className="text-xs tracking-widest uppercase" style={{ color: "oklch(0.60 0.28 350)" }}>KAREN.PERSONALITY.MODULE</span>
              </div>

              <h2 className="text-3xl md:text-4xl font-bold mb-4" style={{ color: "oklch(0.70 0.28 350)", textShadow: "0 0 20px oklch(0.60 0.28 350 / 0.4)" }}>
                Not a Tool. A Synthetic Operator.
              </h2>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                Karen is modeled after the most efficient computer in the ocean. Witty, precise, slightly impatient with vague requirements, and relentlessly capable. Every response, every status message, every system feedback is delivered in her voice.
              </p>

              <div className="space-y-3">
                {KAREN_QUOTES.map((quote, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded"
                    style={{ background: "oklch(0.09 0.02 255 / 0.8)", border: "1px solid oklch(0.22 0.04 255)" }}>
                    <span className="text-xs font-mono mt-0.5 shrink-0" style={{ color: "oklch(0.60 0.28 350)" }}>K://</span>
                    <p className="text-sm text-muted-foreground italic">{quote}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-8 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-4xl font-bold mb-4" style={{ color: "oklch(0.92 0.03 240)" }}>
            Ready to Build Something?
          </h2>
          <p className="text-muted-foreground mb-8">
            Karen is waiting. She's been studying code while you read this.
          </p>
          <Button onClick={handleCTA} size="lg"
            className="px-10 py-6 text-base font-semibold tracking-wider uppercase"
            style={{
              background: "oklch(0.60 0.28 350)",
              color: "oklch(0.98 0.01 0)",
              boxShadow: "0 0 40px oklch(0.60 0.28 350 / 0.4)",
              border: "none",
            }}>
            <Zap className="mr-2 h-5 w-5" />
            {isAuthenticated ? "Go to Dashboard" : "Start Building"}
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-8 text-center" style={{ borderTop: "1px solid oklch(0.22 0.04 255)" }}>
        <div className="flex items-center justify-center gap-3 mb-2">
          <div className="h-4 w-px" style={{ background: "linear-gradient(to bottom, transparent, oklch(0.60 0.28 350), transparent)" }} />
          <span className="text-xs tracking-widest uppercase" style={{ color: "oklch(0.60 0.28 350)" }}>KAREN ANN ENGINE</span>
          <div className="h-4 w-px" style={{ background: "linear-gradient(to bottom, transparent, oklch(0.72 0.18 200), transparent)" }} />
        </div>
        <p className="text-xs text-muted-foreground tracking-widest">
          SYNTHETIC INTELLIGENCE · ALWAYS LEARNING · NEVER OFFLINE
        </p>
      </footer>
    </div>
  );
}
