# Synthia Server Backend Analysis

## Project Overview
**TRIDENT** — 3-Head Tiny LM + P2P RAG + MCP
- ~1M parameter transformer with three specialist heads: Code, Math, Research
- Runs on CPU (Termux/iPad/laptop)
- Knowledge retrieval via P2P WebRTC (no cloud needed)

## Key Files
- `model.py` — Trident architecture (backbone + 3 heads + RAG gate)
- `rag.py` — Python chunk store + P2P RAG node (aiortc)
- `rag_client.js` — Browser P2P RAG client (WebRTC DataChannel)
- `signal_server.py` — Minimal WebSocket signaling
- `mcp_server.py` — FastMCP server exposing tools to Claude/any LLM
- `train.py` — Training loop
- `index.ts` — TypeScript server entry point
- `db.ts` — Database module
- `address.ts` — Address handling
- `gapFiller.ts` — Gap filling logic
- `github.ts` — GitHub integration
- `mixer.ts` — Mixing/blending logic

## MCP Tools Available
| Tool | Purpose |
|------|---------|
| `trident_generate` | Generate text, pick head, optionally RAG |
| `trident_add_chunk` | Add knowledge to RAG store |
| `trident_search_rag` | Search chunks without generating |
| `trident_router` | Predict which head fits a query |
| `trident_list_chunks` | List all stored knowledge chunks |

## Architecture
- Input → Embedding + PositionalEncoding
- Backbone: 4x TransformerBlock (shared)
- HeadRouter → softmax weights
- Per-head: RAGFusionGate (cross-attn) + 1x TransformerBlock + LM Head
- Weighted ensemble OR forced single head output

## P2P RAG Flow
Device A (phone) queries via WebRTC DataChannel to Device B (iPad)
- Device B searches local chunks
- Returns top-K matches
- Device A merges local + peer results
- Top-K embeddings → RAGFusionGate → model generates

## Tech Stack
- **Languages:** Python, TypeScript, JavaScript
- **Frameworks:** FastMCP, aiortc (WebRTC), Express/Node.js
- **Deployment:** Render (dual server setup)
- **P2P:** WebRTC DataChannel, WebSocket signaling

## Next Steps for Mobile App
1. Create Expo React Native app
2. Connect to Render backend via HTTP/WebSocket
3. Integrate MCP tools for code generation
4. Build mobile UI for TRIDENT features
5. Support P2P RAG queries from phone
6. Build APK for Android distribution
