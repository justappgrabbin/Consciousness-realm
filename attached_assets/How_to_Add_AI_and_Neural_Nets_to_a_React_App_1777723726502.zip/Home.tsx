import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Brain, FileUp, Zap, BarChart3, MessageSquare } from "lucide-react";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="flex flex-col items-center gap-4">
          <Brain className="w-12 h-12 animate-pulse text-blue-400" />
          <p className="text-slate-300">Initializing Neural Brain...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-blue-400" />
            <h1 className="text-2xl font-bold text-white">AI Self-Builder</h1>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-slate-300 text-sm">{user?.name || user?.email}</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={logout}
                  className="border-slate-600 hover:bg-slate-700"
                >
                  Logout
                </Button>
              </>
            ) : (
              <Button
                size="sm"
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => (window.location.href = getLoginUrl())}
              >
                Sign In
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 w-fit">
                Intelligent Code Generation
              </Badge>
              <h2 className="text-5xl font-bold text-white leading-tight">
                Self-Building Apps with{" "}
                <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                  Neural Intelligence
                </span>
              </h2>
              <p className="text-xl text-slate-300 leading-relaxed">
                Upload PDFs, extract knowledge, and let the neural brain learn isomorphic patterns to generate intelligent code and adaptive suggestions.
              </p>
            </div>

            <div className="flex gap-4">
              {isAuthenticated ? (
                <>
                  <Link href="/uploader">
                    <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
                      <FileUp className="w-5 h-5 mr-2" />
                      Upload PDF
                    </Button>
                  </Link>
                  <Link href="/chat">
                    <Button
                      variant="outline"
                      className="border-slate-600 hover:bg-slate-700 text-white px-8 py-6 text-lg"
                    >
                      <MessageSquare className="w-5 h-5 mr-2" />
                      Chat
                    </Button>
                  </Link>
                </>
              ) : (
                <Button
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg"
                  onClick={() => (window.location.href = getLoginUrl())}
                >
                  Get Started
                </Button>
              )}
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl blur-3xl opacity-20"></div>
            <div className="relative bg-slate-800 border border-slate-700 rounded-2xl p-8 space-y-6">
              <div className="flex items-center gap-3">
                <Brain className="w-6 h-6 text-blue-400" />
                <h3 className="text-lg font-semibold text-white">Neural Brain Status</h3>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Concepts Learned</span>
                  <span className="text-2xl font-bold text-blue-400">0</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Code Patterns</span>
                  <span className="text-2xl font-bold text-cyan-400">0</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Training Accuracy</span>
                  <span className="text-2xl font-bold text-green-400">0%</span>
                </div>
              </div>
              <div className="pt-4 border-t border-slate-700">
                <p className="text-sm text-slate-400">Upload your first PDF to start training the neural brain</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h3 className="text-4xl font-bold text-white mb-4">Powerful Features</h3>
          <p className="text-xl text-slate-400">Everything you need for intelligent code generation</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              icon: FileUp,
              title: "PDF Knowledge Ingestion",
              description: "Upload PDFs containing concepts, architecture, and code. The system automatically extracts and learns from them.",
              color: "text-blue-400",
            },
            {
              icon: Brain,
              title: "Isomorphic Pattern Learning",
              description: "The neural brain identifies structural equivalences between different concepts and code patterns.",
              color: "text-purple-400",
            },
            {
              icon: Zap,
              title: "Intelligent Code Generation",
              description: "Generate React components and code informed by learned patterns and semantic understanding.",
              color: "text-yellow-400",
            },
            {
              icon: MessageSquare,
              title: "Natural Language Chat",
              description: "Query the knowledge base and neural brain using natural language for instant insights.",
              color: "text-green-400",
            },
            {
              icon: BarChart3,
              title: "Neural Dashboard",
              description: "Visualize training progress, accuracy metrics, and the growing knowledge graph in real-time.",
              color: "text-cyan-400",
            },
            {
              icon: Zap,
              title: "Adaptive Suggestions",
              description: "Get proactive recommendations based on your current context and the neural brain's learned associations.",
              color: "text-pink-400",
            },
          ].map((feature, idx) => (
            <Card
              key={idx}
              className="bg-slate-800 border-slate-700 hover:border-slate-600 transition-colors group"
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <feature.icon className={`w-8 h-8 ${feature.color}`} />
                </div>
                <CardTitle className="text-white mt-4">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-400">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      {isAuthenticated && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl blur-2xl opacity-20"></div>
            <div className="relative bg-gradient-to-r from-slate-800 to-slate-900 border border-slate-700 rounded-2xl p-12 text-center space-y-6">
              <h3 className="text-3xl font-bold text-white">Ready to Build?</h3>
              <p className="text-lg text-slate-300 max-w-2xl mx-auto">
                Start by uploading a PDF with your project concepts and code. The neural brain will learn and help you build better.
              </p>
              <div className="flex gap-4 justify-center">
                <Link href="/uploader">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
                    <FileUp className="w-5 h-5 mr-2" />
                    Upload Your First PDF
                  </Button>
                </Link>
                <Link href="/dashboard">
                  <Button
                    variant="outline"
                    className="border-slate-600 hover:bg-slate-700 text-white px-8 py-6 text-lg"
                  >
                    <BarChart3 className="w-5 h-5 mr-2" />
                    View Dashboard
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/50 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-slate-400">
          <p>AI Self-Builder © 2026 • Powered by Neural Intelligence</p>
        </div>
      </footer>
    </div>
  );
}
