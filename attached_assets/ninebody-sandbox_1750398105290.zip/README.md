# NineBody Sandbox

A 3D consciousness-based game built with React and Three.js. Players explore energetic terrain using avatars tied to different fields of consciousness.
