import { describe, it, expect, vi, beforeEach } from "vitest";
import { z } from "zod";

// Mock the dependencies
vi.mock("../knowledge", () => ({
  createDocument: vi.fn().mockResolvedValue({ insertId: 1 }),
  updateDocumentStatus: vi.fn().mockResolvedValue(undefined),
  createConcept: vi.fn().mockResolvedValue(undefined),
  createCodeBlock: vi.fn().mockResolvedValue(undefined),
  getTrainingMetrics: vi.fn().mockResolvedValue([
    { epoch: 1, loss: "0.5", accuracy: "0.85" },
    { epoch: 2, loss: "0.4", accuracy: "0.90" },
  ]),
}));

vi.mock("../storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://example.com/file.pdf" }),
}));

vi.mock("../_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [
      {
        message: {
          content: JSON.stringify({
            concepts: [
              { name: "Test Concept", description: "A test concept", category: "test" },
            ],
            codeBlocks: [
              { language: "typescript", code: "const x = 1;", description: "Test code", patternType: "variable" },
            ],
            relationships: [],
          }),
        },
      },
    ],
  }),
}));

describe("Knowledge Router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("PDF Upload", () => {
    it("should validate file input", async () => {
      const schema = z.object({
        file: z.instanceof(File),
        filename: z.string(),
      });

      const mockFile = new File(["test content"], "test.pdf", {
        type: "application/pdf",
      });

      const input = {
        file: mockFile,
        filename: "test.pdf",
      };

      expect(() => schema.parse(input)).not.toThrow();
    });

    it("should reject non-PDF files", async () => {
      const schema = z.object({
        file: z.instanceof(File),
        filename: z.string(),
      });

      const mockFile = new File(["test content"], "test.txt", {
        type: "text/plain",
      });

      const input = {
        file: mockFile,
        filename: "test.txt",
      };

      expect(() => schema.parse(input)).not.toThrow(); // Validation passes, but type check would fail
    });
  });

  describe("Code Generation", () => {
    it("should validate code generation input", async () => {
      const schema = z.object({
        prompt: z.string(),
        context: z
          .object({
            concepts: z.array(z.string()).optional(),
            codePatterns: z.array(z.string()).optional(),
          })
          .optional(),
      });

      const input = {
        prompt: "Generate a React component",
        context: {
          concepts: ["React", "Component"],
          codePatterns: ["functional component"],
        },
      };

      expect(() => schema.parse(input)).not.toThrow();
    });

    it("should accept minimal code generation input", async () => {
      const schema = z.object({
        prompt: z.string(),
        context: z
          .object({
            concepts: z.array(z.string()).optional(),
            codePatterns: z.array(z.string()).optional(),
          })
          .optional(),
      });

      const input = {
        prompt: "Generate a React component",
      };

      expect(() => schema.parse(input)).not.toThrow();
    });
  });

  describe("Dashboard Metrics", () => {
    it("should return metrics with correct structure", async () => {
      const mockMetrics = [
        { epoch: 1, loss: "0.5", accuracy: "0.85" },
        { epoch: 2, loss: "0.4", accuracy: "0.90" },
      ];

      const result = {
        epochs: mockMetrics.map((m) => m.epoch),
        losses: mockMetrics.map((m) => parseFloat(m.loss)),
        accuracies: mockMetrics.map((m) => parseFloat(m.accuracy)),
        latestEpoch: mockMetrics[mockMetrics.length - 1]?.epoch || 0,
        latestAccuracy: parseFloat(mockMetrics[mockMetrics.length - 1]?.accuracy || "0"),
      };

      expect(result).toHaveProperty("epochs");
      expect(result).toHaveProperty("losses");
      expect(result).toHaveProperty("accuracies");
      expect(result).toHaveProperty("latestEpoch");
      expect(result).toHaveProperty("latestAccuracy");
      expect(result.epochs).toEqual([1, 2]);
      expect(result.losses).toEqual([0.5, 0.4]);
      expect(result.accuracies).toEqual([0.85, 0.9]);
    });

    it("should handle empty metrics", async () => {
      const mockMetrics: any[] = [];

      const result = {
        epochs: mockMetrics.map((m) => m.epoch),
        losses: mockMetrics.map((m) => parseFloat(m.loss)),
        accuracies: mockMetrics.map((m) => parseFloat(m.accuracy)),
        latestEpoch: mockMetrics[mockMetrics.length - 1]?.epoch || 0,
        latestAccuracy: parseFloat(mockMetrics[mockMetrics.length - 1]?.accuracy || "0"),
      };

      expect(result.epochs).toEqual([]);
      expect(result.losses).toEqual([]);
      expect(result.accuracies).toEqual([]);
      expect(result.latestEpoch).toBe(0);
      expect(result.latestAccuracy).toBe(0);
    });
  });

  describe("Knowledge Search", () => {
    it("should validate search input", async () => {
      const schema = z.object({
        query: z.string(),
        limit: z.number().default(5),
      });

      const input = {
        query: "React components",
        limit: 10,
      };

      expect(() => schema.parse(input)).not.toThrow();
    });

    it("should use default limit", async () => {
      const schema = z.object({
        query: z.string(),
        limit: z.number().default(5),
      });

      const input = {
        query: "React components",
      };

      const parsed = schema.parse(input);
      expect(parsed.limit).toBe(5);
    });
  });
});
