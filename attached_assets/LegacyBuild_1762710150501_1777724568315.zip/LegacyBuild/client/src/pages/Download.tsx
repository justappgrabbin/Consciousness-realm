import { useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, FileCode, Sparkles, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Project } from "@shared/schema";

export default function DownloadPage() {
  const { toast } = useToast();

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  const currentProject = projects[0];

  const downloadMutation = useMutation({
    mutationFn: async (projectId: string) => {
      const response = await apiRequest('POST', `/api/projects/${projectId}/download`, {});
      return response;
    },
    onSuccess: (data) => {
      const link = document.createElement('a');
      link.href = data.downloadUrl;
      link.download = `${currentProject?.name || 'project'}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "Download started",
        description: "Your generated application is being downloaded",
      });
    },
    onError: () => {
      toast({
        title: "Download failed",
        description: "There was an error downloading your project",
        variant: "destructive",
      });
    },
  });

  if (!currentProject) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <Card className="p-12 text-center">
          <FileCode className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-2xl font-bold mb-2">No Project Available</h2>
          <p className="text-muted-foreground mb-6">
            Create and process a project to download your generated application
          </p>
          <Button asChild>
            <a href="/">Create Project</a>
          </Button>
        </Card>
      </div>
    );
  }

  const isProcessing = currentProject.status !== 'completed';

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-4xl font-bold mb-2">Download Your Application</h1>
        <p className="text-muted-foreground">
          Get your optimized, AI-generated application ready for deployment
        </p>
      </div>

      <Card className="p-8">
        <div className="space-y-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
              <FileCode className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold mb-1">{currentProject.name}</h3>
              <p className="text-muted-foreground mb-4">
                {currentProject.description || "Your Legacy project"}
              </p>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-sm">{currentProject.filesProcessed} files processed</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-sm">{currentProject.patternsUnified} patterns unified</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-sm">{currentProject.codeLinesAnalyzed.toLocaleString()} lines analyzed</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-sm">{currentProject.booksReferenced} books referenced</span>
                </div>
              </div>

              {isProcessing ? (
                <Card className="p-4 bg-amber-500/10 border-amber-500/20">
                  <div className="flex items-center gap-3">
                    <Sparkles className="w-5 h-5 text-amber-600 animate-pulse" />
                    <div>
                      <p className="font-semibold text-sm">Processing in progress...</p>
                      <p className="text-xs text-muted-foreground">
                        Your application will be ready for download once processing is complete
                      </p>
                    </div>
                  </div>
                </Card>
              ) : (
                <Button
                  size="lg"
                  onClick={() => downloadMutation.mutate(currentProject.id)}
                  disabled={downloadMutation.isPending}
                  className="w-full"
                  data-testid="button-download-project"
                >
                  <Download className="w-5 h-5 mr-2" />
                  {downloadMutation.isPending ? "Preparing Download..." : "Download Application (.zip)"}
                </Button>
              )}
            </div>
          </div>

          <div className="border-t pt-6">
            <h4 className="font-semibold mb-3">What's included:</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                Complete application source code
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                AI-optimized and unified code patterns
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                Comprehensive documentation and comments
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                Book references and best practices applied
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                Processing report and insights
              </li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}
