import React, { useState, useEffect } from 'react';
import { Settings, Check, FileText, Trash2, X, Upload, Sparkles } from 'lucide-react';

// ============= APP COMPONENTS =============
// Each app is now cleanly separated and can be easily extended

function TodoApp() {
  const [tasks, setTasks] = useState([
    { id: 1, text: 'Welcome to your todo app!', done: false },
    { id: 2, text: 'Add new tasks below', done: false }
  ]);
  const [newTask, setNewTask] = useState('');

  const addTask = () => {
    if (newTask.trim()) {
      setTasks([...tasks, { id: Date.now(), text: newTask, done: false }]);
      setNewTask('');
    }
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, done: !task.done } : task
    ));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && addTask()}
          placeholder="Add a new task..."
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-400"
        />
        <button
          onClick={addTask}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Add
        </button>
      </div>
      
      <div className="space-y-2">
        {tasks.map(task => (
          <div
            key={task.id}
            className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <input
              type="checkbox"
              checked={task.done}
              onChange={() => toggleTask(task.id)}
              className="w-5 h-5 text-blue-600 rounded focus:ring-blue-500"
            />
            <span className={`flex-1 ${task.done ? 'line-through text-gray-400' : 'text-gray-700'}`}>
              {task.text}
            </span>
            <button
              onClick={() => deleteTask(task.id)}
              className="px-3 py-1 text-sm text-red-600 hover:bg-red-50 rounded transition-colors"
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function CalculatorApp() {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState(null);
  const [operation, setOperation] = useState(null);

  const handleNumber = (num) => {
    setDisplay(display === '0' ? num : display + num);
  };

  const handleOperation = (op) => {
    setPreviousValue(parseFloat(display));
    setOperation(op);
    setDisplay('0');
  };

  const calculate = () => {
    const current = parseFloat(display);
    let result;
    
    switch(operation) {
      case '+': result = previousValue + current; break;
      case '-': result = previousValue - current; break;
      case '×': result = previousValue * current; break;
      case '÷': result = previousValue / current; break;
      default: return;
    }
    
    setDisplay(result.toString());
    setOperation(null);
    setPreviousValue(null);
  };

  const clear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
  };

  const buttonClass = "h-16 text-xl font-semibold rounded-lg transition-colors";

  return (
    <div className="max-w-xs mx-auto">
      <div className="bg-gray-900 text-white text-right text-3xl p-6 rounded-lg mb-4 font-mono">
        {display}
      </div>
      
      <div className="grid grid-cols-4 gap-3">
        <button onClick={clear} className={`${buttonClass} bg-gray-300 hover:bg-gray-400 col-span-2`}>C</button>
        <button onClick={() => handleOperation('÷')} className={`${buttonClass} bg-orange-400 hover:bg-orange-500 text-white`}>÷</button>
        <button onClick={() => handleOperation('×')} className={`${buttonClass} bg-orange-400 hover:bg-orange-500 text-white`}>×</button>
        
        <button onClick={() => handleNumber('7')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>7</button>
        <button onClick={() => handleNumber('8')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>8</button>
        <button onClick={() => handleNumber('9')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>9</button>
        <button onClick={() => handleOperation('-')} className={`${buttonClass} bg-orange-400 hover:bg-orange-500 text-white`}>-</button>
        
        <button onClick={() => handleNumber('4')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>4</button>
        <button onClick={() => handleNumber('5')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>5</button>
        <button onClick={() => handleNumber('6')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>6</button>
        <button onClick={() => handleOperation('+')} className={`${buttonClass} bg-orange-400 hover:bg-orange-500 text-white`}>+</button>
        
        <button onClick={() => handleNumber('1')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>1</button>
        <button onClick={() => handleNumber('2')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>2</button>
        <button onClick={() => handleNumber('3')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>3</button>
        <button onClick={calculate} className={`${buttonClass} bg-green-500 hover:bg-green-600 text-white row-span-2`}>=</button>
        
        <button onClick={() => handleNumber('0')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300 col-span-2`}>0</button>
        <button onClick={() => setDisplay(display + '.')} className={`${buttonClass} bg-gray-200 hover:bg-gray-300`}>.</button>
      </div>
    </div>
  );
}

function TimerApp() {
  const [time, setTime] = useState(300);
  const [isRunning, setIsRunning] = useState(false);
  const [inputMinutes, setInputMinutes] = useState('5');

  useEffect(() => {
    let interval;
    if (isRunning && time > 0) {
      interval = setInterval(() => {
        setTime(t => t - 1);
      }, 1000);
    } else if (time === 0) {
      setIsRunning(false);
    }
    return () => clearInterval(interval);
  }, [isRunning, time]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const setTimer = () => {
    const minutes = parseInt(inputMinutes) || 0;
    setTime(minutes * 60);
    setIsRunning(false);
  };

  const reset = () => {
    setTime(parseInt(inputMinutes) * 60 || 300);
    setIsRunning(false);
  };

  return (
    <div className="text-center space-y-6">
      <div className="text-7xl font-bold text-gray-800 font-mono">
        {formatTime(time)}
      </div>
      
      <div className="flex gap-4 justify-center">
        <button
          onClick={() => setIsRunning(!isRunning)}
          className={`px-8 py-3 rounded-lg font-semibold transition-colors ${
            isRunning 
              ? 'bg-yellow-500 hover:bg-yellow-600 text-white' 
              : 'bg-green-500 hover:bg-green-600 text-white'
          }`}
        >
          {isRunning ? 'Pause' : 'Start'}
        </button>
        <button
          onClick={reset}
          className="px-8 py-3 bg-gray-300 hover:bg-gray-400 rounded-lg font-semibold transition-colors"
        >
          Reset
        </button>
      </div>
      
      <div className="pt-6 border-t">
        <label className="block text-sm text-gray-600 mb-2">Set timer (minutes):</label>
        <div className="flex gap-2 justify-center">
          <input
            type="number"
            value={inputMinutes}
            onChange={(e) => setInputMinutes(e.target.value)}
            className="w-24 px-3 py-2 border border-gray-300 rounded-lg text-center focus:outline-none focus:border-blue-400"
            min="0"
          />
          <button
            onClick={setTimer}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            Set
          </button>
        </div>
      </div>
    </div>
  );
}

function NotesApp() {
  const [notes, setNotes] = useState([
    { id: 1, text: 'Click the + button to add notes!', timestamp: Date.now() }
  ]);
  const [newNote, setNewNote] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const addNote = () => {
    if (newNote.trim()) {
      setNotes([{ id: Date.now(), text: newNote, timestamp: Date.now() }, ...notes]);
      setNewNote('');
      setIsAdding(false);
    }
  };

  const deleteNote = (id) => {
    setNotes(notes.filter(note => note.id !== id));
  };

  return (
    <div className="space-y-4">
      {!isAdding ? (
        <button
          onClick={() => setIsAdding(true)}
          className="w-full py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-400 hover:text-blue-600 transition-colors font-semibold"
        >
          + Add New Note
        </button>
      ) : (
        <div className="space-y-2">
          <textarea
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            placeholder="Write your note here..."
            className="w-full h-32 p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-400 resize-none"
            autoFocus
          />
          <div className="flex gap-2">
            <button
              onClick={addNote}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Save Note
            </button>
            <button
              onClick={() => { setIsAdding(false); setNewNote(''); }}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      
      <div className="space-y-3">
        {notes.map(note => (
          <div key={note.id} className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-gray-800 whitespace-pre-wrap mb-2">{note.text}</p>
            <div className="flex justify-between items-center text-xs text-gray-500">
              <span>{new Date(note.timestamp).toLocaleString()}</span>
              <button
                onClick={() => deleteNote(note.id)}
                className="text-red-600 hover:text-red-800"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============= APP REGISTRY (Pluggable System) =============
// Adding new apps is as easy as creating a component and registering it here

const appRegistry = {
  todo: {
    name: "Todo List App",
    description: "A simple task management application",
    component: TodoApp,
    detectKeywords: ["todo", "task", "checklist"]
  },
  calculator: {
    name: "Calculator App",
    description: "A basic calculator for arithmetic operations",
    component: CalculatorApp,
    detectKeywords: ["calculator", "calculate", "math", "calc"]
  },
  timer: {
    name: "Timer App",
    description: "A countdown timer application",
    component: TimerApp,
    detectKeywords: ["timer", "countdown", "stopwatch", "clock"]
  },
  notes: {
    name: "Quick Notes App",
    description: "A minimalist note-taking application",
    component: NotesApp,
    detectKeywords: ["note", "memo", "journal"]
  }
};

function detectAppType(text) {
  const lower = text.toLowerCase();
  for (const [key, config] of Object.entries(appRegistry)) {
    if (config.detectKeywords.some(keyword => lower.includes(keyword))) {
      return key;
    }
  }
  return "todo";
}

function detectAppTypeFromFilename(filename) {
  const lower = filename.toLowerCase();
  for (const [key, config] of Object.entries(appRegistry)) {
    if (config.detectKeywords.some(keyword => lower.includes(keyword))) {
      return key;
    }
  }
  const types = Object.keys(appRegistry);
  return types[Math.floor(Math.random() * types.length)];
}

// ============= BUILD PIPELINE (Simulation System) =============
// Clean abstraction for simulating build progress

async function runPipeline(steps, onProgress, onLog) {
  return new Promise((resolve) => {
    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        const step = steps[currentStep];
        onProgress(step.progress);
        if (step.log) onLog(step.log);
        currentStep++;
      } else {
        clearInterval(interval);
        resolve();
      }
    }, 200);
  });
}

async function simulateBuildFromText(text, onProgress) {
  const pipeline = [
    { progress: 20 },
    { progress: 45 },
    { progress: 70 },
    { progress: 90 },
    { progress: 100 }
  ];
  await runPipeline(pipeline, onProgress, () => {});
}

async function simulateBuildFromZip(file, onProgress, onLog) {
  const mockFiles = [
    'index.html', 'styles.css', 'app.js',
    'components/Header.jsx', 'components/MainView.jsx',
    'utils/helpers.js', 'assets/logo.png',
    'package.json', 'README.md'
  ];

  const initialSteps = [
    { progress: 15, log: `📦 Reading ${file.name}...` },
    { progress: 30, log: '🔍 Validating archive structure...' },
    { progress: 45, log: `📂 Extracting ${mockFiles.length} files...` }
  ];

  await runPipeline(initialSteps, onProgress, onLog);

  for (let i = 0; i < mockFiles.length; i++) {
    await new Promise(resolve => setTimeout(resolve, 200));
    onProgress(45 + (i / mockFiles.length) * 40);
    onLog(`  ✓ ${mockFiles[i]}`);
  }

  onProgress(85);
  onLog('🔨 Building application...');
  await new Promise(resolve => setTimeout(resolve, 400));
  
  onProgress(95);
  onLog('✨ Finalizing...');
  await new Promise(resolve => setTimeout(resolve, 400));
  
  onProgress(100);
  onLog('✅ App ready!');
  await new Promise(resolve => setTimeout(resolve, 600));
}

// ============= UI COMPONENTS =============

function Notebook({ value, onChange }) {
  return (
    <div className="relative">
      <div className="absolute left-16 top-0 bottom-0 w-px bg-red-300 opacity-40"></div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Start typing..."
        className="w-full min-h-[600px] pl-20 pr-8 py-8 focus:outline-none resize-none text-gray-800 text-lg leading-relaxed bg-transparent relative z-10"
        style={{ 
          fontFamily: 'Courier New, monospace',
          backgroundImage: 'repeating-linear-gradient(white, white 30px, #cbd5e1 30px, #cbd5e1 31px)',
          lineHeight: '31px',
          paddingTop: '16px'
        }}
      />
    </div>
  );
}

function ProgressDisplay({ progress, extractionLog, uploadedFile }) {
  return (
    <div className="min-h-[600px] p-8 flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="text-center max-w-md w-full">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full mb-6 shadow-lg">
          <Sparkles className="w-10 h-10 text-white animate-pulse" />
        </div>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">
          {uploadedFile ? `Extracting ${uploadedFile.name}...` : 'Building your app...'}
        </h3>
        <p className="text-gray-600 mb-8">Please wait a moment</p>
        
        <div className="mb-8">
          <div className="h-4 bg-gray-200 rounded-full overflow-hidden shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 transition-all duration-500 ease-out relative overflow-hidden"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30 animate-shimmer"></div>
            </div>
          </div>
          <div className="flex justify-between items-center mt-3">
            <span className="text-sm font-medium text-gray-600">Processing...</span>
            <span className="text-lg font-bold text-blue-600">{progress}%</span>
          </div>
        </div>

        {extractionLog.length > 0 && (
          <div className="bg-gray-900 text-green-400 rounded-lg p-4 font-mono text-sm max-h-64 overflow-y-auto text-left shadow-xl border border-gray-700">
            {extractionLog.map((log, i) => (
              <div key={i} className="mb-1 animate-fade-in">{log}</div>
            ))}
            <div className="mt-2 flex items-center gap-2 text-green-300">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs">Working...</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SettingsPanel({ 
  show, onClose, buildMode, setBuildMode, noteText, setNoteText,
  onBuildFromText, onFileUpload, isDragging, onDragOver, onDragLeave, onDrop
}) {
  if (!show) return null;

  return (
    <div className="absolute top-0 right-0 w-80 h-full bg-white border-l border-gray-200 shadow-2xl z-10">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-800">Build Settings</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded transition-colors">
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-3">Build Mode</label>
          <div className="space-y-2">
            <button
              onClick={() => setBuildMode('text')}
              className={`w-full p-3 rounded-lg border-2 transition-all text-left ${
                buildMode === 'text' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                <FileText className="w-4 h-4 text-gray-700" />
                <span className="font-medium text-gray-800">Text Prompt</span>
              </div>
              <p className="text-xs text-gray-600">Describe the app you want to build</p>
            </button>
            
            <button
              onClick={() => setBuildMode('upload')}
              className={`w-full p-3 rounded-lg border-2 transition-all text-left ${
                buildMode === 'upload' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                <Upload className="w-4 h-4 text-gray-700" />
                <span className="font-medium text-gray-800">Upload ZIP</span>
              </div>
              <p className="text-xs text-gray-600">Upload a .zip file to extract</p>
            </button>
          </div>
        </div>

        {buildMode === 'text' && (
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
              <p className="text-sm text-blue-800 mb-2">
                <span className="font-semibold">How it works:</span>
              </p>
              <ol className="text-xs text-blue-700 space-y-1 list-decimal list-inside">
                <li>Write what you want in the notepad</li>
                <li>Click "Build App" below</li>
                <li>Your app will be generated!</li>
              </ol>
            </div>

            <div className="p-3 bg-gray-50 rounded border border-gray-200">
              <p className="text-xs text-gray-600 mb-2 font-medium">Try these:</p>
              <div className="flex flex-wrap gap-1">
                {['todo list', 'calculator', 'timer', 'notes app'].map((example) => (
                  <button
                    key={example}
                    onClick={() => setNoteText(example)}
                    className="px-2 py-1 bg-white border border-gray-300 rounded text-xs hover:bg-gray-50 transition-colors"
                  >
                    {example}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={onBuildFromText}
              disabled={!noteText.trim()}
              className={`w-full py-3 rounded-lg font-medium transition-all ${
                noteText.trim() ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              Build App
            </button>
          </div>
        )}

        {buildMode === 'upload' && (
          <div className="space-y-4">
            <div
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onDrop={onDrop}
              className={`border-2 border-dashed rounded-lg p-6 text-center transition-all cursor-pointer ${
                isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-gray-50 hover:border-gray-400'
              }`}
            >
              <input type="file" accept=".zip" onChange={onFileUpload} className="hidden" id="file-upload-settings" />
              <label htmlFor="file-upload-settings" className="cursor-pointer">
                <div className="flex flex-col items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <Upload className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-800 mb-1">Drop ZIP file here</p>
                    <p className="text-xs text-gray-600">or click to browse</p>
                  </div>
                </div>
              </label>
            </div>

            <div className="p-3 bg-amber-50 rounded border border-amber-200">
              <p className="text-xs text-amber-800">
                <span className="font-semibold">Note:</span> Any .zip file will be extracted and simulated as an app build process.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ============= MAIN APP =============

export default function NotebookApp() {
  const [noteText, setNoteText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedApp, setGeneratedApp] = useState(null);
  const [progress, setProgress] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [extractionLog, setExtractionLog] = useState([]);
  const [showSettings, setShowSettings] = useState(false);
  const [buildMode, setBuildMode] = useState('text');

  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes shimmer {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
      }
      @keyframes fade-in {
        from { opacity: 0; transform: translateY(-4px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .animate-shimmer { animation: shimmer 2s infinite; }
      .animate-fade-in { animation: fade-in 0.3s ease-out; }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  const appendLog = (message) => setExtractionLog(prev => [...prev, message]);

  const handleBuildFromText = async () => {
    setIsGenerating(true);
    setProgress(0);
    setShowSettings(false);
    await simulateBuildFromText(noteText, setProgress);
    const appType = detectAppType(noteText);
    setGeneratedApp(appRegistry[appType]);
    setIsGenerating(false);
  };

  const handleBuildFromZip = async (file) => {
    setIsGenerating(true);
    setProgress(0);
    setExtractionLog([]);
    setUploadedFile(file);
    await simulateBuildFromZip(file, setProgress, appendLog);
    const appType = detectAppTypeFromFilename(file.name);
    setGeneratedApp(appRegistry[appType]);
    setIsGenerating(false);
  };

  const resetApp = () => {
    setGeneratedApp(null);
    setNoteText('');
    setProgress(0);
    setUploadedFile(null);
    setExtractionLog([]);
    setShowSettings(false);
  };

  const handleDragOver = (e) => { e.preventDefault(); setIsDragging(true); };
  const handleDragLeave = (e) => { e.preventDefault(); setIsDragging(false); };
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.name.endsWith('.zip')) handleBuildFromZip(file);
      else alert('Please upload a .zip file');
    }
  };

  const handleFileInput = (e) => {
    const files = e.target.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.name.endsWith('.zip')) handleBuildFromZip(file);
      else alert('Please upload a .zip file');
    }
    e.target.value = '';
  };

  if (generatedApp) {
    const AppComponent = generatedApp.component;
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl bg-white shadow-2xl rounded-lg overflow-hidden">
          <div className="bg-gradient-to-r from-amber-50 to-yellow-50 border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Check className="w-6 h-6 text-green-600" />
              <div>
                <h2 className="font-semibold text-gray-800">{generatedApp.name}</h2>
                <p className="text-sm text-gray-600">{generatedApp.description}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => { setGeneratedApp(null); setShowSettings(true); setBuildMode('upload'); }}
                className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded border transition-colors"
              >
                Upload Another
              </button>
              <button
                onClick={resetApp}
                className="px-4 py-2 text-sm bg-white hover:bg-gray-50 text-gray-700 rounded border border-gray-300 transition-colors"
              >
                New Page
              </button>
            </div>
          </div>
          <div className="p-8 min-h-[600px]">
            <AppComponent />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-white shadow-2xl rounded-lg overflow-hidden relative">
        <div className="bg-gradient-to-r from-amber-50 to-yellow-50 border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FileText className="w-6 h-6 text-gray-700" />
            <h1 className="text-lg font-semibold text-gray-800">Notepad</h1>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setNoteText('')} className="p-2 hover:bg-white rounded transition-colors" title="Clear">
              <Trash2 className="w-5 h-5 text-gray-600" />
            </button>
            <button onClick={() => setShowSettings(!showSettings)} className="p-2 hover:bg-white rounded transition-colors" title="Settings">
              <Settings className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="relative bg-white">
          {!isGenerating ? (
            <Notebook value={noteText} onChange={setNoteText} />
          ) : (
            <ProgressDisplay progress={progress} extractionLog={extractionLog} uploadedFile={uploadedFile} />
          )}
        </div>

        <SettingsPanel
          show={showSettings}
          onClose={() => setShowSettings(false)}
          buildMode={buildMode}
          setBuildMode={setBuildMode}
          noteText={noteText}
          setNoteText={setNoteText}
          onBuildFromText={handleBuildFromText}
          onFileUpload={handleFileInput}
          isDragging={isDragging}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        />
      </div>
    </div>
  );
}
