import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Send, Copy, Check, MessageSquare, Lightbulb } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  code?: string;
  suggestions?: string[];
  timestamp: Date;
}

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [copied, setCopied] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const generateCode = trpc.knowledge.code.generate.useMutation();
  const getAdaptiveSuggestions = trpc.knowledge.suggestions.getAdaptive.useQuery(
    { currentContext: input, limit: 3 },
    { enabled: input.length > 10 }
  );

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");

    // Generate code/response
    try {
      const result = await generateCode.mutateAsync({
        prompt: input,
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: `Generated code based on your request and learned patterns.`,
        code: result.code,
        suggestions: result.context?.concepts || [],
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      toast.error("Failed to generate code. Please try again.");
      console.error(error);
    }
  };

  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
    toast.success("Code copied to clipboard!");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <MessageSquare className="w-8 h-8 text-blue-400" />
            <h1 className="text-4xl font-bold text-white">Neural Chat</h1>
          </div>
          <p className="text-slate-400">
            Chat with the neural brain to generate code and explore learned patterns
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Chat Area */}
          <div className="lg:col-span-3 space-y-6">
            {/* Messages */}
            <Card className="bg-slate-800 border-slate-700 h-96 overflow-y-auto flex flex-col">
              <CardContent className="flex-1 space-y-4 p-6">
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center space-y-4">
                      <MessageSquare className="w-12 h-12 text-slate-600 mx-auto" />
                      <p className="text-slate-400">Start a conversation to generate code</p>
                    </div>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          msg.role === "user"
                            ? "bg-blue-600 text-white"
                            : "bg-slate-700 text-slate-100"
                        }`}
                      >
                        <p className="text-sm">{msg.content}</p>
                        {msg.code && (
                          <div className="mt-3 bg-slate-900 rounded p-3">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-xs text-slate-400">Code</span>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 px-2"
                                onClick={() => copyToClipboard(msg.code!, msg.id)}
                              >
                                {copied === msg.id ? (
                                  <Check className="w-4 h-4 text-green-400" />
                                ) : (
                                  <Copy className="w-4 h-4 text-slate-400" />
                                )}
                              </Button>
                            </div>
                            <pre className="text-xs overflow-x-auto text-slate-300">
                              <code>{msg.code}</code>
                            </pre>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
                <div ref={messagesEndRef} />
              </CardContent>
            </Card>

            {/* Input Area */}
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-6">
                <div className="flex gap-2">
                  <Input
                    placeholder="Describe the code you want to generate..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                    disabled={generateCode.isPending}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={generateCode.isPending || !input.trim()}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {generateCode.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Adaptive Suggestions */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Lightbulb className="w-5 h-5 text-yellow-400" />
                  Suggestions
                </CardTitle>
                <CardDescription>Based on your context</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {getAdaptiveSuggestions.isLoading ? (
                  <div className="flex items-center justify-center py-4">
                    <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
                  </div>
                ) : getAdaptiveSuggestions.data?.suggestedConcepts &&
                  getAdaptiveSuggestions.data.suggestedConcepts.length > 0 ? (
                  getAdaptiveSuggestions.data.suggestedConcepts.map((concept, idx) => (
                    <Badge
                      key={idx}
                      variant="secondary"
                      className="bg-slate-700 hover:bg-slate-600 cursor-pointer text-slate-200 block text-center py-2"
                      onClick={() => setInput(`Generate code for: ${concept.name}`)}
                    >
                      {concept.name}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-slate-400">Start typing to get suggestions</p>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full border-slate-600 hover:bg-slate-700 text-slate-200 justify-start"
                  onClick={() => setInput("Generate a React component")}
                >
                  React Component
                </Button>
                <Button
                  variant="outline"
                  className="w-full border-slate-600 hover:bg-slate-700 text-slate-200 justify-start"
                  onClick={() => setInput("Generate a TypeScript hook")}
                >
                  TypeScript Hook
                </Button>
                <Button
                  variant="outline"
                  className="w-full border-slate-600 hover:bg-slate-700 text-slate-200 justify-start"
                  onClick={() => setInput("Generate API endpoint")}
                >
                  API Endpoint
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
