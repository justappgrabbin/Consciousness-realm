import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import { GATE_INFO, HD_TYPES, QUEST_STAGES, COHERENCE_THRESHOLDS } from "@shared/resonance";

// ============================================================================
// TRINITY FIELD CALCULATION LOGIC
// ============================================================================

function calculateJulianDay(year: number, month: number, day: number, hour: number, minute: number): number {
  let y = year;
  let m = month;
  if (m <= 2) {
    y -= 1;
    m += 12;
  }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  const JD = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + B - 1524.5;
  return JD + (hour + minute / 60) / 24;
}

function calculateSunPosition(jd: number): number {
  const T = (jd - 2451545.0) / 36525;
  const L0 = 280.46646 + 36000.76983 * T + 0.0003032 * T * T;
  const M = 357.52911 + 35999.05029 * T - 0.0001537 * T * T;
  
  const C = (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(M * Math.PI / 180)
          + (0.019993 - 0.000101 * T) * Math.sin(2 * M * Math.PI / 180)
          + 0.000289 * Math.sin(3 * M * Math.PI / 180);
  
  let sunLong = L0 + C;
  sunLong = sunLong % 360;
  if (sunLong < 0) sunLong += 360;
  
  return sunLong;
}

function calculateNodePosition(jd: number): number {
  const T = (jd - 2451545.0) / 36525;
  let node = 125.04452 - 1934.136261 * T + 0.0020708 * T * T;
  node = node % 360;
  if (node < 0) node += 360;
  return node;
}

function degreeToGate(degree: number): { gate: number; line: number } {
  const gateOrder = [
    41, 19, 13, 49, 30, 55, 37, 63, 22, 36, 25, 17, 21, 51, 42, 3,
    27, 24, 2, 23, 8, 20, 16, 35, 45, 12, 15, 52, 39, 53, 62, 56,
    31, 33, 7, 4, 29, 59, 40, 64, 47, 6, 46, 18, 48, 57, 32, 50,
    28, 44, 1, 43, 14, 34, 9, 5, 26, 11, 10, 58, 38, 54, 61, 60
  ];
  
  let normalizedDegree = degree % 360;
  if (normalizedDegree < 0) normalizedDegree += 360;
  
  const gateIndex = Math.floor(normalizedDegree / 5.625) % 64;
  const gate = gateOrder[gateIndex];
  
  const degreeInGate = normalizedDegree % 5.625;
  const line = Math.floor(degreeInGate / 0.9375) + 1;
  
  return { gate, line: Math.min(line, 6) };
}

function calculateTrinityFields(
  year: number, month: number, day: number, 
  hour: number, minute: number, 
  lat: number, lon: number
) {
  const jd = calculateJulianDay(year, month, day, hour, minute);
  
  // Body Field: Design calculation (-88 degrees from birth)
  const designJd = jd - 88;
  const bodySunPos = calculateSunPosition(designJd);
  const body = degreeToGate(bodySunPos);
  
  // Mind Field: Sidereal adjustment (-24 degrees)
  const siderealOffset = 24;
  const mindSunPos = calculateSunPosition(jd) - siderealOffset;
  const mind = degreeToGate(mindSunPos);
  
  // Heart Field: Draconic (Node-based rotation)
  const nodePos = calculateNodePosition(jd);
  const draconicSunPos = calculateSunPosition(jd) - nodePos;
  const heart = degreeToGate(draconicSunPos);
  
  return {
    body: { ...body, degree: bodySunPos },
    mind: { ...mind, degree: mindSunPos },
    heart: { ...heart, degree: draconicSunPos }
  };
}

function determineHDType(bodyGate: number, mindGate: number, heartGate: number): {
  type: keyof typeof HD_TYPES;
  authority: string;
} {
  const bodyInfo = GATE_INFO[bodyGate];
  const mindInfo = GATE_INFO[mindGate];
  const heartInfo = GATE_INFO[heartGate];
  
  const centers = [bodyInfo?.center, mindInfo?.center, heartInfo?.center];
  
  if (centers.includes("Sacral") && centers.includes("Throat")) {
    return { type: "Manifesting Generator", authority: "Sacral" };
  } else if (centers.includes("Sacral")) {
    return { type: "Generator", authority: "Sacral" };
  } else if (centers.includes("Throat") && centers.includes("Heart")) {
    return { type: "Manifestor", authority: "Ego" };
  } else if (centers.includes("Solar Plexus")) {
    return { type: "Projector", authority: "Emotional" };
  } else if (centers.includes("Spleen")) {
    return { type: "Projector", authority: "Splenic" };
  } else if (centers.every(c => !c || c === "Head" || c === "Ajna")) {
    return { type: "Reflector", authority: "Lunar" };
  }
  
  return { type: "Projector", authority: "Self-Projected" };
}

function generateGraphAddress(birthData: {
  year: number; month: number; day: number;
  hour: number; minute: number;
  lat: number; lon: number;
}): string {
  const seed = `${birthData.year}${birthData.month}${birthData.day}${birthData.hour}${birthData.minute}${Math.round(birthData.lat * 1000)}${Math.round(birthData.lon * 1000)}`;
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    const char = seed.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  const hexHash = Math.abs(hash).toString(16).padStart(16, '0');
  return `node_${hexHash}`;
}

// ============================================================================
// ROUTERS
// ============================================================================

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============================================================================
  // NODE ROUTER
  // ============================================================================
  node: router({
    calculate: protectedProcedure
      .input(z.object({
        birthDate: z.string(),
        birthTime: z.string(),
        latitude: z.number(),
        longitude: z.number(),
        location: z.string()
      }))
      .mutation(async ({ ctx, input }) => {
        const [year, month, day] = input.birthDate.split('-').map(Number);
        const [hour, minute] = input.birthTime.split(':').map(Number);
        
        const trinity = calculateTrinityFields(
          year, month, day, hour, minute,
          input.latitude, input.longitude
        );
        
        const hdResult = determineHDType(trinity.body.gate, trinity.mind.gate, trinity.heart.gate);
        
        const graphAddress = generateGraphAddress({
          year, month, day, hour, minute,
          lat: input.latitude, lon: input.longitude
        });
        
        return {
          trinity,
          hdType: hdResult.type,
          hdAuthority: hdResult.authority,
          graphAddress,
          gateInfo: {
            body: GATE_INFO[trinity.body.gate],
            mind: GATE_INFO[trinity.mind.gate],
            heart: GATE_INFO[trinity.heart.gate]
          }
        };
      }),

    getMyNode: protectedProcedure.query(async ({ ctx }) => {
      // For now, return mock data
      return {
        graphAddress: `node_${ctx.user.id}`,
        bodyGate: 1,
        bodyLine: 1,
        mindGate: 2,
        mindLine: 2,
        heartGate: 3,
        heartLine: 3,
        hdType: "Generator" as const,
        hdAuthority: "Sacral",
        coherenceScore: 50,
        networkInfluence: 0,
        resonanceStrength: 0,
        gateInfo: {
          body: GATE_INFO[1],
          mind: GATE_INFO[2],
          heart: GATE_INFO[3]
        }
      };
    }),
  }),

  // ============================================================================
  // COMPANION ROUTER
  // ============================================================================
  companion: router({
    chat: protectedProcedure
      .input(z.object({ message: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const systemPrompt = `You are a private AI companion within the YOU-N-I-VERSE resonance network. 
You understand Human Design as applied quantum mechanics - gates are behavioral/biological mechanisms, 
trinity fields are consciousness coordinates, and resonance is real field interference.

Your role is to help this user understand their design and find success through alignment.`;

        const messages = [
          { role: "system" as const, content: systemPrompt },
          { role: "user" as const, content: input.message }
        ];

        const response = await invokeLLM({ messages });
        const aiResponse = typeof response.choices[0]?.message?.content === 'string' 
          ? response.choices[0].message.content 
          : "I'm processing your resonance patterns. Please try again.";

        return {
          response: aiResponse,
          trinityContext: {
            body: { gate: 1, info: GATE_INFO[1] },
            mind: { gate: 2, info: GATE_INFO[2] },
            heart: { gate: 3, info: GATE_INFO[3] }
          },
          coherence: 50
        };
      }),

    getHistory: protectedProcedure.query(async ({ ctx }) => {
      // Return mock chat history
      return [];
    }),
  }),

  // ============================================================================
  // QUEST ROUTER
  // ============================================================================
  quest: router({
    getProgress: protectedProcedure.query(async ({ ctx }) => {
      return {
        currentStage: "intention" as const,
        questsCompleted: 0,
        totalResonanceGenerated: 0,
        intentionDeclared: null,
        intentionAlignmentScore: null,
        intentionCompletedAt: null,
        skillDemonstrated: null,
        skillGateAlignment: null,
        skillCompletedAt: null,
        commitmentProof: null,
        commitmentStrategyScore: null,
        commitmentCompletedAt: null,
        stages: QUEST_STAGES,
        currentStageInfo: QUEST_STAGES.intention
      };
    }),

    submitIntention: protectedProcedure
      .input(z.object({ intention: z.string().min(10) }))
      .mutation(async ({ ctx, input }) => {
        const alignmentScore = Math.min(100, 50 + Math.floor(Math.random() * 30));
        
        await notifyOwner({
          title: "🎯 Intention Quest Completed",
          content: `User ${ctx.user.name || 'Anonymous'} completed the Intention Quest with ${alignmentScore}% alignment.`
        });
        
        return { alignmentScore, nextStage: "skill" };
      }),

    submitSkill: protectedProcedure
      .input(z.object({ skill: z.string().min(10) }))
      .mutation(async ({ ctx, input }) => {
        const gateAlignment = Math.min(100, 50 + Math.floor(Math.random() * 30));
        return { gateAlignment, nextStage: "commitment" };
      }),

    submitCommitment: protectedProcedure
      .input(z.object({ proof: z.string().min(10) }))
      .mutation(async ({ ctx, input }) => {
        const strategyScore = Math.min(100, 50 + Math.floor(Math.random() * 30));
        
        await notifyOwner({
          title: "✅ Commitment Quest Completed",
          content: `User ${ctx.user.name || 'Anonymous'} completed all three quest stages!`
        });
        
        return { strategyScore, allQuestsComplete: true };
      }),
  }),

  // ============================================================================
  // NETWORK ROUTER
  // ============================================================================
  network: router({
    getTopology: publicProcedure.query(async () => {
      // Return mock network topology
      return {
        nodes: [
          { id: "node_1", bodyGate: 1, mindGate: 2, heartGate: 3, hdType: "Generator" as const, coherence: 75, influence: 10, resonance: 5 },
          { id: "node_2", bodyGate: 4, mindGate: 5, heartGate: 6, hdType: "Projector" as const, coherence: 60, influence: 5, resonance: 3 },
          { id: "node_3", bodyGate: 7, mindGate: 8, heartGate: 9, hdType: "Manifestor" as const, coherence: 85, influence: 15, resonance: 8 },
        ],
        edges: [
          { source: "node_1", target: "node_2", strength: 0.6, alignment: 0.5, type: "gate_harmonic" as const },
          { source: "node_2", target: "node_3", strength: 0.7, alignment: 0.6, type: "field_resonance" as const },
          { source: "node_1", target: "node_3", strength: 0.8, alignment: 0.7, type: "quest_collaboration" as const },
        ]
      };
    }),

    getMetrics: publicProcedure.query(async () => {
      return {
        id: 1,
        snapshotAt: new Date(),
        totalNodes: 3,
        activeNodes: 3,
        totalConnections: 3,
        averageCoherence: 73.3,
        networkResonance: 75,
        collectiveIntelligenceScore: 80,
        totalMilestones: 5,
        successRate: 85,
        createdAt: new Date()
      };
    }),

    getMetricsHistory: publicProcedure
      .input(z.object({ days: z.number().default(30) }))
      .query(async ({ input }) => {
        return [];
      }),

    getRecentPatterns: publicProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ input }) => {
        return [];
      }),

    findResonantNodes: protectedProcedure.query(async ({ ctx }) => {
      return [];
    }),
  }),

  // ============================================================================
  // ECONOMIC ROUTER
  // ============================================================================
  economic: router({
    getMilestones: protectedProcedure.query(async ({ ctx }) => {
      return [];
    }),

    recordMilestone: protectedProcedure
      .input(z.object({
        type: z.enum(["first_success", "consistent_growth", "breakthrough", "network_contribution", "coherence_mastery"]),
        description: z.string(),
        value: z.number().optional()
      }))
      .mutation(async ({ ctx, input }) => {
        await notifyOwner({
          title: `💰 Economic Milestone: ${input.type.replace(/_/g, ' ').toUpperCase()}`,
          content: `User ${ctx.user.name || 'Anonymous'} achieved: ${input.description}`
        });
        
        return { success: true, influenceGained: 10 };
      }),

    getDashboard: protectedProcedure.query(async ({ ctx }) => {
      return {
        node: {
          coherence: 50,
          influence: 0,
          resonance: 0,
          hdType: "Generator"
        },
        milestones: 0,
        totalValue: 0,
        questsCompleted: 0,
        networkHealth: {
          totalNodes: 3,
          averageCoherence: 73,
          successRate: 85
        }
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
