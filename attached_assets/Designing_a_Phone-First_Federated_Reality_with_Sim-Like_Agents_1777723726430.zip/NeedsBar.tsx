import { cn } from "@/lib/utils";

interface NeedsBarProps {
  label: string;
  value: number; // 0-100
  color: string;
  icon: string;
  compact?: boolean;
}

export function NeedsBar({ label, value, color, icon, compact = false }: NeedsBarProps) {
  const pct = Math.max(0, Math.min(100, value));
  const isLow = pct < 25;
  const isMedium = pct >= 25 && pct < 50;

  return (
    <div className={cn("flex items-center gap-2", compact ? "gap-1.5" : "gap-2")}>
      <span className={cn("shrink-0", compact ? "text-xs" : "text-sm")}>{icon}</span>
      {!compact && (
        <span className="text-xs text-muted-foreground w-14 shrink-0">{label}</span>
      )}
      <div className={cn("flex-1 rounded-full overflow-hidden", compact ? "h-1.5" : "h-2")}
        style={{ background: "oklch(0.2 0.01 260)" }}>
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${pct}%`,
            background: isLow
              ? "oklch(0.55 0.2 25)"
              : isMedium
              ? "oklch(0.7 0.18 60)"
              : color,
          }}
        />
      </div>
      {!compact && (
        <span className={cn("text-xs font-mono w-7 text-right shrink-0",
          isLow ? "text-red-400" : isMedium ? "text-amber-400" : "text-muted-foreground"
        )}>
          {Math.round(pct)}
        </span>
      )}
    </div>
  );
}

interface AgentNeedsProps {
  needs: {
    hunger: number;
    energy: number;
    social: number;
    fun: number;
    hygiene: number;
    comfort: number;
  };
  compact?: boolean;
}

export function AgentNeeds({ needs, compact = false }: AgentNeedsProps) {
  const needsList = [
    { key: "hunger", label: "Hunger", icon: "🍽️", color: "oklch(0.7 0.18 50)" },
    { key: "energy", label: "Energy", icon: "⚡", color: "oklch(0.8 0.18 90)" },
    { key: "social", label: "Social", icon: "💬", color: "oklch(0.65 0.18 240)" },
    { key: "fun", label: "Fun", icon: "🎉", color: "oklch(0.65 0.22 340)" },
    { key: "hygiene", label: "Hygiene", icon: "🚿", color: "oklch(0.65 0.18 200)" },
    { key: "comfort", label: "Comfort", icon: "🛋️", color: "oklch(0.65 0.18 160)" },
  ];

  return (
    <div className={cn("flex flex-col", compact ? "gap-1" : "gap-2")}>
      {needsList.map(n => (
        <NeedsBar
          key={n.key}
          label={n.label}
          value={(needs as any)[n.key] ?? 50}
          color={n.color}
          icon={n.icon}
          compact={compact}
        />
      ))}
    </div>
  );
}
