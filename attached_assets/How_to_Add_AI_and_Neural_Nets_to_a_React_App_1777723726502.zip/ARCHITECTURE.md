# AI Self-Builder: Comprehensive Architecture Design

**Author**: Manus AI  
**Date**: April 2026  
**Status**: Design Phase

---

## Executive Summary

The AI Self-Builder is an intelligent, self-learning application that transcends simple heuristics by embedding a real Python neural brain powered by PyTorch. The system ingests PDF documents containing concepts, architectural diagrams, and code snippets, then learns isomorphic relationships between these elements through a Graph Isomorphism Network (GIN). This learned knowledge informs LLM-driven code generation, creating a hybrid intelligence system where pattern discovery and semantic reasoning work in concert.

The architecture separates concerns into three tiers: a React frontend for user interaction, an Express.js/tRPC backend for orchestration and LLM integration, and a FastAPI microservice hosting the PyTorch neural brain for isomorphic reasoning and pattern discovery.

---

## System Architecture

### High-Level Overview

```
┌──────────────────────────────────────────────────────────────────┐
│                     React Frontend (Vite)                        │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ • PDF Upload (drag-and-drop)                               │  │
│  │ • Chat Interface (knowledge queries)                        │  │
│  │ • Code Preview (syntax highlighting)                       │  │
│  │ • Neural Dashboard (metrics & visualization)               │  │
│  │ • Adaptive Suggestions (pattern recommendations)           │  │
│  └────────────────────────────────────────────────────────────┘  │
└────────────────────────┬─────────────────────────────────────────┘
                         │ HTTP/REST (tRPC)
┌────────────────────────▼─────────────────────────────────────────┐
│            Express.js + tRPC Backend (Node.js)                   │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ • PDF Parsing & Text Extraction                            │  │
│  │ • LLM Integration (concept & code extraction)              │  │
│  │ • User Authentication & Authorization                      │  │
│  │ • Knowledge Base Orchestration                             │  │
│  │ • Code Generation Pipeline                                 │  │
│  │ • Neural Brain Coordination                                │  │
│  └────────────────────────────────────────────────────────────┘  │
└────────────────────────┬─────────────────────────────────────────┘
                         │ HTTP/REST
┌────────────────────────▼─────────────────────────────────────────┐
│        FastAPI Neural Brain Microservice (Python)                │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │ PyTorch Neural Network Engine                              │  │
│  │ • Graph Isomorphism Networks (GIN)                         │  │
│  │ • Sentence Transformers (semantic embeddings)             │  │
│  │ • Contrastive Learning (pattern discovery)                │  │
│  │ • Isomorphic Reasoning (structural equivalence)           │  │
│  │ • Adaptive Suggestion Generation                          │  │
│  └────────────────────────────────────────────────────────────┘  │
└────────────────────────┬─────────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
┌───────▼──────┐  ┌──────▼──────┐  ┌────▼──────────┐
│   MySQL DB   │  │ Vector DB   │  │ S3 Storage   │
│ (Knowledge   │  │ (Embeddings)│  │ (PDFs, Code) │
│  Base)       │  │             │  │              │
└──────────────┘  └─────────────┘  └──────────────┘
```

---

## Component Specifications

### 1. React Frontend (Vite + TypeScript)

**Responsibilities**:
- User interface for PDF upload and document management
- Real-time chat interface for querying the knowledge base
- Code preview with syntax highlighting and apply/save mechanisms
- Neural dashboard displaying training progress and knowledge graph
- Adaptive suggestion panel showing related concepts and patterns

**Key Components**:

| Component | Purpose | State Management |
|-----------|---------|------------------|
| `PDFUploader` | Drag-and-drop PDF ingestion | React Query (tRPC) |
| `ChatInterface` | Natural language queries | React Context + tRPC |
| `CodePreview` | Display generated code | Local state + clipboard |
| `NeuralDashboard` | Training metrics & graphs | React Query (polling) |
| `AdaptiveSuggestions` | Pattern recommendations | React Query (polling) |
| `KnowledgeGraph` | Concept relationship visualization | D3.js / Vis.js |

**Technology Stack**:
- React 19 with Hooks
- Tailwind CSS 4 for styling
- shadcn/ui for component library
- Syntax highlighting: Prism.js or Highlight.js
- Graph visualization: D3.js or Vis.js

---

### 2. Express.js + tRPC Backend

**Responsibilities**:
- Orchestrate PDF upload and parsing
- Coordinate LLM calls for concept/code extraction
- Manage user authentication and authorization
- Persist knowledge base entries
- Route requests to neural brain microservice
- Generate code using LLM informed by neural patterns

**tRPC Procedures**:

| Procedure | Input | Output | Purpose |
|-----------|-------|--------|---------|
| `pdf.upload` | File buffer, metadata | `{ docId, status }` | Ingest PDF |
| `pdf.parse` | `docId` | `{ concepts, codeBlocks }` | Extract content |
| `knowledge.query` | Query string | `{ results, patterns }` | Search knowledge base |
| `code.generate` | Prompt, context | `{ code, explanation }` | Generate code |
| `neural.train` | Training data | `{ accuracy, loss }` | Train neural model |
| `neural.suggest` | Context | `{ suggestions }` | Get recommendations |
| `dashboard.metrics` | None | `{ metrics, history }` | Get training metrics |

**Key Workflows**:

**PDF Ingestion Workflow**:
1. User uploads PDF via `PDFUploader` component
2. Frontend calls `pdf.upload` tRPC procedure
3. Backend stores PDF in S3, extracts text
4. Backend calls LLM to extract concepts and code blocks
5. Backend sends extracted data to neural brain for embedding
6. Neural brain returns embeddings; backend stores in vector DB
7. Frontend receives confirmation and updates dashboard

**Code Generation Workflow**:
1. User enters prompt in chat interface
2. Frontend calls `code.generate` tRPC procedure
3. Backend queries knowledge base for relevant patterns
4. Backend calls neural brain to find isomorphic patterns
5. Backend uses LLM with pattern context to generate code
6. Backend returns generated code to frontend
7. Frontend displays code with syntax highlighting

---

### 3. FastAPI Neural Brain Microservice (Python)

**Responsibilities**:
- Train PyTorch models on ingested knowledge
- Compute semantic embeddings for concepts and code
- Identify isomorphic relationships between structures
- Generate adaptive suggestions based on learned patterns
- Provide inference endpoints for pattern discovery

**Core Modules**:

#### 3.1 Embedding Engine
- **Input**: Concepts, code snippets, architectural descriptions
- **Process**: Sentence Transformers (pre-trained) for semantic embeddings
- **Output**: 384-dimensional embeddings (or configurable)
- **Storage**: Vector database (Pinecone, Weaviate, or in-memory for MVP)

#### 3.2 Graph Isomorphism Network (GIN)
- **Architecture**: PyTorch Geometric implementation
- **Input**: Knowledge graph (nodes = concepts/code, edges = relationships)
- **Process**: Multi-layer GIN to learn node representations
- **Output**: Node embeddings capturing structural equivalence
- **Training**: Contrastive learning with positive/negative pairs

#### 3.3 Isomorphic Reasoning Engine
- **Input**: Two code structures or concept hierarchies
- **Process**: Compare learned node embeddings, identify structural equivalences
- **Output**: Isomorphism score, mapping between equivalent elements
- **Use Case**: Discover that two different code implementations solve the same problem

#### 3.4 Adaptive Suggestion Generator
- **Input**: Current context (user query, code snippet, concept)
- **Process**: Query neural model for similar patterns, rank by relevance
- **Output**: Ranked list of related concepts, code patterns, next steps
- **Integration**: Feeds into frontend's adaptive suggestion panel

**API Endpoints**:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/embed` | POST | Compute embeddings for text/code |
| `/train` | POST | Train neural model on knowledge graph |
| `/infer` | POST | Perform isomorphic pattern discovery |
| `/suggest` | POST | Generate adaptive suggestions |
| `/health` | GET | Service health check |
| `/metrics` | GET | Training metrics and statistics |

**Example Request/Response**:

```json
POST /infer
{
  "structure_a": {
    "type": "code",
    "content": "function map(arr, fn) { return arr.map(fn); }"
  },
  "structure_b": {
    "type": "code",
    "content": "const transform = (list, callback) => list.map(callback);"
  }
}

Response:
{
  "isomorphic": true,
  "confidence": 0.94,
  "mapping": {
    "arr": "list",
    "fn": "callback",
    "map": "map"
  },
  "explanation": "Both implement array transformation with a callback function"
}
```

---

## Data Models

### Knowledge Base Schema

**Concepts Table**:
```sql
CREATE TABLE concepts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  source_doc_id INT,
  embedding VECTOR(384),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (source_doc_id) REFERENCES documents(id)
);
```

**Code Blocks Table**:
```sql
CREATE TABLE code_blocks (
  id INT PRIMARY KEY AUTO_INCREMENT,
  language VARCHAR(50),
  code TEXT NOT NULL,
  description TEXT,
  source_doc_id INT,
  embedding VECTOR(384),
  pattern_type VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (source_doc_id) REFERENCES documents(id)
);
```

**Relationships Table**:
```sql
CREATE TABLE relationships (
  id INT PRIMARY KEY AUTO_INCREMENT,
  source_id INT NOT NULL,
  source_type ENUM('concept', 'code_block'),
  target_id INT NOT NULL,
  target_type ENUM('concept', 'code_block'),
  relationship_type VARCHAR(100),
  confidence FLOAT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (source_id) REFERENCES concepts(id) OR code_blocks(id),
  FOREIGN KEY (target_id) REFERENCES concepts(id) OR code_blocks(id)
);
```

**Documents Table**:
```sql
CREATE TABLE documents (
  id INT PRIMARY KEY AUTO_INCREMENT,
  filename VARCHAR(255),
  file_path VARCHAR(500),
  user_id INT,
  ingestion_status ENUM('pending', 'processing', 'completed', 'failed'),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);
```

---

## Integration Points

### Frontend ↔ Backend (tRPC)

All communication uses tRPC with automatic type safety. Procedures are defined in `server/routers.ts` and consumed via `trpc.*` hooks in React components.

**Example**:
```typescript
// Backend (server/routers.ts)
export const appRouter = router({
  pdf: router({
    upload: protectedProcedure
      .input(z.object({ file: z.instanceof(File), metadata: z.record(z.string()) }))
      .mutation(async ({ input, ctx }) => {
        // Handle PDF upload
      }),
  }),
});

// Frontend (client/src/pages/PDFUploader.tsx)
const { mutate: uploadPDF } = trpc.pdf.upload.useMutation();
uploadPDF({ file, metadata: { title: "Mew.pdf" } });
```

### Backend ↔ Neural Brain (HTTP REST)

The Express backend communicates with the FastAPI neural brain via HTTP requests.

**Example**:
```typescript
// Backend (server/routers.ts)
const neuralBrainResponse = await fetch(`${NEURAL_BRAIN_URL}/infer`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    structure_a: extractedConcept1,
    structure_b: extractedConcept2,
  }),
});
```

---

## Knowledge Accumulation & Learning

### Training Loop

1. **Ingestion**: PDF uploaded, text extracted, LLM identifies concepts and code blocks
2. **Embedding**: Each concept/code block converted to semantic embedding
3. **Graph Construction**: Relationships identified between elements
4. **Neural Training**: GIN trained on knowledge graph to learn structural patterns
5. **Persistence**: Embeddings and learned patterns stored in database
6. **Inference**: New queries compared against learned patterns for suggestions

### Isomorphic Reasoning Process

When the system encounters a new code snippet or concept:

1. **Embedding**: Convert to semantic embedding
2. **Similarity Search**: Find similar patterns in knowledge base
3. **Structural Analysis**: Use GIN to identify isomorphic structures
4. **Pattern Mapping**: Discover equivalent elements across different implementations
5. **Suggestion Generation**: Propose related concepts, alternative implementations, next steps

---

## Deployment & Scalability

### Development Environment

- **Frontend**: Vite dev server on `localhost:5173`
- **Backend**: Express on `localhost:3000`
- **Neural Brain**: FastAPI on `localhost:8001`
- **Database**: MySQL on `localhost:3306`
- **Vector DB**: In-memory (MVP) or Pinecone (production)

### Production Deployment

- **Frontend**: Static hosting (Vercel, Netlify, or Manus platform)
- **Backend**: Container (Docker) on serverless (AWS Lambda, Google Cloud Run) or traditional server
- **Neural Brain**: Dedicated container with GPU support (NVIDIA CUDA)
- **Database**: Managed MySQL (AWS RDS, Google Cloud SQL)
- **Vector DB**: Managed service (Pinecone, Weaviate Cloud)

---

## Security & Privacy

- **Authentication**: Manus OAuth with JWT tokens
- **Authorization**: Role-based access control (user, admin)
- **Data Encryption**: TLS for all network communication
- **PDF Storage**: Encrypted in S3 with user-specific access controls
- **Embeddings**: Stored separately from raw content; embeddings are non-invertible
- **Neural Model**: Runs in isolated container; no direct access to raw data

---

## Performance Considerations

| Operation | Target Latency | Strategy |
|-----------|-----------------|----------|
| PDF Upload | < 2s | Async processing, S3 direct upload |
| Concept Extraction | < 5s | Batch LLM calls, caching |
| Code Generation | < 3s | Cached patterns, streaming response |
| Embedding Computation | < 100ms | Pre-computed, vector DB indexing |
| Isomorphic Inference | < 500ms | GIN inference optimization, batching |

---

## Next Steps

1. **Phase 3**: Implement React frontend with PDF upload, chat, and dashboard
2. **Phase 4**: Build FastAPI neural brain with PyTorch models
3. **Phase 5**: Integrate frontend and backend with tRPC procedures
4. **Phase 6**: Polish UI, add visualizations, seed with Mew.pdf
5. **Phase 7**: Deploy and document

---

## References

- [Graph Isomorphism Networks](https://arxiv.org/abs/1810.00826)
- [Sentence Transformers](https://www.sbert.net/)
- [PyTorch Geometric](https://pytorch-geometric.readthedocs.io/)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [tRPC Documentation](https://trpc.io/)
