# Kimi Agent: Complete Setup Guide

## 🎯 Choose Your Setup Method

Pick the option that works best for you:

---

## Option 1: Local Development (Fastest - 2 minutes)

### For Mac/Linux:
```bash
cd kimi-agent-upgraded
./bootstrap.sh
pnpm dev
```

### For Windows:
```bash
cd kimi-agent-upgraded
pnpm install
pnpm dev
```

**Then open:** http://localhost:3000

---

## Option 2: Docker (Zero Config - 3 minutes)

### Prerequisites:
- Install [Docker Desktop](https://www.docker.com/products/docker-desktop)

### Run:
```bash
cd kimi-agent-upgraded
docker-compose up
```

**Then open:** http://localhost:3000

The database starts automatically. Everything is configured.

---

## Option 3: Manual Setup (Full Control)

### Step 1: Install Node.js
Download from [nodejs.org](https://nodejs.org) (version 18+)

### Step 2: Install Dependencies
```bash
cd kimi-agent-upgraded
npm install
# or
pnpm install
```

### Step 3: Set Up Database
The app uses MySQL. You can:

**Option A: Use existing MySQL**
```bash
# Create database
mysql -u root -p -e "CREATE DATABASE kimi_agent;"
```

**Option B: Use Docker just for database**
```bash
docker run -d \
  --name kimi-db \
  -e MYSQL_ROOT_PASSWORD=password \
  -e MYSQL_DATABASE=kimi_agent \
  -p 3306:3306 \
  mysql:8.0
```

### Step 4: Configure Environment
```bash
# Copy example to .env (secrets are auto-injected)
cp .env.example .env
```

### Step 5: Start Development Server
```bash
pnpm dev
```

**Then open:** http://localhost:3000

---

## 🚀 Quick Commands

| Command | Purpose |
|---------|---------|
| `pnpm dev` | Start dev server with hot reload |
| `pnpm build` | Build for production |
| `pnpm start` | Run production build |
| `pnpm test` | Run all 36 tests |
| `pnpm check` | Check TypeScript errors |
| `pnpm format` | Format code with Prettier |

---

## 📱 Mobile Testing

### Test on Phone (Same Network):
1. Find your computer's IP:
   - **Mac/Linux:** `ifconfig \| grep "inet "`
   - **Windows:** `ipconfig` (look for IPv4 Address)

2. On your phone, visit: `http://YOUR_IP:3000`

### Test in Browser DevTools:
1. Press `F12` to open DevTools
2. Click the phone icon (Toggle device toolbar)
3. Select a device to test

---

## ✅ Verify Everything Works

### Run Tests:
```bash
pnpm test
```

**Expected output:**
```
Test Files  4 passed (4)
Tests  36 passed (36)
```

### Check TypeScript:
```bash
pnpm check
```

**Expected output:**
```
No errors found
```

---

## 🐛 Troubleshooting

### Port 3000 Already in Use?
```bash
# Use a different port
PORT=3001 pnpm dev
```

### Can't Connect to Database?
```bash
# Check if MySQL is running
# If using Docker:
docker ps | grep mysql

# If using local MySQL:
mysql -u root -p -e "SELECT 1;"
```

### Dependencies Won't Install?
```bash
# Clear cache
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Hot Reload Not Working?
```bash
# Restart dev server
pnpm dev
```

---

## 📊 What You Get

✅ **React 19** - Latest React with hooks  
✅ **TensorFlow.js** - Real neural network  
✅ **Monaco Editor** - Professional code editor  
✅ **Tailwind CSS 4** - Utility-first styling  
✅ **tRPC** - Type-safe API calls  
✅ **MySQL** - Persistent database  
✅ **36 Tests** - Full test coverage  
✅ **Mobile-First** - Works on all devices  
✅ **Dark Cyberpunk Theme** - Violet/fuchsia accents  
✅ **Hot Reload** - Changes save instantly  

---

## 🎨 First Time Using the App?

1. **Paste Code** → Click Monaco Editor, paste JavaScript/TypeScript
2. **Watch Learn** → Real-time metrics show GNN training
3. **Review Proposals** → AI generates code improvements
4. **Approve & Execute** → Apply proposals to improve code
5. **Track Goals** → GNN sets autonomous improvement targets

---

## 📚 Project Structure

```
kimi-agent-upgraded/
├── client/           # React frontend (mobile-first)
├── server/           # Express backend + GNN
├── drizzle/          # Database schema
├── QUICKSTART.md     # 5-minute quick start
├── SETUP.md          # This file
├── bootstrap.sh      # One-command setup
├── Dockerfile        # Docker image
├── docker-compose.yml # Full stack with database
└── package.json      # Dependencies
```

---

## 🚀 Next Steps

1. **Start the app** using Option 1, 2, or 3 above
2. **Explore the code** in `client/src/pages/KimiBuilder.tsx`
3. **Modify the GNN** in `server/gnn/core.ts`
4. **Add features** by creating components in `client/src/components/`
5. **Deploy** using the Manus UI's Publish button

---

## 💡 Pro Tips

- **Hot reload:** Dev server auto-reloads on file changes
- **Database persists:** Trained weights survive restarts
- **Tests included:** Run `pnpm test` anytime to verify
- **Mobile first:** Design on phone, scale to desktop
- **LLM toggle:** Settings → disable LLM for GNN-only mode

---

## ❓ Still Need Help?

1. Check the logs in your terminal
2. Run `pnpm check` to verify TypeScript
3. Run `pnpm test` to verify all features
4. Review `QUICKSTART.md` for common issues
5. Check `todo.md` for feature documentation

---

**You're ready! Pick an option above and start building.** 🚀
