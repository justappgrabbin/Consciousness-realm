import { useLocation } from "wouter";

export default function NotFound() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 text-center">
      <div className="text-6xl mb-6 opacity-60">🌌</div>
      <h1 className="text-3xl font-bold text-foreground mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
        404
      </h1>
      <p className="text-muted-foreground mb-6 text-sm">
        This corner of the world doesn't exist yet.
      </p>
      <button
        onClick={() => navigate("/")}
        className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm"
      >
        ← Return to the world
      </button>
    </div>
  );
}
