import { Upload } from "lucide-react";
import { Card } from "@/components/ui/card";

interface FileUploadZoneProps {
  onUploadClick: () => void;
}

export function FileUploadZone({ onUploadClick }: FileUploadZoneProps) {
  return (
    <Card
      className="border-2 border-dashed border-border hover-elevate active-elevate-2 cursor-pointer transition-colors min-h-96 flex flex-col items-center justify-center gap-6 p-12"
      onClick={onUploadClick}
      data-testid="zone-file-upload"
    >
      <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
        <Upload className="w-10 h-10 text-primary" />
      </div>
      
      <div className="text-center space-y-2">
        <h3 className="text-xl font-semibold">Drop files here or click to browse</h3>
        <p className="text-muted-foreground">
          Upload your code, books, documentation, and resources
        </p>
      </div>
      
      <div className="flex flex-wrap gap-2 justify-center text-sm text-muted-foreground">
        <span className="px-3 py-1 rounded-md bg-muted">.js</span>
        <span className="px-3 py-1 rounded-md bg-muted">.py</span>
        <span className="px-3 py-1 rounded-md bg-muted">.pdf</span>
        <span className="px-3 py-1 rounded-md bg-muted">.epub</span>
        <span className="px-3 py-1 rounded-md bg-muted">.zip</span>
        <span className="px-3 py-1 rounded-md bg-muted">.txt</span>
        <span className="px-3 py-1 rounded-md bg-muted">.md</span>
      </div>
    </Card>
  );
}
