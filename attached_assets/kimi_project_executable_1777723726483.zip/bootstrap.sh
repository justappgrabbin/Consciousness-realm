#!/bin/bash

# Kimi Agent: One-Command Bootstrap Script
# Usage: ./bootstrap.sh

set -e

echo "🚀 Kimi Agent - Mobile-First React App Bootstrap"
echo "=================================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install it from https://nodejs.org"
    exit 1
fi

echo "✅ Node.js detected: $(node --version)"
echo ""

# Check if pnpm or npm is available
if command -v pnpm &> /dev/null; then
    PM="pnpm"
    echo "✅ Using pnpm: $(pnpm --version)"
else
    PM="npm"
    echo "✅ Using npm: $(npm --version)"
fi

echo ""
echo "📦 Installing dependencies..."
echo "This may take 2-3 minutes on first run..."
echo ""

$PM install

echo ""
echo "✅ Dependencies installed successfully!"
echo ""
echo "🎯 Next steps:"
echo ""
echo "   1. Start the development server:"
echo "      $PM dev"
echo ""
echo "   2. Open your browser to:"
echo "      http://localhost:3000"
echo ""
echo "   3. Paste code into the Monaco Editor"
echo "   4. Watch the GNN analyze and learn"
echo "   5. Review AI-generated improvement proposals"
echo ""
echo "📱 For mobile testing:"
echo "   Find your computer's IP and visit: http://YOUR_IP:3000"
echo ""
echo "📚 Full guide: Read QUICKSTART.md"
echo ""
echo "=================================================="
echo "Ready to go! 🚀"
echo ""
