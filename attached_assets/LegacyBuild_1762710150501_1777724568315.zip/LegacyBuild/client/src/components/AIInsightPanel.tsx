import { Sparkles, BookOpen } from "lucide-react";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { BookReference } from "@shared/schema";

interface AIInsightPanelProps {
  bookReferences: BookReference[];
}

export function AIInsightPanel({ bookReferences }: AIInsightPanelProps) {
  return (
    <Card className="p-6 border-primary/20 bg-primary/5">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold">AI Commentary & Book References</h3>
          <p className="text-sm text-muted-foreground">Insights from referenced literature</p>
        </div>
      </div>

      <ScrollArea className="h-[400px] pr-4">
        <div className="space-y-4">
          {bookReferences.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <BookOpen className="w-12 h-12 mx-auto mb-3" />
              <p className="text-sm">No book references yet</p>
            </div>
          ) : (
            bookReferences.map((ref, index) => (
              <Card key={index} className="p-4" data-testid={`book-ref-${index}`}>
                <div className="flex items-start gap-3">
                  <BookOpen className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm mb-1">{ref.title}</h4>
                    <p className="text-xs text-muted-foreground mb-2">by {ref.author}</p>
                    <blockquote className="border-l-2 border-primary pl-3 text-sm italic mb-2">
                      "{ref.quote}"
                    </blockquote>
                    <p className="text-sm text-muted-foreground">{ref.relevance}</p>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}
