import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { useState } from "react";
import { AgentAvatar } from "@/components/AgentAvatar";
import { MoodBadge } from "@/components/MoodBadge";

const ACTIVITY_EMOJI: Record<string, string> = {
  eating: "🍽️", sleeping: "😴", working: "💼", socializing: "💬",
  exercising: "🏃", relaxing: "🛋️", bathing: "🚿", creative: "🎨",
  idle: "💤",
};

function AgentCard({ agent, mood, needs, onClick }: {
  agent: {
    id: number;
    name: string;
    age: number;
    job: string;
    avatarSeed: string;
    currentActivity: string;
    currentLocation: string;
    districtId: number;
  };
  mood?: { mood: string; dominantEmotion: string; moodScore: number } | null;
  needs?: { hunger: number; energy: number; social: number; fun: number } | null;
  onClick: () => void;
}) {
  const lowestNeed = needs ? Object.entries({
    hunger: needs.hunger,
    energy: needs.energy,
    social: needs.social,
    fun: needs.fun,
  }).sort(([, a], [, b]) => a - b)[0] : null;

  const needsAlert = lowestNeed && lowestNeed[1] < 25;

  return (
    <button
      onClick={onClick}
      className="w-full rounded-2xl p-4 border border-border/40 text-left transition-all duration-200 active:scale-[0.98]"
      style={{ background: "oklch(0.12 0.012 260)" }}
    >
      <div className="flex items-start gap-3">
        <AgentAvatar
          seed={agent.avatarSeed}
          name={agent.name}
          size="md"
          mood={mood?.mood}
        />

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="font-semibold text-foreground text-sm" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                {agent.name}
              </h3>
              <p className="text-xs text-muted-foreground">{agent.age}yo · {agent.job}</p>
            </div>
            {mood && (
              <MoodBadge mood={mood.mood} size="sm" showLabel={false} />
            )}
          </div>

          <div className="flex items-center gap-2 mt-2">
            <span className="text-sm">{ACTIVITY_EMOJI[agent.currentActivity] ?? "✨"}</span>
            <span className="text-xs text-muted-foreground capitalize">
              {agent.currentActivity === "idle" ? "Idle" : agent.currentActivity}
            </span>
            <span className="text-muted-foreground/40 text-xs">·</span>
            <span className="text-xs text-muted-foreground">{agent.currentLocation}</span>
          </div>

          {/* Mini needs bars */}
          {needs && (
            <div className="flex gap-1 mt-2">
              {[
                { key: "hunger", icon: "🍽️", val: needs.hunger, color: "bg-orange-400" },
                { key: "energy", icon: "⚡", val: needs.energy, color: "bg-yellow-400" },
                { key: "social", icon: "💬", val: needs.social, color: "bg-blue-400" },
                { key: "fun", icon: "🎉", val: needs.fun, color: "bg-pink-400" },
              ].map(n => (
                <div key={n.key} className="flex-1 relative">
                  <div className="h-1 rounded-full overflow-hidden" style={{ background: "oklch(0.2 0.01 260)" }}>
                    <div
                      className={cn("h-full rounded-full transition-all duration-500", n.val < 25 ? "bg-red-400" : n.color)}
                      style={{ width: `${n.val}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {needsAlert && (
        <div className="mt-2 flex items-center gap-1.5 text-xs text-red-400">
          <span>⚠️</span>
          <span>Low {lowestNeed![0]} ({Math.round(lowestNeed![1])})</span>
        </div>
      )}
    </button>
  );
}

export default function AgentsList() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterDistrict, setFilterDistrict] = useState<number | null>(null);

  const { data: agents = [], isLoading } = trpc.agents.list.useQuery(undefined, {
    refetchInterval: 8000,
  });

  const { data: districts = [] } = trpc.world.districts.useQuery();

  // Fetch moods and needs for all agents
  const agentIds = agents.map(a => a.id);

  const filteredAgents = agents.filter(agent => {
    const matchesSearch = !searchQuery ||
      agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      agent.job.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDistrict = !filterDistrict || agent.districtId === filterDistrict;
    return matchesSearch && matchesDistrict;
  });

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen bg-background">
        <div className="px-4 pt-12 pb-3">
          <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>Agents</h1>
        </div>
        <div className="px-3 space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-24 rounded-2xl shimmer" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-20 px-4 pt-12 pb-3"
        style={{ background: "oklch(0.08 0.01 260 / 0.95)", backdropFilter: "blur(20px)" }}>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Agents
            </h1>
            <p className="text-xs text-muted-foreground">{agents.length} inhabitants</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-2">
          <input
            type="text"
            placeholder="Search by name or job..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full rounded-xl px-4 py-2.5 text-sm bg-secondary border border-border/40 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary/50"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              ✕
            </button>
          )}
        </div>

        {/* District filter */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setFilterDistrict(null)}
            className={cn(
              "shrink-0 px-3 py-1 rounded-full text-xs font-medium transition-all",
              !filterDistrict ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
            )}
          >
            All
          </button>
          {districts.map(d => (
            <button
              key={d.id}
              onClick={() => setFilterDistrict(filterDistrict === d.id ? null : d.id)}
              className={cn(
                "shrink-0 px-3 py-1 rounded-full text-xs font-medium transition-all",
                filterDistrict === d.id ? "text-white" : "bg-secondary text-muted-foreground"
              )}
              style={filterDistrict === d.id ? { background: d.color } : {}}
            >
              {d.name.split(" ")[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Agent list */}
      <div className="flex-1 px-3 pb-24 pt-2 space-y-2">
        {filteredAgents.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="text-4xl mb-3">🔍</div>
            <p className="text-muted-foreground text-sm">No agents found</p>
          </div>
        ) : (
          filteredAgents.map(agent => (
            <AgentCardWithData
              key={agent.id}
              agent={agent}
              onClick={() => navigate(`/agents/${agent.id}`)}
            />
          ))
        )}
      </div>
    </div>
  );
}

function AgentCardWithData({ agent, onClick }: {
  agent: any;
  onClick: () => void;
}) {
  const { data: mood } = trpc.agents.mood.useQuery({ id: agent.id }, {
    refetchInterval: 10000,
  });
  const { data: needs } = trpc.agents.needs.useQuery({ id: agent.id }, {
    refetchInterval: 10000,
  });

  return (
    <AgentCard
      agent={agent}
      mood={mood}
      needs={needs}
      onClick={onClick}
    />
  );
}
