import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ReportsTabs } from "@/components/ReportsTabs";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Project, ProcessingResult, UnusedFile, MonetizationSuggestion, NextStepRecommendation } from "@shared/schema";

export default function Reports() {
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  // Find the most recent project with completed status, or just the most recent one
  const defaultProject = projects.find(p => p.status === 'completed') || projects[0];
  const [selectedProjectId, setSelectedProjectId] = useState<string | undefined>(defaultProject?.id);

  const currentProject = projects.find(p => p.id === selectedProjectId) || defaultProject;

  const { data: processingResults = [] } = useQuery<ProcessingResult[]>({
    queryKey: ['/api/projects', currentProject?.id, 'processing-results'],
    enabled: !!currentProject?.id,
  });

  const { data: unusedFiles = [] } = useQuery<UnusedFile[]>({
    queryKey: ['/api/projects', currentProject?.id, 'unused-files'],
    enabled: !!currentProject?.id,
  });

  const { data: monetizationData } = useQuery<{ suggestions: MonetizationSuggestion[] }>({
    queryKey: ['/api/projects', currentProject?.id, 'monetization'],
    enabled: !!currentProject?.id,
  });

  const { data: nextStepsData } = useQuery<{ steps: NextStepRecommendation[] }>({
    queryKey: ['/api/projects', currentProject?.id, 'next-steps'],
    enabled: !!currentProject?.id,
  });

  if (!currentProject) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">No Project Found</h2>
          <p className="text-muted-foreground">Create a project to view reports</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold mb-2">Project Reports</h1>
          <p className="text-muted-foreground">
            Comprehensive analysis and insights
          </p>
        </div>
        
        {projects.length > 1 && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" data-testid="button-select-project">
                {currentProject.name}
                <ChevronDown className="w-4 h-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              {projects.map((project) => (
                <DropdownMenuItem
                  key={project.id}
                  onClick={() => setSelectedProjectId(project.id)}
                  data-testid={`menu-project-${project.id}`}
                >
                  <div className="flex flex-col gap-1">
                    <span className="font-medium">{project.name}</span>
                    <span className="text-xs text-muted-foreground capitalize">{project.status}</span>
                  </div>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      {processingResults.length === 0 && unusedFiles.length === 0 && 
       !monetizationData?.suggestions?.length && !nextStepsData?.steps?.length ? (
        <Card className="p-12 text-center">
          <h3 className="text-lg font-semibold mb-2">No Reports Available Yet</h3>
          <p className="text-muted-foreground mb-4">
            This project hasn't been processed yet. Process your files to generate reports.
          </p>
        </Card>
      ) : (
        <ReportsTabs
          processingResults={processingResults}
          unusedFiles={unusedFiles}
          monetizationSuggestions={monetizationData?.suggestions || []}
          nextSteps={nextStepsData?.steps || []}
        />
      )}
    </div>
  );
}
