import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Clock, AlertCircle, CheckCircle2, TrendingUp, Lightbulb } from "lucide-react";
import type { ProcessingResult, UnusedFile, MonetizationSuggestion, NextStepRecommendation } from "@shared/schema";

interface ReportsTabsProps {
  processingResults: ProcessingResult[];
  unusedFiles: UnusedFile[];
  monetizationSuggestions: MonetizationSuggestion[];
  nextSteps: NextStepRecommendation[];
}

export function ReportsTabs({
  processingResults,
  unusedFiles,
  monetizationSuggestions,
  nextSteps,
}: ReportsTabsProps) {
  return (
    <Tabs defaultValue="processing" className="w-full" data-testid="tabs-reports">
      <TabsList className="grid w-full grid-cols-4 mb-6">
        <TabsTrigger value="processing" data-testid="tab-processing">Processing Report</TabsTrigger>
        <TabsTrigger value="unused" data-testid="tab-unused">Unused Files</TabsTrigger>
        <TabsTrigger value="monetization" data-testid="tab-monetization">Monetization</TabsTrigger>
        <TabsTrigger value="nextsteps" data-testid="tab-nextsteps">Next Steps</TabsTrigger>
      </TabsList>

      <TabsContent value="processing">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Processing Timeline
          </h3>
          
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-4">
              {processingResults.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <p>No processing results yet</p>
                </div>
              ) : (
                processingResults.map((result, index) => (
                  <div key={result.id} className="border-l-2 border-primary pl-4 pb-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-semibold">{result.step}</h4>
                        <p className="text-sm text-muted-foreground">
                          {result.processingTime ? `${result.processingTime}ms` : 'Processing...'}
                        </p>
                      </div>
                      <Badge variant={result.status === 'completed' ? 'outline' : 'default'}>
                        {result.status}
                      </Badge>
                    </div>
                    {result.result && (
                      <div className="text-sm bg-muted p-3 rounded-md mt-2">
                        <pre className="whitespace-pre-wrap font-mono text-xs">
                          {JSON.stringify(result.result, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </Card>
      </TabsContent>

      <TabsContent value="unused">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            Files Not Incorporated
          </h3>
          
          <ScrollArea className="h-[500px]">
            <div className="space-y-3">
              {unusedFiles.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <CheckCircle2 className="w-12 h-12 mx-auto mb-3" />
                  <p>All files were successfully processed!</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4 font-semibold">File</th>
                        <th className="text-left py-3 px-4 font-semibold">Reason</th>
                        <th className="text-left py-3 px-4 font-semibold">Suggested Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {unusedFiles.map((unused) => (
                        <tr key={unused.id} className="border-b hover-elevate" data-testid={`unused-${unused.id}`}>
                          <td className="py-3 px-4 font-mono text-sm">{unused.fileId}</td>
                          <td className="py-3 px-4 text-sm">{unused.reason}</td>
                          <td className="py-3 px-4 text-sm text-muted-foreground">
                            {unused.suggestedAction || 'N/A'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </ScrollArea>
        </Card>
      </TabsContent>

      <TabsContent value="monetization">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Monetization Strategies
          </h3>
          
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-4">
              {monetizationSuggestions.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <p>Generating monetization insights...</p>
                </div>
              ) : (
                monetizationSuggestions.map((suggestion, index) => (
                  <Card key={index} className="p-4 bg-accent/20" data-testid={`monetization-${index}`}>
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold">{suggestion.title}</h4>
                      <Badge variant="outline" className="ml-2">
                        {suggestion.confidence}% confidence
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{suggestion.description}</p>
                    <p className="text-sm font-medium text-primary">
                      Potential: {suggestion.potentialRevenue}
                    </p>
                  </Card>
                ))
              )}
            </div>
          </ScrollArea>
        </Card>
      </TabsContent>

      <TabsContent value="nextsteps">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            Recommended Next Steps
          </h3>
          
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-4">
              {nextSteps.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <p>Analyzing improvements...</p>
                </div>
              ) : (
                nextSteps.map((step, index) => (
                  <Card key={index} className="p-4" data-testid={`nextstep-${index}`}>
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm">
                          {index + 1}
                        </span>
                        {step.title}
                      </h4>
                      <Badge
                        variant={
                          step.priority === 'high'
                            ? 'destructive'
                            : step.priority === 'medium'
                            ? 'default'
                            : 'secondary'
                        }
                      >
                        {step.priority}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2 ml-8">{step.description}</p>
                    <p className="text-xs text-muted-foreground ml-8">
                      Est. time: {step.estimatedTime}
                    </p>
                  </Card>
                ))
              )}
            </div>
          </ScrollArea>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
