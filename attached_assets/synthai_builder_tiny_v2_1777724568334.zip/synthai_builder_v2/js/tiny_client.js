
// tiny_client.js — Optional in-browser TinyLlama via WebLLM (no bash).
// Requires <script type="module" src="https://unpkg.com/@mlc-ai/web-llm/dist/web-llm.min.js"></script>
// Gracefully degrades if WebLLM or WebGPU is unavailable.
export class TinyClient {
  constructor(logFn = console.log){
    this.log = logFn;
    this.engine = null;
    this.chat = null;
    this.supported = typeof navigator !== 'undefined' && 'gpu' in navigator;
  }

  async init() {
    if (!this.supported || !window.webllm) {
      this.log("WebGPU/WebLLM not available; TinyLlama disabled.");
      return false;
    }
    const { CreateMLCEngine } = window.webllm;
    // Use TinyLlama chat model (quantized) via WebLLM registry
    const model = "TinyLlama-1.1B-Chat-v1.0-q4f16_1-MLC";
    this.log("Loading TinyLlama in-browser… (~few hundred MB via CDN on first load)");
    this.engine = await CreateMLCEngine(model, {
      // request low memory mode if available
      lowResourceMode: true,
    });
    this.chat = await this.engine.createChatCompletion();
    this.log("TinyLlama ready.");
    return true;
    }

  async ask(prompt, sys="You are a helpful, bash-free SynthAI.") {
    if (!this.engine || !this.chat) throw new Error("TinyLlama not initialized.");
    const messages = [
      { role: "system", content: sys },
      { role: "user", content: prompt }
    ];
    const reply = await this.engine.chat.completions.create({ messages });
    // reply.choices[0].message.content
    const content = reply?.choices?.[0]?.message?.content || "(no content)";
    return content;
  }
}
