"""
Neural Brain Model Persistence

Handles saving and loading trained neural network state to ensure
knowledge accumulation across application restarts.
"""

import json
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional


class ModelPersistence:
    """Manages persistence of neural brain state and training metrics."""

    def __init__(self, storage_dir: str = "./model_state"):
        """
        Initialize persistence manager.

        Args:
            storage_dir: Directory to store model state files
        """
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.state_file = self.storage_dir / "network_state.json"
        self.metrics_file = self.storage_dir / "training_metrics.json"
        self.checkpoint_dir = self.storage_dir / "checkpoints"
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def save_network_state(self, network_data: Dict[str, Any]) -> bool:
        """
        Save neural network state to disk.

        Args:
            network_data: Dictionary containing nodes, edges, and metadata

        Returns:
            True if save successful, False otherwise
        """
        try:
            # Add timestamp
            network_data["last_saved"] = datetime.now().isoformat()

            with open(self.state_file, "w") as f:
                json.dump(network_data, f, indent=2, default=str)

            print(f"[Persistence] Network state saved to {self.state_file}")
            return True
        except Exception as e:
            print(f"[Persistence] Error saving network state: {e}")
            return False

    def load_network_state(self) -> Optional[Dict[str, Any]]:
        """
        Load neural network state from disk.

        Returns:
            Dictionary containing network state, or None if not found
        """
        try:
            if not self.state_file.exists():
                print(f"[Persistence] No saved state found at {self.state_file}")
                return None

            with open(self.state_file, "r") as f:
                network_data = json.load(f)

            print(f"[Persistence] Network state loaded from {self.state_file}")
            return network_data
        except Exception as e:
            print(f"[Persistence] Error loading network state: {e}")
            return None

    def save_training_metrics(self, metrics: Dict[str, Any]) -> bool:
        """
        Save training metrics to disk.

        Args:
            metrics: Dictionary containing training metrics

        Returns:
            True if save successful, False otherwise
        """
        try:
            # Add timestamp
            metrics["last_updated"] = datetime.now().isoformat()

            with open(self.metrics_file, "w") as f:
                json.dump(metrics, f, indent=2, default=str)

            print(f"[Persistence] Training metrics saved to {self.metrics_file}")
            return True
        except Exception as e:
            print(f"[Persistence] Error saving metrics: {e}")
            return False

    def load_training_metrics(self) -> Optional[Dict[str, Any]]:
        """
        Load training metrics from disk.

        Returns:
            Dictionary containing training metrics, or None if not found
        """
        try:
            if not self.metrics_file.exists():
                print(f"[Persistence] No saved metrics found at {self.metrics_file}")
                return None

            with open(self.metrics_file, "r") as f:
                metrics = json.load(f)

            print(f"[Persistence] Training metrics loaded from {self.metrics_file}")
            return metrics
        except Exception as e:
            print(f"[Persistence] Error loading metrics: {e}")
            return None

    def save_checkpoint(self, network_data: Dict[str, Any], metrics: Dict[str, Any], name: str = "") -> bool:
        """
        Save a checkpoint of the current network state and metrics.

        Args:
            network_data: Network state to checkpoint
            metrics: Training metrics to checkpoint
            name: Optional checkpoint name/identifier

        Returns:
            True if save successful, False otherwise
        """
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            checkpoint_name = f"checkpoint_{timestamp}_{name}" if name else f"checkpoint_{timestamp}"
            checkpoint_path = self.checkpoint_dir / checkpoint_name

            checkpoint_path.mkdir(parents=True, exist_ok=True)

            # Save network state
            with open(checkpoint_path / "network.json", "w") as f:
                json.dump(network_data, f, indent=2, default=str)

            # Save metrics
            with open(checkpoint_path / "metrics.json", "w") as f:
                json.dump(metrics, f, indent=2, default=str)

            # Save metadata
            metadata = {
                "timestamp": timestamp,
                "name": name,
                "nodes_count": len(network_data.get("nodes", [])),
                "edges_count": len(network_data.get("edges", [])),
                "latest_epoch": metrics.get("latest_epoch", 0),
            }
            with open(checkpoint_path / "metadata.json", "w") as f:
                json.dump(metadata, f, indent=2)

            print(f"[Persistence] Checkpoint saved: {checkpoint_path}")
            return True
        except Exception as e:
            print(f"[Persistence] Error saving checkpoint: {e}")
            return False

    def list_checkpoints(self) -> list:
        """
        List all available checkpoints.

        Returns:
            List of checkpoint names
        """
        try:
            if not self.checkpoint_dir.exists():
                return []

            checkpoints = sorted([d.name for d in self.checkpoint_dir.iterdir() if d.is_dir()])
            return checkpoints
        except Exception as e:
            print(f"[Persistence] Error listing checkpoints: {e}")
            return []

    def load_checkpoint(self, checkpoint_name: str) -> Optional[tuple]:
        """
        Load a specific checkpoint.

        Args:
            checkpoint_name: Name of checkpoint to load

        Returns:
            Tuple of (network_data, metrics) or None if not found
        """
        try:
            checkpoint_path = self.checkpoint_dir / checkpoint_name

            if not checkpoint_path.exists():
                print(f"[Persistence] Checkpoint not found: {checkpoint_name}")
                return None

            # Load network state
            with open(checkpoint_path / "network.json", "r") as f:
                network_data = json.load(f)

            # Load metrics
            with open(checkpoint_path / "metrics.json", "r") as f:
                metrics = json.load(f)

            print(f"[Persistence] Checkpoint loaded: {checkpoint_name}")
            return (network_data, metrics)
        except Exception as e:
            print(f"[Persistence] Error loading checkpoint {checkpoint_name}: {e}")
            return None

    def cleanup_old_checkpoints(self, keep_count: int = 5) -> int:
        """
        Remove old checkpoints, keeping only the most recent ones.

        Args:
            keep_count: Number of recent checkpoints to keep

        Returns:
            Number of checkpoints deleted
        """
        try:
            checkpoints = self.list_checkpoints()

            if len(checkpoints) <= keep_count:
                return 0

            # Sort by name (timestamp-based) and remove oldest
            to_delete = checkpoints[:-keep_count]
            deleted_count = 0

            for checkpoint_name in to_delete:
                checkpoint_path = self.checkpoint_dir / checkpoint_name
                try:
                    import shutil

                    shutil.rmtree(checkpoint_path)
                    deleted_count += 1
                    print(f"[Persistence] Deleted old checkpoint: {checkpoint_name}")
                except Exception as e:
                    print(f"[Persistence] Error deleting checkpoint {checkpoint_name}: {e}")

            return deleted_count
        except Exception as e:
            print(f"[Persistence] Error during cleanup: {e}")
            return 0

    def get_storage_info(self) -> Dict[str, Any]:
        """
        Get information about storage usage.

        Returns:
            Dictionary with storage statistics
        """
        try:
            total_size = 0
            checkpoint_count = len(self.list_checkpoints())

            # Calculate directory size
            for dirpath, dirnames, filenames in os.walk(self.storage_dir):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    if os.path.exists(filepath):
                        total_size += os.path.getsize(filepath)

            return {
                "storage_dir": str(self.storage_dir),
                "total_size_mb": round(total_size / (1024 * 1024), 2),
                "checkpoint_count": checkpoint_count,
                "has_state": self.state_file.exists(),
                "has_metrics": self.metrics_file.exists(),
            }
        except Exception as e:
            print(f"[Persistence] Error getting storage info: {e}")
            return {}
