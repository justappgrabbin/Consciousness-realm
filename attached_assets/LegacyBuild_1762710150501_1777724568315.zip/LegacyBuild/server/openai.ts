import OpenAI from "openai";
import pLimit from "p-limit";
import pRetry, { AbortError } from "p-retry";

// Referenced from blueprint:javascript_openai_ai_integrations
// This is using Replit's AI Integrations service
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

function isRateLimitError(error: any): boolean {
  const errorMsg = error?.message || String(error);
  return (
    errorMsg.includes("429") ||
    errorMsg.includes("RATELIMIT_EXCEEDED") ||
    errorMsg.toLowerCase().includes("quota") ||
    errorMsg.toLowerCase().includes("rate limit")
  );
}

export async function analyzeCode(code: string, filename: string, mode: string = 'quick'): Promise<any> {
  return await pRetry(
    async () => {
      try {
        let prompt = '';
        
        if (mode === 'quick') {
          // Quick mode: basic analysis only
          prompt = `Quickly analyze this code file "${filename}". Return JSON with: language, linesOfCode, keyPatterns (array of 2-3 items), reusabilityScore (0-100).

Code:
${code}`;
        } else if (mode === 'creative') {
          // Creative mode: deep analysis with suggestions
          prompt = `Deeply analyze this code file "${filename}". Provide comprehensive insights:
1) Programming language and version
2) Lines of code and complexity metrics
3) Detailed patterns, structures, and architecture
4) Creative improvements and refactoring suggestions
5) Modern best practices recommendations
6) Reusability score (0-100) with explanation
7) Potential integrations and enhancements

Return as detailed JSON.

Code:
${code}`;
        } else {
          // Pusher mode: focus on deployment readiness
          prompt = `Analyze this code file "${filename}" for deployment. Return JSON with: language, linesOfCode, deploymentReadiness (0-100), missingConfigs (array), securityIssues (array), keyPatterns (array).

Code:
${code}`;
        }

        const response = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{
            role: "user",
            content: prompt
          }],
          response_format: { type: "json_object" },
          max_completion_tokens: mode === 'creative' ? 16384 : 8192,
        });
        return JSON.parse(response.choices[0]?.message?.content || "{}");
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    { retries: 7, minTimeout: 2000, maxTimeout: 128000, factor: 2 }
  );
}

export async function unifyCodePatterns(codes: Array<{ filename: string; content: string; analysis: any }>): Promise<any> {
  return await pRetry(
    async () => {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{
            role: "user",
            content: `Analyze these code files and identify common patterns that can be unified. Suggest refactorings and return merged/optimized code. Return as JSON with 'patterns', 'refactorings', and 'unifiedCode' fields.

Files:
${codes.map(c => `${c.filename}:\n${c.content}\n\nAnalysis: ${JSON.stringify(c.analysis)}`).join('\n\n---\n\n')}`
          }],
          response_format: { type: "json_object" },
          max_completion_tokens: 8192,
        });
        return JSON.parse(response.choices[0]?.message?.content || "{}");
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    { retries: 7, minTimeout: 2000, maxTimeout: 128000, factor: 2 }
  );
}

export async function generateMonetizationSuggestions(projectDescription: string, codebase: string): Promise<any> {
  return await pRetry(
    async () => {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{
            role: "user",
            content: `Based on this project and codebase, suggest 5 monetization strategies. For each: title, description, confidence (0-100), and potentialRevenue. Return as JSON array.

Project: ${projectDescription}
Codebase summary: ${codebase.substring(0, 3000)}`
          }],
          response_format: { type: "json_object" },
          max_completion_tokens: 8192,
        });
        const result = JSON.parse(response.choices[0]?.message?.content || "{}");
        return result.suggestions || [];
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    { retries: 7, minTimeout: 2000, maxTimeout: 128000, factor: 2 }
  );
}

export async function generateNextSteps(projectDescription: string, codebase: string): Promise<any> {
  return await pRetry(
    async () => {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{
            role: "user",
            content: `Based on this project and codebase, recommend 5 next steps for improvement. For each: title, description, priority (high/medium/low), and estimatedTime. Return as JSON array.

Project: ${projectDescription}
Codebase summary: ${codebase.substring(0, 3000)}`
          }],
          response_format: { type: "json_object" },
          max_completion_tokens: 8192,
        });
        const result = JSON.parse(response.choices[0]?.message?.content || "{}");
        return result.steps || [];
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    { retries: 7, minTimeout: 2000, maxTimeout: 128000, factor: 2 }
  );
}

export async function fillCodeGaps(code: string, gaps: Array<{ lineNumber: number; description: string }>): Promise<string> {
  return await pRetry(
    async () => {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{
            role: "user",
            content: `Complete this code by filling in the gaps at the specified lines. Return the complete, working code.

Code:
${code}

Gaps to fill:
${gaps.map(g => `Line ${g.lineNumber}: ${g.description}`).join('\n')}`
          }],
          max_completion_tokens: 8192,
        });
        return response.choices[0]?.message?.content || code;
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    { retries: 7, minTimeout: 2000, maxTimeout: 128000, factor: 2 }
  );
}

export async function extractBookReferences(text: string): Promise<any> {
  return await pRetry(
    async () => {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{
            role: "user",
            content: `Extract book references, quotes, and best practices from this text. For each: title, author, quote, and relevance. Return as JSON array.

Text:
${text.substring(0, 5000)}`
          }],
          response_format: { type: "json_object" },
          max_completion_tokens: 8192,
        });
        const result = JSON.parse(response.choices[0]?.message?.content || "{}");
        return result.references || [];
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    { retries: 7, minTimeout: 2000, maxTimeout: 128000, factor: 2 }
  );
}

export async function detectCodeGaps(code: string): Promise<Array<{ lineNumber: number; description: string; suggestedCompletion: string }>> {
  return await pRetry(
    async () => {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5",
          messages: [{
            role: "user",
            content: `Analyze this code and identify any gaps, incomplete functions, or TODOs. For each gap: lineNumber, description, and suggestedCompletion. Return as JSON array.

Code:
${code}`
          }],
          response_format: { type: "json_object" },
          max_completion_tokens: 8192,
        });
        const result = JSON.parse(response.choices[0]?.message?.content || "{}");
        return result.gaps || [];
      } catch (error: any) {
        if (isRateLimitError(error)) {
          throw error;
        }
        throw new AbortError(error);
      }
    },
    { retries: 7, minTimeout: 2000, maxTimeout: 128000, factor: 2 }
  );
}
