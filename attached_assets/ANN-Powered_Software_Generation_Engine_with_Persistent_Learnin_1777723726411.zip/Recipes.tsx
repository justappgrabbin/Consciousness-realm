import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { ArrowLeft, BookOpen, Plus, Zap, Lock, Globe, Loader2, X } from "lucide-react";
import { toast } from "sonner";

export default function Recipes() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", tags: "", isPublic: false });

  const { data: myRecipes, isLoading: loadingMine } = trpc.recipes.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );
  const { data: publicRecipes, isLoading: loadingPublic } = trpc.recipes.public.useQuery();

  const utils = trpc.useUtils();
  const create = trpc.recipes.create.useMutation({
    onSuccess: () => {
      utils.recipes.list.invalidate();
      utils.recipes.public.invalidate();
      setShowCreate(false);
      setForm({ name: "", description: "", tags: "", isPublic: false });
      toast.success("K:// Recipe saved. I'll remember that pattern.");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const handleCreate = () => {
    if (!form.name.trim()) return;
    create.mutate({
      name: form.name,
      description: form.description || undefined,
      tags: form.tags ? form.tags.split(",").map((t) => t.trim()).filter(Boolean) : [],
      isPublic: form.isPublic,
    });
  };

  return (
    <div className="min-h-screen" style={{ background: "oklch(0.09 0.02 255)" }}>
      {/* Header */}
      <div className="sticky top-0 z-10 px-8 py-4 flex items-center gap-4"
        style={{ background: "oklch(0.09 0.02 255 / 0.95)", borderBottom: "1px solid oklch(0.22 0.04 255)", backdropFilter: "blur(12px)" }}>
        <button onClick={() => navigate("/dashboard")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </button>
        <div className="h-4 w-px" style={{ background: "oklch(0.22 0.04 255)" }} />
        <div className="flex items-center gap-2">
          <BookOpen className="h-4 w-4" style={{ color: "oklch(0.72 0.18 200)" }} />
          <span className="text-sm font-medium">Recipe Library</span>
        </div>
        <div className="ml-auto">
          {isAuthenticated && (
            <Button onClick={() => setShowCreate(true)} size="sm"
              style={{ background: "oklch(0.60 0.28 350)", color: "oklch(0.98 0.01 0)", border: "none" }}>
              <Plus className="h-3 w-3 mr-1" /> New Recipe
            </Button>
          )}
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-8 py-8">
        {/* Intro */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">Recipe Library</h1>
          <p className="text-sm text-muted-foreground">
            Reusable architectural patterns, code blueprints, and project templates.
            Karen learns from every recipe and applies them intelligently to new projects.
          </p>
          <div className="mt-3 p-3 rounded-lg inline-block" style={{ background: "oklch(0.72 0.18 200 / 0.05)", border: "1px solid oklch(0.72 0.18 200 / 0.2)" }}>
            <p className="text-xs font-mono" style={{ color: "oklch(0.72 0.18 200)" }}>
              K:// Recipes are how I avoid reinventing the wheel. Your patterns, my memory.
            </p>
          </div>
        </div>

        {/* Create Form */}
        {showCreate && (
          <div className="mb-8 p-6 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.60 0.28 350 / 0.3)" }}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold">New Recipe</h2>
              <button onClick={() => setShowCreate(false)} className="text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Recipe Name *</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. SaaS Auth Scaffold"
                  className="w-full px-3 py-2 rounded text-sm outline-none"
                  style={{ background: "oklch(0.08 0.02 255)", border: "1px solid oklch(0.22 0.04 255)", color: "oklch(0.92 0.03 240)" }} />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Description</label>
                <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="What does this recipe do? When should Karen use it?"
                  rows={3}
                  className="w-full px-3 py-2 rounded text-sm outline-none resize-none"
                  style={{ background: "oklch(0.08 0.02 255)", border: "1px solid oklch(0.22 0.04 255)", color: "oklch(0.92 0.03 240)" }} />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Tags (comma-separated)</label>
                <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })}
                  placeholder="auth, saas, typescript, react"
                  className="w-full px-3 py-2 rounded text-sm outline-none"
                  style={{ background: "oklch(0.08 0.02 255)", border: "1px solid oklch(0.22 0.04 255)", color: "oklch(0.92 0.03 240)" }} />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="isPublic" checked={form.isPublic}
                  onChange={(e) => setForm({ ...form, isPublic: e.target.checked })}
                  className="rounded" />
                <label htmlFor="isPublic" className="text-xs text-muted-foreground">Make this recipe public</label>
              </div>
              <Button onClick={handleCreate} disabled={!form.name.trim() || create.isPending}
                style={{ background: "oklch(0.60 0.28 350)", color: "oklch(0.98 0.01 0)", border: "none" }}>
                {create.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Zap className="h-4 w-4 mr-2" />}
                Save Recipe
              </Button>
            </div>
          </div>
        )}

        {/* My Recipes */}
        {isAuthenticated && (
          <div className="mb-8">
            <h2 className="text-xs tracking-widest uppercase mb-4 text-muted-foreground">My Recipes</h2>
            {loadingMine ? (
              <div className="space-y-3">{[1, 2].map((i) => <div key={i} className="h-20 rounded animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />)}</div>
            ) : myRecipes?.length === 0 ? (
              <div className="text-center py-8 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
                <BookOpen className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs text-muted-foreground">No recipes yet</p>
                <p className="text-xs italic mt-1" style={{ color: "oklch(0.72 0.18 200)" }}>K:// Create your first recipe to teach me your patterns.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {myRecipes?.map((recipe) => (
                  <RecipeCard key={recipe.id} recipe={recipe} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Public Recipes */}
        <div>
          <h2 className="text-xs tracking-widest uppercase mb-4 text-muted-foreground">Public Recipes</h2>
          {loadingPublic ? (
            <div className="space-y-3">{[1, 2, 3].map((i) => <div key={i} className="h-20 rounded animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />)}</div>
          ) : publicRecipes?.length === 0 ? (
            <div className="text-center py-8 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
              <Globe className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
              <p className="text-xs text-muted-foreground">No public recipes yet. Be the first to share.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {publicRecipes?.map((recipe) => (
                <RecipeCard key={recipe.id} recipe={recipe} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function RecipeCard({ recipe }: { recipe: any }) {
  const tags = Array.isArray(recipe.tags) ? recipe.tags : [];
  return (
    <div className="p-5 rounded-lg transition-all"
      style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}
      onMouseEnter={(e) => (e.currentTarget.style.borderColor = "oklch(0.60 0.28 350 / 0.4)")}
      onMouseLeave={(e) => (e.currentTarget.style.borderColor = "oklch(0.22 0.04 255)")}>
      <div className="flex items-start justify-between gap-3 mb-2">
        <h3 className="text-sm font-medium">{recipe.name}</h3>
        <span className="shrink-0">
          {recipe.isPublic
            ? <Globe className="h-3 w-3 text-muted-foreground" />
            : <Lock className="h-3 w-3 text-muted-foreground" />}
        </span>
      </div>
      {recipe.description && (
        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{recipe.description}</p>
      )}
      {tags.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {tags.map((tag: string, i: number) => (
            <span key={i} className="text-xs px-2 py-0.5 rounded"
              style={{ background: "oklch(0.55 0.22 255 / 0.1)", color: "oklch(0.70 0.22 255)", border: "1px solid oklch(0.55 0.22 255 / 0.3)" }}>
              {tag}
            </span>
          ))}
        </div>
      )}
      <p className="text-xs text-muted-foreground mt-3">
        Used {recipe.usageCount ?? 0} time{recipe.usageCount !== 1 ? "s" : ""}
      </p>
    </div>
  );
}
