"""
Consciousness System - Modular Tree File Organizer
Dynamically build, visualize, and export organized module structures
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field, asdict

@dataclass
class FileNode:
    """Represents a file or folder in the tree"""
    name: str
    node_type: str = "file"  # "file", "folder", "module"
    description: str = ""
    children: List['FileNode'] = field(default_factory=list)
    tags: Set[str] = field(default_factory=set)
    
    def add_child(self, node: 'FileNode'):
        """Add a child node"""
        self.children.append(node)
        return node
    
    def find(self, name: str) -> Optional['FileNode']:
        """Recursively find a node by name"""
        if self.name == name:
            return self
        for child in self.children:
            found = child.find(name)
            if found:
                return found
        return None
    
    def to_dict(self):
        """Convert to serializable dict"""
        return {
            'name': self.name,
            'node_type': self.node_type,
            'description': self.description,
            'tags': list(self.tags),
            'children': [child.to_dict() for child in self.children]
        }


class ModuleTree:
    """Manages a single module's file tree"""
    
    def __init__(self, module_name: str, description: str = ""):
        self.root = FileNode(module_name, "module", description)
        self.module_name = module_name
    
    def add_folder(self, path: str, description: str = "") -> FileNode:
        """Add a folder at path (e.g., 'core/utils')"""
        parts = path.split('/')
        current = self.root
        
        for part in parts:
            existing = current.find(part)
            if existing and existing in current.children:
                current = existing
            else:
                new_folder = FileNode(part, "folder", description)
                current.add_child(new_folder)
                current = new_folder
        
        return current
    
    def add_file(self, path: str, description: str = "", tags: Set[str] = None):
        """Add a file at path (e.g., 'core/utils/waveforms.py')"""
        parts = path.split('/')
        folder_path = '/'.join(parts[:-1]) if len(parts) > 1 else ""
        file_name = parts[-1]
        
        if folder_path:
            parent = self.add_folder(folder_path)
        else:
            parent = self.root
        
        file_node = FileNode(file_name, "file", description, tags=tags or set())
        parent.add_child(file_node)
        return file_node
    
    def visualize(self, node: Optional[FileNode] = None, prefix: str = "", is_last: bool = True) -> str:
        """Generate ASCII tree visualization"""
        if node is None:
            node = self.root
        
        lines = []
        
        # Node symbol based on type
        symbols = {
            "module": "📦",
            "folder": "📁",
            "file": "📄"
        }
        symbol = symbols.get(node.node_type, "•")
        
        # Current node
        connector = "└── " if is_last else "├── "
        if node == self.root:
            lines.append(f"{symbol} {node.name}/")
        else:
            lines.append(f"{prefix}{connector}{symbol} {node.name}")
        
        # Add description if exists
        if node.description:
            desc_prefix = prefix + ("    " if is_last else "│   ")
            lines.append(f"{desc_prefix}💭 {node.description}")
        
        # Add tags if exist
        if node.tags:
            tag_prefix = prefix + ("    " if is_last else "│   ")
            lines.append(f"{tag_prefix}🏷️  {', '.join(node.tags)}")
        
        # Children
        for i, child in enumerate(node.children):
            child_is_last = (i == len(node.children) - 1)
            child_prefix = prefix + ("    " if is_last else "│   ")
            lines.append(self.visualize(child, child_prefix, child_is_last))
        
        return "\n".join(lines)
    
    def export_structure(self, output_path: Path):
        """Export tree as JSON"""
        data = {
            'module': self.module_name,
            'tree': self.root.to_dict()
        }
        output_path.write_text(json.dumps(data, indent=2))
    
    def generate_filesystem(self, base_path: Path):
        """Actually create the folders and __init__.py files"""
        def create_node(node: FileNode, current_path: Path):
            if node.node_type in ["folder", "module"]:
                node_path = current_path / node.name
                node_path.mkdir(parents=True, exist_ok=True)
                
                # Create __init__.py with description as docstring
                init_file = node_path / "__init__.py"
                if not init_file.exists():
                    docstring = f'"""{node.description}"""\n' if node.description else ""
                    init_file.write_text(docstring)
                
                # Recurse for children
                for child in node.children:
                    create_node(child, node_path)
            
            elif node.node_type == "file":
                file_path = current_path / node.name
                if not file_path.exists():
                    docstring = f'"""{node.description}"""\n' if node.description else ""
                    file_path.write_text(docstring)
        
        create_node(self.root, base_path)


class TreeOrganizer:
    """Manages multiple module trees"""
    
    def __init__(self):
        self.modules: Dict[str, ModuleTree] = {}
    
    def add_module(self, name: str, description: str = "") -> ModuleTree:
        """Create a new module tree"""
        tree = ModuleTree(name, description)
        self.modules[name] = tree
        return tree
    
    def get_module(self, name: str) -> Optional[ModuleTree]:
        """Retrieve a module tree"""
        return self.modules.get(name)
    
    def visualize_all(self) -> str:
        """Show all module trees"""
        output = ["🌳 CONSCIOUSNESS SYSTEM - MODULE FOREST", "=" * 60, ""]
        for name, tree in self.modules.items():
            output.append(tree.visualize())
            output.append("")
        return "\n".join(output)
    
    def export_all(self, output_dir: Path):
        """Export all trees as JSON"""
        output_dir.mkdir(parents=True, exist_ok=True)
        for name, tree in self.modules.items():
            tree.export_structure(output_dir / f"{name}.json")
    
    def generate_all(self, base_path: Path):
        """Generate entire filesystem structure"""
        for tree in self.modules.values():
            tree.generate_filesystem(base_path)


# Example usage and templates
def create_example_structure():
    """Demo showing how to build your consciousness system"""
    organizer = TreeOrganizer()
    
    # Core module
    core = organizer.add_module("core", "Central system intelligence")
    core.add_file("__init__.py", "Core module initialization")
    core.add_file("config.py", "Global configuration and paths", {"config", "settings"})
    core.add_file("field_registry.py", "Maps all 9 consciousness bodies", {"registry"})
    core.add_file("resonance_engine.py", "Cross-field waveform calculations", {"waveform", "resonance"})
    
    # Fields module with submodules
    fields = organizer.add_module("fields", "9-body consciousness field definitions")
    fields.add_file("__init__.py", "Fields module initialization")
    fields.add_file("base_field.py", "Abstract base class for all fields", {"base", "abstract"})
    
    for body in ["mind", "heart", "body", "soul", "spirit", "shadow", "light", "void", "unity"]:
        fields.add_folder(body, f"{body.title()} field logic and charts")
        fields.add_file(f"{body}/__init__.py")
        fields.add_file(f"{body}/logic.py", f"{body.title()}-specific calculations", {"logic"})
        fields.add_file(f"{body}/charts.py", f"Chart types for {body}", {"charts"})
    
    # Charts module
    charts = organizer.add_module("charts", "Astrological chart calculation systems")
    charts.add_file("__init__.py")
    charts.add_file("sidereal.py", "Sidereal zodiac calculations", {"sidereal", "astrology"})
    charts.add_file("tropical.py", "Tropical zodiac calculations", {"tropical", "astrology"})
    charts.add_file("draconic.py", "Draconic chart calculations", {"draconic", "nodes"})
    charts.add_file("stellar_proximology.py", "Star proximity resonance", {"stellar", "proximity"})
    
    # Oracles module
    oracles = organizer.add_module("oracles", "Oracle and interpretation engines")
    oracles.add_file("__init__.py")
    oracles.add_file("decoder.py", "Chart interpretation logic", {"interpreter"})
    oracles.add_file("query_engine.py", "User query interface", {"oracle", "query"})
    
    # AI module
    ai = organizer.add_module("ai", "AI integration and prompt management")
    ai.add_file("__init__.py")
    ai.add_folder("prompts", "AI prompt templates")
    ai.add_file("prompts/__init__.py")
    ai.add_file("integration.py", "AI engine hooks", {"ai", "llm"})
    
    return organizer


# Interactive CLI
if __name__ == "__main__":
    print("🌳 Consciousness System - Modular Tree Organizer\n")
    
    # Create example
    organizer = create_example_structure()
    
    # Visualize
    print(organizer.visualize_all())
    
    # Menu
    print("\n" + "=" * 60)
    print("OPTIONS:")
    print("1. Export trees as JSON")
    print("2. Generate actual filesystem")
    print("3. Add new module (interactive)")
    print("4. Exit")
    
    choice = input("\nSelect option (1-4): ").strip()
    
    if choice == "1":
        output_dir = Path("./exports")
        organizer.export_all(output_dir)
        print(f"✅ Exported to {output_dir}/")
    
    elif choice == "2":
        base_path = Path("./consciousness-system")
        organizer.generate_all(base_path)
        print(f"✅ Generated filesystem at {base_path}/")
    
    elif choice == "3":
        name = input("Module name: ").strip()
        desc = input("Description: ").strip()
        tree = organizer.add_module(name, desc)
        print(f"✅ Created module '{name}'")
        print("\nAdd files with: tree.add_file('path/file.py', 'description')")
    
    print("\n🎉 Done!")


# FILE SCANNER AND INTELLIGENT PLACEMENT ENGINE
class FileScanner:
    """Scans existing files and suggests placement in module trees"""
    
    def __init__(self, organizer: TreeOrganizer):
        self.organizer = organizer
        self.keyword_map = {
            # Core system keywords
            'config': ['config', 'settings', 'setup', 'constants', 'globals'],
            'registry': ['registry', 'register', 'catalog', 'index'],
            'resonance': ['resonance', 'waveform', 'frequency', 'vibration', 'harmonic'],
            
            # Field/body keywords
            'mind': ['mind', 'mental', 'thought', 'cognitive', 'intellect'],
            'heart': ['heart', 'emotional', 'feeling', 'sentiment'],
            'body': ['body', 'physical', 'somatic', 'corporeal'],
            'soul': ['soul', 'essence', 'core'],
            'spirit': ['spirit', 'ethereal', 'transcendent'],
            'shadow': ['shadow', 'unconscious', 'hidden', 'repressed'],
            'light': ['light', 'conscious', 'illuminated', 'aware'],
            'void': ['void', 'empty', 'potential', 'quantum'],
            'unity': ['unity', 'wholeness', 'integration', 'unified'],
            
            # Chart types
            'sidereal': ['sidereal', 'vedic', 'fixed stars'],
            'tropical': ['tropical', 'western astrology', 'seasons'],
            'draconic': ['draconic', 'nodes', 'karmic', 'north node', 'south node'],
            'stellar': ['stellar', 'star', 'proximity', 'constellation'],
            'human_design': ['human design', 'hd', 'gates', 'channels', 'bodygraph'],
            
            # Oracle/interpretation
            'oracle': ['oracle', 'divination', 'reading', 'interpretation'],
            'decoder': ['decode', 'interpret', 'translate', 'parse'],
            'query': ['query', 'question', 'ask', 'search'],
            
            # AI/automation
            'ai': ['ai', 'llm', 'gpt', 'claude', 'prompt', 'agent'],
            'prompt': ['prompt', 'template', 'instruction'],
            
            # Utils
            'math': ['math', 'calculate', 'computation', 'formula'],
            'converter': ['convert', 'transform', 'translate'],
            'validator': ['validate', 'check', 'verify', 'sanitize'],
            'date': ['date', 'time', 'datetime', 'calendar', 'epoch'],
            
            # Data
            'ephemeris': ['ephemeris', 'ephemerides', 'planetary', 'positions'],
            'cache': ['cache', 'store', 'memoize', 'persist'],
            
            # UI
            'cli': ['cli', 'command line', 'terminal', 'console'],
            'web': ['web', 'flask', 'fastapi', 'http', 'api'],
            'gui': ['gui', 'desktop', 'tkinter', 'qt', 'window'],
        }
        
        # Module placement rules
        self.placement_rules = {
            'config': ('core', 'config.py'),
            'registry': ('core', 'field_registry.py'),
            'resonance': ('core', 'resonance_engine.py'),
            
            'mind': ('fields', 'mind/'),
            'heart': ('fields', 'heart/'),
            'body': ('fields', 'body/'),
            'soul': ('fields', 'soul/'),
            'spirit': ('fields', 'spirit/'),
            'shadow': ('fields', 'shadow/'),
            'light': ('fields', 'light/'),
            'void': ('fields', 'void/'),
            'unity': ('fields', 'unity/'),
            
            'sidereal': ('charts', 'sidereal.py'),
            'tropical': ('charts', 'tropical.py'),
            'draconic': ('charts', 'draconic.py'),
            'stellar': ('charts', 'stellar_proximology.py'),
            'human_design': ('data', 'human_design/'),
            
            'oracle': ('oracles', 'decoder.py'),
            'decoder': ('oracles', 'decoder.py'),
            'query': ('oracles', 'query_engine.py'),
            
            'ai': ('ai', 'integration.py'),
            'prompt': ('ai', 'prompts/'),
            
            'math': ('utils', 'waveforms.py'),
            'converter': ('utils', 'converters.py'),
            'validator': ('utils', 'validators.py'),
            'date': ('utils', 'converters.py'),
            
            'ephemeris': ('data', 'ephemerides/'),
            'cache': ('data', 'cache/'),
            
            'cli': ('ui', 'cli.py'),
            'web': ('ui', 'web/'),
            'gui': ('ui', 'desktop/'),
        }
    
    def scan_file(self, file_path: Path) -> Dict:
        """Analyze a single file and extract metadata"""
        result = {
            'path': file_path,
            'name': file_path.name,
            'matches': {},
            'content_preview': '',
            'imports': [],
            'functions': [],
            'classes': [],
            'suggested_module': None,
            'suggested_path': None,
            'confidence': 0.0
        }
        
        try:
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            result['content_preview'] = content[:500]
            
            # Extract imports
            import_lines = [line for line in content.split('\n') if line.strip().startswith(('import ', 'from '))]
            result['imports'] = import_lines[:10]  # First 10 imports
            
            # Extract function/class names (simple regex)
            import re
            result['functions'] = re.findall(r'^def\s+(\w+)', content, re.MULTILINE)[:10]
            result['classes'] = re.findall(r'^class\s+(\w+)', content, re.MULTILINE)[:10]
            
            # Score content against keywords
            content_lower = content.lower()
            filename_lower = file_path.name.lower()
            
            for category, keywords in self.keyword_map.items():
                score = 0
                matched_keywords = []
                
                for keyword in keywords:
                    # Filename matches (high weight)
                    if keyword in filename_lower:
                        score += 10
                        matched_keywords.append(f"filename:{keyword}")
                    
                    # Content matches (lower weight)
                    count = content_lower.count(keyword)
                    if count > 0:
                        score += min(count, 5)  # Cap at 5 points per keyword
                        matched_keywords.append(f"content:{keyword}({count}x)")
                
                if score > 0:
                    result['matches'][category] = {
                        'score': score,
                        'keywords': matched_keywords
                    }
            
            # Determine best placement
            if result['matches']:
                best_match = max(result['matches'].items(), key=lambda x: x[1]['score'])
                category, match_data = best_match
                result['confidence'] = min(match_data['score'] / 20.0, 1.0)  # Normalize to 0-1
                
                if category in self.placement_rules:
                    module, path = self.placement_rules[category]
                    result['suggested_module'] = module
                    result['suggested_path'] = path
        
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def scan_directory(self, directory: Path, extensions: List[str] = ['.py']) -> List[Dict]:
        """Recursively scan directory for matching files"""
        results = []
        
        for file_path in directory.rglob('*'):
            if file_path.is_file() and file_path.suffix in extensions:
                # Skip common non-source files
                if any(skip in str(file_path) for skip in ['__pycache__', '.git', 'venv', 'node_modules']):
                    continue
                
                result = self.scan_file(file_path)
                results.append(result)
        
        return results
    
    def generate_report(self, results: List[Dict], sort_by: str = 'confidence') -> str:
        """Generate a human-readable placement report"""
        # Sort results
        if sort_by == 'confidence':
            results = sorted(results, key=lambda x: x['confidence'], reverse=True)
        elif sort_by == 'name':
            results = sorted(results, key=lambda x: x['name'])
        
        lines = [
            "=" * 80,
            "🔍 FILE SCAN REPORT - Suggested Placements",
            "=" * 80,
            ""
        ]
        
        # Group by confidence levels
        high_confidence = [r for r in results if r['confidence'] >= 0.7]
        medium_confidence = [r for r in results if 0.3 <= r['confidence'] < 0.7]
        low_confidence = [r for r in results if r['confidence'] < 0.3]
        
        def format_section(title, items):
            section = [f"\n{title} ({len(items)} files)", "-" * 40]
            for item in items:
                confidence_bar = "█" * int(item['confidence'] * 10)
                section.append(f"\n📄 {item['name']}")
                section.append(f"   Confidence: [{confidence_bar:<10}] {item['confidence']:.0%}")
                
                if item['suggested_module'] and item['suggested_path']:
                    section.append(f"   📍 {item['suggested_module']}/{item['suggested_path']}")
                else:
                    section.append(f"   ❓ No clear placement - manual review needed")
                
                if item['matches']:
                    top_matches = sorted(item['matches'].items(), key=lambda x: x[1]['score'], reverse=True)[:3]
                    section.append(f"   🎯 Top matches: {', '.join([m[0] for m in top_matches])}")
                
                if item.get('classes'):
                    section.append(f"   🏛️  Classes: {', '.join(item['classes'][:3])}")
                if item.get('functions'):
                    section.append(f"   ⚙️  Functions: {', '.join(item['functions'][:3])}")
            
            return "\n".join(section)
        
        if high_confidence:
            lines.append(format_section("🟢 HIGH CONFIDENCE - Safe to auto-place", high_confidence))
        
        if medium_confidence:
            lines.append(format_section("🟡 MEDIUM CONFIDENCE - Review suggested placement", medium_confidence))
        
        if low_confidence:
            lines.append(format_section("🔴 LOW CONFIDENCE - Manual categorization needed", low_confidence))
        
        # Summary
        lines.append("\n" + "=" * 80)
        lines.append("📊 SUMMARY")
        lines.append(f"   Total files scanned: {len(results)}")
        lines.append(f"   High confidence: {len(high_confidence)}")
        lines.append(f"   Medium confidence: {len(medium_confidence)}")
        lines.append(f"   Low confidence: {len(low_confidence)}")
        lines.append("=" * 80)
        
        return "\n".join(lines)
    
    def auto_organize(self, results: List[Dict], min_confidence: float = 0.7, dry_run: bool = True) -> Dict:
        """Automatically place files based on scan results"""
        actions = {
            'moved': [],
            'skipped': [],
            'errors': []
        }
        
        for result in results:
            if result['confidence'] < min_confidence:
                actions['skipped'].append({
                    'file': result['name'],
                    'reason': f"Confidence {result['confidence']:.0%} below threshold"
                })
                continue
            
            if not result['suggested_module'] or not result['suggested_path']:
                actions['skipped'].append({
                    'file': result['name'],
                    'reason': "No clear placement found"
                })
                continue
            
            # Construct target path
            module_tree = self.organizer.get_module(result['suggested_module'])
            if not module_tree:
                actions['errors'].append({
                    'file': result['name'],
                    'error': f"Module '{result['suggested_module']}' not found in organizer"
                })
                continue
            
            target_path = result['suggested_path']
            if target_path.endswith('/'):
                # It's a folder, append filename
                target_path = target_path + result['name']
            
            if dry_run:
                actions['moved'].append({
                    'file': result['path'],
                    'to': f"{result['suggested_module']}/{target_path}",
                    'confidence': result['confidence'],
                    'dry_run': True
                })
            else:
                try:
                    # Actually move the file (implement based on your needs)
                    actions['moved'].append({
                        'file': result['path'],
                        'to': f"{result['suggested_module']}/{target_path}",
                        'confidence': result['confidence'],
                        'dry_run': False
                    })
                except Exception as e:
                    actions['errors'].append({
                        'file': result['name'],
                        'error': str(e)
                    })
        
        return actions


# Enhanced interactive CLI with scanner
def interactive_scanner():
    """Interactive file scanning and organization"""
    print("🔍 FILE SCANNER - Organize Your Consciousness System\n")
    
    # Get directory to scan
    scan_path = input("Enter directory to scan (or '.' for current): ").strip()
    if not scan_path:
        scan_path = "."
    
    scan_dir = Path(scan_path).resolve()
    if not scan_dir.exists():
        print(f"❌ Directory not found: {scan_dir}")
        return
    
    print(f"\n📂 Scanning: {scan_dir}")
    
    # Create organizer with example structure
    organizer = create_example_structure()
    scanner = FileScanner(organizer)
    
    # Scan files
    print("⏳ Analyzing files...")
    results = scanner.scan_directory(scan_dir)
    
    if not results:
        print("❌ No Python files found")
        return
    
    # Generate report
    report = scanner.generate_report(results)
    print("\n" + report)
    
    # Options
    print("\n" + "=" * 80)
    print("OPTIONS:")
    print("1. Export report to file")
    print("2. Auto-organize (dry run) - show what would move")
    print("3. Auto-organize (REAL) - actually move files")
    print("4. Export scan results as JSON")
    print("5. Exit")
    
    choice = input("\nSelect option (1-5): ").strip()
    
    if choice == "1":
        report_file = Path("./scan_report.txt")
        report_file.write_text(report)
        print(f"✅ Report saved to {report_file}")
    
    elif choice == "2":
        actions = scanner.auto_organize(results, min_confidence=0.7, dry_run=True)
        print(f"\n🔄 DRY RUN - Would move {len(actions['moved'])} files:")
        for action in actions['moved']:
            print(f"   {action['file'].name} → {action['to']} ({action['confidence']:.0%})")
        print(f"\n⏭️  Skipped: {len(actions['skipped'])}")
        print(f"❌ Errors: {len(actions['errors'])}")
    
    elif choice == "3":
        confirm = input("⚠️  This will MOVE files. Continue? (yes/no): ").strip().lower()
        if confirm == 'yes':
            # First generate the filesystem
            base_path = Path("./consciousness-system")
            organizer.generate_all(base_path)
            print(f"✅ Created structure at {base_path}/")
            
            # Then organize (note: actual file moving needs implementation)
            actions = scanner.auto_organize(results, min_confidence=0.7, dry_run=False)
            print(f"✅ Moved {len(actions['moved'])} files")
        else:
            print("Cancelled")
    
    elif choice == "4":
        output_file = Path("./scan_results.json")
        import json
        output_file.write_text(json.dumps([{
            'name': r['name'],
            'path': str(r['path']),
            'confidence': r['confidence'],
            'suggested_module': r['suggested_module'],
            'suggested_path': r['suggested_path'],
            'matches': r['matches']
        } for r in results], indent=2))
        print(f"✅ Results saved to {output_file}")
    
    print("\n🎉 Done!")


# GOOGLE DOCS INTEGRATION
class GoogleDocsExtractor:
    """Extract code and specs from Google Docs to organize into modules"""
    
    def __init__(self, organizer: TreeOrganizer):
        self.organizer = organizer
        self.scanner = FileScanner(organizer)
    
    def extract_code_blocks(self, doc_content: str) -> List[Dict]:
        """Extract code blocks from Google Doc text"""
        code_blocks = []
        
        # Try multiple patterns for code detection
        patterns = [
            # Python code blocks (markdown style)
            r'```python\n(.*?)```',
            r'```py\n(.*?)```',
            r'```\n(.*?)```',
            # Indented code blocks
            r'\n((?:    .*\n)+)',
            # Code with common Python keywords
            r'((?:^|\n)(?:def|class|import|from) .*(?:\n(?:    |\t).*)*)',
        ]
        
        import re
        for pattern in patterns:
            matches = re.finditer(pattern, doc_content, re.MULTILINE | re.DOTALL)
            for match in matches:
                code = match.group(1).strip()
                if len(code) > 20:  # Minimum viable code block
                    code_blocks.append({
                        'code': code,
                        'start_pos': match.start(),
                        'context': self._extract_context(doc_content, match.start())
                    })
        
        return code_blocks
    
    def _extract_context(self, text: str, position: int, window: int = 200) -> str:
        """Extract surrounding text for context"""
        start = max(0, position - window)
        end = min(len(text), position + window)
        return text[start:end]
    
    def analyze_doc_structure(self, doc_content: str) -> Dict:
        """Analyze a Google Doc for organizational structure"""
        result = {
            'title': self._extract_title(doc_content),
            'sections': [],
            'code_blocks': [],
            'keywords': set(),
            'suggested_modules': []
        }
        
        # Extract code blocks
        code_blocks = self.extract_code_blocks(doc_content)
        
        for i, block in enumerate(code_blocks):
            # Create temporary file to analyze
            temp_analysis = {
                'name': f"extracted_block_{i}.py",
                'content': block['code'],
                'context': block['context']
            }
            
            # Score against keyword map
            matches = {}
            content_lower = block['code'].lower()
            context_lower = block['context'].lower()
            
            for category, keywords in self.scanner.keyword_map.items():
                score = 0
                for keyword in keywords:
                    if keyword in content_lower:
                        score += 2
                    if keyword in context_lower:
                        score += 1
                
                if score > 0:
                    matches[category] = score
            
            if matches:
                best_match = max(matches.items(), key=lambda x: x[1])
                category = best_match[0]
                
                if category in self.scanner.placement_rules:
                    module, path = self.scanner.placement_rules[category]
                    temp_analysis['suggested_module'] = module
                    temp_analysis['suggested_path'] = path
                    temp_analysis['confidence'] = min(best_match[1] / 10.0, 1.0)
            
            result['code_blocks'].append(temp_analysis)
        
        return result
    
    def _extract_title(self, text: str) -> str:
        """Try to extract document title from first line or heading"""
        lines = text.strip().split('\n')
        if lines:
            return lines[0][:100]  # First 100 chars of first line
        return "Untitled Document"
    
    def create_files_from_doc(self, doc_id: str, output_dir: Path, doc_content: str = None):
        """
        Extract and create Python files from a Google Doc
        
        Args:
            doc_id: Google Doc ID (or pass content directly)
            output_dir: Where to save extracted files
            doc_content: Optional - pass content directly if already fetched
        """
        if doc_content is None:
            print("⚠️  Note: You'll need to fetch the doc content first")
            print("    Use: google_drive_fetch tool with document_ids=['{doc_id}']")
            return
        
        print(f"📄 Analyzing document: {doc_id[:20]}...")
        
        analysis = self.analyze_doc_structure(doc_content)
        
        print(f"\n✅ Found {len(analysis['code_blocks'])} code blocks")
        
        output_dir.mkdir(parents=True, exist_ok=True)
        
        for i, block in enumerate(analysis['code_blocks']):
            # Determine filename
            if block.get('suggested_path'):
                filename = block['suggested_path'].split('/')[-1]
                if not filename.endswith('.py'):
                    filename = f"{filename}_{i}.py"
            else:
                filename = f"extracted_{i}.py"
            
            file_path = output_dir / filename
            
            # Add header comment with metadata
            header = f'''"""
Extracted from Google Doc: {analysis['title']}
Block {i+1}/{len(analysis['code_blocks'])}
Suggested placement: {block.get('suggested_module', 'unknown')}/{block.get('suggested_path', 'unknown')}
Confidence: {block.get('confidence', 0):.0%}

Context: {block.get('context', 'No context available')[:200]}
"""

'''
            
            full_content = header + block['code']
            file_path.write_text(full_content)
            
            print(f"   ✓ Created: {filename}")
            if block.get('suggested_module'):
                print(f"     → Suggested: {block['suggested_module']}/{block['suggested_path']}")
        
        # Generate summary report
        report_path = output_dir / "_extraction_report.txt"
        report = [
            "=" * 80,
            f"EXTRACTION REPORT: {analysis['title']}",
            "=" * 80,
            f"\nTotal code blocks extracted: {len(analysis['code_blocks'])}",
            "\nSuggested placements:",
        ]
        
        for i, block in enumerate(analysis['code_blocks']):
            report.append(f"\n{i+1}. extracted_{i}.py")
            report.append(f"   Module: {block.get('suggested_module', 'unknown')}")
            report.append(f"   Path: {block.get('suggested_path', 'unknown')}")
            report.append(f"   Confidence: {block.get('confidence', 0):.0%}")
        
        report_path.write_text("\n".join(report))
        print(f"\n📊 Report saved to: {report_path}")


def interactive_docs_extractor():
    """Interactive Google Docs code extraction"""
    print("📚 GOOGLE DOCS CODE EXTRACTOR\n")
    print("This tool extracts code from your Google Docs and organizes it.")
    print("\nYou can either:")
    print("1. Provide a Google Doc URL/ID directly")
    print("2. Upload/paste doc content")
    
    choice = input("\nSelect option (1-2): ").strip()
    
    organizer = create_example_structure()
    extractor = GoogleDocsExtractor(organizer)
    
    if choice == "1":
        doc_input = input("\nEnter Google Doc URL or ID: ").strip()
        
        # Extract doc ID from URL if needed
        if 'docs.google.com' in doc_input:
            import re
            match = re.search(r'/document/d/([a-zA-Z0-9-_]+)', doc_input)
            if match:
                doc_id = match.group(1)
            else:
                print("❌ Couldn't extract doc ID from URL")
                return
        else:
            doc_id = doc_input
        
        print(f"\n📡 Doc ID: {doc_id}")
        print("\n⚠️  To fetch the content, you need to:")
        print(f"    1. Use the google_drive_fetch tool")
        print(f"    2. Pass document_ids=['{doc_id}']")
        print("    3. Copy the returned content and run this again with option 2")
        
    elif choice == "2":
        print("\n📝 Paste your Google Doc content below.")
        print("(Press Ctrl+D when done, or type '###END###' on a new line)\n")
        
        lines = []
        try:
            while True:
                line = input()
                if line.strip() == '###END###':
                    break
                lines.append(line)
        except EOFError:
            pass
        
        doc_content = '\n'.join(lines)
        
        if not doc_content.strip():
            print("❌ No content provided")
            return
        
        output_dir = Path("./extracted_from_docs")
        extractor.create_files_from_doc("pasted_content", output_dir, doc_content)
        
        print(f"\n✅ Extraction complete!")
        print(f"📁 Files saved to: {output_dir}")
        
        # Offer to scan the extracted files
        scan = input("\nScan extracted files for placement? (yes/no): ").strip().lower()
        if scan == 'yes':
            scanner = FileScanner(organizer)
            results = scanner.scan_directory(output_dir)
            report = scanner.generate_report(results)
            print("\n" + report)


# GITHUB INTEGRATION
class GitHubRepoAnalyzer:
    """Clone and analyze GitHub repositories for integration"""
    
    def __init__(self, organizer: TreeOrganizer):
        self.organizer = organizer
        self.scanner = FileScanner(organizer)
    
    def parse_github_url(self, url: str) -> Dict:
        """Extract owner and repo from GitHub URL"""
        import re
        
        patterns = [
            r'github\.com/([^/]+)/([^/]+?)(?:\.git)?$',
            r'github\.com/([^/]+)/([^/]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return {
                    'owner': match.group(1),
                    'repo': match.group(2).replace('.git', ''),
                    'url': url
                }
        
        return None
    
    def clone_repo(self, repo_url: str, target_dir: Path) -> bool:
        """Clone a GitHub repo using git command"""
        import subprocess
        
        try:
            target_dir.mkdir(parents=True, exist_ok=True)
            
            print(f"🔄 Cloning {repo_url}...")
            result = subprocess.run(
                ['git', 'clone', repo_url, str(target_dir)],
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode == 0:
                print(f"✅ Cloned successfully to {target_dir}")
                return True
            else:
                print(f"❌ Clone failed: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            print("❌ Clone timed out (>2 min)")
            return False
        except FileNotFoundError:
            print("❌ Git not installed. Install git first:")
            print("   - Windows: https://git-scm.com/download/win")
            print("   - Mac: brew install git")
            print("   - Linux: sudo apt install git")
            return False
        except Exception as e:
            print(f"❌ Clone error: {e}")
            return False
    
    def download_repo_zip(self, repo_url: str, target_dir: Path) -> bool:
        """Fallback: Download repo as zip (no git required)"""
        import urllib.request
        import zipfile
        import shutil
        
        try:
            repo_info = self.parse_github_url(repo_url)
            if not repo_info:
                print("❌ Invalid GitHub URL")
                return False
            
            zip_url = f"https://github.com/{repo_info['owner']}/{repo_info['repo']}/archive/refs/heads/main.zip"
            
            print(f"📦 Downloading {repo_info['repo']} as zip...")
            
            target_dir.mkdir(parents=True, exist_ok=True)
            zip_path = target_dir / "repo.zip"
            
            # Download
            urllib.request.urlretrieve(zip_url, zip_path)
            
            # Extract
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(target_dir)
            
            # Clean up zip
            zip_path.unlink()
            
            # Move contents from subdirectory (GitHub adds repo-name-main folder)
            subdirs = [d for d in target_dir.iterdir() if d.is_dir()]
            if subdirs:
                subdir = subdirs[0]
                for item in subdir.iterdir():
                    shutil.move(str(item), str(target_dir))
                subdir.rmdir()
            
            print(f"✅ Downloaded to {target_dir}")
            return True
            
        except urllib.error.HTTPError as e:
            if e.code == 404:
                # Try 'master' branch instead
                print("⚠️  'main' branch not found, trying 'master'...")
                zip_url = f"https://github.com/{repo_info['owner']}/{repo_info['repo']}/archive/refs/heads/master.zip"
                try:
                    urllib.request.urlretrieve(zip_url, zip_path)
                    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                        zip_ref.extractall(target_dir)
                    zip_path.unlink()
                    print(f"✅ Downloaded to {target_dir}")
                    return True
                except:
                    print("❌ Couldn't find 'master' branch either")
                    return False
            else:
                print(f"❌ Download failed: {e}")
                return False
        except Exception as e:
            print(f"❌ Download error: {e}")
            return False
    
    def analyze_repo_structure(self, repo_dir: Path) -> Dict:
        """Analyze a cloned repo's structure"""
        structure = {
            'python_files': 0,
            'total_files': 0,
            'directories': 0,
            'has_setup_py': False,
            'has_requirements': False,
            'has_readme': False,
            'likely_type': 'unknown'
        }
        
        for item in repo_dir.rglob('*'):
            if item.is_file():
                structure['total_files'] += 1
                
                if item.suffix == '.py':
                    structure['python_files'] += 1
                
                if item.name == 'setup.py':
                    structure['has_setup_py'] = True
                elif item.name in ['requirements.txt', 'pyproject.toml', 'Pipfile']:
                    structure['has_requirements'] = True
                elif item.name.lower().startswith('readme'):
                    structure['has_readme'] = True
            
            elif item.is_dir():
                structure['directories'] += 1
        
        # Guess project type
        if structure['has_setup_py']:
            structure['likely_type'] = 'python_package'
        elif structure['python_files'] > 10:
            structure['likely_type'] = 'python_project'
        elif structure['python_files'] > 0:
            structure['likely_type'] = 'scripts'
        
        return structure
    
    def generate_integration_plan(self, scan_results: List[Dict], repo_name: str) -> str:
        """Create a markdown integration plan"""
        lines = [
            f"# Integration Plan: {repo_name}",
            "",
            "## Overview",
            f"- Total files analyzed: {len(scan_results)}",
            f"- High confidence placements: {len([r for r in scan_results if r['confidence'] >= 0.7])}",
            f"- Needs review: {len([r for r in scan_results if r['confidence'] < 0.7])}",
            "",
            "## Recommended Actions",
            ""
        ]
        
        # Group by suggested module
        by_module = {}
        for result in scan_results:
            module = result.get('suggested_module', 'unclassified')
            if module not in by_module:
                by_module[module] = []
            by_module[module].append(result)
        
        for module, files in sorted(by_module.items()):
            lines.append(f"### {module.upper()} Module")
            lines.append("")
            
            for file in sorted(files, key=lambda x: x['confidence'], reverse=True):
                confidence_icon = "🟢" if file['confidence'] >= 0.7 else "🟡" if file['confidence'] >= 0.3 else "🔴"
                lines.append(f"- {confidence_icon} `{file['name']}` → `{file.get('suggested_path', 'TBD')}`")
                lines.append(f"  - Confidence: {file['confidence']:.0%}")
                
                if file.get('classes'):
                    lines.append(f"  - Classes: `{', '.join(file['classes'][:3])}`")
                if file.get('functions'):
                    lines.append(f"  - Functions: `{', '.join(file['functions'][:3])}`")
                
                lines.append("")
        
        lines.extend([
            "## Next Steps",
            "",
            "1. Review high-confidence placements (🟢)",
            "2. Manually categorize low-confidence files (🔴)",
            "3. Check for dependency conflicts",
            "4. Test integration with existing modules",
            "5. Update imports and paths",
        ])
        
        return "\n".join(lines)


def interactive_github_analyzer():
    """Interactive GitHub repo analysis and integration"""
    print("🐙 GITHUB REPO ANALYZER\n")
    print("Analyze and integrate code from GitHub repositories")
    print("(Works with your repos or any public repo)\n")
    
    repo_url = input("Enter GitHub repo URL: ").strip()
    
    if not repo_url:
        print("❌ No URL provided")
        return
    
    organizer = create_example_structure()
    analyzer = GitHubRepoAnalyzer(organizer)
    
    # Parse URL
    repo_info = analyzer.parse_github_url(repo_url)
    if not repo_info:
        print("❌ Invalid GitHub URL")
        print("   Expected format: https://github.com/username/repo")
        return
    
    print(f"\n📍 Repository: {repo_info['owner']}/{repo_info['repo']}")
    
    # Choose clone method
    print("\nClone method:")
    print("1. Git clone (requires git installed, faster)")
    print("2. Download ZIP (no dependencies, works everywhere)")
    
    method = input("Select (1-2): ").strip()
    
    target_dir = Path(f"./github_repos/{repo_info['repo']}")
    
    success = False
    if method == "1":
        success = analyzer.clone_repo(repo_url, target_dir)
    else:
        success = analyzer.download_repo_zip(repo_url, target_dir)
    
    if not success:
        return
    
    # Analyze structure
    print("\n🔍 Analyzing repository structure...")
    structure = analyzer.analyze_repo_structure(target_dir)
    
    print(f"\n📊 Repository Stats:")
    print(f"   Python files: {structure['python_files']}")
    print(f"   Total files: {structure['total_files']}")
    print(f"   Directories: {structure['directories']}")
    print(f"   Project type: {structure['likely_type']}")
    
    if structure['python_files'] == 0:
        print("\n⚠️  No Python files found. This repo might not be relevant.")
        return
    
    # Scan files
    print(f"\n🔬 Scanning {structure['python_files']} Python files...")
    scanner = FileScanner(organizer)
    results = scanner.scan_directory(target_dir)
    
    # Generate report
    report = scanner.generate_report(results, sort_by='confidence')
    print("\n" + report)
    
    # Generate integration plan
    print("\n📋 Generating integration plan...")
    plan = analyzer.generate_integration_plan(results, repo_info['repo'])
    
    plan_file = Path(f"./integration_plan_{repo_info['repo']}.md")
    plan_file.write_text(plan)
    print(f"✅ Integration plan saved to: {plan_file}")
    
    # Options
    print("\n" + "=" * 80)
    print("What would you like to do?")
    print("1. View integration plan")
    print("2. Auto-organize high-confidence files (dry run)")
    print("3. Export scan results as JSON")
    print("4. Keep repo for manual integration")
    print("5. Delete downloaded repo")
    
    choice = input("\nSelect (1-5): ").strip()
    
    if choice == "1":
        print("\n" + plan)
    
    elif choice == "2":
        actions = scanner.auto_organize(results, min_confidence=0.7, dry_run=True)
        print(f"\n🔄 Would integrate {len(actions['moved'])} files:")
        for action in actions['moved']:
            print(f"   {action['file'].name} → {action['to']} ({action['confidence']:.0%})")
    
    elif choice == "3":
        import json
        output_file = Path(f"./github_scan_{repo_info['repo']}.json")
        output_file.write_text(json.dumps([{
            'name': r['name'],
            'path': str(r['path']),
            'confidence': r['confidence'],
            'suggested_module': r['suggested_module'],
            'suggested_path': r['suggested_path'],
            'matches': r['matches'],
            'classes': r.get('classes', []),
            'functions': r.get('functions', [])
        } for r in results], indent=2))
        print(f"✅ Saved to: {output_file}")
    
    elif choice == "4":
        print(f"✅ Repo kept at: {target_dir}")
        print("   You can manually review and integrate files")
    
    elif choice == "5":
        import shutil
        shutil.rmtree(target_dir)
        print(f"✅ Deleted: {target_dir}")
    
    print("\n🎉 Done!")


# CODE STITCHER - Seamless Integration Engine
class CodeStitcher:
    """Intelligently merge and integrate multiple code sources"""
    
    def __init__(self, organizer: TreeOrganizer):
        self.organizer = organizer
        self.scanner = FileScanner(organizer)
    
    def analyze_dependencies(self, file_paths: List[Path]) -> Dict:
        """Build dependency graph between files"""
        import re
        
        graph = {
            'files': {},
            'imports': {},
            'conflicts': [],
            'merge_candidates': []
        }
        
        for file_path in file_paths:
            try:
                content = file_path.read_text(encoding='utf-8', errors='ignore')
                
                file_info = {
                    'path': file_path,
                    'imports': [],
                    'exports': {
                        'classes': re.findall(r'^class\s+(\w+)', content, re.MULTILINE),
                        'functions': re.findall(r'^def\s+(\w+)', content, re.MULTILINE),
                        'variables': re.findall(r'^(\w+)\s*=', content, re.MULTILINE)
                    },
                    'internal_imports': [],
                    'external_imports': []
                }
                
                # Parse imports
                import_lines = re.findall(r'^(?:from\s+([\w.]+)\s+)?import\s+(.+?)(?:\s+as\s+\w+)?$', 
                                         content, re.MULTILINE)
                
                for module, items in import_lines:
                    if module:
                        file_info['imports'].append(f"{module}.{items.split(',')[0].strip()}")
                    else:
                        file_info['imports'].append(items.split(',')[0].strip())
                
                graph['files'][file_path.name] = file_info
                
            except Exception as e:
                print(f"⚠️  Error analyzing {file_path.name}: {e}")
        
        # Detect conflicts (same class/function names)
        all_exports = {}
        for filename, info in graph['files'].items():
            for export_type, names in info['exports'].items():
                for name in names:
                    if name not in all_exports:
                        all_exports[name] = []
                    all_exports[name].append((filename, export_type))
        
        for name, sources in all_exports.items():
            if len(sources) > 1:
                graph['conflicts'].append({
                    'name': name,
                    'sources': sources
                })
        
        # Find merge candidates (files that should be combined)
        for f1_name, f1_info in graph['files'].items():
            for f2_name, f2_info in graph['files'].items():
                if f1_name >= f2_name:  # Avoid duplicates
                    continue
                
                # Check if they have similar purpose
                similarity_score = self._calculate_similarity(f1_info, f2_info)
                
                if similarity_score > 0.6:  # High similarity threshold
                    graph['merge_candidates'].append({
                        'file1': f1_name,
                        'file2': f2_name,
                        'score': similarity_score,
                        'reason': self._explain_similarity(f1_info, f2_info)
                    })
        
        return graph
    
    def _calculate_similarity(self, file1_info: Dict, file2_info: Dict) -> float:
        """Calculate similarity score between two files"""
        score = 0.0
        
        # Same imports = related purpose
        imports1 = set(file1_info['imports'])
        imports2 = set(file2_info['imports'])
        
        if imports1 and imports2:
            import_overlap = len(imports1 & imports2) / len(imports1 | imports2)
            score += import_overlap * 0.4
        
        # Similar export types
        exports1 = set(file1_info['exports']['classes'] + file1_info['exports']['functions'])
        exports2 = set(file2_info['exports']['classes'] + file2_info['exports']['functions'])
        
        if exports1 and exports2:
            # Check for naming patterns (e.g., both have 'calculate_' functions)
            pattern_match = sum(1 for e1 in exports1 for e2 in exports2 
                              if e1[:5].lower() == e2[:5].lower())
            if pattern_match > 0:
                score += min(pattern_match / max(len(exports1), len(exports2)), 0.3)
        
        return score
    
    def _explain_similarity(self, file1_info: Dict, file2_info: Dict) -> str:
        """Generate explanation for why files are similar"""
        reasons = []
        
        imports1 = set(file1_info['imports'])
        imports2 = set(file2_info['imports'])
        overlap = imports1 & imports2
        
        if overlap:
            reasons.append(f"Shared imports: {', '.join(list(overlap)[:3])}")
        
        exports1 = file1_info['exports']['classes']
        exports2 = file2_info['exports']['classes']
        
        if exports1 and exports2:
            reasons.append(f"Related classes")
        
        return "; ".join(reasons) if reasons else "Similar structure"
    
    def resolve_conflicts(self, graph: Dict) -> Dict:
        """Generate conflict resolution strategies"""
        resolutions = {
            'rename_suggestions': [],
            'namespace_strategy': {},
            'merge_strategy': []
        }
        
        for conflict in graph['conflicts']:
            name = conflict['name']
            sources = conflict['sources']
            
            # Strategy 1: Rename with module prefix
            for filename, export_type in sources:
                base_name = filename.replace('.py', '')
                resolutions['rename_suggestions'].append({
                    'original': name,
                    'new': f"{base_name}_{name}",
                    'file': filename,
                    'type': export_type
                })
            
            # Strategy 2: Keep most comprehensive version
            # (Would need deeper analysis - placeholder for now)
            resolutions['merge_strategy'].append({
                'conflict': name,
                'recommendation': 'Review manually - choose most feature-complete version'
            })
        
        return resolutions
    
    def stitch_files(self, source_files: List[Path], output_path: Path, 
                    strategy: str = 'namespace') -> str:
        """
        Merge multiple files into one cohesive module
        
        Strategies:
        - 'namespace': Create submodules, no renaming
        - 'merge': Combine similar files, resolve conflicts
        - 'bridge': Keep separate, create integration layer
        """
        
        print(f"\n🧵 Stitching {len(source_files)} files...")
        print(f"   Strategy: {strategy}")
        
        # Analyze dependencies
        graph = self.analyze_dependencies(source_files)
        
        if strategy == 'namespace':
            return self._stitch_namespace(source_files, output_path, graph)
        elif strategy == 'merge':
            return self._stitch_merge(source_files, output_path, graph)
        elif strategy == 'bridge':
            return self._stitch_bridge(source_files, output_path, graph)
    
    def _stitch_namespace(self, files: List[Path], output_path: Path, graph: Dict) -> str:
        """Create namespace-based integration (safest)"""
        
        stitched_content = [
            '"""',
            f'Integrated module from {len(files)} source files',
            'Strategy: Namespace isolation',
            '"""',
            '',
            '# Auto-generated imports and namespace setup',
            ''
        ]
        
        # Create submodules for each file
        for file_path in files:
            module_name = file_path.stem
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            
            # Wrap in class namespace
            stitched_content.extend([
                f'# ========== From: {file_path.name} ==========',
                f'class {module_name}_namespace:',
                '    """Isolated namespace"""',
                ''
            ])
            
            # Indent all content
            for line in content.split('\n'):
                if line.strip() and not line.strip().startswith('#'):
                    stitched_content.append('    ' + line)
                elif line.strip().startswith('#'):
                    stitched_content.append(line)  # Keep comments unindented
                else:
                    stitched_content.append('')
            
            stitched_content.append('')
        
        # Add convenience accessor
        stitched_content.extend([
            '',
            '# Convenience accessors',
            'def get_module(name: str):',
            '    """Access a specific module namespace"""',
            '    modules = {',
        ])
        
        for file_path in files:
            module_name = file_path.stem
            stitched_content.append(f'        "{module_name}": {module_name}_namespace,')
        
        stitched_content.extend([
            '    }',
            '    return modules.get(name)',
            ''
        ])
        
        result = '\n'.join(stitched_content)
        output_path.write_text(result)
        
        print(f"✅ Namespace stitching complete: {output_path}")
        return result
    
    def _stitch_merge(self, files: List[Path], output_path: Path, graph: Dict) -> str:
        """Intelligently merge compatible files"""
        
        stitched_content = [
            '"""',
            f'Merged module from {len(files)} source files',
            'Strategy: Smart merge with conflict resolution',
            '"""',
            '',
        ]
        
        # Collect all imports first
        all_imports = set()
        for file_info in graph['files'].values():
            all_imports.update(file_info['imports'])
        
        stitched_content.extend([
            '# Unified imports',
            *[f'import {imp}' for imp in sorted(all_imports) if '.' not in imp],
            *[f'from {imp.rsplit(".", 1)[0]} import {imp.rsplit(".", 1)[1]}' 
              for imp in sorted(all_imports) if '.' in imp],
            '',
            ''
        ])
        
        # Handle conflicts
        resolutions = self.resolve_conflicts(graph)
        
        if graph['conflicts']:
            stitched_content.extend([
                '# Conflict resolution map',
                'RENAMED_EXPORTS = {',
            ])
            
            for suggestion in resolutions['rename_suggestions']:
                stitched_content.append(
                    f'    "{suggestion["original"]}": "{suggestion["new"]}",  # from {suggestion["file"]}'
                )
            
            stitched_content.extend([
                '}',
                '',
                ''
            ])
        
        # Merge file contents with renaming
        for file_path in files:
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            module_name = file_path.stem
            
            stitched_content.extend([
                f'# ========== From: {file_path.name} ==========',
                ''
            ])
            
            # Apply renaming for conflicts
            for suggestion in resolutions['rename_suggestions']:
                if suggestion['file'] == file_path.name:
                    # Simple string replacement (would need AST for robustness)
                    import re
                    pattern = r'\b' + suggestion['original'] + r'\b'
                    content = re.sub(pattern, suggestion['new'], content)
            
            # Remove import statements (already unified)
            lines = [line for line in content.split('\n') 
                    if not line.strip().startswith(('import ', 'from '))]
            
            stitched_content.extend(lines)
            stitched_content.append('')
        
        result = '\n'.join(stitched_content)
        output_path.write_text(result)
        
        print(f"✅ Merge stitching complete: {output_path}")
        if graph['conflicts']:
            print(f"⚠️  Resolved {len(graph['conflicts'])} naming conflicts")
        
        return result
    
    def _stitch_bridge(self, files: List[Path], output_path: Path, graph: Dict) -> str:
        """Create integration bridge layer"""
        
        stitched_content = [
            '"""',
            f'Integration bridge for {len(files)} modules',
            'Strategy: Unified interface with separate implementations',
            '"""',
            '',
            'from pathlib import Path',
            'import importlib.util',
            '',
            ''
        ]
        
        # Dynamic loader
        stitched_content.extend([
            'class IntegrationBridge:',
            '    """Unified interface to multiple module implementations"""',
            '    ',
            '    def __init__(self):',
            '        self.modules = {}',
            '        self._load_modules()',
            '    ',
            '    def _load_modules(self):',
            '        """Dynamically load all source modules"""',
        ])
        
        for file_path in files:
            module_name = file_path.stem
            stitched_content.extend([
                f'        # Load {file_path.name}',
                f'        spec = importlib.util.spec_from_file_location("{module_name}", "{file_path}")',
                f'        module = importlib.util.module_from_spec(spec)',
                f'        spec.loader.exec_module(module)',
                f'        self.modules["{module_name}"] = module',
                '        ',
            ])
        
        # Create unified interface methods
        stitched_content.extend([
            '    ',
            '    def get(self, module_name: str):',
            '        """Get a specific module"""',
            '        return self.modules.get(module_name)',
            '    ',
            '    def call(self, module_name: str, function_name: str, *args, **kwargs):',
            '        """Call a function from a specific module"""',
            '        module = self.modules.get(module_name)',
            '        if module and hasattr(module, function_name):',
            '            return getattr(module, function_name)(*args, **kwargs)',
            '        raise AttributeError(f"Function {function_name} not found in {module_name}")',
            '    ',
            '    def list_functions(self, module_name: str = None):',
            '        """List all available functions"""',
            '        if module_name:',
            '            module = self.modules.get(module_name)',
            '            return [name for name in dir(module) if callable(getattr(module, name)) and not name.startswith("_")]',
            '        ',
            '        return {name: self.list_functions(name) for name in self.modules.keys()}',
            '',
            '',
            '# Create global bridge instance',
            'bridge = IntegrationBridge()',
        ])
        
        result = '\n'.join(stitched_content)
        output_path.write_text(result)
        
        print(f"✅ Bridge stitching complete: {output_path}")
        return result
    
    def generate_integration_tests(self, stitched_file: Path, original_files: List[Path]) -> Path:
        """Generate tests to verify integration works"""
        
        test_content = [
            '"""',
            f'Integration tests for {stitched_file.name}',
            'Auto-generated test suite',
            '"""',
            '',
            'import pytest',
            f'from {stitched_file.stem} import *',
            '',
            ''
        ]
        
        # Basic smoke tests
        test_content.extend([
            'def test_imports():',
            '    """Verify all components can be imported"""',
            '    # Add specific import checks here',
            '    assert True',
            '',
            '',
            'def test_no_conflicts():',
            '    """Verify no naming conflicts"""',
            '    # Check for duplicate names',
            '    assert True',
            '',
            ''
        ])
        
        test_file = stitched_file.parent / f'test_{stitched_file.stem}.py'
        test_file.write_text('\n'.join(test_content))
        
        print(f"✅ Generated tests: {test_file}")
        return test_file


def interactive_stitcher():
    """Interactive code stitching workflow"""
    print("🧵 CODE STITCHER - Seamless Integration\n")
    print("Merge multiple code sources into unified modules")
    print("=" * 70)
    
    # Get files to stitch
    print("\nHow do you want to select files?")
    print("1. From a directory (scan all Python files)")
    print("2. From GitHub repo analysis results")
    print("3. Manual file list")
    
    choice = input("\nSelect (1-3): ").strip()
    
    files_to_stitch = []
    
    if choice == "1":
        dir_path = input("Enter directory path: ").strip()
        source_dir = Path(dir_path)
        
        if not source_dir.exists():
            print("❌ Directory not found")
            return
        
        files_to_stitch = list(source_dir.glob('*.py'))
        print(f"✅ Found {len(files_to_stitch)} Python files")
    
    elif choice == "2":
        print("⚠️  Use this after running GitHub analyzer")
        repo_dir = input("Enter repo directory: ").strip()
        source_dir = Path(repo_dir)
        
        if not source_dir.exists():
            print("❌ Directory not found")
            return
        
        files_to_stitch = list(source_dir.rglob('*.py'))
        
        # Filter by confidence if scan results exist
        scan_file = Path(f"./github_scan_{source_dir.name}.json")
        if scan_file.exists():
            import json
            scan_data = json.loads(scan_file.read_text())
            high_conf_names = [r['name'] for r in scan_data if r['confidence'] >= 0.7]
            files_to_stitch = [f for f in files_to_stitch if f.name in high_conf_names]
            print(f"✅ Filtered to {len(files_to_stitch)} high-confidence files")
    
    elif choice == "3":
        print("Enter file paths (one per line, empty line to finish):")
        while True:
            path = input().strip()
            if not path:
                break
            file_path = Path(path)
            if file_path.exists():
                files_to_stitch.append(file_path)
            else:
                print(f"⚠️  File not found: {path}")
    
    if not files_to_stitch:
        print("❌ No files to stitch")
        return
    
    # Show files
    print(f"\n📋 Files to stitch ({len(files_to_stitch)}):")
    for f in files_to_stitch[:10]:
        print(f"   - {f.name}")
    if len(files_to_stitch) > 10:
        print(f"   ... and {len(files_to_stitch) - 10} more")
    
    # Choose strategy
    print("\n🎯 Stitching strategy:")
    print("1. Namespace (safest - isolates each file)")
    print("2. Merge (smart - combines compatible files)")
    print("3. Bridge (dynamic - unified interface layer)")
    
    strategy_choice = input("\nSelect (1-3): ").strip()
    strategy_map = {'1': 'namespace', '2': 'merge', '3': 'bridge'}
    strategy = strategy_map.get(strategy_choice, 'namespace')
    
    # Output location
    output_name = input("\nOutput module name (e.g., 'unified_consciousness.py'): ").strip()
    if not output_name.endswith('.py'):
        output_name += '.py'
    
    output_path = Path(f"./stitched/{output_name}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Execute stitching
    organizer = create_example_structure()
    stitcher = CodeStitcher(organizer)
    
    result = stitcher.stitch_files(files_to_stitch, output_path, strategy)
    
    # Generate tests
    generate_tests = input("\nGenerate integration tests? (yes/no): ").strip().lower()
    if generate_tests == 'yes':
        stitcher.generate_integration_tests(output_path, files_to_stitch)
    
    print(f"\n🎉 Stitching complete!")
    print(f"📄 Output: {output_path}")
    print(f"💾 Size: {len(result)} characters")


if __name__ == "__main__":
    print("Choose mode:")
    print("1. Build module structure manually")
    print("2. Scan and organize existing files")
    print("3. Extract code from Google Docs")
    print("4. Analyze GitHub repository")
    print("5. Stitch files together (seamless integration)")
    mode = input("Select (1-5): ").strip()
    
    if mode == "2":
        interactive_scanner()
    elif mode == "3":
        interactive_docs_extractor()
    elif mode == "4":
        interactive_github_analyzer()
    elif mode == "5":
        interactive_stitcher()
    else:
        # Original organizer code
        print("🌳 Consciousness System - Modular Tree Organizer\n")
        organizer = create_example_structure()
        print(organizer.visualize_all())
        print("\n" + "=" * 60)
        print("OPTIONS:")
        print("1. Export trees as JSON")
        print("2. Generate actual filesystem")
        print("3. Add new module (interactive)")
        print("4. Exit")
        
        choice = input("\nSelect option (1-4): ").strip()
        
        if choice == "1":
            output_dir = Path("./exports")
            organizer.export_all(output_dir)
            print(f"✅ Exported to {output_dir}/")
        
        elif choice == "2":
            base_path = Path("./consciousness-system")
            organizer.generate_all(base_path)
            print(f"✅ Generated filesystem at {base_path}/")
        
        elif choice == "3":
            name = input("Module name: ").strip()
            desc = input("Description: ").strip()
            tree = organizer.add_module(name, desc)
            print(f"✅ Created module '{name}'")
            print("\nAdd files with: tree.add_file('path/file.py', 'description')")
        
        print("\n🎉 Done!")
