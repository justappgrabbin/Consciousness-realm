import { cn } from "@/lib/utils";

interface WorldClockProps {
  worldHour: number;
  worldDay: number;
  tick: number;
  paused: boolean;
  className?: string;
  compact?: boolean;
}

function formatTime(worldHour: number): string {
  const h = Math.floor(worldHour);
  const m = Math.round((worldHour - h) * 60);
  const ampm = h >= 12 ? "PM" : "AM";
  const displayH = h % 12 === 0 ? 12 : h % 12;
  return `${displayH}:${m.toString().padStart(2, "0")} ${ampm}`;
}

function getTimeOfDay(worldHour: number): { label: string; emoji: string; bg: string } {
  if (worldHour >= 5 && worldHour < 8) return { label: "Dawn", emoji: "🌅", bg: "from-orange-900/30 to-pink-900/20" };
  if (worldHour >= 8 && worldHour < 12) return { label: "Morning", emoji: "☀️", bg: "from-yellow-900/20 to-amber-900/10" };
  if (worldHour >= 12 && worldHour < 14) return { label: "Noon", emoji: "🌞", bg: "from-yellow-800/20 to-orange-800/10" };
  if (worldHour >= 14 && worldHour < 18) return { label: "Afternoon", emoji: "🌤️", bg: "from-blue-900/20 to-sky-900/10" };
  if (worldHour >= 18 && worldHour < 21) return { label: "Evening", emoji: "🌆", bg: "from-purple-900/30 to-indigo-900/20" };
  if (worldHour >= 21 && worldHour < 24) return { label: "Night", emoji: "🌙", bg: "from-indigo-950/40 to-slate-950/30" };
  return { label: "Midnight", emoji: "🌑", bg: "from-slate-950/40 to-zinc-950/30" };
}

export function WorldClock({ worldHour, worldDay, tick, paused, className, compact = false }: WorldClockProps) {
  const timeOfDay = getTimeOfDay(worldHour);

  if (compact) {
    return (
      <div className={cn("flex items-center gap-2", className)}>
        <span className="text-sm">{timeOfDay.emoji}</span>
        <div>
          <div className="text-xs font-mono font-semibold text-foreground">{formatTime(worldHour)}</div>
          <div className="text-[10px] text-muted-foreground">Day {worldDay}</div>
        </div>
        {paused && (
          <span className="text-xs px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-medium">PAUSED</span>
        )}
      </div>
    );
  }

  return (
    <div className={cn(
      "rounded-2xl p-4 bg-gradient-to-br border border-border/50",
      timeOfDay.bg,
      className
    )}>
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl">{timeOfDay.emoji}</span>
            <div>
              <div className="text-2xl font-mono font-bold text-foreground tracking-tight">
                {formatTime(worldHour)}
              </div>
              <div className="text-xs text-muted-foreground">{timeOfDay.label} · Day {worldDay}</div>
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className={cn(
            "text-xs px-2 py-1 rounded-full font-medium",
            paused
              ? "bg-amber-500/20 text-amber-400"
              : "bg-green-500/20 text-green-400"
          )}>
            {paused ? "⏸ Paused" : "▶ Running"}
          </div>
          <div className="text-xs text-muted-foreground mt-1">Tick #{tick}</div>
        </div>
      </div>
    </div>
  );
}
