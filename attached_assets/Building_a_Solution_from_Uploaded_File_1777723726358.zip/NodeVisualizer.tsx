/**
 * NodeVisualizer Component
 * 
 * Design: Abstract Crystalline
 * Visualizes the 18-node recursive oscillator network with animated connections
 * and pulsing nodes showing recursive structure.
 */

import { useEffect, useRef, useState } from 'react';
import { Card } from '@/components/ui/card';

interface Node {
  id: number;
  x: number;
  y: number;
  layer: number;
  active: boolean;
  intensity: number;
}

interface Connection {
  from: number;
  to: number;
  strength: number;
}

export default function NodeVisualizer() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [nodes, setNodes] = useState<Node[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const animationRef = useRef<number | undefined>(undefined);
  const timeRef = useRef<number>(0);

  // Initialize 18-node network with recursive structure
  useEffect(() => {
    const newNodes: Node[] = [];
    const newConnections: Connection[] = [];

    // Create 3 layers of 6 nodes each (18 total)
    for (let layer = 0; layer < 3; layer++) {
      for (let i = 0; i < 6; i++) {
        const angle = (i / 6) * Math.PI * 2;
        const radius = 80 + layer * 60;
        newNodes.push({
          id: layer * 6 + i,
          x: Math.cos(angle) * radius,
          y: Math.sin(angle) * radius,
          layer,
          active: false,
          intensity: 0,
        });
      }
    }

    // Create recursive connections
    for (let i = 0; i < newNodes.length; i++) {
      const node = newNodes[i];
      // Connect to nearby nodes in same layer
      for (let j = i + 1; j < newNodes.length; j++) {
        const other = newNodes[j];
        if (other.layer === node.layer) {
          const dist = Math.hypot(other.x - node.x, other.y - node.y);
          if (dist < 120) {
            newConnections.push({
              from: i,
              to: j,
              strength: Math.random() * 0.8 + 0.2,
            });
          }
        }
      }
      // Connect to next layer
      if (node.layer < 2) {
        const nextLayerStart = (node.layer + 1) * 6;
        const targetIdx = nextLayerStart + (i % 6);
        newConnections.push({
          from: i,
          to: targetIdx,
          strength: 0.6,
        });
      }
    }

    setNodes(newNodes);
    setConnections(newConnections);
  }, []);

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const animate = () => {
      timeRef.current += 0.016; // ~60fps

      // Clear canvas
      ctx.fillStyle = '#0d0d0d';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      // Update node intensities based on time
      const updatedNodes = nodes.map((node, idx) => ({
        ...node,
        active: Math.sin(timeRef.current + idx * 0.3) > 0.5,
        intensity: Math.max(0, Math.sin(timeRef.current + idx * 0.3) * 0.5 + 0.5),
      }));

      // Draw connections
      ctx.strokeStyle = 'rgba(14, 165, 233, 0.15)';
      ctx.lineWidth = 1;
      connections.forEach((conn) => {
        const fromNode = updatedNodes[conn.from];
        const toNode = updatedNodes[conn.to];
        const opacity = conn.strength * 0.3 * (fromNode.intensity + toNode.intensity) / 2;
        ctx.strokeStyle = `rgba(14, 165, 233, ${opacity})`;
        ctx.beginPath();
        ctx.moveTo(centerX + fromNode.x, centerY + fromNode.y);
        ctx.lineTo(centerX + toNode.x, centerY + toNode.y);
        ctx.stroke();
      });

      // Draw nodes
      updatedNodes.forEach((node) => {
        const x = centerX + node.x;
        const y = centerY + node.y;
        const size = 4 + node.intensity * 3;

        // Glow effect
        const gradient = ctx.createRadialGradient(x, y, 0, x, y, size * 3);
        gradient.addColorStop(0, `rgba(124, 58, 237, ${node.intensity * 0.4})`);
        gradient.addColorStop(1, 'rgba(124, 58, 237, 0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(x - size * 3, y - size * 3, size * 6, size * 6);

        // Node core
        ctx.fillStyle = node.active ? '#7c3aed' : '#0ea5e9';
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fill();

        // Bright center
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(x, y, size * 0.4, 0, Math.PI * 2);
        ctx.fill();
      });

      setNodes(updatedNodes);
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [nodes, connections]);

  return (
    <div className="space-y-6">
      <Card className="p-6 border-border bg-card overflow-hidden">
        <div className="mb-4">
          <h4 className="font-mono text-sm text-cyan-400 uppercase tracking-wider mb-2">
            Recursive Network Topology
          </h4>
          <p className="text-sm text-muted-foreground">
            18 nodes arranged in 3 recursive layers with dynamic connection strength
          </p>
        </div>
        <canvas
          ref={canvasRef}
          width={600}
          height={400}
          className="w-full border border-border rounded-sm bg-black/50"
        />
      </Card>

      <div className="grid md:grid-cols-3 gap-4">
        {[
          {
            label: 'Total Nodes',
            value: '18',
            desc: 'Arranged in 3 recursive layers',
          },
          {
            label: 'Connection Density',
            value: '~42',
            desc: 'Dynamic recursive pathways',
          },
          {
            label: 'Oscillation State',
            value: 'Active',
            desc: 'Real-time pulsing visualization',
          },
        ].map((stat, i) => (
          <Card key={i} className="p-4 border-border bg-secondary/50">
            <div className="font-mono text-xs text-cyan-400 uppercase tracking-wider mb-1">
              {stat.label}
            </div>
            <div className="text-2xl font-bold text-violet-400 mb-1">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.desc}</div>
          </Card>
        ))}
      </div>

      <Card className="p-6 border-border bg-secondary/30">
        <h4 className="font-mono text-sm text-violet-400 uppercase tracking-wider mb-3">
          Network Properties
        </h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Integrated Curvature (Ω)</span>
            <span className="font-mono text-cyan-400">0.847</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Information Manifold Complexity</span>
            <span className="font-mono text-cyan-400">High</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Recursive Depth</span>
            <span className="font-mono text-cyan-400">3 Levels</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Non-Decomposability Index</span>
            <span className="font-mono text-cyan-400">0.923</span>
          </div>
        </div>
      </Card>
    </div>
  );
}
