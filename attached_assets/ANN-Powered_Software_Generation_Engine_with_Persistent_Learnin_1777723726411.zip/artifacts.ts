import { storagePut } from "./storage";
import type { GeneratedApp } from "./karen";

// ─── Zip Packaging ────────────────────────────────────────────────────────────
// Build a simple zip-like tar structure using base64 encoding
// We store each file as a JSON manifest for download

export interface ArtifactPackage {
  projectName: string;
  files: Array<{
    path: string;
    content: string;
    language: string;
    description: string;
  }>;
  setupInstructions: string;
  deploymentNotes: string;
  karenNotes: string;
  detectedPatterns: string[];
  gapsFilled: string[];
  generatedAt: string;
}

export async function packageAndUploadArtifact(
  projectId: number,
  userId: number,
  projectName: string,
  generatedApp: GeneratedApp
): Promise<{ s3Key: string; s3Url: string; fileTree: string[] }> {
  const pkg: ArtifactPackage = {
    projectName,
    files: generatedApp.files,
    setupInstructions: generatedApp.setupInstructions,
    deploymentNotes: generatedApp.deploymentNotes,
    karenNotes: generatedApp.karenNotes,
    detectedPatterns: generatedApp.detectedPatterns,
    gapsFilled: generatedApp.gapsFilled,
    generatedAt: new Date().toISOString(),
  };

  const jsonContent = JSON.stringify(pkg, null, 2);
  const buffer = Buffer.from(jsonContent, "utf-8");
  const suffix = Math.random().toString(36).substring(2, 10);
  const s3Key = `artifacts/project-${projectId}-user-${userId}-${suffix}.json`;

  const { url } = await storagePut(s3Key, buffer, "application/json");

  const fileTree = generatedApp.files.map((f) => f.path);

  return { s3Key, s3Url: url, fileTree };
}

export function buildFileTree(files: Array<{ path: string }>): Record<string, unknown> {
  const tree: Record<string, unknown> = {};

  for (const file of files) {
    const parts = file.path.split("/");
    let current = tree;
    for (let i = 0; i < parts.length - 1; i++) {
      const part = parts[i];
      if (!current[part]) current[part] = {};
      current = current[part] as Record<string, unknown>;
    }
    const filename = parts[parts.length - 1];
    current[filename] = "file";
  }

  return tree;
}

export function generatePreviewScaffold(
  projectName: string,
  generatedApp: GeneratedApp
): string {
  const fileList = generatedApp.files
    .map(
      (f) => `
    <div class="file-item">
      <span class="file-icon">${getFileIcon(f.language)}</span>
      <span class="file-path">${f.path}</span>
      <span class="file-lang">${f.language}</span>
    </div>`
    )
    .join("");

  const patternList = generatedApp.detectedPatterns
    .map((p) => `<li>${p}</li>`)
    .join("");

  const gapList = generatedApp.gapsFilled
    .map((g) => `<li>${g}</li>`)
    .join("");

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${projectName} — Karen ANN Preview</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: #0a0e1a;
      color: #e0e6ff;
      font-family: 'Courier New', monospace;
      padding: 2rem;
      min-height: 100vh;
    }
    .header {
      border-bottom: 1px solid #ff2d78;
      padding-bottom: 1rem;
      margin-bottom: 2rem;
    }
    .header h1 {
      font-size: 2rem;
      color: #ff2d78;
      text-shadow: 0 0 20px #0066ff;
      letter-spacing: 0.1em;
    }
    .header p { color: #00d4ff; margin-top: 0.5rem; font-size: 0.9rem; letter-spacing: 0.2em; }
    .section { margin-bottom: 2rem; }
    .section h2 {
      color: #00d4ff;
      font-size: 1rem;
      letter-spacing: 0.3em;
      text-transform: uppercase;
      margin-bottom: 1rem;
      border-left: 3px solid #ff2d78;
      padding-left: 0.75rem;
    }
    .file-item {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 0.5rem 0.75rem;
      border: 1px solid #1a2040;
      margin-bottom: 0.25rem;
      border-radius: 4px;
      transition: background 0.2s;
    }
    .file-item:hover { background: #0d1530; }
    .file-path { flex: 1; color: #a0b0e0; font-size: 0.85rem; }
    .file-lang {
      color: #ff2d78;
      font-size: 0.75rem;
      background: rgba(255,45,120,0.1);
      padding: 0.2rem 0.5rem;
      border-radius: 3px;
    }
    .karen-notes {
      background: rgba(0, 212, 255, 0.05);
      border: 1px solid #00d4ff;
      border-radius: 8px;
      padding: 1.5rem;
      color: #c0d8ff;
      line-height: 1.6;
    }
    .karen-notes::before {
      content: "KAREN://";
      color: #00d4ff;
      font-weight: bold;
      display: block;
      margin-bottom: 0.5rem;
      letter-spacing: 0.2em;
    }
    ul { list-style: none; padding: 0; }
    ul li {
      padding: 0.4rem 0.75rem;
      border-left: 2px solid #0066ff;
      margin-bottom: 0.25rem;
      color: #a0b0e0;
      font-size: 0.85rem;
    }
    .stats {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 1rem;
      margin-bottom: 2rem;
    }
    .stat {
      background: rgba(255,45,120,0.05);
      border: 1px solid rgba(255,45,120,0.2);
      border-radius: 8px;
      padding: 1rem;
      text-align: center;
    }
    .stat-value { font-size: 2rem; color: #ff2d78; font-weight: bold; }
    .stat-label { color: #606880; font-size: 0.75rem; letter-spacing: 0.2em; text-transform: uppercase; margin-top: 0.25rem; }
  </style>
</head>
<body>
  <div class="header">
    <h1>${projectName}</h1>
    <p>GENERATED BY KAREN ANN ENGINE · ${new Date().toISOString()}</p>
  </div>

  <div class="stats">
    <div class="stat">
      <div class="stat-value">${generatedApp.files.length}</div>
      <div class="stat-label">Files Generated</div>
    </div>
    <div class="stat">
      <div class="stat-value">${generatedApp.detectedPatterns.length}</div>
      <div class="stat-label">Patterns Applied</div>
    </div>
    <div class="stat">
      <div class="stat-value">${generatedApp.gapsFilled.length}</div>
      <div class="stat-label">Gaps Filled</div>
    </div>
  </div>

  <div class="section">
    <h2>Karen's Assessment</h2>
    <div class="karen-notes">${generatedApp.karenNotes}</div>
  </div>

  <div class="section">
    <h2>Generated Files</h2>
    ${fileList}
  </div>

  <div class="section">
    <h2>Detected Patterns</h2>
    <ul>${patternList}</ul>
  </div>

  <div class="section">
    <h2>Gaps Filled</h2>
    <ul>${gapList}</ul>
  </div>

  <div class="section">
    <h2>Setup Instructions</h2>
    <div class="karen-notes">${generatedApp.setupInstructions}</div>
  </div>

  <div class="section">
    <h2>Deployment Notes</h2>
    <div class="karen-notes">${generatedApp.deploymentNotes}</div>
  </div>
</body>
</html>`;
}

function getFileIcon(language: string): string {
  const icons: Record<string, string> = {
    typescript: "⟨TS⟩",
    javascript: "⟨JS⟩",
    python: "⟨PY⟩",
    rust: "⟨RS⟩",
    go: "⟨GO⟩",
    sql: "⟨DB⟩",
    css: "⟨CSS⟩",
    html: "⟨HTML⟩",
    json: "⟨JSON⟩",
    yaml: "⟨YAML⟩",
    markdown: "⟨MD⟩",
    shell: "⟨SH⟩",
  };
  return icons[language.toLowerCase()] ?? "⟨FILE⟩";
}
