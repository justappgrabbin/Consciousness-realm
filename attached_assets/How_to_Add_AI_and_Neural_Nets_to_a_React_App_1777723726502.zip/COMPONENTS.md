# Frontend Components Documentation

## Overview

This document describes the key React components that make up the AI Self-Builder frontend. Each component is designed with elegant styling, responsive layout, and smooth interactions.

## Page Components

### Home.tsx

**Purpose**: Landing page with feature overview and navigation

**Key Features**:
- Hero section with gradient text
- Feature cards grid (6 features)
- Neural brain status widget
- Call-to-action sections
- Responsive navigation bar

**State**:
- `user`: Current authenticated user
- `loading`: Auth loading state
- `isAuthenticated`: User authentication status

**Data Flow**:
```
useAuth() → Display user info
           → Show login/logout buttons
           → Display authenticated CTA
```

**Styling**:
- Dark gradient background (`from-slate-900 via-slate-800 to-slate-900`)
- Blue accent colors (`text-blue-400`, `bg-blue-600`)
- Smooth hover transitions on cards
- Animated gradient text

**Responsive Breakpoints**:
- Mobile: Single column layout
- Tablet (md): 2-column grids
- Desktop (lg): 3-4 column grids

### PDFUploader.tsx

**Purpose**: PDF file upload with drag-and-drop and progress tracking

**Key Features**:
- Drag-and-drop file zone
- File selection dialog
- Progress bar during upload
- Extracted content display
- Error handling with toast notifications

**State**:
- `file`: Selected file
- `uploading`: Upload in progress
- `progress`: Upload progress percentage
- `extractedContent`: Extracted concepts and code

**Data Flow**:
```
File Drop/Select
    ↓
trpc.knowledge.pdf.upload
    ↓
S3 Upload (with progress)
    ↓
trpc.knowledge.pdf.extract
    ↓
Display Results
```

**tRPC Procedures**:
- `knowledge.pdf.upload` - Upload PDF to S3
- `knowledge.pdf.extract` - Extract and process knowledge

**Styling**:
- Dashed border drop zone
- Animated upload progress bar
- Color-coded badges for concepts/code
- Smooth transitions

### ChatInterface.tsx

**Purpose**: Chat interface for code generation with adaptive suggestions

**Key Features**:
- Message history with auto-scroll
- User and assistant message bubbles
- Code block display with copy button
- Adaptive suggestions sidebar
- Quick action buttons

**State**:
- `messages`: Array of chat messages
- `input`: Current input text
- `copied`: ID of copied message
- `suggestions`: Adaptive suggestions

**Data Flow**:
```
User Input
    ↓
trpc.knowledge.code.generate
    ↓
Neural Brain: Find Patterns
    ↓
LLM: Generate Code
    ↓
Display Code + Suggestions
```

**tRPC Procedures**:
- `knowledge.code.generate` - Generate code with neural context
- `knowledge.suggestions.getAdaptive` - Get adaptive suggestions

**Message Structure**:
```typescript
interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  code?: string;  // Generated code
  suggestions?: string[];  // Related concepts
  timestamp: Date;
}
```

**Styling**:
- User messages: Blue background, right-aligned
- Assistant messages: Slate background, left-aligned
- Code blocks: Dark background with syntax highlighting
- Smooth message animations

### NeuralDashboard.tsx

**Purpose**: Real-time monitoring of neural brain training and knowledge growth

**Key Features**:
- Key metrics cards (4 metrics)
- Training loss chart
- Model accuracy chart
- Combined loss/accuracy chart
- Network statistics
- Live status indicators

**State**:
- `metricsData`: Array of training metrics
- Auto-refetch every 5 seconds

**Data Flow**:
```
trpc.knowledge.dashboard.metrics (refetch every 5s)
    ↓
Update Chart Data
    ↓
Display Metrics Cards
    ↓
Show Network Statistics
```

**Metrics Displayed**:
- **Concepts**: Number of extracted concepts
- **Code Patterns**: Number of learned code patterns
- **Accuracy**: Current training accuracy (%)
- **Epoch**: Current training iteration

**Charts**:
- Loss trend (red line)
- Accuracy trend (green line)
- Combined view with dual Y-axes

**Styling**:
- Dark theme with slate colors
- Color-coded metrics (blue, yellow, green, purple)
- Smooth line charts with Recharts
- Animated metric cards

## Reusable Components

### UI Components (shadcn/ui)

The app uses shadcn/ui components for consistency:

- `Button` - Styled buttons with variants (default, outline, ghost)
- `Card` - Container cards with header/content/footer
- `Input` - Text input fields
- `Badge` - Colored badges for tags/labels
- `Select` - Dropdown selectors
- `Dialog` - Modal dialogs
- `Toast` - Notification toasts (via Sonner)

### Custom Components

#### DashboardLayout

**Purpose**: Sidebar navigation layout for admin/dashboard apps

**Features**:
- Persistent sidebar with navigation
- Collapsible menu
- User profile section
- Active route highlighting

**Usage**:
```tsx
import DashboardLayout from '@/components/DashboardLayout';

export default function AdminPage() {
  return (
    <DashboardLayout>
      <div>Page content</div>
    </DashboardLayout>
  );
}
```

#### AIChatBox

**Purpose**: Full-featured chat interface with streaming support

**Features**:
- Message history
- Streaming responses
- Markdown rendering
- Code syntax highlighting

**Usage**:
```tsx
import AIChatBox from '@/components/AIChatBox';

export default function ChatPage() {
  return (
    <AIChatBox
      onSendMessage={(msg) => console.log(msg)}
      messages={[]}
    />
  );
}
```

## Design System

### Color Palette

**Dark Theme**:
- Background: `#0f172a` (slate-900)
- Surface: `#1e293b` (slate-800)
- Border: `#334155` (slate-700)
- Text Primary: `#f1f5f9` (slate-100)
- Text Secondary: `#cbd5e1` (slate-300)

**Accent Colors**:
- Blue: `#3b82f6` (primary actions)
- Purple: `#a855f7` (neural/AI)
- Green: `#10b981` (success/accuracy)
- Yellow: `#f59e0b` (warnings/patterns)
- Red: `#ef4444` (errors/loss)
- Cyan: `#06b6d4` (highlights)

### Typography

**Font Stack**: System fonts (Segoe UI, Roboto, sans-serif)

**Sizes**:
- `text-xs`: 12px (small labels)
- `text-sm`: 14px (body text)
- `text-base`: 16px (default)
- `text-lg`: 18px (section titles)
- `text-2xl`: 24px (card titles)
- `text-3xl`: 30px (page titles)
- `text-4xl`: 36px (hero titles)

**Weights**:
- Regular: 400
- Semibold: 600
- Bold: 700

### Spacing

Uses Tailwind's spacing scale (4px base unit):
- `p-2`: 8px padding
- `p-4`: 16px padding
- `p-6`: 24px padding
- `p-8`: 32px padding
- `gap-2`: 8px gap
- `gap-4`: 16px gap
- `gap-6`: 24px gap

### Animations

**Smooth Transitions**:
- Hover effects on interactive elements
- Fade-in for modals and overlays
- Slide animations for sidebars
- Pulse animations for loading states

**Implemented with**:
- Tailwind CSS transitions
- Framer Motion (optional for complex animations)
- CSS animations in `index.css`

## Data Flow Patterns

### PDF Upload Workflow

```
User selects file
    ↓
PDFUploader validates
    ↓
trpc.knowledge.pdf.upload
    ↓
Backend: Upload to S3
    ↓
Backend: Create document record
    ↓
trpc.knowledge.pdf.extract
    ↓
Backend: LLM extraction
    ↓
Backend: Neural brain embeddings
    ↓
Backend: Store in MySQL
    ↓
PDFUploader displays results
```

### Code Generation Workflow

```
User types prompt
    ↓
ChatInterface detects input
    ↓
Suggestions query neural brain
    ↓
Display adaptive suggestions
    ↓
User sends message
    ↓
trpc.knowledge.code.generate
    ↓
Backend: Find neural patterns
    ↓
Backend: LLM generates code
    ↓
ChatInterface displays code
    ↓
User can copy code
```

### Dashboard Metrics Workflow

```
NeuralDashboard mounts
    ↓
trpc.knowledge.dashboard.metrics (initial)
    ↓
Display metrics cards and charts
    ↓
Refetch every 5 seconds
    ↓
Update chart data
    ↓
Smooth animation to new values
```

## Performance Optimization

### Code Splitting

Large pages are lazy-loaded:
```tsx
const ChatInterface = lazy(() => import('./pages/ChatInterface'));
const NeuralDashboard = lazy(() => import('./pages/NeuralDashboard'));
```

### Query Caching

tRPC with React Query handles caching:
- Queries cached for 5 minutes by default
- Manual invalidation on mutations
- Optimistic updates for instant feedback

### Image Optimization

- All images uploaded to S3 via `manus-upload-file`
- CDN URLs used directly (no local files)
- Lazy loading for off-screen images

### Bundle Size

- Tree-shaking removes unused code
- Dynamic imports for heavy libraries
- Minification in production build

## Accessibility

### WCAG 2.1 Compliance

- Semantic HTML structure
- ARIA labels for interactive elements
- Keyboard navigation support
- Focus indicators visible
- Color contrast ratios meet AA standards

### Keyboard Navigation

- Tab through interactive elements
- Enter/Space to activate buttons
- Arrow keys in select dropdowns
- Escape to close modals

## Testing

### Component Testing

Use Vitest for unit tests:

```typescript
import { render, screen } from '@testing-library/react';
import Home from './pages/Home';

describe('Home', () => {
  it('renders hero section', () => {
    render(<Home />);
    expect(screen.getByText(/Self-Building Apps/i)).toBeInTheDocument();
  });
});
```

### Integration Testing

Test data flows between components and tRPC:

```typescript
it('uploads PDF and displays results', async () => {
  render(<PDFUploader />);
  const file = new File(['content'], 'test.pdf');
  const input = screen.getByRole('textbox');
  fireEvent.change(input, { target: { files: [file] } });
  await waitFor(() => {
    expect(screen.getByText(/Concepts extracted/i)).toBeInTheDocument();
  });
});
```

## Deployment Checklist

- [ ] All components tested
- [ ] TypeScript compilation passes
- [ ] No console errors or warnings
- [ ] Responsive design verified on mobile/tablet/desktop
- [ ] Dark theme colors verified
- [ ] Animations smooth and performant
- [ ] Accessibility audit passed
- [ ] Bundle size optimized
- [ ] Images optimized and using CDN URLs
- [ ] Environment variables configured
- [ ] Database migrations applied
- [ ] Neural brain running and accessible
