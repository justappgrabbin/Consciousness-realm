/**
 * Simulation Engine
 * Tick-based world clock driving agent lifecycle events
 */

import {
  getAllAgents, getAllDistricts, getSimulationState, upsertSimulationState,
  getAgentNeeds, upsertAgentNeeds, getAgentMood, upsertAgentMood,
  addAgentMemory, getRecentAgentMemories, getAgentRelationships,
  getAgentActiveTasks, createTask, updateTask, addFeedEvent,
  getRelationship, upsertRelationship, createConversation, updateAgent,
  updateDistrictPopulation, getAgentsByDistrict, createWorldEvent,
  getActiveWorldEvents, resolveWorldEvent,
} from "./db";
import {
  applyNeedsDecay, applyActivityToNeeds, calculateMoodScore, getMoodLabel,
  getDominantEmotion, selectActivityByNeeds, shouldMigrate, evolveRelationship,
  applyWorldEventToNeeds, generateTasksForAgent, WORLD_HOURS_PER_TICK,
} from "./worldRules";
import {
  generateInnerMonologue, makeAgentDecision, generateConversation, planAgentTask,
  summarizeAgentMemories, generateCrossDistrictMessage,
} from "./agentCognition";
import type { Agent, AgentNeeds, District } from "../drizzle/schema";

// ─── Tick Processor ────────────────────────────────────────────────────────────
export async function processTick(): Promise<{ tick: number; events: string[] }> {
  const state = await getSimulationState();
  if (!state || state.paused) return { tick: state?.tick ?? 0, events: [] };

  const newTick = state.tick + 1;
  const newWorldHour = (state.worldHour + WORLD_HOURS_PER_TICK) % 24;
  const newWorldDay = newWorldHour < state.worldHour ? state.worldDay + 1 : state.worldDay;

  await upsertSimulationState({
    tick: newTick,
    worldHour: newWorldHour,
    worldDay: newWorldDay,
    lastTickAt: new Date(),
  });

  const [allAgents, allDistricts] = await Promise.all([getAllAgents(), getAllDistricts()]);
  const districtMap = new Map(allDistricts.map(d => [d.id, d]));
  const events: string[] = [];

  // Process world events
  await processWorldEvents(newTick, newWorldDay, newWorldHour, allAgents, allDistricts);

  // Process each agent (staggered to avoid LLM overload — process a subset per tick)
  const agentsToProcess = allAgents.filter((_, i) => i % 3 === newTick % 3);

  for (const agent of agentsToProcess) {
    try {
      const district = districtMap.get(agent.districtId);
      if (!district) continue;

      const agentEvents = await processAgentTick(agent, district, allAgents, newTick, newWorldDay, newWorldHour);
      events.push(...agentEvents);
    } catch (err) {
      console.error(`[Sim] Error processing agent ${agent.id}:`, err);
    }
  }

  // Occasionally trigger social interactions
  if (newTick % 4 === 0) {
    await processSocialInteractions(allAgents, districtMap, newTick, newWorldDay, newWorldHour);
  }

  return { tick: newTick, events };
}

// ─── Agent Tick ────────────────────────────────────────────────────────────────
async function processAgentTick(
  agent: Agent,
  district: District,
  allAgents: Agent[],
  tick: number,
  worldDay: number,
  worldHour: number
): Promise<string[]> {
  const events: string[] = [];

  // 1. Get current state
  let needs = await getAgentNeeds(agent.id);
  if (!needs) {
    await upsertAgentNeeds(agent.id, {});
    needs = await getAgentNeeds(agent.id);
    if (!needs) return events;
  }

  // 2. Apply needs decay
  const decayedNeeds = applyNeedsDecay(needs, district.resourceLevel ?? 1);
  await upsertAgentNeeds(agent.id, decayedNeeds);
  const updatedNeeds = { ...needs, ...decayedNeeds };

  // 3. Apply active world events
  const activeEvents = await getActiveWorldEvents();
  for (const worldEvent of activeEvents) {
    if (worldEvent.effects) {
      const eventNeeds = applyWorldEventToNeeds(updatedNeeds, worldEvent.effects as any);
      if (Object.keys(eventNeeds).length > 0) {
        await upsertAgentNeeds(agent.id, eventNeeds);
        Object.assign(updatedNeeds, eventNeeds);
      }
    }
  }

  // 4. Calculate and update mood
  const moodScore = calculateMoodScore(updatedNeeds as AgentNeeds);
  const moodLabel = getMoodLabel(moodScore);
  const dominantEmotion = getDominantEmotion(updatedNeeds as AgentNeeds, agent.personality);
  await upsertAgentMood(agent.id, { mood: moodLabel, moodScore, dominantEmotion });

  // 5. Select activity
  const suggestion = selectActivityByNeeds(updatedNeeds as AgentNeeds, worldHour, agent.personality, district);

  // 6. Occasionally use LLM for inner monologue and decision (not every tick — too expensive)
  const shouldUseLLM = tick % 6 === agent.id % 6;
  let chosenActivity = suggestion.activity;
  let chosenLocation = suggestion.location;

  if (shouldUseLLM) {
    const mood = await getAgentMood(agent.id);
    const recentMemories = await getRecentAgentMemories(agent.id, 5);
    const relationships = await getAgentRelationships(agent.id);
    const relSummary = relationships.slice(0, 3).map(r => {
      const otherId = r.agentAId === agent.id ? r.agentBId : r.agentAId;
      const other = allAgents.find(a => a.id === otherId);
      return { name: other?.name ?? "Unknown", type: r.type, strength: r.strength };
    });

    if (mood) {
      const monologue = await generateInnerMonologue({
        agent,
        needs: updatedNeeds as AgentNeeds,
        mood,
        recentMemories: recentMemories.map(m => m.content),
        relationships: relSummary,
        worldHour,
        worldDay,
        districtName: district.name,
        currentActivity: agent.currentActivity,
      });

      await addAgentMemory({
        agentId: agent.id,
        tick,
        worldDay,
        worldHour,
        type: "inner_monologue",
        content: monologue,
        importance: 0.3,
        relatedAgentId: null,
      });

      // Add to feed if interesting
      if (moodScore < 30 || moodScore > 85) {
        await addFeedEvent({
          tick,
          worldDay,
          worldHour,
          agentId: agent.id,
          districtId: district.id,
          type: "mood",
          title: `${agent.name} is feeling ${moodLabel}`,
          content: monologue,
          emoji: getMoodEmoji(moodLabel),
          importance: 0.4,
        });
        events.push(`${agent.name}: ${monologue}`);
      }
    }
  }

  // 7. Apply activity effects to needs
  const activityNeeds = applyActivityToNeeds(updatedNeeds as AgentNeeds, chosenActivity);
  if (Object.keys(activityNeeds).length > 0) {
    await upsertAgentNeeds(agent.id, activityNeeds);
  }

  // 8. Update agent activity
  const activityChanged = agent.currentActivity !== chosenActivity || agent.currentLocation !== chosenLocation;
  if (activityChanged) {
    await updateAgent(agent.id, { currentActivity: chosenActivity, currentLocation: chosenLocation });

    await addFeedEvent({
      tick,
      worldDay,
      worldHour,
      agentId: agent.id,
      districtId: district.id,
      type: "lifecycle",
      title: `${agent.name} is now ${getActivityDescription(chosenActivity)}`,
      content: `${agent.name} moved to ${chosenLocation} to ${chosenActivity}. ${suggestion.reason}.`,
      emoji: getActivityEmoji(chosenActivity),
      importance: 0.3,
    });
  }

  // 9. Task management
  await processAgentTasks(agent, tick, worldDay, worldHour, district, events);

  // 10. Migration check
  const allDistricts = await getAllDistricts();
  const migration = shouldMigrate(agent, district, allDistricts);
  if (migration.should && migration.targetDistrictId) {
    await updateAgent(agent.id, { districtId: migration.targetDistrictId });
    await updateDistrictPopulation(district.id, Math.max(0, district.population - 1));
    const targetDistrict = allDistricts.find(d => d.id === migration.targetDistrictId);
    if (targetDistrict) {
      await updateDistrictPopulation(targetDistrict.id, targetDistrict.population + 1);
    }

    await addFeedEvent({
      tick,
      worldDay,
      worldHour,
      agentId: agent.id,
      districtId: migration.targetDistrictId,
      type: "migration",
      title: `${agent.name} moved to ${targetDistrict?.name ?? "a new district"}`,
      content: `${agent.name} left ${district.name} and relocated to ${targetDistrict?.name}. Reason: ${migration.reason}`,
      emoji: "🏃",
      importance: 0.6,
    });
    events.push(`${agent.name} migrated to ${targetDistrict?.name}`);
  }

  return events;
}

// ─── Task Processing ───────────────────────────────────────────────────────────
async function processAgentTasks(
  agent: Agent,
  tick: number,
  worldDay: number,
  worldHour: number,
  district: District,
  events: string[]
) {
  const activeTasks = await getAgentActiveTasks(agent.id);

  // Progress in-progress tasks
  for (const task of activeTasks.filter(t => t.status === "in_progress")) {
    const newProgress = Math.min(1, task.progress + 0.15 + Math.random() * 0.1);
    if (newProgress >= 1) {
      await updateTask(task.id, { status: "completed", progress: 1, completedTick: tick });
      await addFeedEvent({
        tick,
        worldDay,
        worldHour,
        agentId: agent.id,
        districtId: district.id,
        type: "task",
        title: `${agent.name} completed: ${task.title}`,
        content: `${agent.name} successfully finished "${task.title}".`,
        emoji: "✅",
        importance: 0.5,
      });
      events.push(`${agent.name} completed task: ${task.title}`);
    } else {
      await updateTask(task.id, { progress: newProgress });
    }
  }

  // Start pending tasks
  const pendingTasks = activeTasks.filter(t => t.status === "pending");
  if (pendingTasks.length > 0 && activeTasks.filter(t => t.status === "in_progress").length === 0) {
    const topTask = pendingTasks.sort((a, b) => b.priority - a.priority)[0];
    if (topTask) {
      await updateTask(topTask.id, { status: "in_progress", startTick: tick });
    }
  }

  // Generate new tasks occasionally
  if (activeTasks.length < 2 && tick % 8 === agent.id % 8) {
    const shouldUseLLM = Math.random() < 0.3;
    if (shouldUseLLM) {
      const newTask = await planAgentTask(agent, worldDay, worldHour);
      if (newTask) {
        const validTypes = ["work", "errand", "social", "personal", "creative", "survival"] as const;
        const taskType = validTypes.includes(newTask.type as any) ? newTask.type as typeof validTypes[number] : "personal";
        await createTask({
          agentId: agent.id,
          title: newTask.title,
          description: newTask.description,
          type: taskType,
          status: "pending",
          priority: newTask.priority,
          progress: 0,
          startTick: null,
          completedTick: null,
          dueDay: worldDay + 3,
          reward: {},
        });
      }
    } else {
      const generatedTasks = generateTasksForAgent(agent, worldDay, activeTasks.length);
      for (const t of generatedTasks.slice(0, 1)) {
        await createTask({
          agentId: agent.id,
          title: t.title,
          description: t.description,
          type: t.type,
          status: "pending",
          priority: t.priority,
          progress: 0,
          startTick: null,
          completedTick: null,
          dueDay: worldDay + 3,
          reward: {},
        });
      }
    }
  }
}

// ─── Social Interactions ───────────────────────────────────────────────────────
async function processSocialInteractions(
  allAgents: Agent[],
  districtMap: Map<number, District>,
  tick: number,
  worldDay: number,
  worldHour: number
) {
  // Only during social hours
  if (worldHour < 9 || worldHour > 22) return;

  // Pick a random pair of agents in the same district
  const socialAgents = allAgents.filter(a => a.currentActivity === "socializing" || Math.random() < 0.15);
  if (socialAgents.length < 2) return;

  const agentA = socialAgents[Math.floor(Math.random() * socialAgents.length)]!;
  const sameDistrict = socialAgents.filter(a => a.id !== agentA.id && a.districtId === agentA.districtId);
  if (sameDistrict.length === 0) return;

  const agentB = sameDistrict[Math.floor(Math.random() * sameDistrict.length)]!;
  const district = districtMap.get(agentA.districtId);
  if (!district) return;

  const existingRel = await getRelationship(agentA.id, agentB.id);
  const conversation = await generateConversation(agentA, agentB, existingRel, worldHour, worldDay, district.name);

  // Save conversation
  await createConversation({
    agentAId: agentA.id,
    agentBId: agentB.id,
    tick,
    worldDay,
    worldHour,
    messages: conversation.messages,
    summary: conversation.summary,
    sentiment: conversation.sentiment,
    location: district.name,
  });

  // Update relationship
  const relEvolution = evolveRelationship(
    existingRel?.strength ?? 0.05,
    existingRel?.sentiment ?? 0.5,
    conversation.sentiment,
    (existingRel?.interactionCount ?? 0) + 1
  );

  await upsertRelationship(agentA.id, agentB.id, {
    type: relEvolution.type as any,
    strength: relEvolution.strength,
    sentiment: relEvolution.sentiment,
    interactionCount: (existingRel?.interactionCount ?? 0) + 1,
    lastInteractionTick: tick,
  });

  // Add to memories
  await addAgentMemory({
    agentId: agentA.id,
    tick,
    worldDay,
    worldHour,
    type: "conversation",
    content: `Talked with ${agentB.name}: ${conversation.summary}`,
    importance: 0.5 + conversation.sentiment * 0.3,
    relatedAgentId: agentB.id,
  });

  await addAgentMemory({
    agentId: agentB.id,
    tick,
    worldDay,
    worldHour,
    type: "conversation",
    content: `Talked with ${agentA.name}: ${conversation.summary}`,
    importance: 0.5 + conversation.sentiment * 0.3,
    relatedAgentId: agentA.id,
  });

  // Add to feed
  const firstMessage = conversation.messages[0]?.text ?? "";
  await addFeedEvent({
    tick,
    worldDay,
    worldHour,
    agentId: agentA.id,
    districtId: district.id,
    type: "social",
    title: `${agentA.name} & ${agentB.name} are talking`,
    content: `"${firstMessage}" — ${conversation.summary}`,
    emoji: getRelationshipEmoji(relEvolution.type),
    importance: 0.55,
  });

  // Occasionally trigger cross-district communication (agents messaging each other across nodes)
  if (tick % 12 === 0 && allAgents.length > 2) {
    const crossSender = allAgents[Math.floor(Math.random() * allAgents.length)]!;
    const crossReceivers = allAgents.filter(a => a.id !== crossSender.id && a.districtId !== crossSender.districtId);
    if (crossReceivers.length > 0) {
      const crossReceiver = crossReceivers[Math.floor(Math.random() * crossReceivers.length)]!;
      const crossRel = await getRelationship(crossSender.id, crossReceiver.id);
      const msg = await generateCrossDistrictMessage(crossSender, crossReceiver, crossRel, worldDay);

      await addAgentMemory({
        agentId: crossSender.id,
        tick,
        worldDay,
        worldHour,
        type: "conversation",
        content: `Sent a message to ${crossReceiver.name} in another district: "${msg.subject}"`,
        importance: 0.4,
        relatedAgentId: crossReceiver.id,
      });
      await addAgentMemory({
        agentId: crossReceiver.id,
        tick,
        worldDay,
        worldHour,
        type: "conversation",
        content: `Received a message from ${crossSender.name}: "${msg.subject}" — ${msg.message}`,
        importance: 0.45,
        relatedAgentId: crossSender.id,
      });

      const senderDistrict = districtMap.get(crossSender.districtId);
      const receiverDistrict = districtMap.get(crossReceiver.districtId);
      await addFeedEvent({
        tick,
        worldDay,
        worldHour,
        agentId: crossSender.id,
        districtId: crossSender.districtId,
        type: "social",
        title: `${crossSender.name} messaged ${crossReceiver.name} across districts`,
        content: `From ${senderDistrict?.name ?? "unknown"} → ${receiverDistrict?.name ?? "unknown"}: "${msg.subject}" — ${msg.message}`,
        emoji: "📨",
        importance: 0.5,
      });
    }
  }

  // Periodically summarize agent memories (every 24 ticks ≈ 1 world day)
  if (tick % 24 === agentA.id % 24) {
    const recentMems = await getRecentAgentMemories(agentA.id, 15);
    if (recentMems.length >= 5) {
      const summary = await summarizeAgentMemories(agentA, recentMems.map(m => m.content));
      await addAgentMemory({
        agentId: agentA.id,
        tick,
        worldDay,
        worldHour,
        type: "inner_monologue",
        content: `[Day ${worldDay} Reflection] ${summary}`,
        importance: 0.8,
        relatedAgentId: null,
      });
    }
  }
}

// ─── World Events ──────────────────────────────────────────────────────────────
async function processWorldEvents(
  tick: number,
  worldDay: number,
  worldHour: number,
  allAgents: Agent[],
  allDistricts: District[]
) {
  // Resolve old events
  const activeEvents = await getActiveWorldEvents();
  for (const event of activeEvents) {
    if (tick - event.tick > 12) {
      await resolveWorldEvent(event.id);
    }
  }

  // Occasionally spawn a random world event
  if (Math.random() < 0.03 && allDistricts.length > 0) {
    const district = allDistricts[Math.floor(Math.random() * allDistricts.length)]!;
    const eventTemplates = [
      { title: "Street Festival", description: `A lively festival breaks out in ${district.name}, lifting everyone's spirits.`, type: "cultural" as const, effects: { moodDelta: 15, needsDeltas: { fun: 20, social: 15 } } },
      { title: "Power Outage", description: `Electricity fails in ${district.name}, disrupting daily routines.`, type: "natural" as const, effects: { moodDelta: -10, needsDeltas: { comfort: -20 } } },
      { title: "Food Market", description: `A pop-up food market appears in ${district.name}.`, type: "economic" as const, effects: { needsDeltas: { hunger: 25 } } },
      { title: "Community Cleanup", description: `Residents of ${district.name} organize a neighborhood cleanup.`, type: "social" as const, effects: { moodDelta: 8, needsDeltas: { social: 15 } } },
      { title: "Heavy Rain", description: `A downpour hits ${district.name}, keeping everyone indoors.`, type: "natural" as const, effects: { moodDelta: -5, needsDeltas: { comfort: -10, social: -10 } } },
    ];

    const template = eventTemplates[Math.floor(Math.random() * eventTemplates.length)]!;
    await createWorldEvent({
      title: template.title,
      description: template.description,
      type: template.type,
      districtId: district.id,
      affectedAgentIds: [],
      effects: template.effects,
      tick,
      worldDay,
      resolved: false,
    });

    await addFeedEvent({
      tick,
      worldDay,
      worldHour,
      agentId: null,
      districtId: district.id,
      type: "world_event",
      title: `🌍 ${template.title} in ${district.name}`,
      content: template.description,
      emoji: "🌍",
      importance: 0.8,
    });
  }
}

// ─── Helpers ───────────────────────────────────────────────────────────────────
function getMoodEmoji(mood: string): string {
  const map: Record<string, string> = {
    ecstatic: "🤩", happy: "😊", content: "😌", neutral: "😐",
    uncomfortable: "😣", sad: "😢", distressed: "😰", furious: "😡",
  };
  return map[mood] ?? "😐";
}

function getActivityEmoji(activity: string): string {
  const map: Record<string, string> = {
    eating: "🍽️", sleeping: "😴", working: "💼", socializing: "💬",
    exercising: "🏃", relaxing: "🛋️", bathing: "🚿", creative: "🎨",
  };
  return map[activity] ?? "✨";
}

function getActivityDescription(activity: string): string {
  const map: Record<string, string> = {
    eating: "having a meal", sleeping: "resting", working: "at work",
    socializing: "socializing", exercising: "exercising", relaxing: "relaxing",
    bathing: "freshening up", creative: "being creative",
  };
  return map[activity] ?? activity;
}

function getRelationshipEmoji(type: string): string {
  const map: Record<string, string> = {
    friend: "👫", rival: "⚔️", romantic: "💕", colleague: "🤝",
    acquaintance: "👋", family: "👨‍👩‍👧", enemy: "😤",
  };
  return map[type] ?? "💬";
}
