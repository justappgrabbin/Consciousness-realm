import React, { useState, useEffect } from 'react';
import { Settings, Check, FileText, Trash2, X, Upload, Download, Sparkles, AlertCircle, Plus, Code } from 'lucide-react';
import JSZip from 'jszip';
import { downloadZip } from 'client-zip';

// ============= ZIP PARSER (READ) =============

async function parseZipFile(file) {
  try {
    const zip = new JSZip();
    const contents = await zip.loadAsync(file);
    
    const files = {};
    const fileList = [];
    
    for (const [filename, zipEntry] of Object.entries(contents.files)) {
      if (!zipEntry.dir) {
        fileList.push(filename);
        
        if (filename.endsWith('.json')) {
          const text = await zipEntry.async('text');
          files[filename] = { type: 'json', content: JSON.parse(text) };
        } else if (filename.match(/\.(js|jsx|ts|tsx|html|css|md|txt)$/)) {
          const text = await zipEntry.async('text');
          files[filename] = { type: 'text', content: text };
        } else if (filename.match(/\.(png|jpg|jpeg|gif|svg)$/)) {
          const blob = await zipEntry.async('blob');
          const dataUrl = await blobToDataUrl(blob);
          files[filename] = { type: 'image', content: dataUrl };
        } else {
          const blob = await zipEntry.async('blob');
          files[filename] = { type: 'blob', content: blob };
        }
      }
    }
    
    return { files, fileList };
  } catch (error) {
    throw new Error(`Failed to parse ZIP: ${error.message}`);
  }
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// ============= ZIP CREATOR (WRITE) =============

async function createZipFile(files, zipName = 'export.zip') {
  try {
    // Convert our file objects to the format client-zip expects
    const zipFiles = files.map(file => {
      if (typeof file.content === 'string') {
        // Text content
        return {
          name: file.name,
          lastModified: new Date(),
          input: file.content
        };
      } else if (file.content instanceof Blob) {
        // Binary content
        return {
          name: file.name,
          lastModified: new Date(),
          input: file.content
        };
      } else {
        // JSON or other objects
        return {
          name: file.name,
          lastModified: new Date(),
          input: JSON.stringify(file.content, null, 2)
        };
      }
    });

    // Create the ZIP blob
    const blob = await downloadZip(zipFiles).blob();
    
    // Trigger download
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = zipName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    return true;
  } catch (error) {
    throw new Error(`Failed to create ZIP: ${error.message}`);
  }
}

// ============= COMPONENT EXECUTOR =============

function executeReactComponent(code, componentName = 'App') {
  try {
    const componentCode = code
      .replace(/export\s+default\s+/g, 'return ')
      .replace(/export\s+/g, '');
    
    const factory = new Function('React', 'useState', 'useEffect', 'useRef', componentCode);
    const Component = factory(React, useState, useEffect, React.useRef);
    
    return Component;
  } catch (error) {
    console.error('Component execution error:', error);
    throw new Error(`Failed to execute component: ${error.message}`);
  }
}

// ============= FILE EDITOR COMPONENT =============

function FileEditor({ filename, content, onSave, onClose }) {
  const [editedContent, setEditedContent] = useState(content);
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-4xl max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-semibold text-gray-800">Editing: {filename}</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>
        
        <textarea
          value={editedContent}
          onChange={(e) => setEditedContent(e.target.value)}
          className="flex-1 p-4 font-mono text-sm focus:outline-none resize-none"
        />
        
        <div className="flex gap-2 p-4 border-t">
          <button
            onClick={() => {
              onSave(editedContent);
              onClose();
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Save Changes
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

// ============= NEW FILE DIALOG =============

function NewFileDialog({ onAdd, onClose }) {
  const [filename, setFilename] = useState('');
  const [content, setContent] = useState('');
  const [template, setTemplate] = useState('blank');
  
  const templates = {
    blank: '',
    react: `import React, { useState } from 'react';

export default function MyComponent() {
  const [count, setCount] = useState(0);

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">My Component</h2>
      <p>Count: {count}</p>
      <button 
        onClick={() => setCount(count + 1)}
        className="px-4 py-2 bg-blue-600 text-white rounded"
      >
        Increment
      </button>
    </div>
  );
}`,
    json: `{
  "name": "my-config",
  "version": "1.0.0",
  "settings": {
    "enabled": true
  }
}`,
    readme: `# My Project

## Description
Add your project description here.

## Usage
Explain how to use your project.
`
  };
  
  useEffect(() => {
    setContent(templates[template]);
  }, [template]);
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-semibold text-gray-800">Add New File</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>
        
        <div className="p-4 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Filename</label>
            <input
              type="text"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              placeholder="example.jsx"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-400"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Template</label>
            <select
              value={template}
              onChange={(e) => setTemplate(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-400"
            >
              <option value="blank">Blank File</option>
              <option value="react">React Component</option>
              <option value="json">JSON Config</option>
              <option value="readme">README</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Content</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full h-48 px-3 py-2 border border-gray-300 rounded-lg font-mono text-sm focus:outline-none focus:border-blue-400 resize-none"
            />
          </div>
        </div>
        
        <div className="flex gap-2 p-4 border-t">
          <button
            onClick={() => {
              if (filename.trim()) {
                onAdd({ name: filename, content });
                onClose();
              }
            }}
            disabled={!filename.trim()}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filename.trim()
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Add File
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

// ============= FILE MANAGER =============

function FileManager({ files, fileList, onUpdateFile, onAddFile, onDeleteFile, onExportZip }) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [editingFile, setEditingFile] = useState(null);
  const [showNewFile, setShowNewFile] = useState(false);
  
  const handleSave = (filename, newContent) => {
    onUpdateFile(filename, newContent);
  };
  
  const handleDelete = (filename) => {
    if (confirm(`Delete ${filename}?`)) {
      onDeleteFile(filename);
      if (selectedFile === filename) setSelectedFile(null);
    }
  };
  
  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-gray-800">Files ({fileList.length})</h3>
        <div className="flex gap-2">
          <button
            onClick={() => setShowNewFile(true)}
            className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New File
          </button>
          <button
            onClick={onExportZip}
            className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Export ZIP
          </button>
        </div>
      </div>
      
      {/* File browser */}
      <div className="grid grid-cols-3 gap-4 min-h-[500px]">
        {/* File list */}
        <div className="col-span-1 border rounded-lg p-3 overflow-y-auto bg-gray-50">
          <div className="space-y-1">
            {fileList.map((filename) => (
              <div
                key={filename}
                className={`group flex items-center justify-between p-2 rounded transition-colors ${
                  selectedFile === filename
                    ? 'bg-blue-100 text-blue-800'
                    : 'hover:bg-white text-gray-700'
                }`}
              >
                <button
                  onClick={() => setSelectedFile(filename)}
                  className="flex-1 text-left text-sm truncate"
                >
                  {filename}
                </button>
                <button
                  onClick={() => handleDelete(filename)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:bg-red-100 text-red-600 rounded transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
        
        {/* File preview */}
        <div className="col-span-2 border rounded-lg p-4 overflow-y-auto bg-white">
          {selectedFile && files[selectedFile] ? (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-gray-800">{selectedFile}</h4>
                {files[selectedFile].type === 'text' && (
                  <button
                    onClick={() => setEditingFile(selectedFile)}
                    className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors flex items-center gap-1"
                  >
                    <Code className="w-3 h-3" />
                    Edit
                  </button>
                )}
              </div>
              <FilePreview file={files[selectedFile]} filename={selectedFile} />
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400">
              Select a file to preview
            </div>
          )}
        </div>
      </div>
      
      {/* Dialogs */}
      {editingFile && (
        <FileEditor
          filename={editingFile}
          content={files[editingFile].content}
          onSave={(newContent) => handleSave(editingFile, newContent)}
          onClose={() => setEditingFile(null)}
        />
      )}
      
      {showNewFile && (
        <NewFileDialog
          onAdd={onAddFile}
          onClose={() => setShowNewFile(false)}
        />
      )}
    </div>
  );
}

function FilePreview({ file, filename }) {
  if (!file) return null;
  
  switch (file.type) {
    case 'text':
      return (
        <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-sm font-mono max-h-96">
          {file.content}
        </pre>
      );
    
    case 'json':
      return (
        <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-sm font-mono max-h-96">
          {JSON.stringify(file.content, null, 2)}
        </pre>
      );
    
    case 'image':
      return (
        <div className="flex justify-center">
          <img src={file.content} alt={filename} className="max-w-full rounded-lg shadow" />
        </div>
      );
    
    default:
      return (
        <div className="text-gray-500">
          Binary file ({file.type})
        </div>
      );
  }
}

// ============= MAIN APP =============

export default function ZipStudioApp() {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [zipData, setZipData] = useState(null);
  const [error, setError] = useState(null);
  const [mode, setMode] = useState('upload'); // 'upload' or 'create'
  
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };
  
  const handleDrop = async (e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      await processZipFile(files[0]);
    }
  };
  
  const handleFileInput = async (e) => {
    const files = e.target.files;
    if (files.length > 0) {
      await processZipFile(files[0]);
    }
    e.target.value = '';
  };
  
  const processZipFile = async (file) => {
    if (!file.name.endsWith('.zip')) {
      setError('Please upload a .zip file');
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    
    try {
      const result = await parseZipFile(file);
      setZipData({
        filename: file.name,
        ...result
      });
      setMode('edit');
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleUpdateFile = (filename, newContent) => {
    setZipData(prev => ({
      ...prev,
      files: {
        ...prev.files,
        [filename]: {
          ...prev.files[filename],
          content: newContent
        }
      }
    }));
  };
  
  const handleAddFile = (fileData) => {
    const { name, content } = fileData;
    setZipData(prev => ({
      ...prev,
      files: {
        ...prev.files,
        [name]: {
          type: 'text',
          content: content
        }
      },
      fileList: [...prev.fileList, name]
    }));
  };
  
  const handleDeleteFile = (filename) => {
    setZipData(prev => {
      const newFiles = { ...prev.files };
      delete newFiles[filename];
      
      return {
        ...prev,
        files: newFiles,
        fileList: prev.fileList.filter(f => f !== filename)
      };
    });
  };
  
  const handleExportZip = async () => {
    try {
      const files = zipData.fileList.map(filename => ({
        name: filename,
        content: zipData.files[filename].content
      }));
      
      await createZipFile(files, zipData.filename || 'export.zip');
    } catch (err) {
      setError(err.message);
    }
  };
  
  const createNewZip = () => {
    setZipData({
      filename: 'new-project.zip',
      files: {},
      fileList: []
    });
    setMode('edit');
  };
  
  const resetApp = () => {
    setZipData(null);
    setError(null);
    setMode('upload');
  };
  
  if (zipData && mode === 'edit') {
    return (
      <div className="min-h-screen bg-gray-100 p-4">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-lg shadow-lg p-6 mb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Check className="w-6 h-6 text-green-600" />
                <div>
                  <h2 className="font-semibold text-gray-800">ZIP Studio</h2>
                  <p className="text-sm text-gray-600">{zipData.filename}</p>
                </div>
              </div>
              <button
                onClick={resetApp}
                className="px-4 py-2 text-sm bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-lg transition-colors"
              >
                Close
              </button>
            </div>
          </div>
          
          {/* File Manager */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <FileManager
              files={zipData.files}
              fileList={zipData.fileList}
              onUpdateFile={handleUpdateFile}
              onAddFile={handleAddFile}
              onDeleteFile={handleDeleteFile}
              onExportZip={handleExportZip}
            />
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full mb-4">
            <FileText className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            ZIP Studio
          </h1>
          <p className="text-gray-600">
            Create, edit, and export ZIP files in your browser
          </p>
        </div>
        
        {/* Mode selector */}
        <div className="flex gap-4 mb-6">
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`flex-1 border-4 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer ${
              isDragging
                ? 'border-blue-500 bg-blue-50 scale-105'
                : 'border-gray-300 bg-white hover:border-gray-400'
            }`}
          >
            <input
              type="file"
              accept=".zip"
              onChange={handleFileInput}
              className="hidden"
              id="file-upload"
              disabled={isProcessing}
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <Upload className="w-12 h-12 text-blue-600 mx-auto mb-3" />
              <p className="font-semibold text-gray-800 mb-1">Upload ZIP</p>
              <p className="text-sm text-gray-600">Edit existing file</p>
            </label>
          </div>
          
          <button
            onClick={createNewZip}
            className="flex-1 border-4 border-dashed border-gray-300 rounded-2xl p-8 hover:border-gray-400 hover:bg-gray-50 transition-all"
          >
            <Plus className="w-12 h-12 text-green-600 mx-auto mb-3" />
            <p className="font-semibold text-gray-800 mb-1">Create New</p>
            <p className="text-sm text-gray-600">Start from scratch</p>
          </button>
        </div>
        
        {/* Error message */}
        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-red-800 mb-1">Error</h4>
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}
        
        {/* Features */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h3 className="font-semibold text-gray-800 mb-3">Features:</h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">📦</span>
              <span><strong>Parse ZIP files</strong> - Extract and view all contents</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">✏️</span>
              <span><strong>Edit files</strong> - Modify text, code, and JSON files</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">➕</span>
              <span><strong>Add files</strong> - Create new files with templates</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">💾</span>
              <span><strong>Export ZIP</strong> - Download your modified archive</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">⚛️</span>
              <span><strong>React templates</strong> - Quick start with component templates</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
