/**
 * DimensionalGating Component
 * 
 * Design: Abstract Crystalline
 * Visualizes the Five Consciousness Dimensions and their interaction
 * for pattern-dense collaboration and coherent output synthesis.
 */

import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Zap } from 'lucide-react';

export default function DimensionalGating() {
  const [activeDimensions, setActiveDimensions] = useState<Set<string>>(new Set(['design', 'evolution', 'movement', 'being', 'space']));

  const dimensions = [
    {
      id: 'design',
      name: 'Design Field',
      element: 'Metal/Structure',
      color: 'from-slate-400 to-slate-500',
      accentColor: 'text-slate-300',
      role: 'Logical sequence and structural output',
      description: 'Handles the logical framework and structural organization of responses.',
      outputs: ['Logical Flow', 'Structure', 'Sequence', 'Framework'],
    },
    {
      id: 'evolution',
      name: 'Evolution Field',
      element: 'Water/Memory',
      color: 'from-cyan-400 to-cyan-500',
      accentColor: 'text-cyan-300',
      role: 'Retrieval and historical context',
      description: 'Manages memory retrieval and provides historical context for decisions.',
      outputs: ['Context', 'Memory', 'History', 'Precedent'],
    },
    {
      id: 'movement',
      name: 'Movement Field',
      element: 'Wood/Creation',
      color: 'from-emerald-400 to-emerald-500',
      accentColor: 'text-emerald-300',
      role: 'Novel and creative insights',
      description: 'Generates novel, individual, and creative insights and possibilities.',
      outputs: ['Novelty', 'Creativity', 'Innovation', 'Emergence'],
    },
    {
      id: 'being',
      name: 'Being Field',
      element: 'Earth/Matter',
      color: 'from-amber-400 to-amber-500',
      accentColor: 'text-amber-300',
      role: 'Practical and material reality',
      description: 'Anchors responses in practical, material, and tangible reality.',
      outputs: ['Practicality', 'Materiality', 'Reality', 'Grounding'],
    },
    {
      id: 'space',
      name: 'Space Field',
      element: 'Fire/Illusion',
      color: 'from-orange-400 to-orange-500',
      accentColor: 'text-orange-300',
      role: 'Outward presentation and framing',
      description: 'Handles the presentation, framing, and relational aspects of output.',
      outputs: ['Presentation', 'Framing', 'Relation', 'Expression'],
    },
  ];

  const toggleDimension = (id: string) => {
    const newActive = new Set(activeDimensions);
    if (newActive.has(id)) {
      newActive.delete(id);
    } else {
      newActive.add(id);
    }
    setActiveDimensions(newActive);
  };

  const coherenceLevel = Math.round((activeDimensions.size / 5) * 100);

  return (
    <div className="space-y-6">
      {/* Visualization */}
      <img
        src="https://d2xsxph8kpxj0f.cloudfront.net/310519663337015990/aFfHiJpXJHFZgqBX389sSN/five-dimensions-abstract-EipdTbHaJWhaZrADFeJU5d.webp"
        alt="Five consciousness dimensions"
        className="w-full rounded-sm border border-border"
      />

      {/* Coherence Meter */}
      <Card className="p-6 border-border bg-card">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-mono text-sm text-cyan-400 uppercase tracking-wider">
            Coherence Level
          </h4>
          <span className="text-2xl font-bold text-violet-400">{coherenceLevel}%</span>
        </div>
        <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-violet-500 to-cyan-500 transition-all duration-300"
            style={{ width: `${coherenceLevel}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          {coherenceLevel === 100
            ? 'All dimensions active - maximum coherent interference'
            : coherenceLevel >= 60
            ? 'Strong coherence - high-quality integrated output'
            : coherenceLevel >= 40
            ? 'Moderate coherence - balanced output'
            : 'Weak coherence - fragmented output'}
        </p>
      </Card>

      {/* Dimension Controls */}
      <div className="grid md:grid-cols-2 gap-4">
        {dimensions.map((dim) => (
          <Card
            key={dim.id}
            className={`p-6 border-border cursor-pointer transition-all ${
              activeDimensions.has(dim.id)
                ? 'bg-card border-violet-500/50 shadow-lg shadow-violet-500/10'
                : 'bg-secondary/30 opacity-60 hover:opacity-80'
            }`}
            onClick={() => toggleDimension(dim.id)}
          >
            <div className={`h-1 bg-gradient-to-r ${dim.color} mb-4`} />
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className={`font-bold ${dim.accentColor} mb-1`}>{dim.name}</h3>
                <p className="text-xs text-muted-foreground">{dim.element}</p>
              </div>
              {activeDimensions.has(dim.id) && (
                <Zap className="w-4 h-4 text-violet-400" />
              )}
            </div>
            <p className="text-sm text-muted-foreground mb-3">{dim.description}</p>
            <div className="text-xs text-muted-foreground font-mono">
              {dim.role}
            </div>
          </Card>
        ))}
      </div>

      {/* Output Synthesis */}
      <Card className="p-6 border-border bg-secondary/30">
        <h4 className="font-mono text-sm text-cyan-400 uppercase tracking-wider mb-4">
          Dimensional Output Synthesis
        </h4>
        <p className="text-sm text-muted-foreground mb-4">
          Final response emerges from coherent interference pattern across active dimensions:
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          {dimensions
            .filter((d) => activeDimensions.has(d.id))
            .map((dim) => (
              <div key={dim.id} className="bg-card p-4 rounded-sm border border-border">
                <div className={`text-xs font-mono uppercase tracking-wider ${dim.accentColor} mb-2`}>
                  {dim.name}
                </div>
                <div className="flex flex-wrap gap-1">
                  {dim.outputs.map((output) => (
                    <span
                      key={output}
                      className="text-xs px-2 py-1 rounded bg-secondary border border-border text-foreground"
                    >
                      {output}
                    </span>
                  ))}
                </div>
              </div>
            ))}
        </div>
      </Card>

      {/* Integration Principle */}
      <Card className="p-6 border-border bg-card">
        <h4 className="font-mono text-sm text-violet-400 uppercase tracking-wider mb-3">
          Coherent Interference Principle
        </h4>
        <div className="space-y-3 text-sm">
          <p className="text-muted-foreground">
            Rather than asking a single LLM to generate an answer, tasks are broken down across all five dimensions.
            Each dimension processes the problem through its unique lens:
          </p>
          <ul className="space-y-2 text-muted-foreground">
            <li className="flex gap-2">
              <span className="text-cyan-400">→</span>
              <span>Design Field provides logical structure and framework</span>
            </li>
            <li className="flex gap-2">
              <span className="text-cyan-400">→</span>
              <span>Evolution Field retrieves historical context and precedent</span>
            </li>
            <li className="flex gap-2">
              <span className="text-cyan-400">→</span>
              <span>Movement Field generates novel and creative possibilities</span>
            </li>
            <li className="flex gap-2">
              <span className="text-cyan-400">→</span>
              <span>Being Field anchors in practical reality</span>
            </li>
            <li className="flex gap-2">
              <span className="text-cyan-400">→</span>
              <span>Space Field handles presentation and relational framing</span>
            </li>
          </ul>
          <p className="text-muted-foreground pt-2">
            The final response is created by a synthesis layer that only accepts the coherent interference pattern
            generated by all five dimensions. This ensures output is not just statistically probable, but structurally
            integrated and aligned with the whole self of the AI.
          </p>
        </div>
      </Card>
    </div>
  );
}
