import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  backgroundJobs,
  codeArtifacts,
  improvementSuggestions,
  InsertBackgroundJob,
  InsertCodeArtifact,
  InsertImprovementSuggestion,
  InsertMonetizationPlan,
  InsertProject,
  InsertProjectInput,
  InsertProjectMessage,
  InsertRecipe,
  InsertUser,
  monetizationPlans,
  projectInputs,
  projectMessages,
  projects,
  recipes,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach((field) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Projects ─────────────────────────────────────────────────────────────────
export async function createProject(data: InsertProject) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(projects).values(data);
  return result.insertId as number;
}

export async function getProjectsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(projects)
    .where(eq(projects.userId, userId))
    .orderBy(desc(projects.updatedAt));
}

export async function getProjectById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(projects)
    .where(and(eq(projects.id, id), eq(projects.userId, userId)))
    .limit(1);
  return result[0];
}

export async function updateProject(
  id: number,
  userId: number,
  data: Partial<InsertProject>
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db
    .update(projects)
    .set(data)
    .where(and(eq(projects.id, id), eq(projects.userId, userId)));
}

export async function deleteProject(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db
    .delete(projects)
    .where(and(eq(projects.id, id), eq(projects.userId, userId)));
}

// ─── Project Inputs ───────────────────────────────────────────────────────────
export async function createProjectInput(data: InsertProjectInput) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(projectInputs).values(data);
  return result.insertId as number;
}

export async function getProjectInputs(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(projectInputs)
    .where(eq(projectInputs.projectId, projectId))
    .orderBy(desc(projectInputs.createdAt));
}

export async function updateProjectInput(
  id: number,
  data: Partial<InsertProjectInput>
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(projectInputs).set(data).where(eq(projectInputs.id, id));
}

export async function deleteProjectInput(id: number, projectId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db
    .delete(projectInputs)
    .where(and(eq(projectInputs.id, id), eq(projectInputs.projectId, projectId)));
}

// ─── Code Artifacts ───────────────────────────────────────────────────────────
export async function createArtifact(data: InsertCodeArtifact) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  // Mark previous artifacts of same type as not latest
  await db
    .update(codeArtifacts)
    .set({ isLatest: false })
    .where(
      and(
        eq(codeArtifacts.projectId, data.projectId!),
        eq(codeArtifacts.artifactType, data.artifactType)
      )
    );
  const [result] = await db.insert(codeArtifacts).values({ ...data, isLatest: true });
  return result.insertId as number;
}

export async function getProjectArtifacts(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(codeArtifacts)
    .where(and(eq(codeArtifacts.projectId, projectId), eq(codeArtifacts.isLatest, true)))
    .orderBy(desc(codeArtifacts.createdAt));
}

export async function getArtifactById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(codeArtifacts)
    .where(eq(codeArtifacts.id, id))
    .limit(1);
  return result[0];
}

// ─── Project Messages ─────────────────────────────────────────────────────────
export async function createMessage(data: InsertProjectMessage) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(projectMessages).values(data);
  return result.insertId as number;
}

export async function getProjectMessages(projectId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(projectMessages)
    .where(eq(projectMessages.projectId, projectId))
    .orderBy(desc(projectMessages.createdAt))
    .limit(limit);
}

// ─── Background Jobs ──────────────────────────────────────────────────────────
export async function createJob(data: InsertBackgroundJob) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(backgroundJobs).values(data);
  return result.insertId as number;
}

export async function getQueuedJobs(limit = 5) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(backgroundJobs)
    .where(eq(backgroundJobs.status, "queued"))
    .orderBy(backgroundJobs.scheduledAt)
    .limit(limit);
}

export async function updateJobStatus(
  id: number,
  status: "running" | "done" | "failed" | "skipped",
  result?: unknown,
  errorMessage?: string
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db
    .update(backgroundJobs)
    .set({
      status,
      result: result as any,
      errorMessage,
      ...(status === "running" ? { startedAt: new Date() } : {}),
      ...(["done", "failed", "skipped"].includes(status) ? { completedAt: new Date() } : {}),
    })
    .where(eq(backgroundJobs.id, id));
}

export async function getJobsByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(backgroundJobs)
    .where(eq(backgroundJobs.projectId, projectId))
    .orderBy(desc(backgroundJobs.createdAt))
    .limit(20);
}

// ─── Recipes ──────────────────────────────────────────────────────────────────
export async function createRecipe(data: InsertRecipe) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(recipes).values(data);
  return result.insertId as number;
}

export async function getRecipesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(recipes)
    .where(eq(recipes.userId, userId))
    .orderBy(desc(recipes.usageCount));
}

export async function getPublicRecipes() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(recipes)
    .where(eq(recipes.isPublic, true))
    .orderBy(desc(recipes.usageCount))
    .limit(20);
}

// ─── Monetization Plans ───────────────────────────────────────────────────────
export async function createMonetizationPlan(data: InsertMonetizationPlan) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(monetizationPlans).values(data);
  return result.insertId as number;
}

export async function getMonetizationPlan(projectId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(monetizationPlans)
    .where(eq(monetizationPlans.projectId, projectId))
    .orderBy(desc(monetizationPlans.updatedAt))
    .limit(1);
  return result[0];
}

// ─── Improvement Suggestions ──────────────────────────────────────────────────
export async function createSuggestion(data: InsertImprovementSuggestion) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const [result] = await db.insert(improvementSuggestions).values(data);
  return result.insertId as number;
}

export async function getSuggestionsByProject(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(improvementSuggestions)
    .where(
      and(
        eq(improvementSuggestions.projectId, projectId),
        eq(improvementSuggestions.status, "pending")
      )
    )
    .orderBy(desc(improvementSuggestions.createdAt));
}

export async function updateSuggestionStatus(
  id: number,
  status: "accepted" | "dismissed" | "applied"
) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db
    .update(improvementSuggestions)
    .set({ status })
    .where(eq(improvementSuggestions.id, id));
}

// ─── Stats ────────────────────────────────────────────────────────────────────
export async function getUserStats(userId: number) {
  const db = await getDb();
  if (!db) return { projectCount: 0, artifactCount: 0, inputCount: 0 };
  const [projectCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(projects)
    .where(eq(projects.userId, userId));
  const [artifactCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(codeArtifacts)
    .where(eq(codeArtifacts.userId, userId));
  const [inputCount] = await db
    .select({ count: sql<number>`count(*)` })
    .from(projectInputs)
    .where(eq(projectInputs.userId, userId));
  return {
    projectCount: Number(projectCount?.count ?? 0),
    artifactCount: Number(artifactCount?.count ?? 0),
    inputCount: Number(inputCount?.count ?? 0),
  };
}
