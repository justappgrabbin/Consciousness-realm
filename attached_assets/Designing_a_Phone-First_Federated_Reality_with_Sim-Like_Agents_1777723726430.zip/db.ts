import { eq, desc, and, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  agents, agentNeeds, agentMoods, agentMemories,
  relationships, tasks, conversations, activityFeed,
  worldEvents, simulationState, districts,
  type Agent, type AgentNeeds, type AgentMood, type AgentMemory,
  type Relationship, type Task, type Conversation, type ActivityFeedItem,
  type WorldEvent, type SimulationState, type District,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ─────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach((field) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  });
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Simulation State ──────────────────────────────────────────────────────────
export async function getSimulationState(): Promise<SimulationState | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(simulationState).limit(1);
  return result[0] ?? null;
}

export async function upsertSimulationState(data: Partial<SimulationState>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getSimulationState();
  if (!existing) {
    await db.insert(simulationState).values({
      tick: data.tick ?? 0,
      worldDay: data.worldDay ?? 1,
      worldHour: data.worldHour ?? 8.0,
      paused: data.paused ?? false,
      tickIntervalMs: data.tickIntervalMs ?? 8000,
      lastTickAt: data.lastTickAt ?? new Date(),
    });
  } else {
    await db.update(simulationState).set({ ...data, lastTickAt: new Date() }).where(eq(simulationState.id, existing.id));
  }
}

// ─── Districts ─────────────────────────────────────────────────────────────────
export async function getAllDistricts(): Promise<District[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(districts);
}

export async function getDistrictById(id: number): Promise<District | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(districts).where(eq(districts.id, id)).limit(1);
  return result[0] ?? null;
}

export async function createDistrict(data: Omit<District, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(districts).values(data);
  return result;
}

export async function updateDistrictPopulation(id: number, population: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(districts).set({ population }).where(eq(districts.id, id));
}

// ─── Agents ────────────────────────────────────────────────────────────────────
export async function getAllAgents(): Promise<Agent[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(agents).where(eq(agents.isAlive, true));
}

export async function getAgentById(id: number): Promise<Agent | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(agents).where(eq(agents.id, id)).limit(1);
  return result[0] ?? null;
}

export async function getAgentsByDistrict(districtId: number): Promise<Agent[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(agents).where(and(eq(agents.districtId, districtId), eq(agents.isAlive, true)));
}

export async function updateAgent(id: number, data: Partial<Agent>) {
  const db = await getDb();
  if (!db) return;
  await db.update(agents).set(data).where(eq(agents.id, id));
}

export async function createAgent(data: Omit<Agent, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(agents).values(data);
  return result;
}

// ─── Agent Needs ───────────────────────────────────────────────────────────────
export async function getAgentNeeds(agentId: number): Promise<AgentNeeds | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(agentNeeds).where(eq(agentNeeds.agentId, agentId)).limit(1);
  return result[0] ?? null;
}

export async function upsertAgentNeeds(agentId: number, data: Partial<AgentNeeds>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getAgentNeeds(agentId);
  if (!existing) {
    await db.insert(agentNeeds).values({ agentId, ...data });
  } else {
    await db.update(agentNeeds).set(data).where(eq(agentNeeds.agentId, agentId));
  }
}

// ─── Agent Moods ───────────────────────────────────────────────────────────────
export async function getAgentMood(agentId: number): Promise<AgentMood | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(agentMoods).where(eq(agentMoods.agentId, agentId)).limit(1);
  return result[0] ?? null;
}

export async function upsertAgentMood(agentId: number, data: Partial<AgentMood>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getAgentMood(agentId);
  if (!existing) {
    await db.insert(agentMoods).values({ agentId, ...data } as any);
  } else {
    await db.update(agentMoods).set(data).where(eq(agentMoods.agentId, agentId));
  }
}

// ─── Agent Memories ────────────────────────────────────────────────────────────
export async function addAgentMemory(data: Omit<AgentMemory, 'id' | 'createdAt'>) {
  const db = await getDb();
  if (!db) return;
  await db.insert(agentMemories).values(data);
}

export async function getAgentMemories(agentId: number, limit = 20): Promise<AgentMemory[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(agentMemories)
    .where(eq(agentMemories.agentId, agentId))
    .orderBy(desc(agentMemories.createdAt))
    .limit(limit);
}

export async function getRecentAgentMemories(agentId: number, limit = 5): Promise<AgentMemory[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(agentMemories)
    .where(eq(agentMemories.agentId, agentId))
    .orderBy(desc(agentMemories.createdAt))
    .limit(limit);
}

// ─── Relationships ─────────────────────────────────────────────────────────────
export async function getAgentRelationships(agentId: number): Promise<Relationship[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(relationships)
    .where(or(eq(relationships.agentAId, agentId), eq(relationships.agentBId, agentId)));
}

export async function getRelationship(agentAId: number, agentBId: number): Promise<Relationship | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(relationships)
    .where(or(
      and(eq(relationships.agentAId, agentAId), eq(relationships.agentBId, agentBId)),
      and(eq(relationships.agentAId, agentBId), eq(relationships.agentBId, agentAId))
    )).limit(1);
  return result[0] ?? null;
}

export async function upsertRelationship(agentAId: number, agentBId: number, data: Partial<Relationship>) {
  const db = await getDb();
  if (!db) return;
  const existing = await getRelationship(agentAId, agentBId);
  if (!existing) {
    await db.insert(relationships).values({ agentAId, agentBId, ...data } as any);
  } else {
    await db.update(relationships).set(data).where(eq(relationships.id, existing.id));
  }
}

// ─── Tasks ─────────────────────────────────────────────────────────────────────
export async function getAgentTasks(agentId: number): Promise<Task[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks)
    .where(eq(tasks.agentId, agentId))
    .orderBy(desc(tasks.createdAt))
    .limit(20);
}

export async function getAgentActiveTasks(agentId: number): Promise<Task[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks)
    .where(and(eq(tasks.agentId, agentId), or(eq(tasks.status, 'pending'), eq(tasks.status, 'in_progress'))));
}

export async function createTask(data: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(tasks).values(data);
}

export async function updateTask(id: number, data: Partial<Task>) {
  const db = await getDb();
  if (!db) return;
  await db.update(tasks).set(data).where(eq(tasks.id, id));
}

// ─── Conversations ─────────────────────────────────────────────────────────────
export async function createConversation(data: Omit<Conversation, 'id' | 'createdAt'>) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(conversations).values(data);
}

export async function getRecentConversations(limit = 10): Promise<Conversation[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(conversations).orderBy(desc(conversations.createdAt)).limit(limit);
}

export async function getAgentConversations(agentId: number, limit = 10): Promise<Conversation[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(conversations)
    .where(or(eq(conversations.agentAId, agentId), eq(conversations.agentBId, agentId)))
    .orderBy(desc(conversations.createdAt))
    .limit(limit);
}

// ─── Activity Feed ─────────────────────────────────────────────────────────────
export async function addFeedEvent(data: Omit<ActivityFeedItem, 'id' | 'createdAt'>) {
  const db = await getDb();
  if (!db) return;
  await db.insert(activityFeed).values(data);
}

export async function getActivityFeed(limit = 50): Promise<ActivityFeedItem[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityFeed).orderBy(desc(activityFeed.createdAt)).limit(limit);
}

export async function getAgentFeed(agentId: number, limit = 20): Promise<ActivityFeedItem[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityFeed)
    .where(eq(activityFeed.agentId, agentId))
    .orderBy(desc(activityFeed.createdAt))
    .limit(limit);
}

// ─── World Events ──────────────────────────────────────────────────────────────
export async function createWorldEvent(data: Omit<WorldEvent, 'id' | 'createdAt'>) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(worldEvents).values(data);
}

export async function getActiveWorldEvents(): Promise<WorldEvent[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(worldEvents).where(eq(worldEvents.resolved, false)).orderBy(desc(worldEvents.createdAt));
}

export async function getRecentWorldEvents(limit = 10): Promise<WorldEvent[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(worldEvents).orderBy(desc(worldEvents.createdAt)).limit(limit);
}

export async function resolveWorldEvent(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(worldEvents).set({ resolved: true }).where(eq(worldEvents.id, id));
}
