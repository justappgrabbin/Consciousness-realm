# Kimi Agent: Mobile-First React App - Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Prerequisites
- **Node.js** 18+ (download from [nodejs.org](https://nodejs.org))
- **npm** or **pnpm** (comes with Node.js)
- **Git** (optional, for cloning)

---

## Step 1: Install Dependencies (1 minute)

```bash
cd kimi-agent-upgraded
pnpm install
```

Or if using npm:
```bash
npm install
```

**What this does:** Downloads all required packages (React, TensorFlow.js, Monaco Editor, Tailwind CSS, etc.)

---

## Step 2: Start Development Server (30 seconds)

```bash
pnpm dev
```

Or with npm:
```bash
npm run dev
```

**Expected output:**
```
Server running on http://localhost:3000/
```

Open your browser to **http://localhost:3000** and you're done! ✅

---

## Step 3: Access the App

The app will load with:
- **Dark cyberpunk theme** with violet/fuchsia accents
- **Mobile-first responsive design** (works on phone, tablet, desktop)
- **Monaco Editor** for code input
- **Real-time metrics dashboard** showing GNN training progress
- **Neural background canvas** with animated graph visualization

---

## 🎯 First Time Using the App?

### 1. **Paste Your Code**
   - Click the Monaco Editor area
   - Paste any JavaScript/TypeScript code
   - The GNN will analyze it automatically

### 2. **Watch the Neural Network Learn**
   - Real-time loss trends appear in the Metrics Dashboard
   - Confidence curves update as the GNN trains
   - Training progress shows live statistics

### 3. **Review Proposals**
   - LLM generates code improvement proposals
   - Each proposal shows a diff with before/after code
   - Filter by status or impact level
   - Approve, reject, or execute proposals

### 4. **Check Autonomous Goals**
   - GNN sets its own improvement goals
   - Goals track progress automatically
   - Mark goals complete when metrics improve

---

## 🔧 Common Commands

| Command | What it does |
|---------|-------------|
| `pnpm dev` | Start development server (hot reload enabled) |
| `pnpm build` | Build for production |
| `pnpm test` | Run all tests (36 tests included) |
| `pnpm check` | Check TypeScript for errors |
| `pnpm format` | Format code with Prettier |

---

## 📱 Mobile Testing

### Test on Your Phone:
1. Find your computer's local IP (run `ipconfig` on Windows or `ifconfig` on Mac/Linux)
2. On your phone, visit: `http://YOUR_IP:3000`
3. The app is fully responsive and touch-friendly

### Or use Chrome DevTools:
1. Open DevTools (F12)
2. Click the phone icon (Toggle device toolbar)
3. Select any device to test responsiveness

---

## 🗄️ Database Setup

The app uses **MySQL** for persistent learning. If you need to reset:

```bash
# The database schema is already migrated
# No additional setup needed!
```

The GNN automatically saves trained weights and embeddings to the database, so learning persists across sessions.

---

## 🐛 Troubleshooting

### **Port 3000 already in use?**
```bash
# Use a different port
PORT=3001 pnpm dev
```

### **Dependencies not installing?**
```bash
# Clear cache and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### **TypeScript errors?**
```bash
pnpm check
# Review errors and fix them
```

### **Tests failing?**
```bash
pnpm test
# All 36 tests should pass
```

---

## 📊 What's Included

✅ **Real TensorFlow.js GNN** - Analyzes code structure as a graph  
✅ **Persistent Learning** - Weights stored in database, restored on restart  
✅ **Autonomous Goals** - GNN sets its own improvement targets  
✅ **Real-Time Metrics** - Live loss trends and confidence curves  
✅ **LLM Integration** - Generates code proposals (toggle on/off)  
✅ **Proposal Workflow** - Approve, reject, execute code improvements  
✅ **Mobile-First Design** - Works perfectly on phones, tablets, desktops  
✅ **Dark Cyberpunk Theme** - Violet/fuchsia accents, animated background  
✅ **Monaco Editor** - Professional code editing with syntax highlighting  
✅ **36 Tests** - Comprehensive test coverage, all passing  

---

## 🎨 Customization

### Change Theme Colors
Edit `client/src/index.css`:
```css
@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 0 0% 3.6%;
    /* Change these values to customize colors */
  }
}
```

### Adjust Mobile Breakpoints
Edit `client/src/index.css` or use Tailwind's responsive prefixes:
```tsx
<div className="text-sm md:text-base lg:text-lg">
  Responsive text that changes on mobile/tablet/desktop
</div>
```

---

## 📚 Project Structure

```
kimi-agent-upgraded/
├── client/                 # React frontend
│   ├── src/
│   │   ├── pages/         # Page components
│   │   ├── components/    # Reusable UI components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── contexts/      # React contexts (settings, auth)
│   │   └── App.tsx        # Main app component
│   └── index.html         # HTML entry point
├── server/                # Express backend
│   ├── gnn/              # TensorFlow.js GNN engine
│   ├── routers/          # tRPC API routes
│   └── _core/            # Core utilities
├── drizzle/              # Database schema
└── package.json          # Dependencies
```

---

## 🚀 Next Steps

1. **Explore the code:** Start in `client/src/pages/KimiBuilder.tsx`
2. **Modify the GNN:** Edit `server/gnn/core.ts` to change neural network behavior
3. **Add features:** Create new components in `client/src/components/`
4. **Deploy:** Use the Manus UI's Publish button to deploy live

---

## 💡 Tips

- **Hot reload enabled:** Changes save automatically while dev server runs
- **Database persists:** Trained weights and goals survive app restarts
- **Tests always passing:** Run `pnpm test` to verify everything works
- **Mobile-first:** Design and test on phone first, then scale up
- **LLM toggle:** Settings → LLM Integration Settings to enable/disable proposals

---

## ❓ Need Help?

- Check the logs in your terminal for errors
- Run `pnpm check` to verify TypeScript
- Run `pnpm test` to verify all features work
- Review `todo.md` for completed features and architecture

---

**You're all set! Start coding and let the neural network learn from your code.** 🧠⚡
