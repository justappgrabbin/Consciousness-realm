import { cn } from "@/lib/utils";

const MOOD_CONFIG: Record<string, { emoji: string; label: string; color: string; bg: string }> = {
  ecstatic: { emoji: "🤩", label: "Ecstatic", color: "text-yellow-300", bg: "bg-yellow-400/15" },
  happy: { emoji: "😊", label: "Happy", color: "text-green-300", bg: "bg-green-400/15" },
  content: { emoji: "😌", label: "Content", color: "text-blue-300", bg: "bg-blue-400/15" },
  neutral: { emoji: "😐", label: "Neutral", color: "text-slate-300", bg: "bg-slate-400/15" },
  uncomfortable: { emoji: "😣", label: "Uncomfortable", color: "text-orange-300", bg: "bg-orange-400/15" },
  sad: { emoji: "😢", label: "Sad", color: "text-blue-400", bg: "bg-blue-600/15" },
  distressed: { emoji: "😰", label: "Distressed", color: "text-purple-300", bg: "bg-purple-500/15" },
  furious: { emoji: "😡", label: "Furious", color: "text-red-400", bg: "bg-red-500/15" },
};

interface MoodBadgeProps {
  mood: string;
  dominantEmotion?: string;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
  className?: string;
}

export function MoodBadge({ mood, dominantEmotion, size = "md", showLabel = true, className }: MoodBadgeProps) {
  const config = MOOD_CONFIG[mood] ?? MOOD_CONFIG.neutral!;

  return (
    <div className={cn(
      "inline-flex items-center gap-1.5 rounded-full font-medium",
      config.bg,
      config.color,
      size === "sm" && "px-2 py-0.5 text-xs",
      size === "md" && "px-3 py-1 text-sm",
      size === "lg" && "px-4 py-1.5 text-base",
      className
    )}>
      <span>{config.emoji}</span>
      {showLabel && (
        <span>{dominantEmotion ? `${config.label} · ${dominantEmotion}` : config.label}</span>
      )}
    </div>
  );
}

export function getMoodEmoji(mood: string): string {
  return MOOD_CONFIG[mood]?.emoji ?? "😐";
}

export function getMoodColor(mood: string): string {
  return MOOD_CONFIG[mood]?.color ?? "text-slate-300";
}
