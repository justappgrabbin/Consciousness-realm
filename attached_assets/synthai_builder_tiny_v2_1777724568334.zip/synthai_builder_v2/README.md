
# SynthAI Builder & Game Maker — Human Design Advanced (No Bash) — v2 Tiny

Adds optional **in-browser TinyLlama** via WebLLM (WebGPU). No CLI.

## Quickstart
1. Open `index.html` in Chrome (desktop or Android). Chrome 113+ recommended for WebGPU.
2. In **Model Mode**, select **TinyLlama** to load the model via CDN (first load takes time).
3. Use the **Tiny Chat** panel to chat locally. If unsupported, switch back to None.
4. Configure your project → **Export ZIP**.

## Notes
- TinyLlama model: `TinyLlama-1.1B-Chat-v1.0-q4f16_1-MLC` via WebLLM registry.
- Offline use: host `web-llm.min.js` and model weights locally and update the script tag / registry.
- Everything else (builder/export) is fully offline once the page is open.

Built 2025-08-30.
