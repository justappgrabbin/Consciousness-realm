"""
Training API routes - Neural brain optimization and learning
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any

router = APIRouter()


class TrainStepInput(BaseModel):
    """Input for training step"""
    learning_rate: float = 0.01
    num_steps: int = 1


class TrainStepResponse(BaseModel):
    """Response from training step"""
    epoch: int
    loss: float
    accuracy: float
    message: str


class MetricsResponse(BaseModel):
    """Current metrics"""
    epoch: int
    loss: float
    accuracy: float
    concepts_count: int
    code_blocks_count: int
    relationships_count: int


@router.post("/step", response_model=TrainStepResponse)
async def train_step(input_data: TrainStepInput):
    """
    Perform one or more training steps
    
    Args:
        input_data: Training parameters
        
    Returns:
        Training results
    """
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    try:
        total_loss = 0.0
        total_accuracy = 0.0
        
        for _ in range(input_data.num_steps):
            loss, accuracy = isomorphic_network.train_step(input_data.learning_rate)
            total_loss += loss
            total_accuracy += accuracy
        
        avg_loss = total_loss / input_data.num_steps
        avg_accuracy = total_accuracy / input_data.num_steps
        
        return TrainStepResponse(
            epoch=isomorphic_network.training_epochs,
            loss=avg_loss,
            accuracy=avg_accuracy,
            message=f"Completed {input_data.num_steps} training step(s)"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/metrics", response_model=MetricsResponse)
async def get_metrics():
    """
    Get current training metrics
    
    Returns:
        Current metrics
    """
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    try:
        stats = isomorphic_network.get_statistics()
        
        return MetricsResponse(
            epoch=stats.get("training_epochs", 0),
            loss=stats.get("current_loss", 0.0),
            accuracy=stats.get("current_accuracy", 0.0),
            concepts_count=stats.get("concepts_count", 0),
            code_blocks_count=stats.get("code_blocks_count", 0),
            relationships_count=stats.get("relationships_count", 0),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/reset")
async def reset_training():
    """
    Reset training metrics
    
    Returns:
        Confirmation
    """
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    try:
        isomorphic_network.training_epochs = 0
        isomorphic_network.total_loss = 0.0
        isomorphic_network.total_accuracy = 0.0
        
        return {
            "success": True,
            "message": "Training metrics reset"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/network-export")
async def export_network():
    """
    Export the entire network as JSON
    
    Returns:
        Network data
    """
    from main import isomorphic_network
    
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Isomorphic network not initialized")
    
    try:
        return isomorphic_network.to_dict()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
