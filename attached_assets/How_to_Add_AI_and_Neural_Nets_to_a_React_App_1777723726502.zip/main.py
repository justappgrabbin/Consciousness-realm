"""
AI Self-Builder Neural Brain - FastAPI Server
Provides embeddings, isomorphic pattern detection, and intelligent code suggestions
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import os
from dotenv import load_dotenv

from models.embeddings import EmbeddingModel
from models.isomorphic_network import IsomorphicNetwork
from models.persistence import ModelPersistence
from routes import embeddings, patterns, training

load_dotenv()

# Initialize FastAPI app
app = FastAPI(
    title="AI Self-Builder Neural Brain",
    description="Neural intelligence core for the AI Self-Builder application",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global models
embedding_model: Optional[EmbeddingModel] = None
isomorphic_network: Optional[IsomorphicNetwork] = None
persistence: Optional[ModelPersistence] = None


@app.on_event("startup")
async def startup_event():
    """Initialize models on startup"""
    global embedding_model, isomorphic_network, persistence
    
    print("🧠 Initializing Neural Brain...")
    
    # Initialize persistence
    persistence = ModelPersistence()
    print("✓ Persistence initialized")
    
    # Load embedding model
    embedding_model = EmbeddingModel()
    print("✓ Embedding model loaded")
    
    # Initialize isomorphic network
    isomorphic_network = IsomorphicNetwork(embedding_dim=embedding_model.embedding_dim)
    print("✓ Isomorphic network initialized")
    
    # Load saved state if available
    if persistence:
        saved_state = persistence.load_network_state()
        if saved_state:
            try:
                isomorphic_network.nodes = saved_state.get("nodes", [])
                isomorphic_network.edges = saved_state.get("edges", [])
                print(f"✓ Restored {len(isomorphic_network.nodes)} nodes and {len(isomorphic_network.edges)} edges")
            except Exception as e:
                print(f"⚠ Failed to restore state: {e}")
        
        # Load training metrics
        saved_metrics = persistence.load_training_metrics()
        if saved_metrics:
            isomorphic_network.training_metrics = saved_metrics
            print(f"✓ Restored training metrics (epoch {saved_metrics.get('latest_epoch', 0)})")
    
    print("🧠 Neural Brain ready!")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    print("🧠 Shutting down Neural Brain...")
    
    # Save state before shutdown
    if persistence and isomorphic_network:
        try:
            network_data = {
                "nodes": isomorphic_network.nodes,
                "edges": isomorphic_network.edges,
            }
            persistence.save_network_state(network_data)
            persistence.save_training_metrics(isomorphic_network.training_metrics)
            print("✓ Neural brain state saved")
        except Exception as e:
            print(f"⚠ Failed to save state: {e}")


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "embedding_model_loaded": embedding_model is not None,
        "isomorphic_network_loaded": isomorphic_network is not None,
    }


@app.get("/status")
async def status():
    """Get neural brain status and statistics"""
    if not isomorphic_network:
        raise HTTPException(status_code=503, detail="Neural brain not initialized")
    
    stats = isomorphic_network.get_statistics()
    return {
        "status": "active",
        "embedding_dimension": embedding_model.embedding_dim if embedding_model else 0,
        "concepts_count": stats.get("concepts_count", 0),
        "code_blocks_count": stats.get("code_blocks_count", 0),
        "relationships_count": stats.get("relationships_count", 0),
        "training_epochs": stats.get("training_epochs", 0),
    }


# Include routers
app.include_router(embeddings.router, prefix="/api/embeddings", tags=["embeddings"])
app.include_router(patterns.router, prefix="/api/patterns", tags=["patterns"])
app.include_router(training.router, prefix="/api/training", tags=["training"])


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "AI Self-Builder Neural Brain",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "status": "/status",
            "embeddings": "/api/embeddings",
            "patterns": "/api/patterns",
            "training": "/api/training",
        }
    }


if __name__ == "__main__":
    import uvicorn
    
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=os.getenv("ENV", "development") == "development"
    )
