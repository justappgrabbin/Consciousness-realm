/**
 * Agent Cognition Engine
 * LLM-powered inner monologue, decision-making, conversations, and memory
 */

import { invokeLLM } from "./_core/llm";
import type { Agent, AgentNeeds, AgentMood as AgentMoodRow, Relationship } from "../drizzle/schema";

export interface CognitionContext {
  agent: Agent;
  needs: AgentNeeds;
  mood: AgentMoodRow;
  recentMemories: string[];
  relationships: Array<{ name: string; type: string; strength: number }>;
  worldHour: number;
  worldDay: number;
  districtName: string;
  currentActivity: string;
}

// ─── Inner Monologue ───────────────────────────────────────────────────────────
export async function generateInnerMonologue(ctx: CognitionContext): Promise<string> {
  const needsSummary = `hunger:${Math.round(ctx.needs.hunger)}, energy:${Math.round(ctx.needs.energy)}, social:${Math.round(ctx.needs.social)}, fun:${Math.round(ctx.needs.fun)}`;
  const personality = ctx.agent.personality;
  const traits = personality.traits?.join(", ") ?? "thoughtful";

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are ${ctx.agent.name}, a ${ctx.agent.age}-year-old ${ctx.agent.job} living in ${ctx.districtName}. 
Your personality traits: ${traits}. 
Openness: ${personality.openness.toFixed(1)}, Conscientiousness: ${personality.conscientiousness.toFixed(1)}, Extraversion: ${personality.extraversion.toFixed(1)}, Agreeableness: ${personality.agreeableness.toFixed(1)}, Neuroticism: ${personality.neuroticism.toFixed(1)}.
Current mood: ${ctx.mood.mood} (${ctx.mood.dominantEmotion}).
Write a brief, authentic inner monologue — 1-2 sentences in first person — reflecting your current state, needs, and what's on your mind. Be specific and human.`,
        },
        {
          role: "user",
          content: `It's ${formatWorldTime(ctx.worldHour)} on Day ${ctx.worldDay}. You're currently ${ctx.currentActivity} in ${ctx.districtName}. Your needs: ${needsSummary}. Recent memories: ${ctx.recentMemories.slice(0, 3).join("; ") || "nothing notable"}. What are you thinking right now?`,
        },
      ],
    });
    const raw = response.choices[0]?.message?.content;
    return (typeof raw === 'string' ? raw.trim() : null) ?? "Just going through the motions...";
  } catch {
    return `Feeling ${ctx.mood.dominantEmotion} today. ${ctx.currentActivity} seems like the right call.`;
  }
}

// ─── Decision Making ───────────────────────────────────────────────────────────
export interface AgentDecision {
  action: string;
  location: string;
  reasoning: string;
  targetAgentId?: number;
}

export async function makeAgentDecision(
  ctx: CognitionContext,
  availableActions: string[],
  suggestedAction: { activity: string; location: string; reason: string }
): Promise<AgentDecision> {
  const personality = ctx.agent.personality;
  const traits = personality.traits?.join(", ") ?? "thoughtful";

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are ${ctx.agent.name}, a ${ctx.agent.age}-year-old ${ctx.agent.job}. Personality: ${traits}. Decide what to do next. Respond with JSON only.`,
        },
        {
          role: "user",
          content: `Current state: mood=${ctx.mood.mood}, hunger=${Math.round(ctx.needs.hunger)}, energy=${Math.round(ctx.needs.energy)}, social=${Math.round(ctx.needs.social)}.
Time: ${formatWorldTime(ctx.worldHour)}, Day ${ctx.worldDay}.
Available actions: ${availableActions.join(", ")}.
Suggested by needs: ${suggestedAction.activity} (${suggestedAction.reason}).
Choose an action. Respond with JSON: {"action": "...", "location": "...", "reasoning": "..."}`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "agent_decision",
          strict: true,
          schema: {
            type: "object",
            properties: {
              action: { type: "string" },
              location: { type: "string" },
              reasoning: { type: "string" },
            },
            required: ["action", "location", "reasoning"],
            additionalProperties: false,
          },
        },
      },
    });

    const raw = response.choices[0]?.message?.content;
    const content = typeof raw === 'string' ? raw : null;
    if (content) {
      const parsed = JSON.parse(content);
      return parsed as AgentDecision;
    }
  } catch {
    // Fall back to suggestion
  }

  return {
    action: suggestedAction.activity,
    location: suggestedAction.location,
    reasoning: suggestedAction.reason,
  };
}

// ─── Agent Conversation ────────────────────────────────────────────────────────
export interface ConversationResult {
  messages: Array<{ role: "a" | "b"; text: string }>;
  summary: string;
  sentiment: number;
  relationshipDelta: number;
}

export async function generateConversation(
  agentA: Agent,
  agentB: Agent,
  relationship: Relationship | null,
  worldHour: number,
  worldDay: number,
  location: string
): Promise<ConversationResult> {
  const relType = relationship?.type ?? "acquaintance";
  const relStrength = relationship?.strength ?? 0.1;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `Generate a short, natural conversation between two people in a social simulation.
${agentA.name} (${agentA.age}yo ${agentA.job}, traits: ${agentA.personality.traits?.join(", ")}).
${agentB.name} (${agentB.age}yo ${agentB.job}, traits: ${agentB.personality.traits?.join(", ")}).
Their relationship: ${relType} (strength: ${(relStrength * 100).toFixed(0)}%).
Location: ${location}. Time: ${formatWorldTime(worldHour)}, Day ${worldDay}.
Generate 3-4 exchanges. Respond with JSON only.`,
        },
        {
          role: "user",
          content: `Generate the conversation. Respond with JSON: {"messages": [{"role": "a", "text": "..."}, {"role": "b", "text": "..."}], "summary": "...", "sentiment": 0.0-1.0, "relationshipDelta": -0.1 to 0.1}`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "conversation",
          strict: true,
          schema: {
            type: "object",
            properties: {
              messages: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    role: { type: "string" },
                    text: { type: "string" },
                  },
                  required: ["role", "text"],
                  additionalProperties: false,
                },
              },
              summary: { type: "string" },
              sentiment: { type: "number" },
              relationshipDelta: { type: "number" },
            },
            required: ["messages", "summary", "sentiment", "relationshipDelta"],
            additionalProperties: false,
          },
        },
      },
    });

    const raw = response.choices[0]?.message?.content;
    const content = typeof raw === 'string' ? raw : null;
    if (content) {
      const parsed = JSON.parse(content);
      return {
        messages: parsed.messages.map((m: any) => ({ role: m.role as "a" | "b", text: m.text })),
        summary: parsed.summary,
        sentiment: Math.max(0, Math.min(1, parsed.sentiment)),
        relationshipDelta: Math.max(-0.15, Math.min(0.15, parsed.relationshipDelta)),
      };
    }
  } catch {
    // Fall back
  }

  return {
    messages: [
      { role: "a", text: `Hey ${agentB.name}, how's it going?` },
      { role: "b", text: `Pretty good, ${agentA.name}. Just taking things one day at a time.` },
      { role: "a", text: "Same here. Catch you later!" },
      { role: "b", text: "Take care!" },
    ],
    summary: `${agentA.name} and ${agentB.name} had a brief casual exchange.`,
    sentiment: 0.6,
    relationshipDelta: 0.02,
  };
}

// ─── Task Planning ─────────────────────────────────────────────────────────────
export async function planAgentTask(
  agent: Agent,
  worldDay: number,
  worldHour: number
): Promise<{ title: string; description: string; type: string; priority: number } | null> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are ${agent.name}, a ${agent.age}-year-old ${agent.job}. Generate one meaningful task for yourself to pursue today. Respond with JSON only.`,
        },
        {
          role: "user",
          content: `It's ${formatWorldTime(worldHour)} on Day ${worldDay}. Your job: ${agent.job}. Your goals: ${(agent.goals as string[])?.join(", ") || "live well"}.
Generate a task. Respond with JSON: {"title": "...", "description": "...", "type": "work|errand|social|personal|creative|survival", "priority": 0.0-1.0}`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "task_plan",
          strict: true,
          schema: {
            type: "object",
            properties: {
              title: { type: "string" },
              description: { type: "string" },
              type: { type: "string" },
              priority: { type: "number" },
            },
            required: ["title", "description", "type", "priority"],
            additionalProperties: false,
          },
        },
      },
    });

    const raw = response.choices[0]?.message?.content;
    const content = typeof raw === 'string' ? raw : null;
    if (content) return JSON.parse(content);
  } catch {
    return null;
  }
  return null;
}

// ─── Memory Summarization ────────────────────────────────────────────────────
export async function summarizeAgentMemories(
  agent: Agent,
  memories: string[]
): Promise<string> {
  if (memories.length === 0) return "No significant memories yet.";

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are a narrator summarizing the recent life experiences of ${agent.name}, a ${agent.age}-year-old ${agent.job}. Write a concise 2-3 sentence summary of their recent memories in third person, capturing the emotional arc and key events. Be vivid and human.`,
        },
        {
          role: "user",
          content: `Recent memories (${memories.length} entries):\n${memories.slice(0, 20).map((m, i) => `${i + 1}. ${m}`).join("\n")}\n\nSummarize these experiences.`,
        },
      ],
    });
    const raw = response.choices[0]?.message?.content;
    return (typeof raw === 'string' ? raw.trim() : null) ?? `${agent.name} has been living their daily life, navigating work, relationships, and personal needs.`;
  } catch {
    return `${agent.name} has been living their daily life, navigating work, relationships, and personal needs.`;
  }
}

// ─── Cross-District Message ────────────────────────────────────────────────────
export async function generateCrossDistrictMessage(
  sender: Agent,
  receiver: Agent,
  relationship: Relationship | null,
  worldDay: number
): Promise<{ subject: string; message: string; sentiment: number }> {
  const relType = relationship?.type ?? "acquaintance";

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are ${sender.name}, a ${sender.age}-year-old ${sender.job}. Write a short message to ${receiver.name} who lives in a different district. You are ${relType}s. Keep it authentic and personal. Respond with JSON only.`,
        },
        {
          role: "user",
          content: `Day ${worldDay}. Write a message to ${receiver.name} (${receiver.job}). Respond with JSON: {"subject": "...", "message": "...", "sentiment": 0.0-1.0}`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "cross_district_message",
          strict: true,
          schema: {
            type: "object",
            properties: {
              subject: { type: "string" },
              message: { type: "string" },
              sentiment: { type: "number" },
            },
            required: ["subject", "message", "sentiment"],
            additionalProperties: false,
          },
        },
      },
    });
    const raw = response.choices[0]?.message?.content;
    const content = typeof raw === 'string' ? raw : null;
    if (content) {
      const parsed = JSON.parse(content);
      return {
        subject: parsed.subject,
        message: parsed.message,
        sentiment: Math.max(0, Math.min(1, parsed.sentiment)),
      };
    }
  } catch {
    // Fall back
  }

  return {
    subject: `Hey from ${sender.name}`,
    message: `Just thinking of you. Hope things are going well over there!`,
    sentiment: 0.7,
  };
}

// ─── Helpers ───────────────────────────────────────────────────────────────────
export function formatWorldTime(worldHour: number): string {
  const h = Math.floor(worldHour);
  const m = Math.round((worldHour - h) * 60);
  const ampm = h >= 12 ? "PM" : "AM";
  const displayH = h % 12 === 0 ? 12 : h % 12;
  return `${displayH}:${m.toString().padStart(2, "0")} ${ampm}`;
}
