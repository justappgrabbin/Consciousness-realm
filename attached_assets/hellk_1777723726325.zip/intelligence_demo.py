"""
Intelligence Engine Demo - Proving the System Learns

This demonstrates all 5 intelligence layers working together:
1. Perception - Understanding components
2. Reasoning - Inferring causality
3. Prediction - Forecasting emergence
4. Learning - Getting smarter over time
5. Governance - HD timing gates

Run this to see intelligence in action.
"""

import sys
sys.path.insert(0, '/home/claude')

from intelligence_engine import (
    ComponentSemantics, Glyph, CausalType
)
from intelligence_layers import IntelligenceEngine


# ============================================================================
# SAMPLE COMPONENTS TO ANALYZE
# ============================================================================

SAMPLE_COMPONENTS = {
    'chart_calculator': '''
class ChartCalculator:
    """Calculate Human Design charts from birth data"""
    
    def calculate_chart(self, birth_date, birth_time, birth_location):
        """
        Calculate complete HD chart.
        
        Returns chart with gates, channels, type, authority.
        """
        chart = {
            'gates': self.calculate_gates(birth_date, birth_time),
            'type': self.determine_type(),
            'authority': self.determine_authority(),
            'profile': self.calculate_profile()
        }
        
        return chart
    
    def calculate_gates(self, date, time):
        """Calculate activated gates from planetary positions"""
        positions = self.get_planetary_positions(date, time)
        gates = [self.position_to_gate(pos) for pos in positions]
        return gates
''',

    'gate_mapper': '''
def map_to_gates(emotion, dimension):
    """
    Map emotional state and dimension to HD gates.
    
    Transform dynamic emotional data into gate activations.
    """
    gate_keywords = load_gate_keywords()
    
    matching_gates = []
    
    for gate_id, keywords in gate_keywords.items():
        if emotion.lower() in keywords:
            matching_gates.append(gate_id)
    
    return matching_gates
''',

    'resonance_engine': '''
class ResonanceSentenceEngine:
    """Generate 69,120 unique consciousness sentences"""
    
    def __init__(self):
        self.bases = 5
        self.tones = 6
        self.colors = 6
        self.lines = 6
        self.gates = 64
        
        # 5 * 6 * 6 * 6 * 64 = 69,120 combinations
    
    def generate_sentence(self, base, tone, color, line, gate):
        """
        Generate unique resonance sentence.
        
        Each position in 69,120 lattice has distinct meaning.
        """
        sentence_structure = self.get_structure(base, tone, color, line)
        gate_meaning = self.get_gate_meaning(gate)
        
        return self.synthesize(sentence_structure, gate_meaning)
''',

    'phase_state_analyzer': '''
class PhaseStateAnalyzer:
    """Analyze current phase state of consciousness"""
    
    def analyze(self, parsed_input):
        """
        Determine which phase is disrupted.
        
        Returns phase state scores for:
        - Solid
        - Liquid
        - Gas
        - Plasma
        - Gel
        - Field
        """
        phase_indicators = self.extract_phase_clues(parsed_input)
        
        states = {
            'solid': self.estimate_solid(phase_indicators),
            'liquid': self.estimate_liquid(phase_indicators),
            'gas': self.estimate_gas(phase_indicators),
            'plasma': self.estimate_plasma(phase_indicators),
            'gel': self.estimate_gel(phase_indicators),
            'field': self.estimate_field(phase_indicators)
        }
        
        return states
''',

    'solution_decoder': '''
def decode_solution(question_structure, chart_data, transits):
    """
    Decode symbolic answer (line, color, tone) from question.
    
    Cross-references:
    - Current question structure
    - User's birth chart
    - Current transits
    
    Returns specific line, color, tone that resolves dissonance.
    """
    gate = question_structure['gates'][0]
    
    # Find resolving line
    line = find_resolving_line(question_structure, chart_data)
    
    # Find resolving color
    color = find_resolving_color(question_structure, chart_data)
    
    # Find resolving tone
    tone = find_resolving_tone(question_structure, chart_data)
    
    return {
        'gate': gate,
        'line': line,
        'color': color,
        'tone': tone
    }
'''
}


# ============================================================================
# DEMONSTRATION FUNCTIONS
# ============================================================================

def demonstrate_perception(engine: IntelligenceEngine):
    """Demonstrate Layer 1: Semantic Perception"""
    
    print("\n" + "="*80)
    print("LAYER 1: PERCEPTION - Understanding Component Semantics")
    print("="*80)
    
    for comp_name, code in SAMPLE_COMPONENTS.items():
        print(f"\n📦 Analyzing: {comp_name}")
        print("-" * 80)
        
        semantics = engine.analyze_component(code, {'name': comp_name})
        
        print(f"Purpose: {semantics.purpose}")
        print(f"Capabilities: {', '.join(semantics.capabilities[:3])}")
        print(f"Primary Glyph: {semantics.glyph_primary.value} ({semantics.glyph_primary.name})")
        print(f"Domains: {', '.join(semantics.domains)}")
        print(f"Field Layer: {semantics.field_layer}")
        print(f"Fragment Type: {semantics.fragment_type}")
        print(f"Quality Potential: {semantics.quality_potential:.2f}")
        print(f"Mutation Risk: {semantics.mutation_risk:.2f}")
        print(f"Confidence: {semantics.confidence:.2f}")
        
        # Show glyph scores
        print("\nGlyph Scores:")
        for glyph, score in semantics.glyph_scores.items():
            if score > 0.2:
                print(f"  {glyph.value} {glyph.name}: {score:.2f}")


def demonstrate_reasoning(engine: IntelligenceEngine, semantics_map):
    """Demonstrate Layer 2: Causal Reasoning"""
    
    print("\n" + "="*80)
    print("LAYER 2: REASONING - Inferring Causal Relationships")
    print("="*80)
    
    # Analyze pairwise causality
    component_names = list(semantics_map.keys())
    
    interesting_pairs = [
        ('chart_calculator', 'gate_mapper'),
        ('gate_mapper', 'phase_state_analyzer'),
        ('phase_state_analyzer', 'solution_decoder'),
        ('resonance_engine', 'solution_decoder')
    ]
    
    for name_a, name_b in interesting_pairs:
        if name_a in semantics_map and name_b in semantics_map:
            print(f"\n🔗 Causality: {name_a} → {name_b}")
            print("-" * 80)
            
            sem_a = semantics_map[name_a]
            sem_b = semantics_map[name_b]
            
            causality = engine.infer_causality(sem_a, sem_b)
            
            print(f"Exists: {causality.exists}")
            if causality.exists:
                print(f"Type: {causality.causal_type.value}")
                print(f"Strength: {causality.strength:.2f}")
                print(f"Resonance: {causality.resonance_score:.2f}")
                print(f"Confidence: {causality.confidence:.2f}")
                print(f"\nMechanism:")
                print(f"  {causality.mechanism}")
                
                if causality.conditions:
                    print(f"\nConditions:")
                    for condition in causality.conditions:
                        print(f"  - {condition}")


def demonstrate_prediction(engine: IntelligenceEngine, semantics_map):
    """Demonstrate Layer 3: Emergence Prediction"""
    
    print("\n" + "="*80)
    print("LAYER 3: PREDICTION - Forecasting Emergent Properties")
    print("="*80)
    
    # Predict emergence from component set
    component_names = ['chart_calculator', 'gate_mapper', 'phase_state_analyzer', 'solution_decoder']
    semantics_list = [semantics_map[name] for name in component_names if name in semantics_map]
    
    print(f"\n🔮 Predicting emergence from {len(semantics_list)} components:")
    print(f"   {', '.join(component_names)}")
    print("-" * 80)
    
    prediction = engine.predict_emergence(semantics_list, component_names)
    
    print(f"\nPredicted Emergent Capabilities:")
    for cap in prediction.capabilities:
        print(f"  ✨ {cap}")
    
    print(f"\nPredicted Failure Modes:")
    for failure in prediction.failure_modes:
        severity_emoji = {'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '🟢'}
        emoji = severity_emoji.get(failure['severity'], '⚪')
        print(f"  {emoji} {failure['type']}: {failure['description']}")
        print(f"     Mitigation: {failure['mitigation']}")
    
    print(f"\nCoherence Score: {prediction.coherence_score:.2f}")
    
    print(f"\nResonance Patterns:")
    for pattern in prediction.resonance_patterns:
        print(f"  🎵 {pattern['components'][0]} ↔ {pattern['components'][1]}")
        print(f"     Resonance: {pattern['resonance_score']:.2f}")
        print(f"     Glyphs: {pattern['glyphs']}")
    
    print(f"\nOverall Prediction Confidence: {prediction.confidence:.2f}")
    
    return prediction


def demonstrate_learning(engine: IntelligenceEngine):
    """Demonstrate Layer 4: Learning from Outcomes"""
    
    print("\n" + "="*80)
    print("LAYER 4: LEARNING - System Getting Smarter Over Time")
    print("="*80)
    
    # Simulate multiple assembly outcomes to show learning
    print("\n📚 Simulating assembly outcomes to demonstrate learning...")
    
    # Scenario 1: Successful assembly
    print("\n--- Scenario 1: Successful Chart Analysis Pipeline ---")
    
    components_1 = ['chart_calculator', 'gate_mapper']
    semantics_1 = [engine.analyze_component(SAMPLE_COMPONENTS[c], {'name': c}) for c in components_1]
    prediction_1 = engine.predict_emergence(semantics_1, components_1)
    
    # Simulate actual outcome (success)
    actual_1 = {
        'capabilities': prediction_1.capabilities + ['additional_emergent_capability'],
        'failures': [],
        'coherence': 0.85,
        'resonance_actual': len(prediction_1.resonance_patterns)
    }
    
    outcome_1 = engine.record_outcome(prediction_1, actual_1, components_1, success=True)
    
    print(f"Prediction Accuracy: {outcome_1.prediction_accuracy:.2f}")
    print(f"Lessons Learned:")
    for lesson in outcome_1.lessons_learned:
        print(f"  📝 {lesson}")
    
    # Scenario 2: Assembly with failures
    print("\n--- Scenario 2: Complex Pipeline with Issues ---")
    
    components_2 = ['gate_mapper', 'phase_state_analyzer', 'solution_decoder']
    semantics_2 = [engine.analyze_component(SAMPLE_COMPONENTS[c], {'name': c}) for c in components_2]
    prediction_2 = engine.predict_emergence(semantics_2, components_2)
    
    # Simulate actual outcome (partial success)
    actual_2 = {
        'capabilities': prediction_2.capabilities[:1],  # Only some capabilities emerged
        'failures': [{'type': 'RACE_CONDITION'}],  # Failure we predicted
        'coherence': 0.60,
        'resonance_actual': len(prediction_2.resonance_patterns) - 1
    }
    
    outcome_2 = engine.record_outcome(prediction_2, actual_2, components_2, success=False)
    
    print(f"Prediction Accuracy: {outcome_2.prediction_accuracy:.2f}")
    print(f"Lessons Learned:")
    for lesson in outcome_2.lessons_learned:
        print(f"  📝 {lesson}")
    
    # Scenario 3: Repeat similar assembly (showing learning improves prediction)
    print("\n--- Scenario 3: Repeating Similar Assembly (System Should Be Smarter) ---")
    
    # Same components as scenario 1
    prediction_3 = engine.predict_emergence(semantics_1, components_1)
    
    # System should now have learned from scenario 1
    print(f"\n💡 System now has learned patterns from {engine.learning.stats['total_observations']} observations")
    
    # Check if learning layer provides better predictions
    learned_insights = engine.learning.predict_from_history(components_1)
    if learned_insights:
        print(f"\n🧠 Learning Layer Retrieved Historical Insights:")
        print(f"   Confidence: {learned_insights['confidence']:.2f}")
        print(f"   Based on: {learned_insights['based_on_observations']} observations")
        print(f"   Success Rate: {learned_insights['success_rate']:.2f}")
    
    # Get overall learning report
    print("\n" + "="*80)
    print("📊 LEARNING REPORT - What the System Has Learned")
    print("="*80)
    
    report = engine.get_learning_report()
    
    print(f"\nStatistics:")
    print(f"  Total Observations: {report['statistics']['total_observations']}")
    print(f"  Successful Assemblies: {report['statistics']['successful_assemblies']}")
    print(f"  Failed Assemblies: {report['statistics']['failed_assemblies']}")
    print(f"  Average Prediction Accuracy: {report.get('average_prediction_accuracy', 0):.2f}")
    
    if report['top_capability_patterns']:
        print(f"\nTop Capability Patterns Learned:")
        for pattern in report['top_capability_patterns']:
            print(f"  ✨ {pattern['name']}")
            print(f"     Accuracy: {pattern['accuracy']:.2f} | Observations: {pattern['observations']}")
    
    if report['top_failure_patterns']:
        print(f"\nTop Failure Patterns Learned:")
        for pattern in report['top_failure_patterns']:
            print(f"  🔴 {pattern['name']}")
            print(f"     Accuracy: {pattern['accuracy']:.2f} | Observations: {pattern['observations']}")
    
    if report['most_frequent_lessons']:
        print(f"\nMost Frequent Lessons:")
        for lesson in report['most_frequent_lessons'][:5]:
            print(f"  📚 [{lesson['frequency']}x] {lesson['lesson']}")
    
    if report.get('prediction_accuracy_trend'):
        print(f"\nPrediction Accuracy Trend (last {len(report['prediction_accuracy_trend'])} observations):")
        trend = report['prediction_accuracy_trend']
        if trend:
            avg_recent = sum(trend) / len(trend)
            print(f"  Average: {avg_recent:.2f}")
            print(f"  Range: {min(trend):.2f} - {max(trend):.2f}")
            
            # Show trend direction
            if len(trend) >= 10:
                first_half_avg = sum(trend[:len(trend)//2]) / (len(trend)//2)
                second_half_avg = sum(trend[len(trend)//2:]) / (len(trend) - len(trend)//2)
                
                if second_half_avg > first_half_avg:
                    print(f"  📈 Trend: IMPROVING (from {first_half_avg:.2f} to {second_half_avg:.2f})")
                else:
                    print(f"  📉 Trend: Declining (from {first_half_avg:.2f} to {second_half_avg:.2f})")


def demonstrate_governance(engine: IntelligenceEngine):
    """Demonstrate Layer 5: HD Governance"""
    
    print("\n" + "="*80)
    print("LAYER 5: GOVERNANCE - Human Design Timing Gates")
    print("="*80)
    
    # Test different user profiles
    test_profiles = [
        {
            'name': 'Generator User',
            'type': 'Generator',
            'strategy': 'TO_RESPOND',
            'definition': 'SINGLE',
            'recent_operations': 2
        },
        {
            'name': 'Projector User',
            'type': 'Projector',
            'strategy': 'WAIT_FOR_INVITATION',
            'definition': 'SPLIT',
            'recent_operations': 1
        },
        {
            'name': 'Reflector User',
            'type': 'Reflector',
            'strategy': 'WAIT_28_DAYS',
            'definition': 'QUAD',
            'recent_operations': 0
        },
        {
            'name': 'Overloaded Split Definition',
            'type': 'Generator',
            'strategy': 'TO_RESPOND',
            'definition': 'SPLIT',
            'recent_operations': 6  # Over limit
        }
    ]
    
    for profile in test_profiles:
        print(f"\n👤 User: {profile['name']}")
        print(f"   Type: {profile['type']} | Strategy: {profile['strategy']} | Definition: {profile['definition']}")
        print("-" * 80)
        
        check = engine.check_governance(profile, 'promote')
        
        if check['ready']:
            print(f"✅ Ready to promote")
            print(f"   Resonance: {check.get('resonance', 0):.2f}")
            print(f"   Guidance: {check['guidance']}")
        else:
            print(f"⛔ NOT ready to promote")
            print(f"   Reason: {check['reason']}")
            print(f"   Guidance: {check['guidance']}")


# ============================================================================
# MAIN DEMONSTRATION
# ============================================================================

def main():
    """Run complete intelligence demonstration"""
    
    print("\n" + "="*80)
    print("🧠 INTELLIGENCE ENGINE DEMONSTRATION")
    print("="*80)
    print("\nShowing all 5 intelligence layers:")
    print("  1. Perception - Understanding component semantics")
    print("  2. Reasoning - Inferring causal relationships")
    print("  3. Prediction - Forecasting emergence")
    print("  4. Learning - Getting smarter over time ⭐")
    print("  5. Governance - HD timing gates")
    
    # Initialize engine
    print("\n🚀 Initializing Intelligence Engine...")
    engine = IntelligenceEngine()
    
    # Analyze all components first
    print("\n📦 Analyzing all components...")
    semantics_map = {}
    for comp_name, code in SAMPLE_COMPONENTS.items():
        semantics_map[comp_name] = engine.analyze_component(code, {'name': comp_name})
    
    # Run demonstrations
    demonstrate_perception(engine)
    demonstrate_reasoning(engine, semantics_map)
    prediction = demonstrate_prediction(engine, semantics_map)
    demonstrate_learning(engine)
    demonstrate_governance(engine)
    
    print("\n" + "="*80)
    print("✨ DEMONSTRATION COMPLETE")
    print("="*80)
    print("\n🎓 The system has demonstrated:")
    print("  ✅ Understanding component semantics")
    print("  ✅ Inferring causal relationships")
    print("  ✅ Predicting emergent properties")
    print("  ✅ Learning from outcomes and improving predictions")
    print("  ✅ Applying HD governance gates")
    print("\n💡 The system is now SMARTER than when it started.")
    print("   Run this again to see continued learning!")
    
    return engine


if __name__ == '__main__':
    engine = main()
    
    # Save learning state
    print("\n💾 Learning state saved to:", engine.learning.storage_path)
    print("   Total observations recorded:", engine.learning.stats['total_observations'])
