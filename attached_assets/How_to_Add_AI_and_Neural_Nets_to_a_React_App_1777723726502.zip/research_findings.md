# Research Findings: AI Self-Builder with Neural Brain

## Phase 1: Research Summary

### 1. Isomorphic Reasoning & Graph Neural Networks
- **Graph Isomorphism Networks (GIN)**: Powerful GNNs that can detect structural equivalences between different graph structures
- **Use Case**: Identifying isomorphic relationships between code structures, architectural patterns, and concept graphs
- **Key Advantage**: GIN has same discriminative power as Weisfeiler-Lehman test for graph isomorphism detection
- **Application**: Can discover non-obvious connections between different code implementations that solve similar problems

### 2. Python Neural Brain Architecture
- **Framework**: PyTorch for flexibility and production-readiness
- **Embedding Strategy**: Use Sentence Transformers for semantic embeddings of code/concepts
- **Graph Representation**: Build knowledge graphs where nodes are concepts/code blocks, edges are relationships
- **Learning Mechanism**: Contrastive learning to identify isomorphic patterns across different domains

### 3. FastAPI + React Integration Pattern
- **Backend**: FastAPI with Uvicorn (async, high-performance)
- **CORS Setup**: Enable cross-origin requests from React frontend
- **API Structure**: RESTful endpoints for PDF upload, concept extraction, code generation
- **Deployment**: Separate backend (port 8000) and frontend (port 5173) during dev, unified in production

### 4. Key Technologies
- **FastAPI**: Modern Python web framework with built-in OpenAPI docs
- **PyTorch**: Deep learning framework for neural networks
- **Sentence Transformers**: Pre-trained models for semantic similarity
- **Graph Neural Networks**: For isomorphic pattern detection
- **React + Vite**: Fast frontend development with TypeScript

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    React Frontend                            │
│  (PDF Upload, Chat, Code Preview, Neural Dashboard)         │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTP/REST
┌────────────────────▼────────────────────────────────────────┐
│                  Express.js Server                           │
│  (tRPC, Auth, File Upload, LLM Integration)                 │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTP/REST
┌────────────────────▼────────────────────────────────────────┐
│              FastAPI Neural Brain Microservice               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ PyTorch Neural Network (Isomorphic Reasoning)        │   │
│  │ - Graph Isomorphism Networks (GIN)                   │   │
│  │ - Sentence Transformers for embeddings              │   │
│  │ - Contrastive learning for pattern discovery        │   │
│  └──────────────────────────────────────────────────────┘   │
└────────────────────┬────────────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        │                         │
┌───────▼────────┐      ┌────────▼──────────┐
│  MySQL Database│      │  Vector Store     │
│  (Knowledge    │      │  (Embeddings &    │
│   Base)        │      │   Similarity)     │
└────────────────┘      └───────────────────┘
```

## Implementation Strategy

### Phase 2: Architecture Design
- Define tRPC procedures for PDF upload, concept extraction, code generation
- Design neural brain API endpoints for training, inference, pattern discovery
- Plan knowledge graph schema (concepts, code blocks, relationships)
- Design embedding strategy for semantic similarity

### Phase 3: React Frontend
- PDF upload component with drag-and-drop
- Chat interface with message history
- Code preview with syntax highlighting
- Neural dashboard with training metrics and knowledge graph visualization

### Phase 4: Python Neural Brain
- FastAPI server with endpoints for training and inference
- PyTorch models for isomorphic pattern detection
- Sentence Transformers for semantic embeddings
- Graph Neural Networks for structural pattern discovery

### Phase 5: Integration
- Connect frontend to neural brain via REST API
- Implement LLM-driven code generation informed by neural patterns
- Persist learned patterns in database
- Implement adaptive suggestion engine

### Phase 6: Polish & Visualization
- Elegant UI with refined styling
- Real-time training progress visualization
- Knowledge graph visualization
- Concept clustering visualization

## Key Design Decisions

1. **Separate Microservices**: FastAPI neural brain runs independently, allowing scalability and specialized optimization
2. **Embedding-First**: All concepts and code are converted to embeddings for semantic similarity
3. **Graph-Based Knowledge**: Relationships between concepts stored as graph edges for isomorphic reasoning
4. **Contrastive Learning**: Train neural network to identify similar patterns across different domains
5. **LLM + Neural Hybrid**: LLM provides reasoning, neural brain provides learned pattern associations
