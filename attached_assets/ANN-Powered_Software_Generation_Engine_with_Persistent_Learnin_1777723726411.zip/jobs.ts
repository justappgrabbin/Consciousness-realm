import {
  analyzeCodeForLearning,
  extractRecipeFromProject,
  ArchitecturePlan,
} from "./karen";
import {
  getQueuedJobs,
  updateJobStatus,
  getProjectInputs,
  updateProjectInput,
  createSuggestion,
  createRecipe,
  getProjectById,
} from "./db";
import type { BackgroundJob } from "../drizzle/schema";

let isProcessing = false;
let jobInterval: ReturnType<typeof setInterval> | null = null;

// ─── Job Processor ────────────────────────────────────────────────────────────
async function processJob(job: BackgroundJob): Promise<void> {
  await updateJobStatus(job.id, "running");

  try {
    switch (job.jobType) {
      case "analyze_input": {
        await processAnalyzeInput(job);
        break;
      }
      case "refine_embeddings": {
        await processRefineEmbeddings(job);
        break;
      }
      case "detect_gaps": {
        await processDetectGaps(job);
        break;
      }
      case "generate_recipe": {
        await processGenerateRecipe(job);
        break;
      }
      case "process_document": {
        await processDocument(job);
        break;
      }
      default: {
        await updateJobStatus(job.id, "skipped", { reason: "Unknown job type" });
        return;
      }
    }

    await updateJobStatus(job.id, "done", { processedAt: new Date().toISOString() });
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error(`[Jobs] Job ${job.id} (${job.jobType}) failed:`, msg);
    await updateJobStatus(job.id, "failed", undefined, msg);
  }
}

async function processAnalyzeInput(job: BackgroundJob): Promise<void> {
  if (!job.inputId || !job.projectId) return;

  const inputs = await getProjectInputs(job.projectId);
  const input = inputs.find((i) => i.id === job.inputId);
  if (!input || !input.content) return;

  await updateProjectInput(input.id, { embeddingStatus: "processing" });

  const projectContext = `Project ID: ${job.projectId}`;
  const insight = await analyzeCodeForLearning(
    input.content,
    input.filename ?? "unknown",
    projectContext
  );

  await updateProjectInput(input.id, {
    analysisResult: insight as any,
    embeddingStatus: "done",
  });

  // Queue improvement suggestions
  for (const improvement of insight.improvements) {
    if (!job.userId || !job.projectId) continue;
    await createSuggestion({
      projectId: job.projectId,
      userId: job.userId,
      suggestionType: improvement.type as any,
      title: improvement.title,
      description: improvement.description,
      priority: improvement.priority,
      sourceJobId: job.id,
    });
  }
}

async function processRefineEmbeddings(job: BackgroundJob): Promise<void> {
  if (!job.projectId) return;
  const inputs = await getProjectInputs(job.projectId);
  const pendingInputs = inputs.filter((i) => i.embeddingStatus === "pending");

  for (const input of pendingInputs.slice(0, 3)) {
    if (!input.content) continue;
    await updateProjectInput(input.id, { embeddingStatus: "processing" });
    try {
      const insight = await analyzeCodeForLearning(
        input.content,
        input.filename ?? "unknown",
        `Project ${job.projectId}`
      );
      await updateProjectInput(input.id, {
        analysisResult: insight as any,
        embeddingStatus: "done",
      });
    } catch {
      await updateProjectInput(input.id, { embeddingStatus: "failed" });
    }
  }
}

async function processDetectGaps(job: BackgroundJob): Promise<void> {
  if (!job.projectId || !job.userId) return;
  const inputs = await getProjectInputs(job.projectId);
  const analyzedInputs = inputs.filter((i) => i.analysisResult && i.embeddingStatus === "done");

  if (analyzedInputs.length === 0) return;

  const allGaps = analyzedInputs.flatMap((i) => {
    const result = i.analysisResult as any;
    return result?.gaps ?? [];
  });

  const uniqueGaps = Array.from(new Set(allGaps as string[]));

  for (const gap of uniqueGaps.slice(0, 5)) {
    await createSuggestion({
      projectId: job.projectId,
      userId: job.userId,
      suggestionType: "missing_feature",
      title: `Gap Detected: ${gap.slice(0, 100)}`,
      description: gap,
      priority: "medium",
      sourceJobId: job.id,
    });
  }
}

async function processGenerateRecipe(job: BackgroundJob): Promise<void> {
  if (!job.projectId || !job.userId) return;

  const payload = job.payload as any;
  if (!payload?.architecturePlan || !payload?.analysis) return;

  const recipe = await extractRecipeFromProject(
    payload.projectName ?? "Unknown Project",
    payload.architecturePlan as ArchitecturePlan,
    payload.analysis
  );

  await createRecipe({
    userId: job.userId,
    name: recipe.name,
    description: recipe.description,
    category: recipe.category,
    pattern: recipe.pattern as any,
    techStack: recipe.techStack as any,
    sourceProjectId: job.projectId,
    isPublic: false,
  });
}

async function processDocument(job: BackgroundJob): Promise<void> {
  if (!job.inputId || !job.projectId || !job.userId) return;

  const inputs = await getProjectInputs(job.projectId);
  const input = inputs.find((i) => i.id === job.inputId);
  if (!input || !input.content) return;

  await updateProjectInput(input.id, { embeddingStatus: "processing" });

  const insight = await analyzeCodeForLearning(
    input.content,
    input.filename ?? "document",
    `Project ${job.projectId}`
  );

  await updateProjectInput(input.id, {
    analysisResult: insight as any,
    embeddingStatus: "done",
  });
}

// ─── Job Runner ───────────────────────────────────────────────────────────────
async function runJobCycle(): Promise<void> {
  if (isProcessing) return;
  isProcessing = true;

  try {
    const jobs = await getQueuedJobs(3);
    for (const job of jobs) {
      await processJob(job);
    }
  } catch (error) {
    console.error("[Jobs] Job cycle error:", error);
  } finally {
    isProcessing = false;
  }
}

// ─── Start/Stop ───────────────────────────────────────────────────────────────
export function startJobProcessor(): void {
  if (jobInterval) return;
  console.log("[Jobs] Karen's background learning loop activated. She never sleeps.");
  jobInterval = setInterval(runJobCycle, 30_000); // Run every 30 seconds
  // Run immediately on start
  runJobCycle().catch(console.error);
}

export function stopJobProcessor(): void {
  if (jobInterval) {
    clearInterval(jobInterval);
    jobInterval = null;
    console.log("[Jobs] Background processor stopped.");
  }
}
