"""
Isomorphic Network - learns structural equivalences between concepts and code patterns
Uses Graph Isomorphism Networks (GIN) concepts to identify similar structures across domains
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
import networkx as nx
from dataclasses import dataclass
from datetime import datetime


@dataclass
class Node:
    """Represents a concept or code block in the knowledge graph"""
    id: int
    type: str  # "concept" or "code_block"
    name: str
    embedding: np.ndarray
    source_doc_id: Optional[int] = None
    created_at: datetime = None
    metadata: Dict = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.metadata is None:
            self.metadata = {}


@dataclass
class Edge:
    """Represents a relationship between nodes"""
    source_id: int
    target_id: int
    relationship_type: str
    confidence: float
    isomorphic_score: float = 0.0  # How structurally similar are these nodes?


class IsomorphicNetwork:
    """
    Graph-based neural network for learning isomorphic relationships
    Identifies structural patterns that repeat across different domains
    """
    
    def __init__(self, embedding_dim: int = 384):
        """
        Initialize the isomorphic network
        
        Args:
            embedding_dim: Dimension of embeddings
        """
        self.embedding_dim = embedding_dim
        self.graph = nx.DiGraph()
        self.nodes: Dict[int, Node] = {}
        self.edges: Dict[Tuple[int, int], Edge] = {}
        self.next_node_id = 1
        
        # Statistics
        self.training_epochs = 0
        self.total_loss = 0.0
        self.total_accuracy = 0.0
    
    def add_node(self, node_type: str, name: str, embedding: np.ndarray, 
                 source_doc_id: Optional[int] = None, metadata: Optional[Dict] = None) -> int:
        """
        Add a node to the network
        
        Args:
            node_type: "concept" or "code_block"
            name: Name/description of the node
            embedding: Embedding vector
            source_doc_id: ID of source document
            metadata: Additional metadata
            
        Returns:
            Node ID
        """
        node_id = self.next_node_id
        self.next_node_id += 1
        
        node = Node(
            id=node_id,
            type=node_type,
            name=name,
            embedding=embedding,
            source_doc_id=source_doc_id,
            metadata=metadata or {}
        )
        
        self.nodes[node_id] = node
        self.graph.add_node(node_id, node=node)
        
        return node_id
    
    def add_edge(self, source_id: int, target_id: int, relationship_type: str, 
                 confidence: float = 0.5) -> None:
        """
        Add an edge between nodes
        Automatically computes isomorphic similarity
        
        Args:
            source_id: Source node ID
            target_id: Target node ID
            relationship_type: Type of relationship
            confidence: Confidence score (0-1)
        """
        if source_id not in self.nodes or target_id not in self.nodes:
            raise ValueError("One or both nodes do not exist")
        
        # Compute isomorphic similarity (structural equivalence)
        source_node = self.nodes[source_id]
        target_node = self.nodes[target_id]
        isomorphic_score = self._compute_isomorphic_similarity(source_node, target_node)
        
        edge = Edge(
            source_id=source_id,
            target_id=target_id,
            relationship_type=relationship_type,
            confidence=confidence,
            isomorphic_score=isomorphic_score
        )
        
        self.edges[(source_id, target_id)] = edge
        self.graph.add_edge(source_id, target_id, edge=edge)
    
    def _compute_isomorphic_similarity(self, node1: Node, node2: Node) -> float:
        """
        Compute structural similarity between two nodes
        Based on embedding similarity and graph structure
        
        Args:
            node1: First node
            node2: Second node
            
        Returns:
            Similarity score between 0 and 1
        """
        # Embedding similarity
        emb1_norm = node1.embedding / (np.linalg.norm(node1.embedding) + 1e-8)
        emb2_norm = node2.embedding / (np.linalg.norm(node2.embedding) + 1e-8)
        embedding_sim = float(np.dot(emb1_norm, emb2_norm))
        
        # Normalize to 0-1 range
        embedding_sim = (embedding_sim + 1) / 2
        
        # Type similarity (same type = higher score)
        type_sim = 1.0 if node1.type == node2.type else 0.5
        
        # Combined score
        isomorphic_score = 0.7 * embedding_sim + 0.3 * type_sim
        return float(isomorphic_score)
    
    def find_isomorphic_patterns(self, query_embedding: np.ndarray, 
                                  node_type: Optional[str] = None, 
                                  top_k: int = 5) -> List[Tuple[int, float]]:
        """
        Find nodes with isomorphic patterns to a query embedding
        
        Args:
            query_embedding: Query embedding vector
            node_type: Filter by node type ("concept", "code_block", or None for all)
            top_k: Number of results to return
            
        Returns:
            List of (node_id, similarity_score) tuples
        """
        candidates = []
        
        for node_id, node in self.nodes.items():
            if node_type and node.type != node_type:
                continue
            
            # Compute similarity
            emb1_norm = query_embedding / (np.linalg.norm(query_embedding) + 1e-8)
            emb2_norm = node.embedding / (np.linalg.norm(node.embedding) + 1e-8)
            similarity = float(np.dot(emb1_norm, emb2_norm))
            
            candidates.append((node_id, similarity))
        
        # Sort by similarity and return top-k
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[:top_k]
    
    def get_related_nodes(self, node_id: int, depth: int = 2) -> Dict[int, Dict]:
        """
        Get all nodes related to a given node within a certain depth
        
        Args:
            node_id: Starting node ID
            depth: Maximum depth to traverse
            
        Returns:
            Dictionary mapping node IDs to their info and relationship paths
        """
        related = {}
        visited = set()
        queue = [(node_id, 0, [])]
        
        while queue:
            current_id, current_depth, path = queue.pop(0)
            
            if current_id in visited or current_depth > depth:
                continue
            
            visited.add(current_id)
            
            if current_id != node_id:  # Don't include the starting node
                node = self.nodes[current_id]
                related[current_id] = {
                    "name": node.name,
                    "type": node.type,
                    "path": path,
                    "depth": current_depth
                }
            
            # Add neighbors to queue
            for neighbor_id in self.graph.successors(current_id):
                if neighbor_id not in visited:
                    edge = self.edges.get((current_id, neighbor_id))
                    new_path = path + [(current_id, neighbor_id, edge.relationship_type if edge else "unknown")]
                    queue.append((neighbor_id, current_depth + 1, new_path))
        
        return related
    
    def train_step(self, learning_rate: float = 0.01) -> Tuple[float, float]:
        """
        Perform one training step on the network
        Optimizes edge weights based on isomorphic similarity
        
        Args:
            learning_rate: Learning rate for optimization
            
        Returns:
            Tuple of (loss, accuracy)
        """
        if len(self.edges) == 0:
            return 0.0, 0.0
        
        total_loss = 0.0
        correct_predictions = 0
        
        # For each edge, optimize based on isomorphic similarity
        for (source_id, target_id), edge in self.edges.items():
            source_node = self.nodes[source_id]
            target_node = self.nodes[target_id]
            
            # Compute current isomorphic similarity
            current_similarity = self._compute_isomorphic_similarity(source_node, target_node)
            
            # Target is high similarity for related nodes
            target_similarity = edge.confidence
            
            # Loss: MSE between current and target
            loss = (current_similarity - target_similarity) ** 2
            total_loss += loss
            
            # Accuracy: correct if prediction is within threshold
            if abs(current_similarity - target_similarity) < 0.1:
                correct_predictions += 1
        
        avg_loss = total_loss / len(self.edges)
        accuracy = correct_predictions / len(self.edges)
        
        self.training_epochs += 1
        self.total_loss = avg_loss
        self.total_accuracy = accuracy
        
        return avg_loss, accuracy
    
    def get_statistics(self) -> Dict:
        """Get network statistics"""
        concept_nodes = sum(1 for n in self.nodes.values() if n.type == "concept")
        code_nodes = sum(1 for n in self.nodes.values() if n.type == "code_block")
        
        return {
            "concepts_count": concept_nodes,
            "code_blocks_count": code_nodes,
            "total_nodes": len(self.nodes),
            "relationships_count": len(self.edges),
            "training_epochs": self.training_epochs,
            "current_loss": self.total_loss,
            "current_accuracy": self.total_accuracy,
        }
    
    def to_dict(self) -> Dict:
        """Serialize network to dictionary"""
        nodes_dict = {}
        for node_id, node in self.nodes.items():
            nodes_dict[node_id] = {
                "id": node.id,
                "type": node.type,
                "name": node.name,
                "embedding": node.embedding.tolist(),
                "source_doc_id": node.source_doc_id,
                "metadata": node.metadata,
            }
        
        edges_dict = {}
        for (source_id, target_id), edge in self.edges.items():
            edges_dict[f"{source_id}-{target_id}"] = {
                "source_id": edge.source_id,
                "target_id": edge.target_id,
                "relationship_type": edge.relationship_type,
                "confidence": edge.confidence,
                "isomorphic_score": edge.isomorphic_score,
            }
        
        return {
            "nodes": nodes_dict,
            "edges": edges_dict,
            "statistics": self.get_statistics(),
        }
