import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  float,
  boolean,
  json,
} from "drizzle-orm/mysql-core";

// ─── Users (auth) ──────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Simulation State ──────────────────────────────────────────────────────────
export const simulationState = mysqlTable("simulation_state", {
  id: int("id").autoincrement().primaryKey(),
  tick: int("tick").default(0).notNull(),
  worldDay: int("world_day").default(1).notNull(),
  worldHour: float("world_hour").default(8.0).notNull(), // 0-24
  paused: boolean("paused").default(false).notNull(),
  tickIntervalMs: int("tick_interval_ms").default(8000).notNull(),
  lastTickAt: timestamp("last_tick_at").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SimulationState = typeof simulationState.$inferSelect;

// ─── Districts ─────────────────────────────────────────────────────────────────
export const districts = mysqlTable("districts", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  description: text("description"),
  theme: varchar("theme", { length: 64 }).notNull().default("urban"), // urban, rural, industrial, academic, creative
  x: float("x").default(0).notNull(), // map position
  y: float("y").default(0).notNull(),
  population: int("population").default(0).notNull(),
  maxPopulation: int("max_population").default(20).notNull(),
  resourceLevel: float("resource_level").default(1.0).notNull(), // 0-1 scarcity factor
  socialNormStrictness: float("social_norm_strictness").default(0.5).notNull(), // 0-1
  rules: json("rules").$type<Record<string, unknown>>().default({}).notNull(),
  color: varchar("color", { length: 16 }).default("#6366f1").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type District = typeof districts.$inferSelect;
export type InsertDistrict = typeof districts.$inferInsert;

// ─── Agents ────────────────────────────────────────────────────────────────────
export const agents = mysqlTable("agents", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  avatarSeed: varchar("avatar_seed", { length: 64 }).notNull(), // for deterministic avatar generation
  age: int("age").default(25).notNull(),
  gender: mysqlEnum("gender", ["male", "female", "nonbinary"]).default("nonbinary").notNull(),
  job: varchar("job", { length: 128 }).notNull().default("Freelancer"),
  jobDescription: text("job_description"),
  districtId: int("district_id").notNull(),
  personality: json("personality").$type<{
    openness: number;       // 0-1
    conscientiousness: number;
    extraversion: number;
    agreeableness: number;
    neuroticism: number;
    traits: string[];       // e.g. ["curious", "ambitious", "empathetic"]
  }>().notNull(),
  backstory: text("backstory"),
  goals: json("goals").$type<string[]>().default([]).notNull(),
  currentActivity: varchar("current_activity", { length: 256 }).default("idle").notNull(),
  currentLocation: varchar("current_location", { length: 128 }).default("home").notNull(),
  isAlive: boolean("is_alive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = typeof agents.$inferInsert;

// ─── Agent Needs ───────────────────────────────────────────────────────────────
export const agentNeeds = mysqlTable("agent_needs", {
  id: int("id").autoincrement().primaryKey(),
  agentId: int("agent_id").notNull(),
  hunger: float("hunger").default(80).notNull(),    // 0-100, lower = more hungry
  energy: float("energy").default(80).notNull(),    // 0-100
  social: float("social").default(60).notNull(),    // 0-100
  fun: float("fun").default(60).notNull(),          // 0-100
  hygiene: float("hygiene").default(80).notNull(),  // 0-100
  comfort: float("comfort").default(70).notNull(),  // 0-100
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AgentNeeds = typeof agentNeeds.$inferSelect;

// ─── Agent Moods ───────────────────────────────────────────────────────────────
export const agentMoods = mysqlTable("agent_moods", {
  id: int("id").autoincrement().primaryKey(),
  agentId: int("agent_id").notNull(),
  mood: mysqlEnum("mood", [
    "ecstatic", "happy", "content", "neutral",
    "uncomfortable", "sad", "distressed", "furious"
  ]).default("content").notNull(),
  moodScore: float("mood_score").default(70).notNull(), // 0-100
  dominantEmotion: varchar("dominant_emotion", { length: 64 }).default("calm").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AgentMood = typeof agentMoods.$inferSelect;

// ─── Agent Memory Log ──────────────────────────────────────────────────────────
export const agentMemories = mysqlTable("agent_memories", {
  id: int("id").autoincrement().primaryKey(),
  agentId: int("agent_id").notNull(),
  tick: int("tick").notNull(),
  worldDay: int("world_day").notNull(),
  worldHour: float("world_hour").notNull(),
  type: mysqlEnum("type", [
    "inner_monologue", "event", "conversation", "decision", "task", "relationship"
  ]).notNull(),
  content: text("content").notNull(),
  importance: float("importance").default(0.5).notNull(), // 0-1
  relatedAgentId: int("related_agent_id"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AgentMemory = typeof agentMemories.$inferSelect;

// ─── Relationships ─────────────────────────────────────────────────────────────
export const relationships = mysqlTable("relationships", {
  id: int("id").autoincrement().primaryKey(),
  agentAId: int("agent_a_id").notNull(),
  agentBId: int("agent_b_id").notNull(),
  type: mysqlEnum("type", [
    "friend", "rival", "romantic", "colleague", "acquaintance", "family", "enemy"
  ]).default("acquaintance").notNull(),
  strength: float("strength").default(0.1).notNull(), // 0-1
  sentiment: float("sentiment").default(0.5).notNull(), // 0-1 (negative to positive)
  interactionCount: int("interaction_count").default(0).notNull(),
  lastInteractionTick: int("last_interaction_tick").default(0).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Relationship = typeof relationships.$inferSelect;

// ─── Tasks ─────────────────────────────────────────────────────────────────────
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  agentId: int("agent_id").notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", [
    "work", "errand", "social", "personal", "creative", "survival"
  ]).notNull(),
  status: mysqlEnum("status", [
    "pending", "in_progress", "completed", "failed", "abandoned"
  ]).default("pending").notNull(),
  priority: float("priority").default(0.5).notNull(), // 0-1
  progress: float("progress").default(0).notNull(), // 0-1
  startTick: int("start_tick"),
  completedTick: int("completed_tick"),
  dueDay: int("due_day"),
  reward: json("reward").$type<{ needs?: Partial<Record<string, number>>; relationships?: number }>().default({}).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;

// ─── Conversations ─────────────────────────────────────────────────────────────
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  agentAId: int("agent_a_id").notNull(),
  agentBId: int("agent_b_id").notNull(),
  tick: int("tick").notNull(),
  worldDay: int("world_day").notNull(),
  worldHour: float("world_hour").notNull(),
  messages: json("messages").$type<Array<{ role: "a" | "b"; text: string }>>().notNull(),
  summary: text("summary"),
  sentiment: float("sentiment").default(0.5).notNull(),
  location: varchar("location", { length: 128 }).default("public_space").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;

// ─── Activity Feed ─────────────────────────────────────────────────────────────
export const activityFeed = mysqlTable("activity_feed", {
  id: int("id").autoincrement().primaryKey(),
  tick: int("tick").notNull(),
  worldDay: int("world_day").notNull(),
  worldHour: float("world_hour").notNull(),
  agentId: int("agent_id"),
  districtId: int("district_id"),
  type: mysqlEnum("type", [
    "lifecycle", "social", "task", "world_event", "relationship", "mood", "migration"
  ]).notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  content: text("content").notNull(),
  emoji: varchar("emoji", { length: 8 }).default("✨").notNull(),
  importance: float("importance").default(0.5).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ActivityFeedItem = typeof activityFeed.$inferSelect;

// ─── World Events ──────────────────────────────────────────────────────────────
export const worldEvents = mysqlTable("world_events", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 256 }).notNull(),
  description: text("description").notNull(),
  type: mysqlEnum("type", [
    "natural", "social", "economic", "political", "cultural", "injected"
  ]).notNull(),
  districtId: int("district_id"), // null = world-wide
  affectedAgentIds: json("affected_agent_ids").$type<number[]>().default([]).notNull(),
  effects: json("effects").$type<{
    resourceDelta?: number;
    moodDelta?: number;
    needsDeltas?: Partial<Record<string, number>>;
    socialNormDelta?: number;
  }>().default({}).notNull(),
  tick: int("tick").notNull(),
  worldDay: int("world_day").notNull(),
  resolved: boolean("resolved").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WorldEvent = typeof worldEvents.$inferSelect;
