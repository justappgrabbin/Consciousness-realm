import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation, useParams } from "wouter";
import { ArrowLeft, Lightbulb, CheckCircle, X, Clock, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function Suggestions() {
  const { isAuthenticated } = useAuth();
  const params = useParams<{ id: string }>();
  const projectId = parseInt(params.id ?? "0");
  const [, navigate] = useLocation();

  const { data: project } = trpc.projects.get.useQuery(
    { id: projectId },
    { enabled: isAuthenticated && !!projectId }
  );
  const { data: suggestions, isLoading } = trpc.suggestions.list.useQuery(
    { projectId },
    { enabled: isAuthenticated && !!projectId }
  );

  const utils = trpc.useUtils();
  const updateStatus = trpc.suggestions.updateStatus.useMutation({
    onSuccess: () => {
      utils.suggestions.list.invalidate({ projectId });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const statusColor = (status: string) => {
    if (status === "accepted" || status === "applied") return "oklch(0.72 0.18 200)";
    if (status === "dismissed") return "oklch(0.45 0.04 255)";
    return "oklch(0.60 0.28 350)";
  };

  const statusBg = (status: string) => {
    if (status === "accepted" || status === "applied") return "oklch(0.72 0.18 200 / 0.1)";
    if (status === "dismissed") return "oklch(0.16 0.02 255)";
    return "oklch(0.60 0.28 350 / 0.1)";
  };

  const priorityColor = (priority: string) => {
    if (priority === "critical") return "oklch(0.58 0.22 25)";
    if (priority === "high") return "oklch(0.60 0.28 350)";
    if (priority === "medium") return "oklch(0.72 0.18 200)";
    return "oklch(0.55 0.22 255)";
  };

  return (
    <div className="min-h-screen" style={{ background: "oklch(0.09 0.02 255)" }}>
      {/* Header */}
      <div className="sticky top-0 z-10 px-8 py-4 flex items-center gap-4"
        style={{ background: "oklch(0.09 0.02 255 / 0.95)", borderBottom: "1px solid oklch(0.22 0.04 255)", backdropFilter: "blur(12px)" }}>
        <button onClick={() => navigate(`/projects/${projectId}`)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-4 w-4" /> Back to Project
        </button>
        <div className="h-4 w-px" style={{ background: "oklch(0.22 0.04 255)" }} />
        <div className="flex items-center gap-2">
          <Lightbulb className="h-4 w-4" style={{ color: "oklch(0.72 0.18 200)" }} />
          <span className="text-sm font-medium">Improvement Suggestions</span>
        </div>
        {project && (
          <>
            <div className="h-4 w-px" style={{ background: "oklch(0.22 0.04 255)" }} />
            <span className="text-sm text-muted-foreground">{project.name}</span>
          </>
        )}
      </div>

      <div className="max-w-4xl mx-auto px-8 py-8">
        {/* Intro */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">Improvement Suggestions</h1>
          <p className="text-sm text-muted-foreground">
            Karen's background learning loop continuously analyzes your codebase and generates
            targeted improvement suggestions — architectural gaps, missing patterns, optimization opportunities.
          </p>
          <div className="mt-3 p-3 rounded-lg inline-block" style={{ background: "oklch(0.60 0.28 350 / 0.05)", border: "1px solid oklch(0.60 0.28 350 / 0.2)" }}>
            <p className="text-xs font-mono" style={{ color: "oklch(0.60 0.28 350)" }}>
              K:// I found these while you were away. You're welcome.
            </p>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-28 rounded animate-pulse" style={{ background: "oklch(0.11 0.025 255)" }} />
            ))}
          </div>
        ) : suggestions?.length === 0 ? (
          <div className="text-center py-16 rounded-lg" style={{ background: "oklch(0.11 0.025 255)", border: "1px solid oklch(0.22 0.04 255)" }}>
            <Lightbulb className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
            <p className="text-sm text-muted-foreground mb-1">No suggestions yet</p>
            <p className="text-xs italic" style={{ color: "oklch(0.72 0.18 200)" }}>
              K:// I'm still analyzing. Check back after I've had time to study your code.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              {(["pending", "accepted", "dismissed"] as const).map((status) => {
                const count = suggestions?.filter((s) => s.status === status).length ?? 0;
                return (
                  <div key={status} className="p-4 rounded-lg text-center"
                    style={{ background: "oklch(0.11 0.025 255)", border: `1px solid ${statusColor(status)} / 0.2` }}>
                    <p className="text-2xl font-bold" style={{ color: statusColor(status) }}>{count}</p>
                    <p className="text-xs text-muted-foreground capitalize mt-1">{status}</p>
                  </div>
                );
              })}
            </div>

            {/* Suggestions List */}
            {suggestions?.map((suggestion) => (
              <div key={suggestion.id} className="p-5 rounded-lg"
                style={{ background: statusBg(suggestion.status), border: `1px solid ${statusColor(suggestion.status)} / 0.2` }}>
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-0.5 rounded font-mono"
                      style={{ background: `${priorityColor(suggestion.priority)} / 0.1`, color: priorityColor(suggestion.priority), border: `1px solid ${priorityColor(suggestion.priority)} / 0.3` }}>
                      {suggestion.priority}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded"
                      style={{ background: "oklch(0.55 0.22 255 / 0.1)", color: "oklch(0.70 0.22 255)", border: "1px solid oklch(0.55 0.22 255 / 0.3)" }}>
                      {suggestion.suggestionType}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {suggestion.status === "pending" && (
                      <>
                        <Button size="sm" variant="outline" onClick={() => updateStatus.mutate({ id: suggestion.id, status: "accepted" })}
                          disabled={updateStatus.isPending}
                          style={{ borderColor: "oklch(0.72 0.18 200 / 0.4)", color: "oklch(0.72 0.18 200)", height: "28px", fontSize: "11px" }}>
                          {updateStatus.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <CheckCircle className="h-3 w-3 mr-1" />}
                          Accept
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => updateStatus.mutate({ id: suggestion.id, status: "dismissed" })}
                          disabled={updateStatus.isPending}
                          style={{ borderColor: "oklch(0.45 0.04 255)", color: "oklch(0.55 0.04 255)", height: "28px", fontSize: "11px" }}>
                          <X className="h-3 w-3 mr-1" /> Dismiss
                        </Button>
                      </>
                    )}
                    {suggestion.status !== "pending" && (
                      <span className="text-xs px-2 py-1 rounded capitalize"
                        style={{ background: statusBg(suggestion.status), color: statusColor(suggestion.status), border: `1px solid ${statusColor(suggestion.status)} / 0.3` }}>
                        {suggestion.status}
                      </span>
                    )}
                  </div>
                </div>

                <h3 className="text-sm font-medium mb-2">{suggestion.title}</h3>
                <p className="text-xs text-muted-foreground mb-3">{suggestion.description}</p>

                {(suggestion as any).affectedFiles && Array.isArray((suggestion as any).affectedFiles) && (suggestion as any).affectedFiles.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {((suggestion as any).affectedFiles as string[]).map((file: string, i: number) => (
                      <span key={i} className="text-xs px-2 py-0.5 rounded font-mono"
                        style={{ background: "oklch(0.08 0.02 255)", color: "oklch(0.82 0.06 200)", border: "1px solid oklch(0.18 0.03 255)" }}>
                        {file}
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span>Discovered {new Date(suggestion.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
