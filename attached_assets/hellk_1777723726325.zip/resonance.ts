/**
 * YOU-N-I-VERSE Resonance Network Constants and Types
 */

// Human Design Gate Information (64 Gates from I Ching)
export const GATE_INFO: Record<number, {
  name: string;
  theme: string;
  biological: string;
  center: string;
  circuit: string;
  geneKey?: { shadow: string; gift: string; siddhi: string };
}> = {
  1: { name: "Self-Expression", theme: "Creative", biological: "Thymus", center: "G", circuit: "Individual", geneKey: { shadow: "Entropy", gift: "Freshness", siddhi: "Beauty" } },
  2: { name: "The Receptive", theme: "Direction of Self", biological: "Liver", center: "G", circuit: "Collective", geneKey: { shadow: "Dislocation", gift: "Orientation", siddhi: "Unity" } },
  3: { name: "Ordering", theme: "Innovation", biological: "Sacral", center: "Sacral", circuit: "Individual", geneKey: { shadow: "Chaos", gift: "Innovation", siddhi: "Innocence" } },
  4: { name: "Formulization", theme: "Mental Answers", biological: "Neocortex", center: "Ajna", circuit: "Collective", geneKey: { shadow: "Intolerance", gift: "Understanding", siddhi: "Forgiveness" } },
  5: { name: "Fixed Rhythms", theme: "Waiting", biological: "Sacral", center: "Sacral", circuit: "Collective", geneKey: { shadow: "Impatience", gift: "Patience", siddhi: "Timelessness" } },
  6: { name: "Friction", theme: "Emotional Clarity", biological: "Solar Plexus", center: "Solar Plexus", circuit: "Collective", geneKey: { shadow: "Conflict", gift: "Diplomacy", siddhi: "Peace" } },
  7: { name: "The Army", theme: "Self in Interaction", biological: "Thymus", center: "G", circuit: "Collective", geneKey: { shadow: "Division", gift: "Guidance", siddhi: "Virtue" } },
  8: { name: "Contribution", theme: "Creative Contribution", biological: "Thyroid", center: "Throat", circuit: "Individual", geneKey: { shadow: "Mediocrity", gift: "Style", siddhi: "Exquisiteness" } },
  9: { name: "Focus", theme: "Determination", biological: "Sacral", center: "Sacral", circuit: "Collective", geneKey: { shadow: "Inertia", gift: "Determination", siddhi: "Invincibility" } },
  10: { name: "Treading", theme: "Behavior of Self", biological: "Thymus", center: "G", circuit: "Individual", geneKey: { shadow: "Self-Obsession", gift: "Naturalness", siddhi: "Being" } },
};

// Add more gates as needed (truncated for brevity)
for (let i = 11; i <= 64; i++) {
  GATE_INFO[i] = {
    name: `Gate ${i}`,
    theme: `Theme ${i}`,
    biological: `System ${i}`,
    center: "G",
    circuit: "Individual"
  };
}

// Human Design Types
export const HD_TYPES = {
  Generator: {
    strategy: "Wait to Respond",
    signature: "Satisfaction",
    notSelf: "Frustration",
    description: "Builders of the world with sustainable life force energy"
  },
  "Manifesting Generator": {
    strategy: "Wait to Respond, then Inform",
    signature: "Satisfaction",
    notSelf: "Frustration & Anger",
    description: "Multi-passionate builders who skip steps efficiently"
  },
  Projector: {
    strategy: "Wait for Invitation",
    signature: "Success",
    notSelf: "Bitterness",
    description: "Guides who see others deeply and direct energy"
  },
  Manifestor: {
    strategy: "Inform before Acting",
    signature: "Peace",
    notSelf: "Anger",
    description: "Initiators who impact and catalyze change"
  },
  Reflector: {
    strategy: "Wait a Lunar Cycle",
    signature: "Surprise",
    notSelf: "Disappointment",
    description: "Mirrors of community health and wisdom"
  }
};

// Quest Stage Definitions
export const QUEST_STAGES = {
  intention: {
    name: "Intention Quest",
    description: "Declare your purpose and align it with your Incarnation Cross",
    requirements: "Clarity of purpose + Cross alignment",
    resonanceWeight: 0.3
  },
  skill: {
    name: "Skill Quest",
    description: "Demonstrate your capability through your gate expression",
    requirements: "Capability validation + Gate alignment",
    resonanceWeight: 0.35
  },
  commitment: {
    name: "Commitment Quest",
    description: "Prove your strategy practice through consistent action",
    requirements: "Strategy adherence + Consistent practice",
    resonanceWeight: 0.35
  }
};

// Coherence Thresholds
export const COHERENCE_THRESHOLDS = {
  low: { min: 0, max: 49, label: "Misaligned", color: "#ff3e3e" },
  moderate: { min: 50, max: 74, label: "Adjusting", color: "#ffaa00" },
  high: { min: 75, max: 89, label: "Aligned", color: "#00bcff" },
  optimal: { min: 90, max: 100, label: "Coherent", color: "#00ff88" }
};

// Network Health Thresholds for Owner Notifications
export const NOTIFICATION_THRESHOLDS = {
  coherenceAlert: 90,
  questCompletion: true,
  economicMilestone: true,
  networkGrowth: 100
};

// Trinity Field Calculation Types
export interface TrinityFields {
  body: { gate: number; line: number; degree: number };
  mind: { gate: number; line: number; degree: number };
  heart: { gate: number; line: number; degree: number };
}

export interface ResonanceSignature {
  graphAddress: string;
  trinityFields: TrinityFields;
  hdType: keyof typeof HD_TYPES;
  hdAuthority: string;
  frequencyVector: [number, number, number];
}
