/**
 * PDF Parser
 * Extracts text and metadata from PDF files
 */

import { invokeLLM } from "./_core/llm";

interface PDFContent {
  text: string;
  metadata: {
    title?: string;
    author?: string;
    subject?: string;
    keywords?: string[];
    pageCount?: number;
  };
}

interface ExtractedKnowledge {
  concepts: Array<{
    name: string;
    description: string;
    category: string;
  }>;
  codeBlocks: Array<{
    language: string;
    code: string;
    description: string;
    patternType: string;
  }>;
  relationships: Array<{
    source: string;
    target: string;
    type: string;
  }>;
}

/**
 * Parse PDF content using LLM-based extraction
 * Assumes the PDF text has already been extracted (e.g., by frontend)
 */
export async function parsePDFContent(
  pdfText: string,
  filename: string
): Promise<PDFContent> {
  // Basic metadata extraction from text
  const metadata = {
    title: filename.replace(/\.pdf$/, ""),
    pageCount: (pdfText.match(/\n/g) || []).length / 50, // Rough estimate
  };

  return {
    text: pdfText,
    metadata,
  };
}

/**
 * Extract knowledge from PDF content using LLM
 * Identifies concepts, code blocks, and relationships
 */
export async function extractKnowledgeFromPDF(
  pdfText: string
): Promise<ExtractedKnowledge> {
  try {
    // Use LLM to extract structured knowledge
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are an expert knowledge extractor. Analyze the provided text and extract:
1. Key concepts with descriptions and categories
2. Code blocks with language, code, description, and pattern type
3. Relationships between concepts

Return ONLY valid JSON in this exact format:
{
  "concepts": [
    {"name": "string", "description": "string", "category": "string"}
  ],
  "codeBlocks": [
    {"language": "string", "code": "string", "description": "string", "patternType": "string"}
  ],
  "relationships": [
    {"source": "string", "target": "string", "type": "string"}
  ]
}`,
        },
        {
          role: "user",
          content: `Extract knowledge from this text:\n\n${pdfText.substring(0, 4000)}`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "knowledge_extraction",
          strict: true,
          schema: {
            type: "object",
            properties: {
              concepts: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    name: { type: "string" },
                    description: { type: "string" },
                    category: { type: "string" },
                  },
                  required: ["name", "description", "category"],
                  additionalProperties: false,
                },
              },
              codeBlocks: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    language: { type: "string" },
                    code: { type: "string" },
                    description: { type: "string" },
                    patternType: { type: "string" },
                  },
                  required: ["language", "code", "description", "patternType"],
                  additionalProperties: false,
                },
              },
              relationships: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    source: { type: "string" },
                    target: { type: "string" },
                    type: { type: "string" },
                  },
                  required: ["source", "target", "type"],
                  additionalProperties: false,
                },
              },
            },
            required: ["concepts", "codeBlocks", "relationships"],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0]?.message.content;
    if (!content || typeof content !== "string") {
      throw new Error("No content in LLM response");
    }

    const extracted = JSON.parse(content) as ExtractedKnowledge;
    return extracted;
  } catch (error) {
    console.error("Failed to extract knowledge from PDF:", error);
    // Return empty knowledge structure on error
    return {
      concepts: [],
      codeBlocks: [],
      relationships: [],
    };
  }
}

/**
 * Generate code based on extracted knowledge and neural patterns
 */
export async function generateCodeFromKnowledge(
  prompt: string,
  concepts: string[],
  codePatterns: string[]
): Promise<string> {
  try {
    const contextStr = `
Available concepts: ${concepts.join(", ")}
Related code patterns: ${codePatterns.join(", ")}
`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are an expert React/TypeScript code generator. Generate clean, production-ready code.
Context: ${contextStr}`,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    const content = response.choices[0]?.message.content;
    const code = typeof content === "string" ? content : "";
    return code;
  } catch (error) {
    console.error("Failed to generate code:", error);
    throw error;
  }
}
