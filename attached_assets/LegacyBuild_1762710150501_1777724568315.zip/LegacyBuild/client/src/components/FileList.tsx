import { FileCode, FileText, BookOpen, Archive, File as FileIcon, X, Eye } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { File } from "@shared/schema";

interface FileListProps {
  files: File[];
  onRemoveFile?: (fileId: string) => void;
  onPreviewFile?: (file: File) => void;
}

const getFileIcon = (type: string) => {
  if (type.includes("javascript") || type.includes("typescript") || type.includes("python")) {
    return FileCode;
  }
  if (type.includes("pdf") || type.includes("epub")) {
    return BookOpen;
  }
  if (type.includes("zip")) {
    return Archive;
  }
  if (type.includes("text")) {
    return FileText;
  }
  return FileIcon;
};

const getStatusBadge = (status: string) => {
  const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
    pending: { variant: "secondary", label: "Pending" },
    processing: { variant: "default", label: "Processing" },
    completed: { variant: "outline", label: "Complete" },
    error: { variant: "destructive", label: "Error" },
    skipped: { variant: "secondary", label: "Skipped" },
  };
  
  const config = variants[status] || variants.pending;
  return <Badge variant={config.variant} data-testid={`badge-${status}`}>{config.label}</Badge>;
};

export function FileList({ files, onRemoveFile, onPreviewFile }: FileListProps) {
  const groupedFiles = files.reduce((acc, file) => {
    const category = file.type.split("/")[0] || "other";
    if (!acc[category]) acc[category] = [];
    acc[category].push(file);
    return acc;
  }, {} as Record<string, File[]>);

  if (files.length === 0) {
    return (
      <Card className="p-12 text-center">
        <div className="flex flex-col items-center gap-4 text-muted-foreground">
          <FileIcon className="w-12 h-12" />
          <div>
            <h3 className="text-lg font-semibold mb-1">No files uploaded yet</h3>
            <p className="text-sm">Upload your first file to begin</p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-4">
      <h3 className="text-base font-semibold mb-3">Uploaded Files ({files.length})</h3>
      
      <ScrollArea className="max-h-[400px] pr-4">
        <div className="space-y-4">
          {Object.entries(groupedFiles).map(([category, categoryFiles]) => (
            <div key={category}>
              <h4 className="text-sm font-medium text-muted-foreground mb-2 capitalize">{category}</h4>
              <div className="space-y-2">
                {categoryFiles.map((file) => {
                  const Icon = getFileIcon(file.type);
                  return (
                    <div
                      key={file.id}
                      className="flex items-center gap-3 p-2.5 rounded-md border bg-card hover-elevate"
                      data-testid={`file-item-${file.id}`}
                    >
                      <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                        <Icon className="w-4 h-4 text-muted-foreground" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate text-sm">{file.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {(file.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                      
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {getStatusBadge(file.status)}
                        
                        {onPreviewFile && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => onPreviewFile(file)}
                            data-testid={`button-preview-${file.id}`}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        )}
                        
                        {onRemoveFile && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => onRemoveFile(file.id)}
                            data-testid={`button-remove-${file.id}`}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </Card>
  );
}
