# AppBuilder Studio — No-Build Self‑Builder
This project contains a single-file studio that runs entirely in your browser.
- Open `appbuilder-studio.html` on your phone or desktop.
- Edit the JSON on the left. The preview rebuilds itself automatically.
- Use **Export Snapshot** to generate a standalone app (no editor).
- Use **Download Project Zip** to export the current studio + snapshot from the browser.

## Zero bash, zero installs
- React + Tailwind are loaded from CDNs in the HTML.
- Works in Chrome, Edge, Safari, and most Android browsers.

## Files
- `appbuilder-studio.html` — the studio.