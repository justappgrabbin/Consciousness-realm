/**
 * World Seeder
 * Populates the initial world with districts, agents, and simulation state
 */

import {
  getAllDistricts, getAllAgents, getSimulationState, upsertSimulationState,
  createDistrict, createAgent, upsertAgentNeeds, upsertAgentMood,
  createTask, updateDistrictPopulation,
} from "./db";
import type { InsertDistrict } from "../drizzle/schema";

const DISTRICTS: Omit<InsertDistrict, 'id' | 'createdAt' | 'updatedAt'>[] = [
  {
    name: "Lumina Heights",
    description: "A gleaming urban district of tech workers, artists, and ambitious dreamers. High energy, high expectations.",
    theme: "urban",
    x: 30, y: 25,
    population: 0, maxPopulation: 15,
    resourceLevel: 0.9,
    socialNormStrictness: 0.4,
    rules: { workHours: "9-18", noiseOrdinance: false },
    color: "#6366f1",
  },
  {
    name: "The Verdant",
    description: "A peaceful green district where academics, healers, and philosophers live in harmony with nature.",
    theme: "academic",
    x: 65, y: 20,
    population: 0, maxPopulation: 12,
    resourceLevel: 0.85,
    socialNormStrictness: 0.6,
    rules: { workHours: "8-17", quietHours: "22-7" },
    color: "#10b981",
  },
  {
    name: "Irongate",
    description: "A gritty industrial district of engineers, mechanics, and laborers. Hard work, strong bonds.",
    theme: "industrial",
    x: 20, y: 60,
    population: 0, maxPopulation: 14,
    resourceLevel: 0.7,
    socialNormStrictness: 0.5,
    rules: { workHours: "6-16", heavyMachinery: true },
    color: "#f59e0b",
  },
  {
    name: "Neon Bazaar",
    description: "A vibrant creative district of artists, musicians, traders, and night owls. Rules are suggestions here.",
    theme: "creative",
    x: 70, y: 65,
    population: 0, maxPopulation: 16,
    resourceLevel: 0.75,
    socialNormStrictness: 0.2,
    rules: { noiseOrdinance: false, openLate: true },
    color: "#ec4899",
  },
  {
    name: "The Commons",
    description: "A central mixed district where all walks of life intersect. The social heart of the world.",
    theme: "urban",
    x: 45, y: 45,
    population: 0, maxPopulation: 18,
    resourceLevel: 0.95,
    socialNormStrictness: 0.45,
    rules: { publicGatherings: true, marketDays: "weekends" },
    color: "#8b5cf6",
  },
];

const AGENT_TEMPLATES = [
  // Lumina Heights
  { name: "Aria Chen", age: 28, gender: "female" as const, job: "Software Engineer", districtIdx: 0, traits: ["analytical", "ambitious", "introverted"], backstory: "Moved to Lumina Heights chasing a dream of building something meaningful. Codes by day, reads philosophy by night.", goals: ["ship a major product", "find work-life balance"], openness: 0.7, conscientiousness: 0.85, extraversion: 0.3, agreeableness: 0.65, neuroticism: 0.5 },
  { name: "Marcus Webb", age: 34, gender: "male" as const, job: "Product Designer", districtIdx: 0, traits: ["creative", "empathetic", "perfectionist"], backstory: "Former architect who pivoted to digital design. Believes beauty and function are inseparable.", goals: ["design an iconic product", "mentor young designers"], openness: 0.9, conscientiousness: 0.75, extraversion: 0.6, agreeableness: 0.8, neuroticism: 0.4 },
  { name: "Zoe Park", age: 25, gender: "female" as const, job: "Data Scientist", districtIdx: 0, traits: ["curious", "methodical", "witty"], backstory: "Obsessed with patterns in everything — data, people, cities. Sees the world as one giant dataset.", goals: ["publish research", "learn to cook"], openness: 0.8, conscientiousness: 0.9, extraversion: 0.4, agreeableness: 0.7, neuroticism: 0.35 },

  // The Verdant
  { name: "Dr. Elias Voss", age: 52, gender: "male" as const, job: "Philosopher", districtIdx: 1, traits: ["wise", "contemplative", "kind"], backstory: "Spent decades in academia before retreating to The Verdant to write his magnum opus on consciousness.", goals: ["finish the book", "find inner peace"], openness: 0.95, conscientiousness: 0.6, extraversion: 0.35, agreeableness: 0.9, neuroticism: 0.25 },
  { name: "Nadia Osei", age: 31, gender: "female" as const, job: "Botanist", districtIdx: 1, traits: ["patient", "nurturing", "observant"], backstory: "Grew up in a farming community. Studies how plants communicate. Believes in slow, deliberate living.", goals: ["discover a new plant species", "build a community garden"], openness: 0.75, conscientiousness: 0.8, extraversion: 0.45, agreeableness: 0.95, neuroticism: 0.2 },
  { name: "Leo Tanaka", age: 22, gender: "male" as const, job: "Graduate Student", districtIdx: 1, traits: ["eager", "anxious", "idealistic"], backstory: "Brilliant but overwhelmed by the weight of his own potential. Studying cognitive science.", goals: ["get his PhD", "overcome imposter syndrome"], openness: 0.85, conscientiousness: 0.7, extraversion: 0.5, agreeableness: 0.75, neuroticism: 0.75 },

  // Irongate
  { name: "Remy Duval", age: 40, gender: "male" as const, job: "Mechanical Engineer", districtIdx: 2, traits: ["pragmatic", "loyal", "stubborn"], backstory: "Third-generation Irongate resident. Built half the infrastructure in this district with his own hands.", goals: ["modernize the district", "retire comfortably"], openness: 0.4, conscientiousness: 0.85, extraversion: 0.55, agreeableness: 0.6, neuroticism: 0.3 },
  { name: "Sasha Volkov", age: 29, gender: "nonbinary" as const, job: "Electrician", districtIdx: 2, traits: ["resourceful", "direct", "humorous"], backstory: "Came to Irongate for work and stayed for the community. Fixes things for free on weekends.", goals: ["start an apprenticeship program", "travel the world"], openness: 0.6, conscientiousness: 0.75, extraversion: 0.7, agreeableness: 0.7, neuroticism: 0.4 },

  // Neon Bazaar
  { name: "Vivienne Sol", age: 27, gender: "female" as const, job: "Musician", districtIdx: 3, traits: ["passionate", "spontaneous", "charismatic"], backstory: "Dropped out of conservatory to make music that actually moves people. Lives for the night.", goals: ["record an album", "fall in love"], openness: 0.95, conscientiousness: 0.3, extraversion: 0.9, agreeableness: 0.65, neuroticism: 0.6 },
  { name: "Cai Xu", age: 33, gender: "male" as const, job: "Street Artist", districtIdx: 3, traits: ["rebellious", "visionary", "solitary"], backstory: "Paints murals that tell the stories no one else will. Anonymous by choice, legendary by accident.", goals: ["create a permanent installation", "stay free"], openness: 0.98, conscientiousness: 0.25, extraversion: 0.35, agreeableness: 0.5, neuroticism: 0.55 },
  { name: "Priya Nair", age: 30, gender: "female" as const, job: "Chef", districtIdx: 3, traits: ["inventive", "warm", "competitive"], backstory: "Runs a late-night food stall that's become a Neon Bazaar institution. Food is her love language.", goals: ["open a proper restaurant", "win a culinary award"], openness: 0.8, conscientiousness: 0.7, extraversion: 0.8, agreeableness: 0.75, neuroticism: 0.45 },

  // The Commons
  { name: "Omar Hassan", age: 45, gender: "male" as const, job: "Community Organizer", districtIdx: 4, traits: ["diplomatic", "passionate", "tireless"], backstory: "Grew up in The Commons and dedicated his life to making it better. Knows everyone by name.", goals: ["build a community center", "bridge district divides"], openness: 0.7, conscientiousness: 0.8, extraversion: 0.85, agreeableness: 0.9, neuroticism: 0.35 },
  { name: "Iris Bloom", age: 38, gender: "female" as const, job: "Journalist", districtIdx: 4, traits: ["inquisitive", "tenacious", "skeptical"], backstory: "Has covered every major story in this world. Believes truth is the most radical act.", goals: ["break a world-changing story", "write a book"], openness: 0.8, conscientiousness: 0.75, extraversion: 0.65, agreeableness: 0.55, neuroticism: 0.5 },
  { name: "Felix Adler", age: 19, gender: "male" as const, job: "Barista", districtIdx: 4, traits: ["friendly", "dreamy", "restless"], backstory: "Just arrived in The Commons from a small town. Everything is new and overwhelming and wonderful.", goals: ["figure out what to do with his life", "make real friends"], openness: 0.85, conscientiousness: 0.45, extraversion: 0.75, agreeableness: 0.85, neuroticism: 0.6 },
];

export async function seedWorld(): Promise<{ seeded: boolean; message: string }> {
  // Check if already seeded
  const existingAgents = await getAllAgents();
  if (existingAgents.length > 0) {
    return { seeded: false, message: "World already seeded" };
  }

  console.log("[Seeder] Seeding world...");

  // Create simulation state
  const state = await getSimulationState();
  if (!state) {
    await upsertSimulationState({
      tick: 0,
      worldDay: 1,
      worldHour: 8.0,
      paused: false,
      tickIntervalMs: 8000,
      lastTickAt: new Date(),
    });
  }

  // Create districts
  const createdDistricts: number[] = [];
  for (const district of DISTRICTS) {
    const result = await createDistrict(district as any);
    const insertId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId;
    createdDistricts.push(insertId);
  }

  // Re-fetch districts to get actual IDs
  const districts = await getAllDistricts();

  // Create agents
  for (const template of AGENT_TEMPLATES) {
    const district = districts[template.districtIdx];
    if (!district) continue;

    const personality = {
      openness: template.openness,
      conscientiousness: template.conscientiousness,
      extraversion: template.extraversion,
      agreeableness: template.agreeableness,
      neuroticism: template.neuroticism,
      traits: template.traits,
    };

    const result = await createAgent({
      name: template.name,
      avatarSeed: template.name.toLowerCase().replace(/\s+/g, "-"),
      age: template.age,
      gender: template.gender,
      job: template.job,
      jobDescription: `Works as a ${template.job} in ${district.name}`,
      districtId: district.id,
      personality,
      backstory: template.backstory,
      goals: template.goals,
      currentActivity: "idle",
      currentLocation: "home",
      isAlive: true,
    });

    const agentId = (result as any)?.[0]?.insertId ?? (result as any)?.insertId;
    if (!agentId) continue;

    // Initialize needs
    await upsertAgentNeeds(agentId, {
      hunger: 60 + Math.random() * 30,
      energy: 60 + Math.random() * 30,
      social: 40 + Math.random() * 40,
      fun: 40 + Math.random() * 40,
      hygiene: 70 + Math.random() * 25,
      comfort: 60 + Math.random() * 30,
    });

    // Initialize mood
    await upsertAgentMood(agentId, {
      mood: "content",
      moodScore: 65 + Math.random() * 20,
      dominantEmotion: "calm",
    });

    // Create initial task
    await createTask({
      agentId,
      title: `Start a new day as ${template.job}`,
      description: `Begin the daily routine in ${district.name}`,
      type: "personal",
      status: "in_progress",
      priority: 0.5,
      progress: 0.1,
      startTick: 0,
      completedTick: null,
      dueDay: 2,
      reward: {},
    });
  }

  // Update district populations
  const allAgents = await getAllAgents();
  for (const district of districts) {
    const count = allAgents.filter(a => a.districtId === district.id).length;
    await updateDistrictPopulation(district.id, count);
  }

  console.log(`[Seeder] World seeded: ${districts.length} districts, ${allAgents.length} agents`);
  return { seeded: true, message: `Created ${districts.length} districts and ${allAgents.length} agents` };
}
