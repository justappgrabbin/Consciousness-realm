import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { useState } from "react";

interface DistrictNodeProps {
  district: {
    id: number;
    name: string;
    theme: string;
    x: number;
    y: number;
    population: number;
    maxPopulation: number;
    resourceLevel: number;
    color: string;
    description?: string | null;
  };
  isSelected: boolean;
  onClick: () => void;
}

function DistrictNode({ district, isSelected, onClick }: DistrictNodeProps) {
  const fillPct = district.population / Math.max(1, district.maxPopulation);
  const resourceColor = district.resourceLevel > 0.7 ? "#10b981" : district.resourceLevel > 0.4 ? "#f59e0b" : "#ef4444";

  return (
    <g
      transform={`translate(${district.x}, ${district.y})`}
      onClick={onClick}
      className="cursor-pointer"
    >
      {/* Glow ring when selected */}
      {isSelected && (
        <circle r="28" fill="none" stroke={district.color} strokeWidth="2" opacity="0.4">
          <animate attributeName="r" values="26;32;26" dur="2s" repeatCount="indefinite" />
          <animate attributeName="opacity" values="0.4;0.1;0.4" dur="2s" repeatCount="indefinite" />
        </circle>
      )}

      {/* Outer ring */}
      <circle r="22" fill={`${district.color}20`} stroke={district.color} strokeWidth={isSelected ? "2" : "1.5"} />

      {/* Population fill */}
      <circle r="18" fill={`${district.color}${Math.round(fillPct * 60 + 20).toString(16).padStart(2, "0")}`} />

      {/* Theme icon */}
      <text textAnchor="middle" dominantBaseline="central" fontSize="14" y="-2">
        {getThemeEmoji(district.theme)}
      </text>

      {/* Population count */}
      <text textAnchor="middle" dominantBaseline="central" fontSize="8" y="9" fill="white" fontWeight="600" opacity="0.9">
        {district.population}
      </text>

      {/* Resource indicator */}
      <circle cx="16" cy="-16" r="5" fill={resourceColor} opacity="0.9" />

      {/* District name */}
      <text textAnchor="middle" y="32" fontSize="9" fill="white" opacity="0.85" fontWeight="500">
        {district.name.split(" ")[0]}
      </text>
    </g>
  );
}

function getThemeEmoji(theme: string): string {
  const map: Record<string, string> = {
    urban: "🏙️",
    academic: "📚",
    industrial: "⚙️",
    creative: "🎨",
    rural: "🌿",
  };
  return map[theme] ?? "🏘️";
}

// Connection lines between districts
function DistrictConnections({ districts }: { districts: Array<{ id: number; x: number; y: number; color: string }> }) {
  const connections: Array<[number, number]> = [
    [0, 4], [1, 4], [2, 4], [3, 4], // All connect to The Commons
    [0, 1], [2, 3], // Some cross-connections
  ];

  return (
    <>
      {connections.map(([a, b], i) => {
        const da = districts[a];
        const db = districts[b];
        if (!da || !db) return null;
        return (
          <line
            key={i}
            x1={da.x} y1={da.y}
            x2={db.x} y2={db.y}
            stroke="oklch(0.4 0.05 260)"
            strokeWidth="1"
            strokeDasharray="4 4"
            opacity="0.4"
          />
        );
      })}
    </>
  );
}

export default function WorldMap() {
  const [, navigate] = useLocation();
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const { data: districts = [], isLoading } = trpc.world.districts.useQuery();
  const { data: worldState } = trpc.world.state.useQuery();
  const { data: agents = [] } = trpc.agents.list.useQuery();

  const selectedDistrict = districts.find(d => d.id === selectedId);
  const districtAgents = agents.filter(a => a.districtId === selectedId);

  if (isLoading) {
    return (
      <div className="flex flex-col h-screen bg-background">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl mb-4 animate-pulse">🌍</div>
            <p className="text-muted-foreground text-sm">Loading world map...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-background pb-20">
      {/* Header */}
      <div className="px-4 pt-12 pb-3">
        <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          World Map
        </h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          {districts.length} districts · {agents.length} inhabitants
        </p>
      </div>

      {/* SVG Map */}
      <div className="flex-1 relative px-2">
        <div className="w-full h-full rounded-2xl border border-border/50 overflow-hidden"
          style={{ background: "radial-gradient(ellipse at 50% 50%, oklch(0.12 0.02 260), oklch(0.07 0.01 260))" }}>
          <svg
            viewBox="0 0 100 90"
            className="w-full h-full"
            style={{ maxHeight: "340px" }}
          >
            {/* Background stars */}
            {Array.from({ length: 30 }, (_, i) => (
              <circle
                key={i}
                cx={Math.sin(i * 2.3) * 50 + 50}
                cy={Math.cos(i * 1.7) * 45 + 45}
                r="0.3"
                fill="white"
                opacity={0.1 + (i % 5) * 0.05}
              />
            ))}

            {/* Connection lines */}
            <DistrictConnections districts={districts} />

            {/* District nodes */}
            {districts.map(d => (
              <DistrictNode
                key={d.id}
                district={d}
                isSelected={selectedId === d.id}
                onClick={() => setSelectedId(selectedId === d.id ? null : d.id)}
              />
            ))}
          </svg>
        </div>
      </div>

      {/* Legend */}
      <div className="px-4 py-2">
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-green-400" />
            <span>High resources</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-amber-400" />
            <span>Medium</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-red-400" />
            <span>Scarce</span>
          </div>
        </div>
      </div>

      {/* District Detail Panel */}
      {selectedDistrict && (
        <div className="mx-3 mb-2 rounded-2xl border border-border/60 p-4 slide-up"
          style={{ background: "oklch(0.13 0.015 260 / 0.95)" }}>
          <div className="flex items-start justify-between mb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg">{getThemeEmoji(selectedDistrict.theme)}</span>
                <h3 className="font-semibold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {selectedDistrict.name}
                </h3>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{selectedDistrict.description}</p>
            </div>
            <button
              onClick={() => setSelectedId(null)}
              className="text-muted-foreground hover:text-foreground p-1"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2 mb-3">
            <div className="rounded-xl p-2 text-center" style={{ background: "oklch(0.17 0.015 260)" }}>
              <div className="text-lg font-bold text-foreground">{selectedDistrict.population}</div>
              <div className="text-[10px] text-muted-foreground">Population</div>
            </div>
            <div className="rounded-xl p-2 text-center" style={{ background: "oklch(0.17 0.015 260)" }}>
              <div className="text-lg font-bold text-foreground">{Math.round(selectedDistrict.resourceLevel * 100)}%</div>
              <div className="text-[10px] text-muted-foreground">Resources</div>
            </div>
            <div className="rounded-xl p-2 text-center" style={{ background: "oklch(0.17 0.015 260)" }}>
              <div className="text-lg font-bold text-foreground capitalize">{selectedDistrict.theme}</div>
              <div className="text-[10px] text-muted-foreground">Theme</div>
            </div>
          </div>

          {/* Agents in district */}
          {districtAgents.length > 0 && (
            <div>
              <p className="text-xs text-muted-foreground mb-2">Residents</p>
              <div className="flex flex-wrap gap-1.5">
                {districtAgents.slice(0, 6).map(agent => (
                  <button
                    key={agent.id}
                    onClick={() => navigate(`/agents/${agent.id}`)}
                    className="text-xs px-2.5 py-1 rounded-full border border-border/60 text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors"
                    style={{ background: "oklch(0.17 0.015 260)" }}
                  >
                    {agent.name.split(" ")[0]}
                  </button>
                ))}
                {districtAgents.length > 6 && (
                  <span className="text-xs px-2.5 py-1 text-muted-foreground">+{districtAgents.length - 6} more</span>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
