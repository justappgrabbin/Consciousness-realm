import { FileCode, Hash, Layers, BookOpen } from "lucide-react";
import { Card } from "@/components/ui/card";

interface StatusCardsProps {
  filesProcessed: number;
  codeLinesAnalyzed: number;
  patternsUnified: number;
  booksReferenced: number;
}

export function StatusCards({
  filesProcessed,
  codeLinesAnalyzed,
  patternsUnified,
  booksReferenced,
}: StatusCardsProps) {
  const stats = [
    {
      label: "Files Processed",
      value: filesProcessed,
      icon: FileCode,
      color: "text-chart-1",
      bgColor: "bg-chart-1/10",
    },
    {
      label: "Code Lines Analyzed",
      value: codeLinesAnalyzed.toLocaleString(),
      icon: Hash,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
    },
    {
      label: "Patterns Unified",
      value: patternsUnified,
      icon: Layers,
      color: "text-chart-3",
      bgColor: "bg-chart-3/10",
    },
    {
      label: "Books Referenced",
      value: booksReferenced,
      icon: BookOpen,
      color: "text-chart-4",
      bgColor: "bg-chart-4/10",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat) => (
        <Card key={stat.label} className="p-6" data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
              <p className="text-3xl font-bold">{stat.value}</p>
            </div>
            <div className={`w-12 h-12 rounded-md ${stat.bgColor} flex items-center justify-center`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
