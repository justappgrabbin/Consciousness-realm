import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Sparkles, Target, Zap, Heart, CheckCircle2, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";

export default function Quests() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [intentionInput, setIntentionInput] = useState("");
  const [skillInput, setSkillInput] = useState("");
  const [commitmentInput, setCommitmentInput] = useState("");

  // Get quest progress
  const { data: questData, isLoading: questLoading } = trpc.quest.getProgress.useQuery(undefined, {
    enabled: isAuthenticated
  });

  // Submit mutations
  const intentionMutation = trpc.quest.submitIntention.useMutation({
    onSuccess: () => {
      setIntentionInput("");
    }
  });

  const skillMutation = trpc.quest.submitSkill.useMutation({
    onSuccess: () => {
      setSkillInput("");
    }
  });

  const commitmentMutation = trpc.quest.submitCommitment.useMutation({
    onSuccess: () => {
      setCommitmentInput("");
    }
  });

  if (authLoading || questLoading) {
    return (
      <div className="min-h-screen cosmic-bg flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen cosmic-bg flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full glass">
          <CardHeader className="text-center">
            <Target className="w-12 h-12 mx-auto mb-4 text-primary" />
            <CardTitle className="gradient-text text-2xl">Quest Progression</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center mb-6">
              Sign in to begin your quest progression
            </p>
            <Button 
              className="w-full glow-primary" 
              onClick={() => window.location.href = getLoginUrl()}
            >
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const stages = questData?.stages || {};
  const currentStage = questData?.currentStage || "intention";
  const progress = questData || {};

  return (
    <div className="min-h-screen cosmic-bg">
      {/* Navigation */}
      <nav className="border-b border-border/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <span className="font-bold gradient-text">YOU-N-I-VERSE</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link href="/companion">
              <Button variant="ghost" size="sm">
                <Zap className="w-4 h-4 mr-2" />
                Companion
              </Button>
            </Link>
            <Link href="/network">
              <Button variant="ghost" size="sm">
                <Target className="w-4 h-4 mr-2" />
                Network
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <Heart className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <main className="container py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold gradient-text mb-4">
              Quest Progression System
            </h1>
            <p className="text-muted-foreground text-lg">
              Three stages of alignment: Intention → Skill → Commitment
            </p>
          </div>

          {/* Progress Overview */}
          <Card className="glass mb-8">
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Quests Completed</span>
                  <span className="text-2xl font-bold">{progress.questsCompleted || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Total Resonance Generated</span>
                  <span className="text-2xl font-bold">{Math.round(progress.totalResonanceGenerated || 0)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Current Stage</span>
                  <span className="text-lg font-semibold capitalize">{currentStage}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quest Stages */}
          <div className="space-y-6">
            {/* Intention Quest */}
            <Card className={`glass ${progress.intentionCompletedAt ? 'border-success' : 'border-border/50'}`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {progress.intentionCompletedAt ? (
                      <CheckCircle2 className="w-6 h-6 text-success" />
                    ) : (
                      <Target className="w-6 h-6 text-primary" />
                    )}
                    <div>
                      <CardTitle>Stage 1: Intention Quest</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Declare your purpose and align it with your Incarnation Cross
                      </p>
                    </div>
                  </div>
                  {progress.intentionCompletedAt && (
                    <span className="text-sm font-medium text-success">Completed</span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {progress.intentionCompletedAt ? (
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-success/10 border border-success/20">
                      <p className="text-sm font-medium mb-1">Your Intention</p>
                      <p className="text-muted-foreground">{progress.intentionDeclared}</p>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Alignment Score</span>
                      <span className="font-bold">{progress.intentionAlignmentScore}%</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      What is your core intention? How does it align with your Heart Field (soul purpose)?
                    </p>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Declare your intention..."
                        value={intentionInput}
                        onChange={(e) => setIntentionInput(e.target.value)}
                        className="bg-input"
                        disabled={intentionMutation.isPending}
                      />
                      <Button
                        onClick={() => intentionMutation.mutate({ intention: intentionInput })}
                        disabled={!intentionInput.trim() || intentionMutation.isPending}
                        className="glow-primary"
                      >
                        {intentionMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>Submit <ArrowRight className="w-4 h-4 ml-2" /></>
                        )}
                      </Button>
                    </div>
                    {intentionMutation.error && (
                      <p className="text-destructive text-sm">{intentionMutation.error.message}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Skill Quest */}
            <Card className={`glass ${progress.skillCompletedAt ? 'border-success' : 'border-border/50'} ${
              currentStage !== "skill" && !progress.skillCompletedAt ? 'opacity-50' : ''
            }`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {progress.skillCompletedAt ? (
                      <CheckCircle2 className="w-6 h-6 text-success" />
                    ) : (
                      <Zap className="w-6 h-6 text-primary" />
                    )}
                    <div>
                      <CardTitle>Stage 2: Skill Quest</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Demonstrate your capability through your gate expression
                      </p>
                    </div>
                  </div>
                  {progress.skillCompletedAt && (
                    <span className="text-sm font-medium text-success">Completed</span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {progress.skillCompletedAt ? (
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-success/10 border border-success/20">
                      <p className="text-sm font-medium mb-1">Skill Demonstrated</p>
                      <p className="text-muted-foreground">{progress.skillDemonstrated}</p>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Gate Alignment</span>
                      <span className="font-bold">{progress.skillGateAlignment}%</span>
                    </div>
                  </div>
                ) : currentStage === "skill" ? (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      What skill or capability aligns with your Body Field (design)? Show how you express this gate.
                    </p>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Describe your skill..."
                        value={skillInput}
                        onChange={(e) => setSkillInput(e.target.value)}
                        className="bg-input"
                        disabled={skillMutation.isPending}
                      />
                      <Button
                        onClick={() => skillMutation.mutate({ skill: skillInput })}
                        disabled={!skillInput.trim() || skillMutation.isPending}
                        className="glow-primary"
                      >
                        {skillMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>Submit <ArrowRight className="w-4 h-4 ml-2" /></>
                        )}
                      </Button>
                    </div>
                    {skillMutation.error && (
                      <p className="text-destructive text-sm">{skillMutation.error.message}</p>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Complete the Intention Quest first to unlock this stage.
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Commitment Quest */}
            <Card className={`glass ${progress.commitmentCompletedAt ? 'border-success' : 'border-border/50'} ${
              currentStage !== "commitment" && !progress.commitmentCompletedAt ? 'opacity-50' : ''
            }`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {progress.commitmentCompletedAt ? (
                      <CheckCircle2 className="w-6 h-6 text-success" />
                    ) : (
                      <Heart className="w-6 h-6 text-primary" />
                    )}
                    <div>
                      <CardTitle>Stage 3: Commitment Quest</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Prove your strategy practice through consistent action
                      </p>
                    </div>
                  </div>
                  {progress.commitmentCompletedAt && (
                    <span className="text-sm font-medium text-success">Completed</span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {progress.commitmentCompletedAt ? (
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-success/10 border border-success/20">
                      <p className="text-sm font-medium mb-1">Commitment Proven</p>
                      <p className="text-muted-foreground">{progress.commitmentProof}</p>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Strategy Adherence</span>
                      <span className="font-bold">{progress.commitmentStrategyScore}%</span>
                    </div>
                  </div>
                ) : currentStage === "commitment" ? (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      How have you consistently practiced your strategy? Show your commitment through action.
                    </p>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Describe your consistent practice..."
                        value={commitmentInput}
                        onChange={(e) => setCommitmentInput(e.target.value)}
                        className="bg-input"
                        disabled={commitmentMutation.isPending}
                      />
                      <Button
                        onClick={() => commitmentMutation.mutate({ proof: commitmentInput })}
                        disabled={!commitmentInput.trim() || commitmentMutation.isPending}
                        className="glow-primary"
                      >
                        {commitmentMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>Submit <ArrowRight className="w-4 h-4 ml-2" /></>
                        )}
                      </Button>
                    </div>
                    {commitmentMutation.error && (
                      <p className="text-destructive text-sm">{commitmentMutation.error.message}</p>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Complete the Skill Quest first to unlock this stage.
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Resonance Info */}
          <Card className="glass mt-8">
            <CardHeader>
              <CardTitle className="text-sm">How Resonance Works</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground space-y-2">
              <p>
                Each quest stage generates resonance patterns that strengthen your position in the network. 
                These patterns are learned by your AI companion and contribute to the collective intelligence.
              </p>
              <p>
                Your alignment scores reflect how well your actions align with your trinity fields. 
                Higher alignment = stronger resonance = greater network influence.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
