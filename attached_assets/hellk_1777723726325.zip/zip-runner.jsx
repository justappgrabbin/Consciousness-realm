import React, { useState, useEffect } from 'react';
import { Settings, Check, FileText, Trash2, X, Upload, Sparkles, AlertCircle } from 'lucide-react';
import JSZip from 'jszip';

// ============= REAL ZIP PARSER =============

async function parseZipFile(file) {
  try {
    const zip = new JSZip();
    const contents = await zip.loadAsync(file);
    
    const files = {};
    const fileList = [];
    
    // Extract all files
    for (const [filename, zipEntry] of Object.entries(contents.files)) {
      if (!zipEntry.dir) {
        fileList.push(filename);
        
        // Get file content based on type
        if (filename.endsWith('.json')) {
          const text = await zipEntry.async('text');
          files[filename] = { type: 'json', content: JSON.parse(text) };
        } else if (filename.match(/\.(js|jsx|ts|tsx|html|css|md|txt)$/)) {
          const text = await zipEntry.async('text');
          files[filename] = { type: 'text', content: text };
        } else if (filename.match(/\.(png|jpg|jpeg|gif|svg)$/)) {
          const blob = await zipEntry.async('blob');
          const dataUrl = await blobToDataUrl(blob);
          files[filename] = { type: 'image', content: dataUrl };
        } else {
          const blob = await zipEntry.async('blob');
          files[filename] = { type: 'blob', content: blob };
        }
      }
    }
    
    return { files, fileList };
  } catch (error) {
    throw new Error(`Failed to parse ZIP: ${error.message}`);
  }
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// ============= COMPONENT EXECUTOR =============

function executeReactComponent(code, componentName = 'App') {
  try {
    // Create a safe execution context
    const componentCode = code
      .replace(/export\s+default\s+/g, 'return ')
      .replace(/export\s+/g, '');
    
    // Build the component factory
    const factory = new Function('React', 'useState', 'useEffect', 'useRef', componentCode);
    
    // Execute and get the component
    const Component = factory(React, useState, useEffect, React.useRef);
    
    return Component;
  } catch (error) {
    console.error('Component execution error:', error);
    throw new Error(`Failed to execute component: ${error.message}`);
  }
}

// ============= ZIP-BASED APPS =============

function ZipViewer({ files, fileList }) {
  const [selectedFile, setSelectedFile] = useState(null);
  
  return (
    <div className="grid grid-cols-3 gap-4 h-[500px]">
      {/* File list */}
      <div className="col-span-1 border-r pr-4 overflow-y-auto">
        <h3 className="font-semibold mb-3 text-gray-800">Files ({fileList.length})</h3>
        <div className="space-y-1">
          {fileList.map((filename) => (
            <button
              key={filename}
              onClick={() => setSelectedFile(filename)}
              className={`w-full text-left px-3 py-2 rounded text-sm transition-colors ${
                selectedFile === filename
                  ? 'bg-blue-100 text-blue-800'
                  : 'hover:bg-gray-100 text-gray-700'
              }`}
            >
              {filename}
            </button>
          ))}
        </div>
      </div>
      
      {/* File preview */}
      <div className="col-span-2 overflow-y-auto">
        {selectedFile ? (
          <div>
            <h3 className="font-semibold mb-3 text-gray-800">{selectedFile}</h3>
            <FilePreview file={files[selectedFile]} filename={selectedFile} />
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-400">
            Select a file to preview
          </div>
        )}
      </div>
    </div>
  );
}

function FilePreview({ file, filename }) {
  if (!file) return null;
  
  switch (file.type) {
    case 'text':
      return (
        <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-sm font-mono">
          {file.content}
        </pre>
      );
    
    case 'json':
      return (
        <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-sm font-mono">
          {JSON.stringify(file.content, null, 2)}
        </pre>
      );
    
    case 'image':
      return (
        <div className="flex justify-center">
          <img src={file.content} alt={filename} className="max-w-full rounded-lg shadow" />
        </div>
      );
    
    default:
      return (
        <div className="text-gray-500">
          Binary file ({file.type})
        </div>
      );
  }
}

function ReactAppRunner({ files, fileList }) {
  const [component, setComponent] = useState(null);
  const [error, setError] = useState(null);
  const [selectedEntry, setSelectedEntry] = useState('App.jsx');
  
  // Find React component files
  const reactFiles = fileList.filter(f => f.match(/\.(jsx|js)$/));
  
  useEffect(() => {
    tryLoadComponent(selectedEntry);
  }, [selectedEntry, files]);
  
  const tryLoadComponent = (filename) => {
    try {
      setError(null);
      const file = files[filename];
      
      if (!file || file.type !== 'text') {
        throw new Error('File not found or not a text file');
      }
      
      const Component = executeReactComponent(file.content);
      setComponent(() => Component);
    } catch (err) {
      setError(err.message);
      setComponent(null);
    }
  };
  
  return (
    <div className="space-y-4">
      {/* Component selector */}
      {reactFiles.length > 1 && (
        <div className="flex items-center gap-2">
          <label className="text-sm font-medium text-gray-700">Component:</label>
          <select
            value={selectedEntry}
            onChange={(e) => setSelectedEntry(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:border-blue-400"
          >
            {reactFiles.map(f => (
              <option key={f} value={f}>{f}</option>
            ))}
          </select>
        </div>
      )}
      
      {/* Component display */}
      {error ? (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-red-800 mb-1">Failed to load component</h4>
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      ) : component ? (
        <div className="border-2 border-blue-200 rounded-lg p-6 bg-blue-50">
          <React.Suspense fallback={<div>Loading component...</div>}>
            {React.createElement(component)}
          </React.Suspense>
        </div>
      ) : (
        <div className="text-gray-500 text-center py-8">
          No component loaded
        </div>
      )}
    </div>
  );
}

// ============= MAIN APP =============

export default function ZipRunnerApp() {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [zipData, setZipData] = useState(null);
  const [error, setError] = useState(null);
  const [viewMode, setViewMode] = useState('viewer'); // 'viewer' or 'runner'
  
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };
  
  const handleDrop = async (e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      await processZipFile(files[0]);
    }
  };
  
  const handleFileInput = async (e) => {
    const files = e.target.files;
    if (files.length > 0) {
      await processZipFile(files[0]);
    }
    e.target.value = '';
  };
  
  const processZipFile = async (file) => {
    if (!file.name.endsWith('.zip')) {
      setError('Please upload a .zip file');
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    
    try {
      const result = await parseZipFile(file);
      setZipData({
        filename: file.name,
        ...result
      });
      
      // Auto-detect if there are React components
      const hasReactComponents = result.fileList.some(f => 
        f.match(/\.(jsx|js)$/) && result.files[f]?.content?.includes('React')
      );
      
      if (hasReactComponents) {
        setViewMode('runner');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };
  
  const resetApp = () => {
    setZipData(null);
    setError(null);
    setViewMode('viewer');
  };
  
  if (zipData) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="w-full max-w-6xl bg-white shadow-2xl rounded-lg overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 border-b border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Check className="w-6 h-6 text-green-600" />
                <div>
                  <h2 className="font-semibold text-gray-800">ZIP Extracted</h2>
                  <p className="text-sm text-gray-600">{zipData.filename} - {zipData.fileList.length} files</p>
                </div>
              </div>
              <button
                onClick={resetApp}
                className="px-4 py-2 text-sm bg-white hover:bg-gray-50 text-gray-700 rounded border border-gray-300 transition-colors"
              >
                Upload New ZIP
              </button>
            </div>
            
            {/* Mode selector */}
            <div className="flex gap-2">
              <button
                onClick={() => setViewMode('viewer')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'viewer'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                📁 File Viewer
              </button>
              <button
                onClick={() => setViewMode('runner')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'runner'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                ⚛️ React Runner
              </button>
            </div>
          </div>
          
          {/* Content */}
          <div className="p-6">
            {viewMode === 'viewer' ? (
              <ZipViewer files={zipData.files} fileList={zipData.fileList} />
            ) : (
              <ReactAppRunner files={zipData.files} fileList={zipData.fileList} />
            )}
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full mb-4">
            <Upload className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            ZIP Parser & Runner
          </h1>
          <p className="text-gray-600">
            Upload a ZIP file to extract and run React components
          </p>
        </div>
        
        {/* Drop zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`border-4 border-dashed rounded-2xl p-16 text-center transition-all ${
            isDragging
              ? 'border-blue-500 bg-blue-50 scale-105'
              : 'border-gray-300 bg-white hover:border-gray-400'
          }`}
        >
          <input
            type="file"
            accept=".zip"
            onChange={handleFileInput}
            className="hidden"
            id="file-upload"
            disabled={isProcessing}
          />
          <label htmlFor="file-upload" className="cursor-pointer">
            <div className="flex flex-col items-center gap-4">
              {isProcessing ? (
                <>
                  <Sparkles className="w-16 h-16 text-blue-600 animate-pulse" />
                  <p className="text-xl font-semibold text-gray-800">Processing ZIP...</p>
                </>
              ) : (
                <>
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center">
                    <Upload className="w-12 h-12 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-xl font-semibold text-gray-800 mb-2">
                      Drop your ZIP file here
                    </p>
                    <p className="text-gray-600">
                      or <span className="text-blue-600 underline">click to browse</span>
                    </p>
                  </div>
                </>
              )}
            </div>
          </label>
        </div>
        
        {/* Error message */}
        {error && (
          <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-red-800 mb-1">Error</h4>
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}
        
        {/* Instructions */}
        <div className="mt-8 bg-white rounded-xl p-6 shadow-lg">
          <h3 className="font-semibold text-gray-800 mb-3">What this does:</h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">•</span>
              <span><strong>Extracts</strong> all files from the ZIP archive</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">•</span>
              <span><strong>Previews</strong> text, JSON, and image files</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">•</span>
              <span><strong>Executes</strong> React components (.jsx/.js files)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-600 font-bold">•</span>
              <span><strong>Runs</strong> the components live in the browser</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
