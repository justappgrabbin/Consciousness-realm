import { useState } from "react";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileCode, ChevronRight, ChevronDown, Download, Sparkles } from "lucide-react";
import type { GeneratedCode, CodeGap } from "@shared/schema";

interface CodeViewerProps {
  generatedFiles: GeneratedCode[];
  codeGaps: CodeGap[];
  onDownload: () => void;
  onFillGaps?: (projectId: string) => void;
  projectId?: string;
}

export function CodeViewer({ generatedFiles, codeGaps, onDownload, onFillGaps, projectId }: CodeViewerProps) {
  const [selectedFile, setSelectedFile] = useState<GeneratedCode | null>(
    generatedFiles.length > 0 ? generatedFiles[0] : null
  );
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['/']));

  const toggleFolder = (path: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedFolders(newExpanded);
  };

  const fileTree = generatedFiles.reduce((tree, file) => {
    const parts = file.filePath.split('/').filter(Boolean);
    let current = tree;
    
    parts.forEach((part, index) => {
      if (!current[part]) {
        current[part] = index === parts.length - 1 ? file : {};
      }
      if (index < parts.length - 1) {
        current = current[part] as Record<string, any>;
      }
    });
    
    return tree;
  }, {} as Record<string, any>);

  const renderTree = (node: Record<string, any>, path = '', level = 0) => {
    return Object.entries(node).map(([key, value]) => {
      const currentPath = `${path}/${key}`;
      const isFile = value && typeof value === 'object' && 'content' in value;
      const isExpanded = expandedFolders.has(currentPath);

      if (isFile) {
        const file = value as GeneratedCode;
        return (
          <div
            key={currentPath}
            className={`flex items-center gap-2 py-2 px-3 cursor-pointer rounded-md hover-elevate ${
              selectedFile?.id === file.id ? 'bg-accent' : ''
            }`}
            style={{ paddingLeft: `${level * 12 + 12}px` }}
            onClick={() => setSelectedFile(file)}
            data-testid={`file-${file.filePath}`}
          >
            <FileCode className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <span className="text-sm font-mono truncate">{key}</span>
            {file.hasGaps && (
              <Badge variant="secondary" className="ml-auto">
                <Sparkles className="w-3 h-3" />
              </Badge>
            )}
          </div>
        );
      }

      return (
        <div key={currentPath}>
          <div
            className="flex items-center gap-2 py-2 px-3 cursor-pointer rounded-md hover-elevate"
            style={{ paddingLeft: `${level * 12 + 12}px` }}
            onClick={() => toggleFolder(currentPath)}
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            )}
            <span className="text-sm font-medium">{key}</span>
          </div>
          {isExpanded && renderTree(value, currentPath, level + 1)}
        </div>
      );
    });
  };

  const hasGaps = codeGaps.length > 0 || generatedFiles.some(f => f.hasGaps);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="p-4 lg:col-span-1">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">Files</h3>
          <Badge variant="secondary">{generatedFiles.length}</Badge>
        </div>
        
        <ScrollArea className="h-[600px]">
          {generatedFiles.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <FileCode className="w-12 h-12 mx-auto mb-3" />
              <p className="text-sm">No files generated yet</p>
            </div>
          ) : (
            <div className="space-y-1">{renderTree(fileTree)}</div>
          )}
        </ScrollArea>
      </Card>

      <Card className="p-6 lg:col-span-2">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold font-mono text-sm">
            {selectedFile?.filePath || 'Select a file'}
          </h3>
          <div className="flex gap-2">
            {hasGaps && onFillGaps && projectId && (
              <Button onClick={() => onFillGaps(projectId)} variant="outline" size="sm" data-testid="button-fill-gaps">
                <Sparkles className="w-4 h-4 mr-2" />
                Fill Gaps
              </Button>
            )}
            <Button onClick={onDownload} size="sm" data-testid="button-download">
              <Download className="w-4 h-4 mr-2" />
              Download All
            </Button>
          </div>
        </div>

        <ScrollArea className="h-[600px]">
          {selectedFile ? (
            <div className="space-y-4">
              {selectedFile.hasGaps && codeGaps.filter(g => g.filePath === selectedFile.filePath).length > 0 && (
                <Card className="p-4 bg-amber-500/10 border-amber-500/20">
                  <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    Code Gaps Detected
                  </h4>
                  <div className="space-y-2 text-sm">
                    {codeGaps
                      .filter(g => g.filePath === selectedFile.filePath)
                      .map((gap, index) => (
                        <div key={index} className="text-muted-foreground">
                          Line {gap.lineNumber}: {gap.description}
                        </div>
                      ))}
                  </div>
                </Card>
              )}
              
              <pre className="bg-muted p-4 rounded-md overflow-x-auto">
                <code className="text-sm font-mono">{selectedFile.content}</code>
              </pre>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <p>Select a file to view its contents</p>
            </div>
          )}
        </ScrollArea>
      </Card>
    </div>
  );
}
