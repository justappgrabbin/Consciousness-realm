import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  json,
  boolean,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Projects ─────────────────────────────────────────────────────────────────
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  intent: text("intent"),
  status: mysqlEnum("status", [
    "draft",
    "analyzing",
    "generating",
    "complete",
    "error",
    "archived",
  ])
    .default("draft")
    .notNull(),
  architecturePlan: json("architecturePlan"),
  techStack: json("techStack"),
  tags: json("tags"),
  pipelineStage: mysqlEnum("pipelineStage", [
    "ingest",
    "analyze",
    "generate",
    "preview",
    "deploy",
  ])
    .default("ingest")
    .notNull(),
  lastGeneratedAt: timestamp("lastGeneratedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

// ─── Project Inputs ───────────────────────────────────────────────────────────
export const projectInputs = mysqlTable("project_inputs", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  inputType: mysqlEnum("inputType", ["file", "code_snippet", "intent", "url", "document"]).notNull(),
  filename: varchar("filename", { length: 512 }),
  mimeType: varchar("mimeType", { length: 128 }),
  content: text("content"),
  s3Key: varchar("s3Key", { length: 1024 }),
  s3Url: text("s3Url"),
  fileSize: bigint("fileSize", { mode: "number" }),
  language: varchar("language", { length: 64 }),
  analysisResult: json("analysisResult"),
  embeddingStatus: mysqlEnum("embeddingStatus", ["pending", "processing", "done", "failed"])
    .default("pending")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProjectInput = typeof projectInputs.$inferSelect;
export type InsertProjectInput = typeof projectInputs.$inferInsert;

// ─── Code Artifacts ───────────────────────────────────────────────────────────
export const codeArtifacts = mysqlTable("code_artifacts", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  artifactType: mysqlEnum("artifactType", [
    "generated_app",
    "architecture_plan",
    "component",
    "api_spec",
    "schema",
    "config",
    "recipe",
    "monetization_plan",
  ]).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  content: text("content"),
  s3Key: varchar("s3Key", { length: 1024 }),
  s3Url: text("s3Url"),
  fileTree: json("fileTree"),
  metadata: json("metadata"),
  version: int("version").default(1).notNull(),
  isLatest: boolean("isLatest").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CodeArtifact = typeof codeArtifacts.$inferSelect;
export type InsertCodeArtifact = typeof codeArtifacts.$inferInsert;

// ─── Project Messages (Karen Chat) ────────────────────────────────────────────
export const projectMessages = mysqlTable("project_messages", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "karen", "system"]).notNull(),
  content: text("content").notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProjectMessage = typeof projectMessages.$inferSelect;
export type InsertProjectMessage = typeof projectMessages.$inferInsert;

// ─── Background Jobs ──────────────────────────────────────────────────────────
export const backgroundJobs = mysqlTable("background_jobs", {
  id: int("id").autoincrement().primaryKey(),
  jobType: mysqlEnum("jobType", [
    "analyze_input",
    "refine_embeddings",
    "detect_gaps",
    "discover_relationships",
    "queue_improvements",
    "generate_recipe",
    "process_document",
  ]).notNull(),
  projectId: int("projectId"),
  inputId: int("inputId"),
  userId: int("userId"),
  status: mysqlEnum("status", ["queued", "running", "done", "failed", "skipped"])
    .default("queued")
    .notNull(),
  payload: json("payload"),
  result: json("result"),
  errorMessage: text("errorMessage"),
  attempts: int("attempts").default(0).notNull(),
  scheduledAt: timestamp("scheduledAt").defaultNow().notNull(),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BackgroundJob = typeof backgroundJobs.$inferSelect;
export type InsertBackgroundJob = typeof backgroundJobs.$inferInsert;

// ─── Recipes ──────────────────────────────────────────────────────────────────
export const recipes = mysqlTable("recipes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 128 }),
  pattern: json("pattern").notNull(),
  techStack: json("techStack"),
  sourceProjectId: int("sourceProjectId"),
  usageCount: int("usageCount").default(0).notNull(),
  isPublic: boolean("isPublic").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = typeof recipes.$inferInsert;

// ─── Monetization Plans ───────────────────────────────────────────────────────
export const monetizationPlans = mysqlTable("monetization_plans", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  pricingModel: mysqlEnum("pricingModel", [
    "freemium",
    "subscription",
    "one_time",
    "usage_based",
    "marketplace",
    "enterprise",
    "open_source_plus",
  ]).notNull(),
  suggestions: json("suggestions").notNull(),
  revenueArchitecture: json("revenueArchitecture"),
  targetMarket: text("targetMarket"),
  estimatedMRR: varchar("estimatedMRR", { length: 128 }),
  competitorAnalysis: json("competitorAnalysis"),
  launchStrategy: text("launchStrategy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MonetizationPlan = typeof monetizationPlans.$inferSelect;
export type InsertMonetizationPlan = typeof monetizationPlans.$inferInsert;

// ─── Improvement Suggestions ──────────────────────────────────────────────────
export const improvementSuggestions = mysqlTable("improvement_suggestions", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  userId: int("userId").notNull(),
  suggestionType: mysqlEnum("suggestionType", [
    "architecture",
    "performance",
    "security",
    "scalability",
    "monetization",
    "ux",
    "missing_feature",
    "cross_project",
  ]).notNull(),
  title: varchar("title", { length: 512 }).notNull(),
  description: text("description").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "dismissed", "applied"])
    .default("pending")
    .notNull(),
  sourceJobId: int("sourceJobId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ImprovementSuggestion = typeof improvementSuggestions.$inferSelect;
export type InsertImprovementSuggestion = typeof improvementSuggestions.$inferInsert;
